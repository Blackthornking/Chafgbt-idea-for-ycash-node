//! YORTAL v0.30.4 "CHANGED PIPELINE" bounded parallel block pipeline.
//!
//! v0.30.4: Sapling Groth16 proofs are batch-verified per range
//! (`ycash_consensus::ProofBatch`), and the committer no longer re-verifies
//! proofs the verify stage already checked.
//!
//! v0.29.2: header reads use a separate read-only SQLite connection, so
//! fetchers no longer stall while the committer writes.
//!
//! v0.29.1 adds Zebra-style batching on top of v0.29.0: header batches are
//! validated against an in-memory window and written in one transaction
//! (main.rs), the head-of-line range is hedged to a second peer when it
//! stalls, and the committer lingers briefly to build bigger commit batches.
//!
//! Same staged shape as Zebra's sync, built on the existing Ycash consensus
//! code. NO consensus rule is added, removed or reordered -- only *where* and
//! *when* each existing check runs changes.
//!
//! ```text
//!  up to 12 peers            N verifier threads          1 committer thread
//!  ┌───────────────┐  jobs   ┌──────────────────┐ ranges ┌─────────────────────┐
//!  │ claim range   │ ──────► │ validate_for_    │ ─────► │ reorder buffer      │
//!  │ getdata ≤16   │ bounded │ commit_opts()    │        │ contiguous ranges → │
//!  │ hash-match    │ channel │ (Equihash-free:  │        │ ONE commit_blocks_  │
//!  │ load ctx      │         │  merkle, Sapling │        │ batch() of ≤256 blk │
//!  └───────────────┘         │  proofs, sigs)   │        │ (UTXO/nullifier/    │
//!        ▲                   └──────────────────┘        │  anchor/value, in   │
//!        └──── backpressure: channel full = peers wait   │  strict height order│
//!                                                        └─────────────────────┘
//! ```
//!
//! Stage 1 (network): each connected peer claims a disjoint ≤16-block range
//! (ycashd's MAX_BLOCKS_IN_TRANSIT_PER_PEER), downloads it, matches each block
//! to our PoW-verified header by hash, and loads everything a verifier needs
//! (median-time-past, chain work, prev hash) in three range queries. It does
//! no validation, so the socket goes straight back to fetching.
//!
//! Stage 2 (verify): contextless checks are independent per block, so they run
//! on every core. Verifier threads never touch SQLite, so they never wait on a
//! commit.
//!
//! Stage 3 (commit): exactly one thread applies blocks, strictly in height
//! order, coalescing contiguous validated ranges into larger batches -- far
//! fewer SQLite transactions than one per 16-block range. All stateful rules
//! still run inside `State::commit_blocks_batch`, unchanged.
//!
//! Tunables (env): YORTAL_VERIFY_THREADS, YORTAL_LOOKAHEAD, YORTAL_COMMIT_BATCH. Defaults are deliberately bounded at 256 lookahead and 16-block commits.

use std::collections::{BTreeMap, HashMap, HashSet};
use std::io::ErrorKind;
use std::net::TcpStream;
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::mpsc::{sync_channel, Receiver, SyncSender};
use std::sync::{Arc, Condvar, Mutex};
use std::time::{Duration, Instant};

use ycash_chain::{genesis_hash_internal, txid};
use ycash_consensus::{validate_for_commit_batched_with_parsed, Context, ProofBatch, GENESIS_TIME, UNSUPPORTED_PREFIX};
use ycash_network::runtime::{getdata_payload, unix_time};
use ycash_state::pipeline::{range_scheduler::RangeLease, AdaptiveConfig, PipelineEngine};
use ycash_state::{BlockCommit, State};
use ycash_state::pipeline::ResourceSample;

use crate::runtime::{RollingCommitSample, SharedState};
use crate::{is_timeout, read_message, send};

/// Optional assume-valid checkpoint. Full consensus verification is the
/// default; this checkpoint is used only when YCASH_ASSUME_VALID=1 and the
/// verified header at the checkpoint height matches. YCASH_FULL_VERIFY=1
/// explicitly forces full verification as well.
pub const ASSUME_VALID_HEIGHT: u64 = 2_250_000;
pub const ASSUME_VALID_HASH_DISPLAY: &str = "000003f98b7497fdcd8a6b6d10a93a887c5d47127e24a9dc3a40cb65754d21e7";

/// Heights planned per `ensure_planned` call (split into ≤16-block ranges).
const PLAN_WINDOW: usize = 16;

/// Zebra-style hedged request: if the range blocking `next_commit` has been
/// leased this long while later ranges already wait in the commit buffer,
/// hand it to a second peer too. First valid copy wins; the other is dropped.
const HEDGE_AFTER: Duration = Duration::from_secs(20);

/// Commit linger: once blocks are ready, wait up to this long for more
/// contiguous ranges so each SQLite transaction carries a bigger batch.
const COMMIT_LINGER: Duration = Duration::from_millis(300);

/// Consecutive 1-second read timeouts tolerated mid-range before dropping a peer.
const IDLE_READS_BEFORE_DROP: u32 = 30;

fn env_usize(name: &str) -> Option<usize> {
    std::env::var(name).ok().and_then(|v| v.trim().parse::<usize>().ok())
}

/// Maximum verifier pool size. The pool is fixed once at startup to avoid
/// thread churn; the adaptive controller separately decides how many workers
/// may actively consume jobs at any moment.
pub fn verify_threads() -> usize {
    let detected = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1);
    let default_workers = detected.saturating_sub(1).clamp(1, 4);
    env_usize("YORTAL_VERIFY_THREADS").unwrap_or(default_workers).clamp(1, 32)
}

/// Adaptive lookahead ceiling. The controller starts conservatively and grows
/// only when CPU, memory, DB and validation pressure stay below the low
/// watermark. Individual network ranges remain capped at 16 blocks.
fn lookahead() -> u64 {
    env_usize("YORTAL_LOOKAHEAD").unwrap_or(128).clamp(16, 1024) as u64
}

/// Max blocks folded into one SQLite transaction by the committer.
fn commit_batch_blocks() -> usize {
    env_usize("YORTAL_COMMIT_BATCH").unwrap_or(16).clamp(16, 512)
}

/// Cached once positive: the checkpoint header never changes after it matches,
/// so later ranges skip the lookup.
static ASSUME_VALID_CONFIRMED: AtomicBool = AtomicBool::new(false);

fn assume_valid_active(state: &State) -> bool {
    if std::env::var("YCASH_FULL_VERIFY").ok().as_deref() == Some("1") { return false; }
    if ASSUME_VALID_CONFIRMED.load(Ordering::Relaxed) { return true; }
    let ok = assume_valid_check(state);
    if ok { ASSUME_VALID_CONFIRMED.store(true, Ordering::Relaxed); }
    ok
}

fn assume_valid_check(state: &State) -> bool {
    if ASSUME_VALID_HEIGHT == 0 || ASSUME_VALID_HASH_DISPLAY.len() != 64 { return false; }
    let Ok(bytes) = hex::decode(ASSUME_VALID_HASH_DISPLAY) else { return false };
    let mut internal = [0u8; 32];
    for i in 0..32 { internal[i] = bytes[31 - i]; }
    matches!(state.header_hash_by_height(ASSUME_VALID_HEIGHT), Ok(Some(v)) if v.as_slice() == internal)
}

/// Error kind used for "this node can't validate this block yet". Not the
/// peer's fault: don't release/retry the range and don't drop the connection.
pub fn is_node_unsupported(e: &std::io::Error) -> bool {
    e.kind() == ErrorKind::Unsupported
}

fn pipeline_log(stage: &str, detail: impl std::fmt::Display) {
    eprintln!("[PIPELINE] stage={} {}", stage, detail);
}

/// A downloaded, hash-matched range plus every piece of context the verifier
/// needs, so verifier threads are pure CPU.
struct VerifyJob {
    lease: RangeLease,
    peer: String,
    /// (height, expected hash, median-time-past, chain work, raw block), ascending.
    blocks: Vec<(u64, [u8; 32], u32, [u8; 32], Vec<u8>)>,
    prev_of_start: [u8; 32],
    assume_valid_ok: bool,
    bytes: u64,
}

type Buffered = (RangeLease, Vec<BlockCommit>, u64);

struct Inner {
    engine: PipelineEngine,
    next_commit: u64,
    buffered: BTreeMap<u64, Buffered>,
    planned_up_to: u64,
    halted: Option<String>,
    /// Peers that served a block failing contextless validation. Their session
    /// is closed on the next claim attempt (previously the error dropped the
    /// connection directly; the verifier runs off the peer thread now).
    misbehaving: HashSet<String>,
    /// Ranges sitting in the verify channel or being verified.
    verifying: u64,
    /// Start heights of ranges already downloaded and in verification
    /// (never hedged -- their bytes are here, they're just queued).
    verifying_starts: HashSet<u64>,
    /// Inclusive end of the batch the committer is writing right now
    /// (0 = none). Late duplicates at or below it are dropped.
    committing_upto: u64,
    hedged_ranges: u64,
    duplicate_ranges: u64,
}

#[derive(Clone)]
pub struct BlockPipeline {
    inner: Arc<Mutex<Inner>>,
    commit_cv: Arc<Condvar>,
    jobs: Arc<Mutex<Option<SyncSender<VerifyJob>>>>,
    started: Arc<AtomicBool>,
    verified_blocks: Arc<AtomicU64>,
    active_workers: Arc<AtomicUsize>,
}

impl BlockPipeline {
    /// `next_commit` should be the current validated block tip + 1.
    pub fn new(next_commit: u64) -> Self {
        pipeline_log("INIT", format_args!(
            "mode=SEQUENTIAL_FULL_VERIFY next_commit={} verify_threads={} lookahead={} commit_batch={} assume_valid_height={} full_verify={}",
            next_commit, verify_threads(), lookahead(), commit_batch_blocks(), ASSUME_VALID_HEIGHT,
            std::env::var("YCASH_ASSUME_VALID").ok().as_deref() != Some("1")
        ));
        Self {
            inner: Arc::new(Mutex::new(Inner {
                engine: PipelineEngine::new(AdaptiveConfig {
                    min_window: 16,
                    initial_window: 32,
                    max_window: 128,
                    step: 16,
                    high_watermark: 0.85,
                    low_watermark: 0.50,
                    max_validation_workers: verify_threads(),
                    max_inflight_ranges: 8,
                }),
                next_commit,
                buffered: BTreeMap::new(),
                planned_up_to: next_commit.saturating_sub(1),
                halted: None,
                misbehaving: HashSet::new(),
                verifying: 0,
                verifying_starts: HashSet::new(),
                committing_upto: 0,
                hedged_ranges: 0,
                duplicate_ranges: 0,
            })),
            commit_cv: Arc::new(Condvar::new()),
            jobs: Arc::new(Mutex::new(None)),
            started: Arc::new(AtomicBool::new(false)),
            verified_blocks: Arc::new(AtomicU64::new(0)),
            active_workers: Arc::new(AtomicUsize::new(verify_threads())),
        }
    }

    /// Spawn the verifier pool and the ordered committer. Idempotent.
    pub fn start(&self, state: Arc<State>, live: SharedState) {
        if self.started.swap(true, Ordering::SeqCst) { return; }
        let n = verify_threads();
        // Bounded: when verifiers fall behind, peer threads block on send
        // instead of piling raw blocks into RAM.
        let (tx, rx) = sync_channel::<VerifyJob>(n * 2);
        *self.jobs.lock().unwrap() = Some(tx);
        let rx = Arc::new(Mutex::new(rx));
        for i in 0..n {
            let me = self.clone();
            let rx = rx.clone();
            let live = live.clone();
            std::thread::Builder::new()
                .name(format!("yortal-verify-{i}"))
                .spawn(move || me.verifier_loop(i, rx, live))
                .expect("spawn verifier");
        }
        let me = self.clone();
        std::thread::Builder::new()
            .name("yortal-commit".into())
            .spawn(move || me.committer_loop(state, live))
            .expect("spawn committer");
        pipeline_log("START", format_args!("verifier_threads={} committer=1", n));
    }

    /// Make sure claimable ranges exist up to `chain_tip`. Cheap to call often.
    pub fn ensure_planned(&self, chain_tip: u64, workers: usize) {
        let mut g = self.inner.lock().unwrap();
        let next_commit = g.next_commit;
        g.engine.requeue_if_quarantined_at(next_commit);
        // Hedge the head-of-line range when it is what's holding everyone up.
        // Hedge fast when later ranges are waiting on it; slower otherwise (it
        // also recovers a range whose only copy failed verification after its
        // hedged twin was already dropped as a duplicate).
        if !g.verifying_starts.contains(&next_commit) {
            let after = if g.buffered.is_empty() { HEDGE_AFTER * 4 } else { HEDGE_AFTER };
            if let Some(id) = g.engine.range_ids_at_start(next_commit) {
                if g.engine.requeue_if_lease_stalled(id, after) {
                    g.hedged_ranges += 1;
                    pipeline_log("HEDGE", format_args!(
                        "range_start={} re-offered to another peer after {}s (buffered_ranges={})",
                        next_commit, after.as_secs(), g.buffered.len()
                    ));
                }
            }
        }
        if chain_tip <= g.planned_up_to { return; }
        // Backpressure: never plan further than `lookahead` past the commit tip.
        if g.planned_up_to.saturating_sub(g.next_commit).saturating_add(1) >= lookahead() {
            return;
        }
        let next = g.next_commit.max(g.planned_up_to.saturating_add(1));
        if next > chain_tip { return; }
        let active_workers = g.engine.max_validation_workers();
        let ids = g.engine.plan_parallel_ranges(next, chain_tip, active_workers.max(workers.max(1)));
        let window = g.engine.window();
        // Advance only across ranges that really entered the scheduler. When
        // the adaptive in-flight budget is full, the remaining heights must be
        // planned later rather than being skipped by planned_up_to.
        if let Some(end) = ids.iter().filter_map(|id| g.engine.range_end(*id)).max() {
            g.planned_up_to = g.planned_up_to.max(end).min(chain_tip);
        }
        pipeline_log("PLAN", format_args!(
            "next={} planned_up_to={} ranges={} chain_tip={} next_commit={} in_flight={}",
            next, g.planned_up_to, ids.len(), chain_tip, g.next_commit, g.engine.outstanding_heights()
        ));
    }

    /// Claim one range for this peer, download it, and hand it to the verifier
    /// pool. Returns `Ok(true)` if a range was fetched, `Ok(false)` if nothing
    /// was claimable. An `Err` means the session should close.
    pub fn run_once(
        &self,
        stream: &mut TcpStream,
        state: &Arc<State>,
        live: &SharedState,
        peer_label: &str,
        peer_height: Option<u64>,
    ) -> std::io::Result<bool> {
        let max_end = peer_height.unwrap_or(u64::MAX);
        let lease = {
            let mut g = self.inner.lock().unwrap();
            if g.misbehaving.remove(peer_label) {
                return Err(ioe("peer served a block that failed validation; disconnecting"));
            }
            if let Some(reason) = g.halted.clone() {
                drop(g);
                live.write().unwrap().message = reason;
                return Ok(false);
            }
            g.engine.claim_upto(peer_label, max_end)
        };
        let Some(lease) = lease else { return Ok(false) };

        match fetch_range(stream, state, &lease) {
            Ok(mut job) => {
                job.peer = peer_label.to_string();
                let sender = self.jobs.lock().unwrap().clone();
                let Some(sender) = sender else {
                    // Pool not started: give the range back rather than lose it.
                    let mut g = self.inner.lock().unwrap();
                    if g.engine.is_current_lease(lease.id, lease.generation) { g.engine.requeue_lease(lease.id); }
                    return Ok(false);
                };
                {
                    let mut g = self.inner.lock().unwrap();
                    // A hedged twin already delivered this range: skip the work.
                    let st = lease.range.start;
                    if st < g.next_commit
                        || (g.committing_upto != 0 && st <= g.committing_upto)
                        || g.buffered.contains_key(&st)
                        || g.verifying_starts.contains(&st)
                        || g.engine.range_ids_at_start(st).is_none()
                    {
                        g.duplicate_ranges += 1;
                        return Ok(true);
                    }
                    g.verifying += 1;
                    g.verifying_starts.insert(lease.range.start);
                }
                if sender.send(job).is_err() {
                    let mut g = self.inner.lock().unwrap();
                    g.verifying = g.verifying.saturating_sub(1);
                    g.verifying_starts.remove(&lease.range.start);
                    if g.engine.is_current_lease(lease.id, lease.generation) { g.engine.requeue_lease(lease.id); }
                    return Ok(false);
                }
                self.publish(live, None);
                Ok(true)
            }
            Err(e) => {
                pipeline_log("RANGE_ERROR", format_args!(
                    "peer={} range={}..{} kind={:?} error={}",
                    peer_label, lease.range.start, lease.range.end, e.kind(), e
                ));
                {
                    let mut g = self.inner.lock().unwrap();
                    // Only count the failure against the lease we still own;
                    // a hedge may have handed the range to another peer.
                    g.engine.release_if_current(lease.id, lease.generation);
                    let nc = g.next_commit;
                    g.engine.requeue_if_quarantined_at(nc);
                }
                self.publish(live, None);
                Err(e)
            }
        }
    }

    fn verifier_loop(&self, worker_id: usize, rx: Arc<Mutex<Receiver<VerifyJob>>>, live: SharedState) {
        loop {
            // The pool is fixed-size, but the adaptive controller can lower the
            // active worker budget under pressure. Inactive workers sleep rather
            // than competing for the bounded queue, so reducing concurrency also
            // reduces CPU pressure rather than merely moving it elsewhere.
            while worker_id >= self.active_workers.load(Ordering::Acquire) {
                std::thread::sleep(Duration::from_millis(25));
            }
            let job = { let r = rx.lock().unwrap(); r.recv() };
            let Ok(job) = job else { return };
            let (start, end) = (job.lease.range.start, job.lease.range.end);
            let peer = job.peer.clone();
            let started = Instant::now();
            let result = verify_job(job);
            let mut g = self.inner.lock().unwrap();
            g.verifying = g.verifying.saturating_sub(1);
            g.verifying_starts.remove(&start);
            match result {
                Ok((_, _, _)) if start < g.next_commit
                    || (g.committing_upto != 0 && start <= g.committing_upto)
                    || g.buffered.contains_key(&start)
                    || g.engine.range_ids_at_start(start).is_none() => {
                    g.duplicate_ranges += 1;
                    pipeline_log("DUPLICATE", format_args!("range={}..{} dropped (hedged twin already delivered)", start, end));
                }
                Ok((lease, commits, bytes)) => {
                    self.verified_blocks.fetch_add(commits.len() as u64, Ordering::Relaxed);
                    let validation_ms = started.elapsed().as_millis() as u64;
                    {
                        let mut st = live.write().unwrap();
                        st.validation_ms_total = st.validation_ms_total.saturating_add(validation_ms);
                    }
                    pipeline_log("VERIFIED", format_args!(
                        "range={}..{} blocks={} ms={} buffered={}",
                        start, end, commits.len(), started.elapsed().as_millis(), g.buffered.len() + 1
                    ));
                    g.buffered.insert(lease.range.start, (lease, commits, bytes));
                    drop(g);
                    self.commit_cv.notify_one();
                }
                Err((lease, e)) if is_node_unsupported(&e) => {
                    let reason = format!("block sync halted: {}", e);
                    pipeline_log("UNSUPPORTED", format_args!("range={}..{} error={}", start, end, e));
                    if g.engine.is_current_lease(lease.id, lease.generation) { g.engine.requeue_lease(lease.id); }
                    g.halted = Some(reason.clone());
                    drop(g);
                    let mut st = live.write().unwrap();
                    st.last_error = reason.clone();
                    st.message = reason;
                }
                Err((lease, e)) => {
                    pipeline_log("VALIDATION_ERROR", format_args!(
                        "peer={} range={}..{} error={}", peer, start, end, e
                    ));
                    g.engine.release_if_current(lease.id, lease.generation);
                    let nc = g.next_commit;
                    g.engine.requeue_if_quarantined_at(nc);
                    g.misbehaving.insert(peer.clone());
                    drop(g);
                    live.write().unwrap().last_error = format!("{} block validation: {}", peer, e);
                }
            }
        }
    }

    fn committer_loop(&self, state: Arc<State>, live: SharedState) {
        let max_blocks = commit_batch_blocks();
        loop {
            // Take the longest run of contiguous validated ranges at next_commit.
            let batch: Vec<Buffered> = {
                let mut g = self.inner.lock().unwrap();
                let mut first_ready: Option<Instant> = None;
                loop {
                    // How many blocks are ready contiguously from next_commit?
                    let (ready, _) = if g.halted.is_none() {
                        let mut expected = g.next_commit;
                        let mut count = 0usize;
                        while count < max_blocks {
                            let Some(item) = g.buffered.get(&expected) else { break };
                            expected = item.0.range.end + 1;
                            count += item.1.len();
                        }
                        (count, expected)
                    } else { (0, 0) };
                    if ready > 0 && first_ready.is_none() { first_ready = Some(Instant::now()); }
                    // Commit when the batch is full, when nothing else is coming
                    // soon (no range in verification), or the linger expired.
                    let linger_done = first_ready.map(|t| t.elapsed() >= COMMIT_LINGER).unwrap_or(false);
                    if ready > 0 && (ready >= max_blocks || g.verifying == 0 || linger_done) {
                        let mut out = Vec::new();
                        let mut expected = g.next_commit;
                        let mut count = 0usize;
                        while count < max_blocks {
                            let Some(item) = g.buffered.remove(&expected) else { break };
                            expected = item.0.range.end + 1;
                            count += item.1.len();
                            out.push(item);
                        }
                        g.committing_upto = expected.saturating_sub(1);
                        break out;
                    }
                    let wait = if ready > 0 { Duration::from_millis(50) } else { Duration::from_secs(1) };
                    g = self.commit_cv.wait_timeout(g, wait).unwrap().0;
                }
            };

            let first = batch[0].0.range.start;
            let last = batch[batch.len() - 1].0.range.end;
            // Move (not clone) the raw blocks into one commit vector.
            let mut leases: Vec<(RangeLease, u64)> = Vec::with_capacity(batch.len());
            let mut blocks: Vec<BlockCommit> = Vec::new();
            let mut bytes = 0u64;
            for (lease, b, n) in batch {
                leases.push((lease, b.len() as u64));
                blocks.extend(b);
                bytes += n;
            }
            let started = Instant::now();
            if let Err(e) = state.commit_blocks_batch(&blocks) {
                // Blocks matched PoW-verified headers and passed contextless
                // checks, so a stateful failure is deterministic. Halt.
                let reason = format!("block sync halted: commit {}..{} failed: {}", first, last, e);
                pipeline_log("COMMIT_ERROR", &reason);
                {
                    let mut g = self.inner.lock().unwrap();
                    for (lease, _) in &leases { g.engine.requeue_lease(lease.id); }
                    g.committing_upto = 0;
                    g.halted = Some(reason.clone());
                }
                let mut st = live.write().unwrap();
                st.last_error = reason.clone();
                st.message = reason;
                continue;
            }
            let commit_ms = started.elapsed().as_millis() as u64;
            let commit_timing = state.last_commit_timing();
            {
                let mut g = self.inner.lock().unwrap();
                for (lease, n) in &leases { g.engine.complete(lease.id, *n, 0); }
                g.next_commit = last + 1;
                g.committing_upto = 0;
                // Drop any late duplicate that slipped in below the new tip.
                let nc = g.next_commit;
                g.buffered = g.buffered.split_off(&nc);
                let buffered_blocks = g.buffered.len() as u64 * 16 + g.verifying.saturating_mul(16);
                let validation_ratio = (buffered_blocks as f64 / lookahead() as f64).min(1.0);
                let cpu_ratio = read_cpu_pressure();
                let memory_ratio = read_memory_pressure();
                // SQLite is serialized by the ordered committer. Commit latency
                // is therefore a useful DB-pressure signal without inventing a
                // second concurrent writer or weakening consensus ordering.
                let db_ratio = (commit_ms as f64 / 750.0).min(1.0);
                let network_ratio = 0.0;
                g.engine.observe(ResourceSample {
                    cpu_ratio, memory_ratio, db_queue_ratio: db_ratio,
                    network_ratio, validation_queue_ratio: validation_ratio,
                });
                let new_workers = g.engine.max_validation_workers();
                self.active_workers.store(new_workers, Ordering::Release);
            }
            // Wake any committer wait immediately if more is already buffered.
            self.commit_cv.notify_one();
            let rate = blocks.len() as u64 * 1000 / commit_ms.max(1);
            pipeline_log("COMMIT_OK", format_args!(
                "range={}..{} blocks={} ranges={} commit_ms={} blocks_per_sec={}",
                first, last, blocks.len(), leases.len(), commit_ms, rate
            ));
            let tip_time = state.header_time(last).ok().flatten().unwrap_or(0);
            {
                let mut st = live.write().unwrap();
                st.local_height = last;
                st.tip_time = tip_time;
                st.blocks_received = st.blocks_received.saturating_add(blocks.len() as u64);
                st.blocks_validated = st.blocks_validated.saturating_add(blocks.len() as u64);
                st.block_bytes_received = st.block_bytes_received.saturating_add(bytes);
                st.db_commits = st.db_commits.saturating_add(1);
                st.db_commit_ms_total = st.db_commit_ms_total.saturating_add(commit_ms);
                st.last_begin_ms = commit_timing.begin_ms;
                st.last_state_validation_ms = commit_timing.state_validation_ms;
                st.last_state_validation_us = commit_timing.state_validation_us;
                st.last_state_unattributed_us = commit_timing.state_unattributed_us;
                st.last_header_hash_us = commit_timing.header_hash_us;
                st.last_connector_new_us = commit_timing.connector_new_us;
                st.last_connector_other_us = commit_timing.connector_other_us;
                st.last_block_root_us = commit_timing.block_root_us;
                st.last_block_root_level_us = commit_timing.block_root_level_us;
                st.last_block_root_level_hashes = commit_timing.block_root_level_hashes;
                st.last_block_root_empty_us = commit_timing.block_root_empty_us;
                st.last_block_root_empty_hashes = commit_timing.block_root_empty_hashes;
                st.last_block_root_hash_us = commit_timing.block_root_hash_us;
                st.last_block_root_hashes = commit_timing.block_root_hashes;
                st.last_block_loop_other_us = commit_timing.block_loop_other_us;
                st.last_slowest_block_height = commit_timing.slowest_block_height;
                st.last_slowest_block_us = commit_timing.slowest_block_us;
                st.last_slowest_block_other_us = commit_timing.slowest_block_other_us;
                st.last_slowest_tx_height = commit_timing.slowest_tx_height;
                st.last_slowest_tx_index = commit_timing.slowest_tx_index;
                st.last_slowest_tx_us = commit_timing.slowest_tx_us;
                st.last_slowest_tx_other_us = commit_timing.slowest_tx_other_us;
                st.last_commit_total_us = commit_timing.total_us;
                st.last_tree_ms = commit_timing.tree_ms;
                st.last_parent_state_load_ms = commit_timing.parent_state_load_ms;
                st.last_parent_state_load_us = commit_timing.parent_state_load_us;
                st.last_block_parse_us = commit_timing.block_parse_us;
                st.last_txid_us = commit_timing.txid_us;
                st.last_block_parse_ms = commit_timing.block_parse_ms;
                st.last_tx_parse_us = commit_timing.tx_parse_us;
                st.last_tx_connect_ms = commit_timing.tx_connect_ms;
                st.last_tx_connect_us = commit_timing.tx_connect_us;
                st.last_sigops_us = commit_timing.sigops_us;
                st.last_bip30_us = commit_timing.bip30_us;
                st.last_sigops_ms = commit_timing.sigops_ms;
                st.last_bip30_ms = commit_timing.bip30_ms;
                st.last_utxo_lookup_ms = commit_timing.utxo_lookup_ms;
                st.last_utxo_lookup_us = commit_timing.utxo_lookup_us;
                st.last_sprout_requirements_us = commit_timing.sprout_requirements_us;
                st.last_value_checks_us = commit_timing.value_checks_us;
                st.last_script_us = commit_timing.script_us;
                st.last_coin_state_update_us = commit_timing.coin_state_update_us;
                st.last_sprout_apply_us = commit_timing.sprout_apply_us;
                st.last_sprout_requirements_ms = commit_timing.sprout_requirements_ms;
                st.last_value_checks_ms = commit_timing.value_checks_ms;
                st.last_script_ms = commit_timing.script_ms;
                st.last_script_parallel_workers = commit_timing.script_parallel_workers;
                st.last_script_parallel_us = commit_timing.script_parallel_us;
                st.last_script_input_work_us = commit_timing.script_input_work_us;
                st.last_script_transaction_input_extraction_us = commit_timing.script_transaction_input_extraction_us;
                st.last_script_sig_construction_us = commit_timing.script_sig_construction_us;
                st.last_script_pubkey_retrieval_us = commit_timing.script_pubkey_retrieval_us;
                st.last_script_parsing_us = commit_timing.script_parsing_us;
                st.last_signature_hash_preparation_us = commit_timing.signature_hash_preparation_us;
                st.last_ecdsa_verification_us = commit_timing.ecdsa_verification_us;
                st.last_script_interpreter_us = commit_timing.script_interpreter_us;
                st.last_script_cache_lookup_us = commit_timing.script_cache_lookup_us;
                st.last_script_synchronization_us = commit_timing.script_synchronization_us;
                st.last_script_worker_wall_us = commit_timing.script_worker_wall_us;
                st.last_script_worker_input_work_us = commit_timing.script_worker_input_work_us;
                st.last_script_worker_inputs = commit_timing.script_worker_inputs;
                st.last_script_spawn_us = commit_timing.script_spawn_us;
                st.last_script_join_us = commit_timing.script_join_us;
                st.last_script_pool_overhead_us = commit_timing.script_pool_overhead_us;
                st.last_script_pool_threads = commit_timing.script_pool_threads;
                st.last_script_worker_max_us = commit_timing.script_worker_max_us;
                st.last_script_worker_min_us = commit_timing.script_worker_min_us;
                st.last_script_slowest_input_index = commit_timing.script_slowest_input_index;
                st.last_script_slowest_input_us = commit_timing.script_slowest_input_us;
                st.last_script_slowest_input_tx_height = commit_timing.script_slowest_input_tx_height;
                st.last_script_slowest_input_tx_index = commit_timing.script_slowest_input_tx_index;
                st.last_utxo_cache_hits = commit_timing.utxo_cache_hits;
                st.last_utxo_cache_misses = commit_timing.utxo_cache_misses;
                st.last_parent_state_cache_hit = commit_timing.parent_state_cache_hit;
                st.last_sprout_state_cache_hit = commit_timing.sprout_state_cache_hit;
                st.last_coin_state_update_ms = commit_timing.coin_state_update_ms;
                st.last_sprout_apply_ms = commit_timing.sprout_apply_ms;
                st.last_sapling_validate_ms = commit_timing.sapling_validate_ms;
                st.last_sapling_validate_us = commit_timing.sapling_validate_us;
                st.last_sapling_anchor_lookup_ms = commit_timing.sapling_anchor_lookup_ms;
                st.last_sapling_anchor_lookup_us = commit_timing.sapling_anchor_lookup_us;
                st.last_sapling_nullifier_lookup_ms = commit_timing.sapling_nullifier_lookup_ms;
                st.last_sapling_nullifier_lookup_us = commit_timing.sapling_nullifier_lookup_us;
                st.last_sapling_tree_update_ms = commit_timing.sapling_tree_update_ms;
                st.last_sapling_tree_update_us = commit_timing.sapling_tree_update_us;
                st.last_block_finalize_us = commit_timing.block_finalize_us;
                st.last_tree_encode_us = commit_timing.tree_encode_us;
                st.last_read_transaction_us = commit_timing.read_transaction_us;
                st.last_read_transaction_commit_us = commit_timing.read_transaction_commit_us;
                st.last_parent_frontier_load_us = commit_timing.parent_frontier_load_us;
                st.last_sprout_state_load_us = commit_timing.sprout_state_load_us;
                st.last_block_finalize_ms = commit_timing.block_finalize_ms;
                st.last_sapling_anchor_queries = commit_timing.sapling_anchor_queries;
                st.last_sapling_nullifier_queries = commit_timing.sapling_nullifier_queries;
                st.last_sapling_empty_hashes_avoided = commit_timing.sapling_empty_hashes_avoided;
                st.last_sapling_root_cache_hits = commit_timing.sapling_root_cache_hits;
                st.last_utxo_lookups = commit_timing.utxo_lookups;
                st.last_bip30_checks = commit_timing.bip30_checks;
                st.last_script_checks = commit_timing.script_checks;
                st.last_db_write_ms = commit_timing.db_write_ms;
                st.last_db_write_us = commit_timing.db_write_us;
                st.last_sql_write_ms = commit_timing.sql_write_ms;
                st.last_index_write_ms = commit_timing.index_write_ms;
                st.last_sqlite_commit_ms = commit_timing.sqlite_commit_ms;
                st.last_sqlite_commit_us = commit_timing.sqlite_commit_us;
                st.last_rollback_ms = commit_timing.rollback_ms;
                st.record_rolling_commit(RollingCommitSample {
                    blocks: commit_timing.blocks,
                    txs: commit_timing.txs,
                    total_us: commit_timing.total_us,
                    state_validation_us: commit_timing.state_validation_us,
                    tx_connect_us: commit_timing.tx_connect_us,
                    script_us: commit_timing.script_us,
                    script_transaction_input_extraction_us: commit_timing.script_transaction_input_extraction_us,
                    script_sig_construction_us: commit_timing.script_sig_construction_us,
                    script_pubkey_retrieval_us: commit_timing.script_pubkey_retrieval_us,
                    script_parsing_us: commit_timing.script_parsing_us,
                    signature_hash_preparation_us: commit_timing.signature_hash_preparation_us,
                    ecdsa_verification_us: commit_timing.ecdsa_verification_us,
                    script_interpreter_us: commit_timing.script_interpreter_us,
                    script_cache_lookup_us: commit_timing.script_cache_lookup_us,
                    script_synchronization_us: commit_timing.script_synchronization_us,
                    sqlite_commit_us: commit_timing.sqlite_commit_us,
                    db_write_us: commit_timing.db_write_us,
                });
                st.txs_indexed = st.txs_indexed.saturating_add(blocks.iter().map(|b| b.txs.len() as u64).sum());
                st.batch_size = blocks.len() as u64;
                st.last_commit_unix = unix_time();
            }
            let (hedged, dups) = { let g = self.inner.lock().unwrap(); (g.hedged_ranges, g.duplicate_ranges) };
            self.publish(&live, Some(format!(
                "committed {}..{} ({} blocks in 1 tx, {} verifier threads, hedged {}, duplicates dropped {})",
                first, last, blocks.len(), verify_threads(), hedged, dups
            )));
        }
    }

    /// Mirror pipeline counters to the dashboard.
    fn publish(&self, live: &SharedState, message: Option<String>) {
        let (snap, outstanding, queue, verifying, buffered_ranges, leased_ranges, pending_ranges) = {
            let g = self.inner.lock().unwrap();
            (
                g.engine.snapshot(),
                g.engine.outstanding_heights(),
                g.verifying + g.buffered.len() as u64,
                g.verifying,
                g.buffered.len() as u64,
                g.engine.leased_ranges() as u64,
                g.engine.pending_ranges() as u64,
            )
        };
        let mut st = live.write().unwrap();
        st.blocks_in_flight = outstanding;
        st.pipeline_inflight_ranges = leased_ranges;
        st.pipeline_pending_ranges = pending_ranges;
        st.validation_queue = queue;
        st.verifying_jobs = verifying;
        st.buffered_ranges = buffered_ranges;
        st.active_block_workers = snap.workers.max(1);
        st.current_window = snap.window;
        st.pipeline_verify_threads = verify_threads() as u64;
        st.pipeline_max_inflight_ranges = snap.max_inflight_ranges.max(1);
        st.pipeline_max_validation_workers = snap.workers.max(1);
        st.pipeline_lookahead = lookahead();
        st.pipeline_commit_batch = commit_batch_blocks() as u64;
        st.pipeline_max_range_len = 16;
        st.completed_ranges = snap.completed_ranges;
        st.retried_ranges = snap.retried_ranges;
        st.quarantined_ranges = snap.quarantined_ranges;
        if let Some(m) = message { st.message = m; }
    }
}

fn read_cpu_pressure() -> f64 {
    if let Ok(s) = std::fs::read_to_string("/proc/loadavg") {
        if let Some(load) = s.split_whitespace().next().and_then(|v| v.parse::<f64>().ok()) {
            let cpus = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1) as f64;
            return (load / cpus).clamp(0.0, 1.0);
        }
    }
    0.0
}

fn read_memory_pressure() -> f64 {
    if let Ok(s) = std::fs::read_to_string("/proc/meminfo") {
        let mut total = 0f64;
        let mut available = 0f64;
        for line in s.lines() {
            let mut p = line.split_whitespace();
            match p.next() {
                Some("MemTotal:") => total = p.next().and_then(|v| v.parse().ok()).unwrap_or(0.0),
                Some("MemAvailable:") => available = p.next().and_then(|v| v.parse().ok()).unwrap_or(0.0),
                _ => {}
            }
        }
        if total > 0.0 { return (1.0 - available / total).clamp(0.0, 1.0); }
    }
    0.0
}

/// Block hash straight from the raw block bytes (sha256d of the header incl.
/// Equihash solution).
fn raw_block_hash(raw: &[u8]) -> Option<[u8; 32]> {
    use sha2::{Digest, Sha256};
    let mut i = 140usize;
    let sol_len = ycash_network::runtime::read_compact_size(raw, &mut i).ok()? as usize;
    let end = i.checked_add(sol_len)?;
    let header = raw.get(..end)?;
    let a = Sha256::digest(header);
    let b = Sha256::digest(a);
    let mut out = [0u8; 32];
    out.copy_from_slice(&b);
    Some(out)
}

/// Median-time-past for every height in `start..=end`, computed exactly like
/// `crate::mtp` (median of the 11 preceding header times, with the genesis time
/// standing in below height 12) but from a single range query.
fn mtp_range(state: &State, start: u64, end: u64) -> std::io::Result<HashMap<u64, u32>> {
    let from = start.saturating_sub(11).max(1);
    let rows = state.header_times_range(from, end).map_err(|e| ioe(&e.to_string()))?;
    let times: HashMap<u64, u32> = rows.into_iter().collect();
    let mut out = HashMap::new();
    for h in start..=end {
        let s = h.saturating_sub(11);
        let mut v = Vec::with_capacity(11);
        if s == 0 && h > 0 { v.push(GENESIS_TIME); }
        for x in s.max(1)..h {
            if let Some(t) = times.get(&x) { v.push(*t); }
        }
        let m = if v.is_empty() { 0 } else { v.sort_unstable(); v[v.len() / 2] };
        out.insert(h, m);
    }
    Ok(out)
}

/// Stage 1: download a leased range and attach verifier context. No validation.
fn fetch_range(stream: &mut TcpStream, state: &Arc<State>, lease: &RangeLease) -> std::io::Result<VerifyJob> {
    let (start, end) = (lease.range.start, lease.range.end);
    let hashes = state.header_hashes_range(start, end).map_err(|e| ioe(&e.to_string()))?;
    let works = state.header_works_range(start, end).map_err(|e| ioe(&e.to_string()))?;
    let mtps = mtp_range(state, start, end)?;
    let mut requests = Vec::with_capacity((end - start + 1) as usize);
    for h in start..=end {
        let hash = hashes.get(&h).copied().ok_or_else(|| ioe("missing header for claimed range"))?;
        requests.push((h, hash));
    }
    let prev_of_start: [u8; 32] = if start == 1 {
        genesis_hash_internal()
    } else {
        state.header_hash_by_height(start - 1)
            .map_err(|e| ioe(&e.to_string()))?
            .and_then(|v| <[u8; 32]>::try_from(v.as_slice()).ok())
            .ok_or_else(|| ioe("missing previous header"))?
    };
    let assume_valid_ok = start <= ASSUME_VALID_HEIGHT && assume_valid_active(state);
    if assume_valid_ok { state.set_assume_valid_height(ASSUME_VALID_HEIGHT); }

    let by_hash: HashMap<[u8; 32], u64> = requests.iter().map(|(h, hash)| (*hash, *h)).collect();
    let want: Vec<[u8; 32]> = requests.iter().map(|(_, h)| *h).collect();
    send(stream, "getdata", &getdata_payload(&want)).map_err(|e| phase_error("getdata send", e))?;

    let mut got: BTreeMap<u64, Vec<u8>> = BTreeMap::new();
    let mut bytes = 0u64;
    let mut idle = 0u32;
    // Progress deadline: at least one requested block every 180s
    // (ycashd's post-Blossom minimum block timeout is 150s).
    const PROGRESS_TIMEOUT: Duration = Duration::from_secs(180);
    let mut deadline = Instant::now() + PROGRESS_TIMEOUT;
    while got.len() < requests.len() {
        if Instant::now() >= deadline {
            return Err(ioe(&format!(
                "peer made no progress on range {}..{} for 180s (received {}/{} blocks)",
                start, end, got.len(), requests.len()
            )));
        }
        let (cmd, payload) = match read_message(stream) {
            Ok(v) => v,
            Err(e) if is_timeout(&e) => {
                idle += 1;
                // v0.29.2: 30s of silence (was 8s). Mobile links and busy ycashd
                // peers pause longer than 8s; the head-of-line range is hedged
                // to another peer after 20s anyway, so waiting costs nothing.
                if idle >= IDLE_READS_BEFORE_DROP { return Err(ioe("peer sent nothing for 30s on claimed range")); }
                continue;
            }
            Err(e) => return Err(phase_error("block stream read", e)),
        };
        idle = 0;
        if cmd == "ping" {
            send(stream, "pong", &payload).map_err(|e| phase_error("block-stream pong send", e))?;
            continue;
        }
        if cmd == "notfound" {
            return Err(ioe(&format!("peer sent notfound for range {}..{}", start, end)));
        }
        if cmd != "block" { continue; }
        let Some(height) = raw_block_hash(&payload).and_then(|h| by_hash.get(&h).copied()) else { continue };
        if got.contains_key(&height) { continue; }
        deadline = Instant::now() + PROGRESS_TIMEOUT;
        bytes += payload.len() as u64;
        got.insert(height, payload);
    }

    let mut blocks = Vec::with_capacity(requests.len());
    for (h, hash) in requests {
        let raw = got.remove(&h).ok_or_else(|| ioe("range assembly lost a block"))?;
        let m = *mtps.get(&h).unwrap_or(&0);
        let w = works.get(&h).copied().ok_or_else(|| ioe("missing header chain work"))?;
        blocks.push((h, hash, m, w, raw));
    }
    Ok(VerifyJob { lease: lease.clone(), peer: String::new(), blocks, prev_of_start, assume_valid_ok, bytes })
}

/// Stage 2: complete stateless consensus validation of one range. Pure CPU, no DB.
///
/// Every block must pass the same consensus validation entry point before it
/// can enter the ordered state committer. Full verification is the default;
/// the optional assume-valid checkpoint is never enabled implicitly.
///
/// v0.30.0: every Sapling Groth16 proof in the range goes into one
/// `ProofBatch` (one multi-Miller loop per verifying key instead of one
/// pairing check per proof). Non-pairing checks still run per transaction.
/// Any rejection is re-checked by the original single-proof verifier, whose
/// result is final (see `ycash_consensus::ProofBatch`).
fn verify_job(job: VerifyJob) -> Result<Buffered, (RangeLease, std::io::Error)> {
    let VerifyJob { lease, blocks, prev_of_start, assume_valid_ok, bytes, .. } = job;
    let mut out = Vec::with_capacity(blocks.len());
    let mut prev = prev_of_start;
    let mut batch = ProofBatch::new();
    let as_io = |height: u64, e: ycash_consensus::ConsensusError| {
        let msg = format!("{e:?}");
        let kind = if msg.contains(UNSUPPORTED_PREFIX) { ErrorKind::Unsupported } else { ErrorKind::InvalidData };
        std::io::Error::new(kind, format!("block {height}: {msg}"))
    };
    for (height, hash, mtp_time, work, raw) in blocks {
        let ctx = Context { height, prev_height: height.saturating_sub(1), median_time_past: mtp_time };
        let assume_valid = height <= ASSUME_VALID_HEIGHT && assume_valid_ok;
        let (validated, parsed_txs) = match validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, &mut batch) {
            Ok(v) => v,
            Err(e) => return Err((lease, as_io(height, e))),
        };
        if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
            return Err((lease, ioe("consensus decoder returned inconsistent transaction data")));
        }
        let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
        let precomputed_txs: Vec<ycash_script::PrecomputedTxData> = parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();
        out.push(BlockCommit { height, hash, prev, work, raw, txs, parsed_txs, precomputed_txs, proofs_verified: true });
        prev = hash;
    }
    let proofs = batch.proofs();
    if proofs > 0 {
        let started = Instant::now();
        if let Err((height, e)) = batch.finish() {
            return Err((lease, as_io(height, e)));
        }
        let (batches, total, failed) = ycash_consensus::batch_stats();
        pipeline_log("BATCH_VERIFY", format_args!(
            "range={}..{} proofs={} ms={} total_batches={} total_proofs={} failed_batches={}",
            lease.range.start, lease.range.end, proofs, started.elapsed().as_millis(), batches, total, failed
        ));
    }
    Ok((lease, out, bytes))
}

fn ioe(s: &str) -> std::io::Error {
    std::io::Error::new(ErrorKind::InvalidData, s.to_string())
}

fn phase_error(phase: &str, e: std::io::Error) -> std::io::Error {
    std::io::Error::new(e.kind(), format!("{}: {}", phase, e))
}
