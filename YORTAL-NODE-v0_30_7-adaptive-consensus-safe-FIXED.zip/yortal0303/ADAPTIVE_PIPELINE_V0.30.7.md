# YORTAL v0.30.7 — adaptive consensus-safe pipeline

## Changes

- Added scheduler-level `enqueue_if_disjoint()` and contiguous coverage tracking.
- Repeated planning is idempotent: pending/leased/quarantined ranges cannot overlap.
- `planned_up_to` advances only over ranges actually enqueued.
- Adaptive controller now changes three independent budgets from CPU, memory, DB commit latency, and validation backlog pressure:
  - lookahead window: 16..128 blocks
  - active validation workers: 1..4
  - in-flight network ranges: 1..8
- Individual network ranges remain capped at 16 blocks.
- Verifier thread pool is fixed-size at startup (logical CPUs minus one, capped at 4 by default), while active job consumption is adaptively gated to avoid thread churn.
- High pressure reduces concurrency; sustained low pressure increases the lookahead window.
- Canonical state mutation remains strictly height ordered through the existing commit barrier.
- Added scheduler and adaptive-controller regression tests.

## Consensus boundary

This patch changes scheduling/resource policy only. It does not change block validity rules, transaction rules, chain selection, state transition ordering, tree/nullifier updates, or canonical tip advancement.

## Runtime defaults

`config/pipeline.toml`:

- min_window=16
- initial_window=32
- max_window=128
- window_step=16
- max_validation_workers=4
- max_inflight_ranges=8
- high_watermark=0.85
- low_watermark=0.50
- max_range_len=16

Android uses the same adaptive limits in `pipeline_sync.rs`, with `YORTAL_VERIFY_THREADS` and `YORTAL_LOOKAHEAD` remaining optional benchmarking overrides.
