# YORTAL v0.30.6 — Ycash/Zebra consensus-safe script verifier

## Implemented

- Replaced per-transaction `std::thread::scope` worker creation with one persistent Rayon thread pool.
- Each transparent input is an independent verification job; Rayon dynamically schedules/work-steals jobs.
- Kept the Ycash consensus boundary: all UTXOs are collected first, script checks read immutable transaction/prevout data, and coin/state mutation remains strictly ordered in `connect_tx()`.
- Kept direct execution for tiny transactions (fewer than 2 inputs).
- Default verifier sizing is adaptive: `available_parallelism - 1`, minimum 1, maximum 4.
- Parallel verification has a small-transaction cutoff (`2` inputs by default), configurable with `YORTAL_SCRIPT_PARALLEL_THRESHOLD`.
- Added `YORTAL_SCRIPT_WORKERS=1..4` override for device benchmarking; this does not alter consensus.
- Kept block/pipeline concurrency separate from script CPU concurrency. The existing conservative pipeline remains `max_validation_workers=1` and `max_inflight_ranges=1`.
- Added pool-overhead and pool-thread telemetry. Legacy spawn/join fields remain for API compatibility and are now zero for the persistent pool.
- Preserved deterministic error reporting by selecting the lowest failing input index after parallel checks.

## Consensus safety

No consensus rule, transaction ordering, UTXO mutation order, Sprout application order, Sapling state handling, block root calculation, or commit ordering was changed. The optimization only changes scheduling of independent transparent script checks.

## Rationale

The previous fixed chunking could produce distributions such as `[23,10,2,1]` and paid per-transaction thread lifecycle overhead. The new design follows the useful scheduling properties shared by ycashd's persistent `CCheckQueue` and Zebra's persistent Rayon execution: independent checks, bounded CPU concurrency, dynamic scheduling, and ordered state transition.

## Validation

Run:

```text
cargo test --workspace --all-targets
cargo check -p ycash-state
cargo check -p ycash-android-node
```

For Android performance comparison, record:

- `last_script_parallel_us`
- `last_script_input_work_us`
- `last_script_pool_overhead_us`
- `last_script_pool_threads`
- `last_script_worker_wall_us`
- `last_script_worker_input_work_us`
- `last_script_worker_inputs`

The expected signature of improvement is near-zero per-transaction thread creation/join time, more even worker input counts, and lower parallel wall time relative to summed input work.
