use std::sync::{Arc, RwLock};
use ycash_network::runtime::unix_time;

#[derive(Clone, Debug)]
pub struct LiveNodeState {
    pub running: bool,
    pub peers: u32,
    pub local_height: u64,
    pub target_height: Option<u64>,
    pub headers_height: u64,
    pub connection_source: String,
    pub connection_endpoint: String,
    pub connection_detail: String,
    pub message: String,
    /// Unix time embedded in the most recently validated block's header -- this is a real
    /// consensus field (BlockHeader.time), not a wall-clock timestamp of when we processed it.
    pub tip_time: u32,
    /// Wall-clock unix time this node process started, captured once at state creation.
    pub started_unix: i64,
    pub api_listening: bool,
    pub rpc_listening: bool,
    pub p2p_listening: bool,
    pub lightwallet_listening: bool,
    pub outbound_attempts: u64,
    pub outbound_handshakes: u64,
    pub inbound_connections: u64,
    pub last_error: String,
    /// Last status per outbound peer address (most recent first when rendered).
    pub peer_last: std::collections::BTreeMap<String,(i64,String)>,
    pub active_outbound: u32,
    pub known_peers: u32,
    pub blocks_received: u64,
    pub blocks_validated: u64,
    pub txs_indexed: u64,
    pub last_block_bytes: u64,
    pub last_block_height: u64,
    pub headers_validated: u64,
    pub header_bytes_received: u64,
    pub block_bytes_received: u64,
    pub db_commits: u64,
    pub blocks_in_flight: u64,
    pub validation_queue: u64,
    pub batch_size: u64,
    /// Current adaptive sync window size (mirrors `PipelineSnapshot::window`).
    /// Distinct from `batch_size`, which is the size of the *last committed*
    /// range -- the dashboard previously showed `batch_size` under "Window"
    /// too, so the two fields always displayed identically.
    pub current_window: u64,
    pub validation_ms_total: u64,
    pub db_commit_ms_total: u64,
    pub last_begin_ms: u64,
    pub last_state_validation_ms: u64,
    pub last_state_validation_us: u64,
    pub last_state_unattributed_us: u64,
    pub last_commit_total_us: u64,
    pub last_tree_ms: u64,
    pub last_parent_state_load_ms: u64,
    pub last_parent_state_load_us: u64,
    pub last_block_parse_us: u64,
    pub last_txid_us: u64,
    pub last_block_parse_ms: u64,
    pub last_tx_parse_us: u64,
    pub last_tx_connect_ms: u64,
    pub last_tx_connect_us: u64,
    pub last_sigops_us: u64,
    pub last_bip30_us: u64,
    pub last_sigops_ms: u64,
    pub last_bip30_ms: u64,
    pub last_utxo_lookup_ms: u64,
    pub last_utxo_lookup_us: u64,
    pub last_sprout_requirements_us: u64,
    pub last_value_checks_us: u64,
    pub last_script_us: u64,
    pub last_coin_state_update_us: u64,
    pub last_sprout_apply_us: u64,
    pub last_sprout_requirements_ms: u64,
    pub last_value_checks_ms: u64,
    pub last_script_ms: u64,
    pub last_coin_state_update_ms: u64,
    pub last_sprout_apply_ms: u64,
    pub last_sapling_validate_ms: u64,
    pub last_sapling_validate_us: u64,
    pub last_sapling_anchor_lookup_ms: u64,
    pub last_sapling_anchor_lookup_us: u64,
    pub last_sapling_nullifier_lookup_ms: u64,
    pub last_sapling_nullifier_lookup_us: u64,
    pub last_sapling_tree_update_ms: u64,
    pub last_sapling_tree_update_us: u64,
    pub last_block_finalize_us: u64,
    pub last_tree_encode_us: u64,
    pub last_read_transaction_us: u64,
    pub last_read_transaction_commit_us: u64,
    pub last_parent_frontier_load_us: u64,
    pub last_sprout_state_load_us: u64,
    pub last_block_finalize_ms: u64,
    pub last_sapling_anchor_queries: u64,
    pub last_sapling_nullifier_queries: u64,
    pub last_utxo_lookups: u64,
    pub last_bip30_checks: u64,
    pub last_script_checks: u64,
    pub last_db_write_ms: u64,
    pub last_db_write_us: u64,
    pub last_sql_write_ms: u64,
    pub last_index_write_ms: u64,
    pub last_sqlite_commit_ms: u64,
    pub last_sqlite_commit_us: u64,
    pub last_rollback_ms: u64,
    pub verifying_jobs: u64,
    pub buffered_ranges: u64,
    /// Concurrent block-range workers the pipeline engine currently has
    /// planned (mirrors `PipelineSnapshot::workers`). Distinct from
    /// `active_outbound` (connected peers) -- this is how many of them the
    /// scheduler has actually partitioned the current window across.
    pub active_block_workers: u64,
    /// Height ranges the pipeline has fully validated and committed.
    pub completed_ranges: u64,
    /// Ranges released back to the scheduler after a peer failed/timed out
    /// mid-claim and re-queued for another peer to retry.
    pub retried_ranges: u64,
    /// Ranges that exceeded the retry limit and were quarantined -- a
    /// nonzero value here means part of the chain is stuck behind a range
    /// no peer has been able to serve, independent of any single peer's
    /// connection state.
    pub quarantined_ranges: u64,
    /// Unix time of the last successful batch commit to the database, or 0
    /// if none has happened yet this run. This is a wall-clock stall
    /// detector: headers/s and connection state can look healthy while this
    /// timestamp stops advancing, which is exactly the "height stuck" case.
    pub last_commit_unix: i64,
}
impl Default for LiveNodeState {
    fn default() -> Self {
        Self {
            running: false,
            peers: 0,
            local_height: 0,
            target_height: None,
            headers_height: 0,
            connection_source: "None".into(),
            connection_endpoint: "—".into(),
            connection_detail: "No active Ycash P2P connection".into(),
            message: "node ready".into(),
            tip_time: 0,
            started_unix: unix_time(),
            api_listening: false,
            rpc_listening: false,
            p2p_listening: false,
            lightwallet_listening: false,
            outbound_attempts: 0,
            outbound_handshakes: 0,
            inbound_connections: 0,
            last_error: String::new(),
            peer_last: Default::default(),
            active_outbound: 0,
            known_peers: 0,
            blocks_received: 0,
            blocks_validated: 0,
            txs_indexed: 0,
            last_block_bytes: 0,
            last_block_height: 0,
            headers_validated: 0,
            header_bytes_received: 0,
            block_bytes_received: 0,
            db_commits: 0,
            blocks_in_flight: 0,
            validation_queue: 0,
            batch_size: 0,
            current_window: 0,
            validation_ms_total: 0,
            db_commit_ms_total: 0,
            last_begin_ms: 0,
            last_state_validation_ms: 0,
            last_state_validation_us: 0,
            last_state_unattributed_us: 0,
            last_commit_total_us: 0,
            last_tree_ms: 0,
            last_parent_state_load_ms: 0,
            last_parent_state_load_us: 0,
            last_block_parse_us: 0,
            last_txid_us: 0,
            last_block_parse_ms: 0,
            last_tx_parse_us: 0,
            last_tx_connect_ms: 0,
            last_tx_connect_us: 0,
            last_sigops_us: 0,
            last_bip30_us: 0,
            last_sigops_ms: 0,
            last_bip30_ms: 0,
            last_utxo_lookup_ms: 0,
            last_utxo_lookup_us: 0,
            last_sprout_requirements_us: 0,
            last_value_checks_us: 0,
            last_script_us: 0,
            last_coin_state_update_us: 0,
            last_sprout_apply_us: 0,
            last_sprout_requirements_ms: 0,
            last_value_checks_ms: 0,
            last_script_ms: 0,
            last_coin_state_update_ms: 0,
            last_sprout_apply_ms: 0,
            last_sapling_validate_ms: 0,
            last_sapling_validate_us: 0,
            last_sapling_anchor_lookup_ms: 0,
            last_sapling_anchor_lookup_us: 0,
            last_sapling_nullifier_lookup_ms: 0,
            last_sapling_nullifier_lookup_us: 0,
            last_sapling_tree_update_ms: 0,
            last_sapling_tree_update_us: 0,
            last_block_finalize_us: 0,
            last_tree_encode_us: 0,
            last_read_transaction_us: 0,
            last_read_transaction_commit_us: 0,
            last_parent_frontier_load_us: 0,
            last_sprout_state_load_us: 0,
            last_block_finalize_ms: 0,
            last_sapling_anchor_queries: 0,
            last_sapling_nullifier_queries: 0,
            last_utxo_lookups: 0,
            last_bip30_checks: 0,
            last_script_checks: 0,
            last_db_write_ms: 0,
            last_db_write_us: 0,
            last_sql_write_ms: 0,
            last_index_write_ms: 0,
            last_sqlite_commit_ms: 0,
            last_sqlite_commit_us: 0,
            last_rollback_ms: 0,
            verifying_jobs: 0,
            buffered_ranges: 0,
            active_block_workers: 0,
            completed_ranges: 0,
            retried_ranges: 0,
            quarantined_ranges: 0,
            last_commit_unix: 0,
        }
    }
}
impl LiveNodeState {
    pub fn note(&mut self, addr:&str){
        self.peer_last.insert(addr.to_string(),(unix_time(),self.connection_detail.clone()));
        if self.peer_last.len()>40 { if let Some(k)=self.peer_last.iter().min_by_key(|(_,v)|v.0).map(|(k,_)|k.clone()) { self.peer_last.remove(&k); } }
    }
    pub fn sync_text(&self) -> String {
        match self.target_height {
            // Blocks only start downloading once headers have fully caught up to the peer's
            // announced height (see sync_headers()/download_blocks() in main.rs), so while that's
            // still in progress, local_height sits at 0 the whole time. Report header-sync
            // progress here instead of a percentage that would otherwise read 0% for a very long
            // stretch of real, ongoing work.
            Some(t) if self.headers_height < t => {
                let pct = (self.headers_height.saturating_mul(100)/t.max(1)).min(100);
                format!("headers {}%", pct)
            }
            Some(t) if t > self.local_height =>
                format!("{}%", ((self.local_height.saturating_mul(100))/t).min(100)),
            Some(_) => "100%".into(),
            None => "waiting for headers".into(),
        }
    }
}
pub type SharedState = Arc<RwLock<LiveNodeState>>;
