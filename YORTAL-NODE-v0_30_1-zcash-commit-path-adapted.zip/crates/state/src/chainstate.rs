//! Transparent UTXO set and Sprout shielded state for ordered block commits.
//!
//! Mirrors ycashd 4.5.0 `ConnectBlock` / `Consensus::CheckTxInputs` /
//! `ContextualCheckInputs` / `CCoinsViewCache::HaveShieldedRequirements`:
//! inputs exist and are unspent, coinbase maturity (100) and the
//! coinbase-must-be-shielded rule, value in >= value out, fees, script
//! verification (P2SH | CHECKLOCKTIMEVERIFY), block sigop limit, BIP30,
//! coinbase amount <= subsidy + fees, Sprout nullifiers and anchors
//! (including intermediate anchors inside one transaction), and the ZIP 209
//! Sprout/Sapling value-pool turnstile.
//!
//! Storage model: an output row is written once with the height that created
//! it and, when spent, the height that spent it. "State as of the batch's
//! first height H" is therefore `height < H AND (spent_height IS NULL OR
//! spent_height >= H)`, which stays correct even when the batch replaces an
//! old branch (rows at >= H are rolled back only after validation passes).
//! Spent rows are pruned once they are deeper than the 100-block maximum
//! reorg length ycashd itself enforces.

use anyhow::{anyhow, bail, Result};
use rusqlite::{params, Transaction};
use std::collections::{HashMap, HashSet};
use ycash_chain::ParsedTransaction;
use ycash_consensus::{
    block_subsidy, is_coinbase, money_range, tx_shielded_value_in, tx_value_out, SproutTree, COINBASE_MATURITY,
    MAX_BLOCK_SIGOPS,
};

/// ycashd `MAX_REORG_LENGTH` is 99; keep spent outputs a little longer.
pub const SPENT_OUTPUT_RETENTION: u64 = 100;

pub type OutPoint = ([u8; 32], u32);

#[derive(Clone, Debug)]
pub struct Coin {
    pub value: i64,
    pub script: Vec<u8>,
    pub height: u64,
    pub coinbase: bool,
}

#[derive(Clone, Debug)]
struct CoinEntry {
    coin: Coin,
    spent_height: Option<u64>,
    from_db: bool,
}

pub struct CoinsView {
    first_height: u64,
    entries: HashMap<OutPoint, CoinEntry>,
    batch_txids: HashSet<[u8; 32]>,
}

impl CoinsView {
    pub fn new(first_height: u64) -> Self {
        Self { first_height, entries: HashMap::new(), batch_txids: HashSet::new() }
    }

    pub fn get(&mut self, db: &Transaction<'_>, op: &OutPoint) -> Result<Option<Coin>> {
        if let Some(e) = self.entries.get(op) {
            return Ok(if e.spent_height.is_none() { Some(e.coin.clone()) } else { None });
        }
        // Reuse SQLite's prepared statement cache for every input lookup.
        // `connect_tx()` can perform many of these lookups per batch; preparing
        // the statement afresh for each input adds avoidable parse/VM setup
        // overhead without changing consensus semantics.
        let mut stmt = db.prepare_cached(
            "SELECT value,script,height,coinbase FROM utxos
             WHERE txid=?1 AND vout=?2 AND height<?3 AND (spent_height IS NULL OR spent_height>=?3)",
        )?;
        let row = stmt.query_row(
            params![op.0.as_slice(), op.1 as i64, self.first_height as i64],
            |r| {
                Ok(Coin {
                    value: r.get::<_, i64>(0)?,
                    script: r.get::<_, Vec<u8>>(1)?,
                    height: r.get::<_, i64>(2)? as u64,
                    coinbase: r.get::<_, i64>(3)? != 0,
                })
            },
        );
        match row {
            Ok(coin) => {
                self.entries.insert(*op, CoinEntry { coin: coin.clone(), spent_height: None, from_db: true });
                Ok(Some(coin))
            }
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    /// BIP30: a transaction may not overwrite one with unspent outputs.
    pub fn has_unspent_outputs_of(&self, db: &Transaction<'_>, txid: &[u8; 32]) -> Result<bool> {
        if self.batch_txids.contains(txid)
            && self.entries.iter().any(|(k, e)| k.0 == *txid && !e.from_db && e.spent_height.is_none())
        {
            return Ok(true);
        }
        // This is on the hot path for every transaction (BIP30). Reuse the
        // prepared statement just as with input lookups above.
        let mut stmt = db.prepare_cached(
            "SELECT COUNT(*) FROM utxos WHERE txid=?1 AND height<?2 AND (spent_height IS NULL OR spent_height>=?2)",
        )?;
        let unspent_db: i64 = stmt.query_row(
            params![txid.as_slice(), self.first_height as i64],
            |r| r.get(0),
        )?;
        if unspent_db == 0 {
            return Ok(false);
        }
        let spent_in_batch =
            self.entries.iter().filter(|(k, e)| k.0 == *txid && e.from_db && e.spent_height.is_some()).count() as i64;
        Ok(unspent_db > spent_in_batch)
    }

    pub fn spend(&mut self, op: &OutPoint, height: u64) {
        if let Some(e) = self.entries.get_mut(op) {
            e.spent_height = Some(height);
        }
    }

    pub fn add(&mut self, op: OutPoint, coin: Coin) {
        self.batch_txids.insert(op.0);
        self.entries.insert(op, CoinEntry { coin, spent_height: None, from_db: false });
    }

    /// Write the batch's UTXO changes. Call after the rollback statements.
    pub fn flush(&self, db: &Transaction<'_>) -> Result<()> {
        let mut insert = db.prepare_cached(
            "INSERT INTO utxos(txid,vout,value,script,height,coinbase,spent_height)
             VALUES(?1,?2,?3,?4,?5,?6,?7)
             ON CONFLICT(txid,vout) DO UPDATE SET
               value=excluded.value, script=excluded.script, height=excluded.height,
               coinbase=excluded.coinbase, spent_height=excluded.spent_height",
        )?;
        let mut mark_spent = db.prepare_cached("UPDATE utxos SET spent_height=?3 WHERE txid=?1 AND vout=?2")?;
        for (op, e) in &self.entries {
            if e.from_db {
                if let Some(h) = e.spent_height {
                    mark_spent.execute(params![op.0.as_slice(), op.1 as i64, h as i64])?;
                }
            } else {
                insert.execute(params![
                    op.0.as_slice(),
                    op.1 as i64,
                    e.coin.value,
                    &e.coin.script,
                    e.coin.height as i64,
                    e.coin.coinbase as i64,
                    e.spent_height.map(|h| h as i64),
                ])?;
            }
        }
        Ok(())
    }
}

/// Sprout state carried through a batch.
pub struct SproutView {
    first_height: u64,
    pub tree: SproutTree,
    /// Final treestate of every block already processed in this batch.
    batch_roots: HashMap<[u8; 32], SproutTree>,
    batch_nullifiers: HashMap<[u8; 32], u64>,
    pub chain_sprout_value: i64,
    pub chain_sapling_value: i64,
    pub rows: Vec<BlockStateRow>,
}

pub struct BlockStateRow {
    pub block_hash: [u8; 32],
    pub height: u64,
    pub sprout_root: [u8; 32],
    pub sprout_frontier: Vec<u8>,
    pub chain_sprout_value: i64,
    pub chain_sapling_value: i64,
}

impl SproutView {
    pub fn load(db: &Transaction<'_>, first_height: u64, prev: &[u8; 32]) -> Result<Self> {
        let (tree, sprout_value, sapling_value) = if first_height <= 1 {
            // The genesis block's transactions are never connected.
            (SproutTree::new(), 0, 0)
        } else {
            db.query_row(
                "SELECT sprout_frontier,chain_sprout_value,chain_sapling_value FROM block_state
                 WHERE block_hash=?1 AND height=?2",
                params![prev.as_slice(), (first_height - 1) as i64],
                |r| Ok((r.get::<_, Vec<u8>>(0)?, r.get::<_, i64>(1)?, r.get::<_, i64>(2)?)),
            )
            .map_err(|e| anyhow!("missing Sprout/value-pool state for parent block: {e}"))
            .and_then(|(f, a, b)| {
                SproutTree::decode(&f).map(|t| (t, a, b)).map_err(|e| anyhow!("invalid persisted Sprout frontier: {e:?}"))
            })?
        };
        Ok(Self {
            first_height,
            tree,
            batch_roots: HashMap::new(),
            batch_nullifiers: HashMap::new(),
            chain_sprout_value: sprout_value,
            chain_sapling_value: sapling_value,
            rows: Vec::new(),
        })
    }

    fn db_nullifier_exists(&self, db: &Transaction<'_>, nf: &[u8; 32]) -> Result<bool> {
        match db.query_row(
            "SELECT 1 FROM sprout_nullifiers WHERE n=?1 AND height<?2",
            params![nf.as_slice(), self.first_height as i64],
            |r| r.get::<_, i64>(0),
        ) {
            Ok(_) => Ok(true),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(false),
            Err(e) => Err(e.into()),
        }
    }

    fn anchor_tree(&self, db: &Transaction<'_>, anchor: &[u8; 32]) -> Result<Option<SproutTree>> {
        if let Some(t) = self.batch_roots.get(anchor) {
            return Ok(Some(t.clone()));
        }
        if *anchor == SproutTree::empty_root() {
            return Ok(Some(SproutTree::new()));
        }
        match db.query_row(
            "SELECT sprout_frontier FROM block_state WHERE sprout_root=?1 AND height<?2 LIMIT 1",
            params![anchor.as_slice(), self.first_height as i64],
            |r| r.get::<_, Vec<u8>>(0),
        ) {
            Ok(f) => Ok(Some(SproutTree::decode(&f).map_err(|e| anyhow!("invalid persisted Sprout frontier: {e:?}"))?)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    /// Sprout half of `HaveShieldedRequirements`.
    pub fn check_requirements(&self, db: &Transaction<'_>, tx: &ParsedTransaction) -> Result<()> {
        let mut intermediates: HashMap<[u8; 32], SproutTree> = HashMap::new();
        for js in &tx.joinsplits {
            for nf in &js.nullifiers {
                if self.batch_nullifiers.contains_key(nf) || self.db_nullifier_exists(db, nf)? {
                    bail!("bad-txns-joinsplit-requirements-not-met: Sprout nullifier already spent");
                }
            }
            let mut tree = match intermediates.get(&js.anchor) {
                Some(t) => t.clone(),
                None => self
                    .anchor_tree(db, &js.anchor)?
                    .ok_or_else(|| anyhow!("bad-txns-joinsplit-requirements-not-met: unknown Sprout anchor"))?,
            };
            for cm in &js.commitments {
                tree.append(*cm).map_err(|e| anyhow!("{e:?}"))?;
            }
            intermediates.entry(tree.root()).or_insert(tree);
        }
        Ok(())
    }

    /// Nullifiers, commitments and value pools after a tx is connected.
    pub fn apply(&mut self, tx: &ParsedTransaction, height: u64) -> Result<()> {
        for js in &tx.joinsplits {
            for nf in &js.nullifiers {
                self.batch_nullifiers.insert(*nf, height);
            }
            for cm in &js.commitments {
                self.tree.append(*cm).map_err(|e| anyhow!("{e:?}"))?;
            }
            self.chain_sprout_value = self
                .chain_sprout_value
                .checked_add(js.vpub_old)
                .and_then(|v| v.checked_sub(js.vpub_new))
                .ok_or_else(|| anyhow!("Sprout value pool overflow"))?;
        }
        self.chain_sapling_value = self
            .chain_sapling_value
            .checked_sub(tx.value_balance)
            .ok_or_else(|| anyhow!("Sapling value pool overflow"))?;
        Ok(())
    }

    pub fn finish_block(&mut self, block_hash: [u8; 32], height: u64) -> Result<()> {
        if self.chain_sprout_value < 0 {
            bail!("turnstile-violation-sprout-shielded-pool at height {height}");
        }
        if self.chain_sapling_value < 0 {
            bail!("turnstile-violation-sapling-shielded-pool at height {height}");
        }
        let root = self.tree.root();
        self.batch_roots.entry(root).or_insert_with(|| self.tree.clone());
        self.rows.push(BlockStateRow {
            block_hash,
            height,
            sprout_root: root,
            sprout_frontier: self.tree.encode(),
            chain_sprout_value: self.chain_sprout_value,
            chain_sapling_value: self.chain_sapling_value,
        });
        Ok(())
    }

    pub fn flush(&self, db: &Transaction<'_>) -> Result<()> {
        let mut nf = db.prepare_cached("INSERT OR REPLACE INTO sprout_nullifiers(n,height) VALUES(?1,?2)")?;
        for (n, h) in &self.batch_nullifiers {
            nf.execute(params![n.as_slice(), *h as i64])?;
        }
        let mut st = db.prepare_cached(
            "INSERT OR REPLACE INTO block_state(block_hash,height,sprout_root,sprout_frontier,chain_sprout_value,chain_sapling_value)
             VALUES(?1,?2,?3,?4,?5,?6)",
        )?;
        for r in &self.rows {
            st.execute(params![
                r.block_hash.as_slice(),
                r.height as i64,
                r.sprout_root.as_slice(),
                &r.sprout_frontier,
                r.chain_sprout_value,
                r.chain_sapling_value,
            ])?;
        }
        Ok(())
    }
}

fn txid_display(txid: &[u8; 32]) -> String {
    txid.iter().rev().map(|b| format!("{b:02x}")).collect()
}

/// Per-block accumulator for fees, sigops and the coinbase amount.
pub struct BlockConnector {
    pub height: u64,
    pub consensus_branch_id: u32,
    pub verify_scripts: bool,
    fees: i64,
    sigops: u64,
    coinbase_value_out: i64,
}

impl BlockConnector {
    pub fn new(height: u64, verify_scripts: bool) -> Self {
        Self {
            height,
            consensus_branch_id: ycash_consensus::consensus_branch_id(height),
            verify_scripts,
            fees: 0,
            sigops: 0,
            coinbase_value_out: 0,
        }
    }

    /// Validate `tx` against the view, then connect it (spend inputs, add
    /// outputs, apply Sprout effects). Order follows `ConnectBlock`.
    pub fn connect_tx(
        &mut self,
        db: &Transaction<'_>,
        coins: &mut CoinsView,
        sprout: &mut SproutView,
        tx: &ParsedTransaction,
        txid: &[u8; 32],
    ) -> Result<()> {
        let h = self.height;
        let coinbase = is_coinbase(tx);

        self.sigops += ycash_script::legacy_sig_op_count(tx) as u64;
        if self.sigops > MAX_BLOCK_SIGOPS {
            bail!("bad-blk-sigops at height {h}");
        }
        if coins.has_unspent_outputs_of(db, txid)? {
            bail!("bad-txns-BIP30: tx {} at height {h}", txid_display(txid));
        }

        if coinbase {
            self.coinbase_value_out = tx_value_out(tx).map_err(|e| anyhow!("{e:?}"))?;
        } else {
            let mut prevouts = Vec::with_capacity(tx.vin.len());
            for input in &tx.vin {
                let op = (input.prev_txid, input.prev_index);
                let coin = coins.get(db, &op)?.ok_or_else(|| {
                    anyhow!(
                        "bad-txns-inputs-missingorspent: tx {} spends {}:{} at height {h}",
                        txid_display(txid),
                        txid_display(&input.prev_txid),
                        input.prev_index
                    )
                })?;
                prevouts.push(coin);
            }

            sprout.check_requirements(db, tx)?;

            for (input, coin) in tx.vin.iter().zip(&prevouts) {
                if ycash_script::is_pay_to_script_hash(&coin.script) {
                    self.sigops += ycash_script::p2sh_sig_op_count(&coin.script, &input.script_sig) as u64;
                }
            }
            if self.sigops > MAX_BLOCK_SIGOPS {
                bail!("bad-blk-sigops at height {h}");
            }

            // Consensus::CheckTxInputs
            let mut value_in: i64 = 0;
            for coin in &prevouts {
                if coin.coinbase {
                    if (h as i64) - (coin.height as i64) < COINBASE_MATURITY as i64 {
                        bail!("bad-txns-premature-spend-of-coinbase: tx {} at height {h}", txid_display(txid));
                    }
                    if !tx.vout.is_empty() {
                        bail!("bad-txns-coinbase-spend-has-transparent-outputs: tx {} at height {h}", txid_display(txid));
                    }
                }
                value_in = value_in
                    .checked_add(coin.value)
                    .filter(|v| money_range(coin.value) && money_range(*v))
                    .ok_or_else(|| anyhow!("bad-txns-inputvalues-outofrange at height {h}"))?;
            }
            value_in = value_in
                .checked_add(tx_shielded_value_in(tx).map_err(|e| anyhow!("{e:?}"))?)
                .filter(|v| money_range(*v))
                .ok_or_else(|| anyhow!("bad-txns-inputvalues-outofrange at height {h}"))?;
            let value_out = tx_value_out(tx).map_err(|e| anyhow!("{e:?}"))?;
            if value_in < value_out {
                bail!("bad-txns-in-belowout: tx {} at height {h} ({value_in} < {value_out})", txid_display(txid));
            }
            self.fees = self
                .fees
                .checked_add(value_in - value_out)
                .filter(|v| money_range(*v))
                .ok_or_else(|| anyhow!("bad-txns-fee-outofrange at height {h}"))?;

            if self.verify_scripts {
                let pre = if tx.overwintered { Some(ycash_script::PrecomputedTxData::new(tx)) } else { None };
                for (i, (input, coin)) in tx.vin.iter().zip(&prevouts).enumerate() {
                    let checker = ycash_script::TransactionChecker {
                        tx,
                        n_in: i,
                        amount: coin.value,
                        consensus_branch_id: self.consensus_branch_id,
                        precomputed: pre.as_ref(),
                    };
                    ycash_script::verify_script(
                        &input.script_sig,
                        &coin.script,
                        ycash_script::BLOCK_SCRIPT_VERIFY_FLAGS,
                        &checker,
                    )
                    .map_err(|e| {
                        anyhow!(
                            "mandatory-script-verify-flag-failed ({e:?}): tx {} input {i} at height {h}",
                            txid_display(txid)
                        )
                    })?;
                }
            }

            for input in &tx.vin {
                coins.spend(&(input.prev_txid, input.prev_index), h);
            }
        }

        for (n, out) in tx.vout.iter().enumerate() {
            if !ycash_script::is_unspendable(&out.script_pubkey) {
                coins.add(
                    (*txid, n as u32),
                    Coin { value: out.value, script: out.script_pubkey.clone(), height: h, coinbase },
                );
            }
        }
        sprout.apply(tx, h)?;
        Ok(())
    }

    /// `bad-cb-amount`: coinbase may claim at most subsidy + fees.
    pub fn finish(&self) -> Result<()> {
        let limit = self
            .fees
            .checked_add(block_subsidy(self.height))
            .ok_or_else(|| anyhow!("block reward overflow"))?;
        if self.coinbase_value_out > limit {
            bail!(
                "bad-cb-amount at height {}: coinbase pays {} > subsidy+fees {}",
                self.height,
                self.coinbase_value_out,
                limit
            );
        }
        Ok(())
    }
}
