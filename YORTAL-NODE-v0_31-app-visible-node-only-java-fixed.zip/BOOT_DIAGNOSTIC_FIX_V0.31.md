# YORTAL v0.31 boot/status diagnostic fix

## Problem
The Android UI previously reported only `status API :8834 not responding`. The native node opened RocksDB before binding the status API, so a slow/failing database open and a native executable/linker failure were indistinguishable from an API failure.

## Changes
- Status API `127.0.0.1:8834` now binds before RocksDB is opened.
- `/status` remains available while RocksDB is opening.
- `/export` returns HTTP 503 with `database_opening` until the database is ready.
- Added explicit native `boot_stage`, `boot_started_unix`, and `native_pid` fields to `/status`.
- Added native boot-stage log markers:
  - `PROCESS_START`
  - `STATUS_API_READY`
  - `DATABASE_OPEN_BEGIN`
  - `DATABASE_OPEN_READY`
  - `DATABASE_OPEN_FAILED`
  - `RPC_READY`
  - `LIGHTWALLET_START`
  - `SHIELDED_PARAMS_DONE`
  - `RUNNING`
  - listener failure stages where applicable
- If RocksDB, RPC, or P2P startup fails, the native process keeps the status API alive and exposes the actual error instead of exiting immediately.
- Android `NodeService` records the native executable path, DB path, and native process PID in `node.log`.
- Android startup polling now distinguishes:
  - native process stopped
  - native process alive but status API unavailable
  - normal native boot stages
- When the API is unavailable after repeated polls, Android automatically reads `node.log` and `app-error.log` so the native startup error is visible.
- The Diagnostics panel displays the native boot stage and PID.

## Consensus / sync safety
This change is diagnostic/startup plumbing only. It does not change block validation rules, consensus rules, chain selection, canonical commit ordering, or the pipeline's validation/commit semantics.

## Expected next-run behavior
Instead of immediately showing `NODE NOT RESPONDING`, the app should expose a stage such as:

`DATABASE_OPENING`

with a message such as:

`boot: status API ready; opening RocksDB`

If the database fails, the status API should remain reachable and report:

`DATABASE_OPEN_FAILED`

plus the concrete RocksDB error in `last_error` and `node.log`.
