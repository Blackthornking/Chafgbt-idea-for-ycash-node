#!/usr/bin/env bash
# Verify the actual APK, not merely the pre-packaging jniLibs directory.
# This is the final release gate for the RocksDB C++ runtime dependency.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APK="${1:-$ROOT/android-app/app/build/outputs/apk/release/app-release.apk}"

[[ -f "$APK" ]] || { echo "FAIL: APK does not exist: $APK" >&2; exit 1; }
command -v unzip >/dev/null 2>&1 || { echo "FAIL: unzip is required for APK verification" >&2; exit 1; }

entries="$(unzip -Z1 "$APK")"
for required in \
  "lib/arm64-v8a/libycashandroidnode.so" \
  "lib/arm64-v8a/libc++_shared.so"; do
  grep -Fxq "$required" <<< "$entries" || {
    echo "FAIL: APK is missing required native runtime: $required" >&2
    echo "APK: $APK" >&2
    exit 1
  }
done

# Refuse unexpected legacy packaging of the node as an app asset.
if grep -Eq '^assets/(ycash-android-node|libc\+\+_shared\.so)$' <<< "$entries"; then
  echo "FAIL: legacy asset packaging detected; native runtime must live under lib/arm64-v8a/." >&2
  exit 1
fi

# Extract only to a temporary directory when readelf is available, so the ELF
# dependency can be checked against the exact bytes that are in the APK.
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
unzip -p "$APK" lib/arm64-v8a/libycashandroidnode.so > "$tmp/libycashandroidnode.so"
unzip -p "$APK" lib/arm64-v8a/libc++_shared.so > "$tmp/libc++_shared.so"

if command -v file >/dev/null 2>&1; then
  node_desc="$(file -b "$tmp/libycashandroidnode.so")"
  cxx_desc="$(file -b "$tmp/libc++_shared.so")"
  [[ "$node_desc" == *ELF* && ( "$node_desc" == *aarch64* || "$node_desc" == *ARM64* ) ]] || { echo "FAIL: APK node is not ARM64 ELF: $node_desc" >&2; exit 1; }
  [[ "$node_desc" == *executable* || "$node_desc" == *pie* ]] || { echo "FAIL: APK node is not an executable ELF: $node_desc" >&2; exit 1; }
  [[ "$cxx_desc" == *ELF* && ( "$cxx_desc" == *aarch64* || "$cxx_desc" == *ARM64* ) ]] || { echo "FAIL: APK libc++_shared.so is not ARM64 ELF: $cxx_desc" >&2; exit 1; }
fi

if command -v readelf >/dev/null 2>&1; then
  readelf -d "$tmp/libycashandroidnode.so" | grep -q 'libc++_shared.so' || {
    echo "FAIL: APK's exact node ELF does not declare libc++_shared.so." >&2
    exit 1
  }
fi

echo "PASS: APK contains both ARM64 node and libc++_shared.so, and the packaged node declares the dependency."
