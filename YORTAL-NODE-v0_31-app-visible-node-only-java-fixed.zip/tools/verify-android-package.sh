#!/usr/bin/env bash
# Fail fast if the Android source tree cannot produce a node-capable APK.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LIB="$ROOT/android-app/app/src/main/jniLibs/arm64-v8a/libycashandroidnode.so"

[[ -f "$LIB" ]] || { echo "FAIL: missing $LIB"; exit 1; }
[[ -x "$LIB" ]] || { echo "FAIL: native node is not executable"; exit 1; }

if command -v file >/dev/null 2>&1; then
  DESC="$(file -b "$LIB")"
  echo "$DESC"
  [[ "$DESC" == *ELF* ]] || { echo "FAIL: not an ELF"; exit 1; }
  [[ "$DESC" == *aarch64* || "$DESC" == *ARM64* ]] || { echo "FAIL: not ARM64"; exit 1; }
  [[ "$DESC" == *executable* || "$DESC" == *pie* ]] || { echo "FAIL: not an executable ELF"; exit 1; }
fi

grep -q "libycashandroidnode.so" "$ROOT/android-app/app/build.gradle"
grep -q "nativeLibraryDir" "$ROOT/android-app/app/src/main/java/com/ycash/androidnode/NodeService.java"
! test -f "$ROOT/android-app/app/src/main/jniLibs/arm64-v8a/PLACE_BINARY_HERE.md"

# RocksDB (since v0.31) pulls in the NDK C++ runtime. libc++_shared.so must be
# packaged next to the executable or the device linker fails with
# "CANNOT LINK EXECUTABLE" before the node opens any ports. See
# tools/package-node-binary.sh for where this is installed.
LIBCXX="$ROOT/android-app/app/src/main/jniLibs/arm64-v8a/libc++_shared.so"
[[ -f "$LIBCXX" ]] || { echo "FAIL: missing $LIBCXX (RocksDB needs the NDK C++ runtime bundled alongside the node binary)"; exit 1; }
if command -v file >/dev/null 2>&1; then
  DESC_CXX="$(file -b "$LIBCXX")"
  [[ "$DESC_CXX" == *ELF* && ( "$DESC_CXX" == *aarch64* || "$DESC_CXX" == *ARM64* ) ]] || { echo "FAIL: $LIBCXX is not an ARM64 ELF: $DESC_CXX"; exit 1; }
fi
if command -v readelf >/dev/null 2>&1; then
  # The RocksDB-backed node must declare the runtime dependency that this guard
  # is packaging. Do not downgrade this to a warning: a future build must not
  # silently change the runtime contract and ship an unverified APK.
  readelf -d "$LIB" 2>/dev/null | grep -q "libc++_shared.so" || {
    echo "FAIL: $LIB does not declare DT_NEEDED for libc++_shared.so; refusing to package an unverified node." >&2
    exit 1
  }
fi

"$ROOT/tools/verify-script-pool.sh"

echo "PASS: Android ARM64 node package is present, wired to NodeService, and uses the consensus-safe script pool."
