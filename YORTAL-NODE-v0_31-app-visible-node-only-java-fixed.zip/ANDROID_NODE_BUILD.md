# Android node build and packaging

## Root cause fixed

The APK must contain the Rust ARM64 executable at:

`android-app/app/src/main/jniLibs/arm64-v8a/libycashandroidnode.so`

`NodeService` now **only** executes that PackageManager-installed native binary. It no longer copies an asset into `getFilesDir()` and tries to `chmod`/execute it.

## Build the native node

Install Rust/rustup and an Android SDK/NDK, then run from the repository root:

```bash
export ANDROID_NDK_ROOT=/path/to/android-sdk/ndk/<version>
tools/build-android-arm64.sh
```

The script:

1. installs the `aarch64-linux-android` Rust target;
2. selects the Android API 35 NDK clang linker;
3. builds `ycash-android-node` in release mode;
4. installs it as `libycashandroidnode.so` under `jniLibs/arm64-v8a`;
5. copies `libc++_shared.so` from the same NDK toolchain into `jniLibs/arm64-v8a` (see "v0.31 RocksDB backend" below -- required, not optional);
6. removes the old placeholder file.

## Build the APK

This source export does not include the generated Gradle wrapper JAR, so use an installed Gradle 8.10.2 (or let CI install it):

```bash
cd android-app
gradle assembleRelease --no-daemon
```

Before building, verify the native package:

```bash
cd ..
tools/verify-android-package.sh
```

## Runtime behaviour

The Activity now shows `STARTING` immediately after pressing **START NODE**. It changes to the Rust node's real status only after `127.0.0.1:8834/status` responds. This avoids displaying a false `RUNNING` state while the process is still starting or has already failed.

## v0.31 RocksDB backend

The state backend is RocksDB. Android builds therefore require the NDK C/C++ toolchain used by `librocksdb-sys`; `tools/build-android-arm64.sh` exports the target `CC`/`CXX` tools before invoking Cargo. The node database is a directory named `ycash-node.rocksdb`.

**This also means the built executable has a runtime dependency on the NDK's C++ runtime, `libc++_shared.so`.** Because the node is packaged as a fake "native library" (see above) rather than a real JNI `.so`, Gradle has no other reason to bundle that runtime -- there's no other native code in this app that would normally pull it in. `tools/package-node-binary.sh` now copies `libc++_shared.so` from the NDK sysroot into `jniLibs/arm64-v8a` next to the binary; `tools/verify-android-package.sh` fails the build if it's missing. Skipping this step produces an APK that installs fine but whose node crashes on launch with `CANNOT LINK EXECUTABLE` in logcat, before the P2P/status ports ever open.
