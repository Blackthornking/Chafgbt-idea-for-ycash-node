use std::sync::Arc;
use tokio::sync::mpsc;
use tokio_stream::wrappers::ReceiverStream;
use tonic::{Request, Response, Status};
use ycash_state::State;

pub mod proto { tonic::include_proto!("cash.z.wallet.sdk.rpc"); }
use proto::compact_tx_streamer_server::{CompactTxStreamer, CompactTxStreamerServer};
use proto::{BlockId, BlockRange, ChainSpec, CompactBlock, Empty, LightdInfo};

#[derive(Clone)]
pub struct LightwalletService {
    db: Arc<State>,
}

impl LightwalletService {
    pub fn new(db: Arc<State>) -> Self { Self { db } }

    fn block(&self, height: u64) -> Result<CompactBlock, Status> {
        let raw = self.db.header_by_height(height)
            .map_err(|e| Status::internal(format!("header lookup failed: {e}")))?
            .ok_or_else(|| Status::not_found(format!("block header {height} not available")))?;
        let header = ycash_chain::read_header_at(&mut std::io::Cursor::new(&raw), height)
            .map_err(|e| Status::internal(format!("header decode failed: {e}")))?;
        let hash = header.hash();
        let prev = header.prev.to_vec();
        Ok(CompactBlock {
            height,
            hash: hash.to_vec(),
            prev_hash: prev,
            time: header.time,
            header: raw,
            vtx: Vec::new(),
            chain_metadata: None,
        })
    }
}

#[tonic::async_trait]
impl CompactTxStreamer for LightwalletService {
    async fn get_latest_block(&self, _request: Request<ChainSpec>) -> Result<Response<BlockId>, Status> {
        let height = self.db.header_height()
            .map_err(|e| Status::internal(format!("tip lookup failed: {e}")))?
            .unwrap_or(0);
        let hash = if height == 0 {
            ycash_chain::genesis_hash_internal().to_vec()
        } else {
            self.db.header_hash_by_height(height)
                .map_err(|e| Status::internal(format!("tip hash lookup failed: {e}")))?
                .unwrap_or_else(|| ycash_chain::genesis_hash_internal().to_vec())
        };
        Ok(Response::new(BlockId { height, hash }))
    }

    async fn get_block(&self, request: Request<BlockId>) -> Result<Response<CompactBlock>, Status> {
        let id = request.into_inner();
        let height = if id.height != 0 {
            id.height
        } else {
            return Err(Status::invalid_argument("GetBlock currently requires a block height"));
        };
        Ok(Response::new(self.block(height)?))
    }

    type GetBlockRangeStream = ReceiverStream<Result<CompactBlock, Status>>;

    async fn get_block_range(&self, request: Request<BlockRange>) -> Result<Response<Self::GetBlockRangeStream>, Status> {
        let range = request.into_inner();
        let start = range.start.map(|x| x.height).unwrap_or(0);
        let end = range.end.map(|x| x.height).unwrap_or(start);
        if start == 0 || end == 0 {
            return Err(Status::invalid_argument("GetBlockRange requires non-zero start/end heights"));
        }
        let (tx, rx) = mpsc::channel(8);
        let db = self.db.clone();
        tokio::spawn(async move {
            let step_up = start <= end;
            let mut h = start;
            loop {
                let svc = LightwalletService { db: db.clone() };
                let result = svc.block(h);
                if tx.send(result).await.is_err() { break; }
                if h == end { break; }
                h = if step_up { h.saturating_add(1) } else { h.saturating_sub(1) };
            }
        });
        Ok(Response::new(ReceiverStream::new(rx)))
    }

    async fn get_lightd_info(&self, _request: Request<Empty>) -> Result<Response<LightdInfo>, Status> {
        let height = self.db.header_height().map_err(|e| Status::internal(e.to_string()))?.unwrap_or(0);
        Ok(Response::new(LightdInfo {
            version: "ycash-android-node-0.19.4".into(),
            vendor: "Ycash".into(),
            taddr_support: true,
            chain_name: "main".into(),
            sapling_activation_height: 419200,
            consensus_branch_id: "".into(),
            block_height: height,
            git_commit: "android-node".into(),
            branch: "main".into(),
            build_date: "".into(),
            build_user: "".into(),
            estimated_height: height,
            zcashd_build: "ycash-android-node".into(),
            zcashd_subversion: "/YcashAndroid:0.19.4/".into(),
            donation_address: "".into(),
            upgrade_name: "".into(),
            upgrade_height: 0,
            lightwallet_protocol_version: "compact-tx-streamer".into(),
        }))
    }
}

pub fn start(db: Arc<State>, state: crate::runtime::SharedState) -> std::io::Result<()> {
    let bind = std::env::var("YCASH_LIGHTWALLETD_BIND").unwrap_or_else(|_| "127.0.0.1".into());
    let port = std::env::var("YCASH_LIGHTWALLETD_PORT").ok().and_then(|x| x.parse().ok()).unwrap_or(9067u16);
    let addr = format!("{}:{}", bind, port).parse().map_err(|e: std::net::AddrParseError| std::io::Error::new(std::io::ErrorKind::InvalidInput, e.to_string()))?;
    let rt = tokio::runtime::Builder::new_multi_thread().enable_all().build()
        .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))?;
    let listener = rt.block_on(tokio::net::TcpListener::bind(addr))?;
    {
        let mut s = state.write().unwrap();
        s.lightwalletd_listening = true;
        s.message = format!("YWallet gRPC listening on {}:{}", bind, port);
    }
    std::thread::spawn(move || {
        let incoming = tokio_stream::wrappers::TcpListenerStream::new(listener);
        let service = LightwalletService::new(db);
        rt.block_on(async move {
            let result = tonic::transport::Server::builder()
                .add_service(CompactTxStreamerServer::new(service))
                .serve_with_incoming(incoming)
                .await;
            if let Err(e) = result {
                let mut s = state.write().unwrap();
                s.lightwalletd_listening = false;
                s.last_error = format!("YWallet gRPC server stopped: {e}");
                s.connection_detail = format!("Lightwalletd 9067 stopped: {e}");
            }
        });
    });
    Ok(())
}
