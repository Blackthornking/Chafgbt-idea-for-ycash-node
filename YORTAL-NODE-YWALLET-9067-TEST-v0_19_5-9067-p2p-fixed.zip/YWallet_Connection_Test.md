# YWallet / Lightwalletd connection diagnostics

The app tests the entered endpoint in layers: DNS, TCP, TLS 1.3/cipher, ALPN h2, HTTP/2 SETTINGS, then the standard gRPC `CompactTxStreamer/GetLatestBlock` call. It also reports RST_STREAM and GOAWAY error codes and now sends standard `grpc-accept-encoding` and diagnostic user-agent headers.

For Ycash, the documented lightwalletd endpoint is `https://lite.ycash.xyz:9067`. The gRPC service uses the standard `cash.z.wallet.sdk.rpc.CompactTxStreamer` service and `GetLatestBlock` method.

The Android node's own ports are separate: P2P 8833, JSON-RPC 8832, and localhost status API 8834. The status API is HTTP on loopback only; Android cleartext is explicitly enabled so the app can poll `127.0.0.1:8834/status`.


## v0.19.4 fixes

- P2P discovery now prioritizes `seed.ycash.xyz:8833` and previously successful `peers.dat` entries.
- The two Ycash 4.5.0 fixed seeds are fallback-only and can be enabled for diagnostics with `YCASH_LEGACY_FIXED_SEEDS=1`.
- P2P handshake status is now staged as TCP CONNECT, VERSION SEND/RECV, VERACK SEND/RECV, handshake PASS, and session/sync failures.
- Inbound P2P connections now parse complete Ycash frames after the handshake instead of consuming the stream one byte at a time.
- The Lightwalletd diagnostic sends a standards-compliant unary `CompactTxStreamer/GetLatestBlock` gRPC request over HTTP/2, including `grpc-timeout` immediately after the reserved headers, and reports HTTP/2/RST/GOAWAY/EOF stages.


## Android node local Lightwalletd service

The Android node now binds a native gRPC CompactTxStreamer endpoint on `127.0.0.1:9067` by default. The endpoint is plaintext HTTP/2 for local testing; the YWallet connection test should therefore use TLS **off** for `127.0.0.1:9067`. The node exposes `GetLatestBlock`, `GetBlock`, `GetBlockRange`, and `GetLightdInfo` for diagnostics and initial chain/tip testing.

The node's P2P protocol version is `270014`, matching current Ycash mainnet parameters. The outbound P2P session sends exactly one VERSION message before waiting for VERSION/VERACK.

The 9067 implementation is intentionally marked as a compatibility/testing endpoint: compact blocks currently contain the validated header but do not yet populate shielded/transparent transaction entries. A successful 9067 connection therefore proves the gRPC transport and chain-tip interface, but is not by itself proof that a wallet can complete transaction scanning.
