//! Transport: peer bookkeeping and the streaming block downloader.
//!
//! The downloader owns one rule and nothing else: at most
//! [`MAX_BLOCKS_IN_TRANSIT_PER_PEER`] outstanding block requests per peer, with
//! a slot replenished the moment a block arrives rather than when a whole group
//! completes. It never declares a block valid and never chooses the canonical
//! chain.
//!
//! There are no ranges here. A range makes the slowest block in a group hold up
//! the other 47; streaming requests do not, which is the single biggest
//! throughput difference against the design it replaces.

use std::collections::{HashMap, HashSet};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use anyhow::{anyhow, Result};
use crate::peer_manager::PeerManager;
use ycash_state::state_service::SyncMetrics;
use ycash_state::State;

/// Outstanding block requests allowed per peer. Transport backpressure only:
/// changing it changes throughput and memory, never consensus acceptance.
pub const MAX_BLOCKS_IN_TRANSIT_PER_PEER: usize = 48;

/// Global ceiling on blocks claimed but not yet canonical. Resource bound.
pub const MAX_BLOCKS_IN_FLIGHT: usize = 192;

/// A peer that sends nothing for a requested block this long loses the claim,
/// so the hash can be requested from someone else. The block is not rejected:
/// a failed download never poisons a hash.
pub const REQUEST_TIMEOUT: Duration = Duration::from_secs(90);

/// One block the downloader has asked for, with the header-derived context its
/// semantic verification needs. Gathering this in bulk at assignment time keeps
/// the verifier threads off the database entirely.
#[derive(Clone, Debug)]
pub struct BlockRequest {
    pub height: u64,
    pub hash: [u8; 32],
    /// Cumulative chain work at this height, from the verified header chain.
    pub work: [u8; 32],
    /// Median time past, as consensus defines it for this height.
    pub median_time_past: u32,
}

/// Global claim registry: the same block hash is never in flight twice, and the
/// total number of claimed blocks stays bounded.
pub struct InFlightRegistry {
    claimed: Mutex<HashSet<[u8; 32]>>,
    capacity: usize,
    pub duplicates: AtomicU64,
}

impl InFlightRegistry {
    pub fn new(capacity: usize) -> Self {
        Self { claimed: Mutex::new(HashSet::new()), capacity: capacity.max(1), duplicates: AtomicU64::new(0) }
    }

    pub fn len(&self) -> usize {
        self.claimed.lock().map(|c| c.len()).unwrap_or(0)
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    pub fn spare_capacity(&self) -> usize {
        self.capacity.saturating_sub(self.len())
    }

    /// Claim a hash. Fails if it is already claimed or the global bound is hit.
    pub fn claim(&self, hash: [u8; 32]) -> bool {
        let Ok(mut claimed) = self.claimed.lock() else { return false };
        if claimed.len() >= self.capacity {
            return false;
        }
        if !claimed.insert(hash) {
            self.duplicates.fetch_add(1, Ordering::Relaxed);
            return false;
        }
        true
    }

    /// Release a claim so the hash can be requested again later.
    pub fn release(&self, hash: &[u8; 32]) {
        if let Ok(mut claimed) = self.claimed.lock() {
            claimed.remove(hash);
        }
    }
}

/// Chooses which blocks to request next, from the verified header chain above
/// the canonical tip.
///
/// Header ancestry decides only what is *worth asking for*. The state service
/// remains the authority on validity, so a wrong guess here costs bandwidth and
/// nothing else.
pub struct BlockAssigner {
    state: Arc<State>,
    registry: Arc<InFlightRegistry>,
    metrics: Arc<SyncMetrics>,
    cursor: Mutex<u64>,
}

impl BlockAssigner {
    pub fn new(state: Arc<State>, registry: Arc<InFlightRegistry>, metrics: Arc<SyncMetrics>) -> Self {
        Self { state, registry, metrics, cursor: Mutex::new(0) }
    }

    /// Reset the scan position to just above the canonical tip. Called after a
    /// commit run or a reorganisation so skipped heights are revisited.
    pub fn rewind_to_canonical(&self) -> Result<()> {
        let tip = self.state.tip_height()?.unwrap_or(0);
        if let Ok(mut cursor) = self.cursor.lock() {
            *cursor = tip;
        }
        Ok(())
    }

    /// Claim up to `want` blocks for one peer, with their verification context
    /// read in bulk.
    pub fn assign(&self, want: usize) -> Result<Vec<BlockRequest>> {
        let want = want.min(self.registry.spare_capacity());
        if want == 0 {
            return Ok(Vec::new());
        }
        let canonical = self.state.tip_height()?.unwrap_or(0);
        let header_tip = self.state.header_height()?.unwrap_or(0);
        self.metrics.raise_header_height(header_tip);
        if header_tip <= canonical {
            return Ok(Vec::new());
        }

        let mut cursor = {
            let Ok(mut c) = self.cursor.lock() else { return Ok(Vec::new()) };
            if *c < canonical {
                *c = canonical;
            }
            *c
        };

        // Scan a bounded window so a run of already-claimed heights cannot make
        // this loop unbounded.
        let start = cursor + 1;
        let end = (start + (MAX_BLOCKS_IN_FLIGHT as u64) * 2).min(header_tip);
        if start > end {
            // Everything in the window is claimed; wait for it to drain.
            return Ok(Vec::new());
        }

        let hashes = self.state.header_hashes_range(start, end)?;
        let works = self.state.header_works_range(start, end)?;
        let mtps = median_time_past_range(&self.state, start, end)?;

        let mut out = Vec::with_capacity(want);
        for height in start..=end {
            if out.len() >= want {
                break;
            }
            let (Some(hash), Some(work)) = (hashes.get(&height).copied(), works.get(&height).copied()) else {
                break;
            };
            cursor = height;
            if !self.registry.claim(hash) {
                continue;
            }
            out.push(BlockRequest {
                height,
                hash,
                work,
                median_time_past: mtps.get(&height).copied().unwrap_or(0),
            });
        }
        if let Ok(mut c) = self.cursor.lock() {
            if cursor > *c {
                *c = cursor;
            }
        }
        Ok(out)
    }
}

/// Median time past for every height in `start..=end`, from one range read.
///
/// This is the same quantity the consensus layer expects; computing it in bulk
/// here is a database-access optimisation, not a rule change.
pub fn median_time_past_range(state: &State, start: u64, end: u64) -> Result<HashMap<u64, u32>> {
    let from = start.saturating_sub(11).max(1);
    let times: HashMap<u64, u32> = state.header_times_range(from, end)?.into_iter().collect();
    let mut out = HashMap::new();
    for height in start..=end {
        let floor = height.saturating_sub(11);
        let mut window = Vec::with_capacity(11);
        if floor == 0 && height > 0 {
            window.push(ycash_consensus::GENESIS_TIME);
        }
        for h in floor.max(1)..height {
            if let Some(t) = times.get(&h) {
                window.push(*t);
            }
        }
        let median = if window.is_empty() {
            0
        } else {
            window.sort_unstable();
            window[window.len() / 2]
        };
        out.insert(height, median);
    }
    Ok(out)
}

/// One peer's outstanding requests.
pub struct PeerDownloadSession {
    peer: String,
    assigner: Arc<BlockAssigner>,
    registry: Arc<InFlightRegistry>,
    peers: Arc<PeerManager>,
    metrics: Arc<SyncMetrics>,
    in_flight: HashMap<[u8; 32], (BlockRequest, Instant)>,
    limit: usize,
}

impl PeerDownloadSession {
    pub fn new(
        peer: impl Into<String>,
        assigner: Arc<BlockAssigner>,
        registry: Arc<InFlightRegistry>,
        peers: Arc<PeerManager>,
        metrics: Arc<SyncMetrics>,
    ) -> Self {
        let peer = peer.into();
        peers.connected(&peer);
        Self {
            peer,
            assigner,
            registry,
            peers,
            metrics,
            in_flight: HashMap::new(),
            limit: MAX_BLOCKS_IN_TRANSIT_PER_PEER,
        }
    }

    /// Override the per-peer transport limit. Provided so the same chain can be
    /// synchronised at 16, 48 or 64 blocks per peer and compared: consensus
    /// results must be identical.
    pub fn with_limit(mut self, limit: usize) -> Self {
        self.limit = limit.clamp(1, MAX_BLOCKS_IN_TRANSIT_PER_PEER);
        self
    }

    pub fn peer(&self) -> &str {
        &self.peer
    }

    pub fn in_flight(&self) -> usize {
        self.in_flight.len()
    }

    /// Fill the peer's request window back up to the limit. Returns the hashes
    /// to put in a `getdata`, which is empty when the window is full, the global
    /// bound is reached, or the header chain has nothing further to offer.
    pub fn top_up(&mut self) -> Result<Vec<[u8; 32]>> {
        debug_assert!(self.in_flight.len() <= self.limit);
        let free = self.limit.saturating_sub(self.in_flight.len());
        if free == 0 {
            return Ok(Vec::new());
        }
        let assigned = self.assigner.assign(free)?;
        let mut hashes = Vec::with_capacity(assigned.len());
        let now = Instant::now();
        for request in assigned {
            hashes.push(request.hash);
            self.metrics.raise_download_height(request.height);
            self.in_flight.insert(request.hash, (request, now));
        }
        if !hashes.is_empty() {
            let count = hashes.len() as u64;
            self.peers.update(&self.peer, |s| {
                s.in_flight = self.in_flight.len();
                s.requested = s.requested.saturating_add(count);
            });
            self.metrics
                .blocks_in_flight_total
                .store(self.peers.total_in_flight() as u64, Ordering::Relaxed);
        }
        Ok(hashes)
    }

    /// A block arrived. Frees exactly one slot, immediately: the caller tops up
    /// again without waiting for the other 47.
    pub fn on_block(&mut self, hash: &[u8; 32], bytes: usize) -> Option<BlockRequest> {
        let (request, _) = self.in_flight.remove(hash)?;
        self.registry.release(hash);
        self.peers.update(&self.peer, |s| {
            s.in_flight = self.in_flight.len();
            s.received = s.received.saturating_add(1);
        });
        self.metrics.blocks_downloaded.fetch_add(1, Ordering::Relaxed);
        self.metrics.last_received_height.fetch_max(request.height, Ordering::Relaxed);
        self.metrics.bytes_downloaded.fetch_add(bytes as u64, Ordering::Relaxed);
        self.metrics
            .blocks_in_flight_total
            .store(self.peers.total_in_flight() as u64, Ordering::Relaxed);
        Some(request)
    }

    /// Drop claims this peer has not delivered in time, so another peer can
    /// fetch them.
    pub fn expire_stale(&mut self, timeout: Duration) -> usize {
        let now = Instant::now();
        let stale: Vec<[u8; 32]> = self
            .in_flight
            .iter()
            .filter(|(_, (_, sent))| now.duration_since(*sent) > timeout)
            .map(|(hash, _)| *hash)
            .collect();
        for hash in &stale {
            self.in_flight.remove(hash);
            self.registry.release(hash);
        }
        if !stale.is_empty() {
            let count = stale.len() as u64;
            self.peers.update(&self.peer, |s| {
                s.in_flight = self.in_flight.len();
                s.timeouts = s.timeouts.saturating_add(count);
            });
            self.metrics.expired_requests.fetch_add(count, Ordering::Relaxed);
            let _ = self.assigner.rewind_to_canonical();
        }
        stale.len()
    }

    /// Give up every claim, e.g. when the connection ends.
    pub fn release_all(&mut self) {
        for hash in self.in_flight.keys() {
            self.registry.release(hash);
        }
        self.in_flight.clear();
        self.peers.disconnected(&self.peer);
        self.metrics
            .blocks_in_flight_total
            .store(self.peers.total_in_flight() as u64, Ordering::Relaxed);
        let _ = self.assigner.rewind_to_canonical();
    }
}

impl Drop for PeerDownloadSession {
    fn drop(&mut self) {
        self.release_all();
    }
}

pub fn not_requested(hash: &[u8; 32]) -> anyhow::Error {
    anyhow!("peer sent a block that was not requested: {}", hex_hash(hash))
}

pub fn hex_hash(hash: &[u8; 32]) -> String {
    let mut s = String::with_capacity(64);
    for b in hash.iter().rev() {
        s.push_str(&format!("{b:02x}"));
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_registry_refuses_a_second_claim_on_one_hash() {
        let registry = InFlightRegistry::new(8);
        assert!(registry.claim([7u8; 32]));
        assert!(!registry.claim([7u8; 32]));
        registry.release(&[7u8; 32]);
        assert!(registry.claim([7u8; 32]));
    }

    #[test]
    fn the_registry_enforces_the_global_bound() {
        let registry = InFlightRegistry::new(2);
        assert!(registry.claim([1u8; 32]));
        assert!(registry.claim([2u8; 32]));
        assert!(!registry.claim([3u8; 32]));
        assert_eq!(registry.spare_capacity(), 0);
        registry.release(&[1u8; 32]);
        assert!(registry.claim([3u8; 32]));
    }

    #[test]
    fn the_per_peer_window_never_exceeds_the_transport_limit() {
        assert_eq!(MAX_BLOCKS_IN_TRANSIT_PER_PEER, 48);
        assert!(MAX_BLOCKS_IN_FLIGHT >= MAX_BLOCKS_IN_TRANSIT_PER_PEER);
    }
}
