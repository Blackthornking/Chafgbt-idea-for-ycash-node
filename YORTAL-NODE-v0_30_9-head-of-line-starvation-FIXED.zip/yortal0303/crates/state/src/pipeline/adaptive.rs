//! YORTAL Adaptive Parallel Sync controller.
//! Consensus-neutral scheduling policy: it only controls concurrency and buffering.

/// One observation of the pipeline. The fields are deliberately *not*
/// interchangeable: they fall into three classes that the controller treats
/// completely differently.
///
/// * Throttling constraints (`cpu_ratio`, `memory_ratio`, `db_queue_ratio`):
///   the device is running out of capacity. Only these may shrink the window
///   or shed workers.
/// * Workload demand (`validation_queue_ratio`): how much validation work is
///   queued. A full queue means there is work *for* the workers, so it must
///   never throttle them.
/// * Growth gate (`network_ratio`): peers are unavailable. It prevents
///   speculative growth but never shrinks what is already buffered.
#[derive(Debug, Clone, Copy)]
pub struct ResourceSample {
    pub cpu_ratio: f64,
    pub memory_ratio: f64,
    pub db_queue_ratio: f64,
    pub network_ratio: f64,
    pub validation_queue_ratio: f64,
}

/// Smoothing factor for the window's view of resource pressure. A single noisy
/// 500 ms sample must not be able to collapse a 2000-block window to the floor.
const PRESSURE_ALPHA: f64 = 0.4;

/// Pressure this extreme bypasses smoothing entirely.
const PRESSURE_EMERGENCY: f64 = 0.98;

impl ResourceSample {
    /// The only signals allowed to reduce concurrency or window size.
    pub fn throttle_pressure(&self) -> f64 {
        self.cpu_ratio
            .max(self.memory_ratio)
            .max(self.db_queue_ratio)
            .clamp(0.0, 1.0)
    }

    /// Queued validation work, as a fraction of the verifier pool. This is
    /// demand, not pressure.
    pub fn demand(&self) -> f64 {
        self.validation_queue_ratio.clamp(0.0, 1.0)
    }

    /// Peers are unavailable or not carrying the planned work.
    pub fn network_stalled(&self) -> bool {
        self.network_ratio >= 0.85
    }
}

#[derive(Debug, Clone, Copy)]
pub struct AdaptiveConfig {
    pub min_window: usize,
    pub initial_window: usize,
    pub max_window: usize,
    pub step: usize,
    pub high_watermark: f64,
    pub low_watermark: f64,
    /// Maximum verifier workers permitted by the sync coordinator.
    pub max_validation_workers: usize,
    /// Maximum simultaneously in-flight ranges behind the ordered commit barrier.
    pub max_inflight_ranges: usize,
    /// Scheduler ceiling for one network range, in blocks. Range sizing stays
    /// adaptive below this; this is the hard upper bound the planner uses.
    pub max_range_len: usize,
}

impl Default for AdaptiveConfig {
    fn default() -> Self {
        Self {
            // Fully adaptive range sizing. The controller may use any range
            // from 1 through 100 blocks; 16 is only the startup point, not a cap.
            min_window: 16,
            initial_window: 100,
            max_window: 2000,
            step: 100,
            high_watermark: 0.90,
            low_watermark: 0.55,
            max_validation_workers: std::thread::available_parallelism().map(|n| n.get().saturating_sub(1).max(1)).unwrap_or(1),
            max_inflight_ranges: std::thread::available_parallelism().map(|n| n.get().saturating_sub(1).max(1) * 2).unwrap_or(2),
            max_range_len: 100,
        }
    }
}

#[derive(Debug, Clone)]
pub struct AdaptiveController {
    cfg: AdaptiveConfig,
    window: usize,
    workers: usize,
    inflight: usize,
    /// Smoothed throttling pressure, used for window sizing only.
    pressure_ewma: f64,
    /// Last observed workload demand, kept for telemetry.
    demand: f64,
}

impl AdaptiveController {
    pub fn new(cfg: AdaptiveConfig) -> Self {
        let window = cfg.initial_window.clamp(cfg.min_window, cfg.max_window);
        let workers = cfg.max_validation_workers.max(1);
        let inflight = cfg.max_inflight_ranges.max(1);
        Self { cfg, window, workers, inflight, pressure_ewma: 0.0, demand: 0.0 }
    }

    /// Smoothed throttling pressure the window controller is currently acting
    /// on (CPU / memory / DB only — never queue depth).
    pub fn smoothed_pressure(&self) -> f64 { self.pressure_ewma }

    /// Last observed validation demand. Reported separately from pressure so
    /// dashboards stop showing "queue 100%" as if it were a constraint.
    pub fn current_demand(&self) -> f64 { self.demand }

    pub fn window(&self) -> usize { self.window }

    /// Maximum verifier workers permitted by the sync coordinator.
    pub fn max_validation_workers(&self) -> usize { self.cfg.max_validation_workers }

    /// Maximum simultaneously in-flight ranges behind the ordered commit barrier.
    pub fn max_inflight_ranges(&self) -> usize { self.cfg.max_inflight_ranges }

    /// Configured window bounds and step. These are the *settings*, as opposed
    /// to `window()` / `current_workers()` / `current_inflight()`, which report
    /// what the pressure controller has picked right now.
    pub fn min_window(&self) -> usize { self.cfg.min_window }

    pub fn max_window(&self) -> usize { self.cfg.max_window }

    pub fn window_step(&self) -> usize { self.cfg.step }

    pub fn max_range_len(&self) -> usize { self.cfg.max_range_len.max(1) }

    pub fn high_watermark(&self) -> f64 { self.cfg.high_watermark }

    pub fn low_watermark(&self) -> f64 { self.cfg.low_watermark }

    pub fn current_workers(&self) -> usize { self.workers.max(1) }

    pub fn current_inflight(&self) -> usize { self.inflight.max(1) }

    /// Current worker budget. The coordinator may spawn a fixed-size pool and
    /// use this value as the number of workers allowed to take jobs. Keeping
    /// the pool fixed avoids thread churn while still adapting useful CPU
    /// concurrency.
    pub fn worker_budget(&self, pressure: f64) -> usize {
        let max = self.cfg.max_validation_workers.max(1);
        if max == 1 { return 1; }
        // Smooth proportional throttling instead of a 1/half/max cliff.
        // This lets an 8-core device use 7 workers when healthy, then shed
        // capacity one worker at a time as CPU/DB/memory pressure rises.
        if pressure >= self.cfg.high_watermark { return 1; }
        if pressure <= self.cfg.low_watermark { return max; }
        let span = (self.cfg.high_watermark - self.cfg.low_watermark).max(f64::EPSILON);
        let fraction = ((self.cfg.high_watermark - pressure) / span).clamp(0.0, 1.0);
        (1.0 + fraction * (max.saturating_sub(1) as f64)).round() as usize
    }

    /// Current range budget. This is derived from the same pressure signal as
    /// the window and is always bounded by the configured safety ceiling.
    pub fn inflight_budget(&self, pressure: f64) -> usize {
        let max = self.cfg.max_inflight_ranges.max(1);
        if max == 1 { return 1; }
        // Preserve at least two independent network opportunities unless the
        // device is at emergency pressure. A single in-flight range is a
        // head-of-line failure domain: one peer closing/stalling can otherwise
        // leave the ordered committer with zero input and freeze sync.
        if pressure >= PRESSURE_EMERGENCY { return 1; }
        if pressure >= self.cfg.high_watermark { return 2.min(max); }
        if pressure <= self.cfg.low_watermark { return max; }
        let span = (self.cfg.high_watermark - self.cfg.low_watermark).max(f64::EPSILON);
        let fraction = ((self.cfg.high_watermark - pressure) / span).clamp(0.0, 1.0);
        ((2.0 + fraction * (max.saturating_sub(2) as f64)).round() as usize)
            .clamp(2, max)
    }

    /// AIMD-like controller.
    ///
    /// The previous version folded every signal into one `max()`, which meant
    /// a *full validation queue* read as *100% pressure* and drove the window
    /// straight down to `min_window`. That is backwards: a full queue is work
    /// available for the workers, not a reason to throttle them. Network
    /// handshake failures collapsed the window the same way.
    ///
    /// The three signal classes are now handled separately:
    ///
    /// ```text
    /// healthy CPU + memory + DB  ->  workers may reach cores - 1
    ///   and validation queue has work
    ///   and peers are reachable  ->  window grows 100 -> 200 -> ... -> max
    /// genuine CPU/memory/DB pressure -> workers and window come back down
    /// ```
    pub fn observe(&mut self, s: ResourceSample) -> usize {
        let raw = s.throttle_pressure();
        self.demand = s.demand();

        // Window sizing uses smoothed pressure, because rebuilding a large
        // window is expensive and a one-off spike is not a trend. Truly
        // extreme pressure bypasses the filter.
        self.pressure_ewma = (PRESSURE_ALPHA * raw) + ((1.0 - PRESSURE_ALPHA) * self.pressure_ewma);
        let window_pressure = if raw >= PRESSURE_EMERGENCY { raw } else { self.pressure_ewma };

        if window_pressure >= self.cfg.high_watermark {
            self.window = self.window.saturating_sub(self.cfg.step.max(1))
                .max(self.cfg.min_window);
        } else if window_pressure <= self.cfg.low_watermark
            && raw <= self.cfg.low_watermark
            && !s.network_stalled()
        {
            // Grow whenever the device is genuinely healthy right now and the
            // network can feed the window: 100 -> 200 -> ... -> max_window.
            //
            // Queue depth deliberately does NOT gate this. The memory cost of
            // running ahead is bounded by `max_inflight_ranges * max_range_len`
            // and is already reported through `db_queue_ratio` as commit
            // backlog, so a genuinely over-buffered pipeline still shrinks --
            // via the signal that actually measures it.
            self.window = (self.window + self.cfg.step.max(1)).min(self.cfg.max_window);
        }

        // Concurrency reacts to instantaneous pressure: shedding and restoring
        // a worker is cheap and immediately reversible, unlike the window.
        self.workers = self.worker_budget(raw);
        self.inflight = self.inflight_budget(raw);
        self.window
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn starts_at_configured_initial_window() {
        let cfg = AdaptiveConfig {
            min_window: 64, initial_window: 256, max_window: 4096,
            step: 128, high_watermark: 0.90, low_watermark: 0.55,
            max_validation_workers: 1, max_inflight_ranges: 20, max_range_len: 100,
        };
        assert_eq!(AdaptiveController::new(cfg).window(), 256);
    }

    #[test]
    fn initial_window_is_clamped() {
        let cfg = AdaptiveConfig {
            min_window: 64, initial_window: 8192, max_window: 4096,
            step: 128, high_watermark: 0.90, low_watermark: 0.55,
            max_validation_workers: 1, max_inflight_ranges: 20, max_range_len: 100,
        };
        assert_eq!(AdaptiveController::new(cfg).window(), 4096);
    }
}

#[cfg(test)]
mod adaptive_pressure_tests {
    use super::*;

    fn cfg() -> AdaptiveConfig {
        AdaptiveConfig {
            min_window: 16, initial_window: 32, max_window: 128, step: 16,
            high_watermark: 0.85, low_watermark: 0.50,
            max_validation_workers: 4, max_inflight_ranges: 4, max_range_len: 100,
        }
    }

    #[test]
    fn low_pressure_enables_full_concurrency() {
        let mut c = AdaptiveController::new(cfg());
        c.observe(ResourceSample { cpu_ratio: 0.20, memory_ratio: 0.20,
            db_queue_ratio: 0.20, network_ratio: 0.20, validation_queue_ratio: 0.20 });
        assert_eq!(c.current_workers(), 4);
        assert_eq!(c.current_inflight(), 4);
        assert_eq!(c.window(), 48);
    }

    #[test]
    fn high_non_emergency_pressure_keeps_two_network_slots() {
        let mut c = AdaptiveController::new(cfg());
        let inflight = c.inflight_budget(0.95);
        assert_eq!(inflight, 2);
    }

    #[test]
    fn emergency_pressure_can_use_single_network_slot() {
        let mut c = AdaptiveController::new(cfg());
        let inflight = c.inflight_budget(0.99);
        assert_eq!(inflight, 1);
    }

    #[test]
    fn high_pressure_reduces_workers_inflight_and_window() {
        let mut c = AdaptiveController::new(cfg());
        c.observe(ResourceSample { cpu_ratio: 0.95, memory_ratio: 0.20,
            db_queue_ratio: 0.20, network_ratio: 0.20, validation_queue_ratio: 0.20 });
        assert_eq!(c.current_workers(), 1);
        assert_eq!(c.current_inflight(), 1);
        assert!(c.window() >= 1 && c.window() <= 100);
    }

    /// The reported bug: a full validation queue was read as full pressure and
    /// drove the window to `min_window` while the device was completely idle.
    #[test]
    fn full_validation_queue_is_demand_not_pressure() {
        let mut c = AdaptiveController::new(cfg());
        for _ in 0..8 {
            c.observe(ResourceSample { cpu_ratio: 0.10, memory_ratio: 0.10,
                db_queue_ratio: 0.10, network_ratio: 0.0, validation_queue_ratio: 1.0 });
        }
        // Workers stay wide open: there is work for every one of them.
        assert_eq!(c.current_workers(), 4);
        assert_eq!(c.current_inflight(), 4);
        // And the window grows instead of collapsing to the 16-block floor.
        assert!(c.window() > 32, "window did not grow: {}", c.window());
    }

    #[test]
    fn healthy_device_grows_the_window_towards_max() {
        let mut c = AdaptiveController::new(cfg());
        for _ in 0..20 {
            c.observe(ResourceSample { cpu_ratio: 0.10, memory_ratio: 0.10,
                db_queue_ratio: 0.10, network_ratio: 0.0, validation_queue_ratio: 0.40 });
        }
        assert_eq!(c.window(), 128);
        assert_eq!(c.current_workers(), 4);
    }

    /// 75% memory *utilisation* is not 75% memory *pressure*; either way the
    /// controller must not treat a below-watermark reading as a reason to cut.
    #[test]
    fn moderate_memory_does_not_shrink_window() {
        let mut c = AdaptiveController::new(cfg());
        let start = c.window();
        for _ in 0..10 {
            c.observe(ResourceSample { cpu_ratio: 0.10, memory_ratio: 0.75,
                db_queue_ratio: 0.10, network_ratio: 0.0, validation_queue_ratio: 0.50 });
        }
        assert!(c.window() >= start, "window shrank from {} to {}", start, c.window());
    }

    #[test]
    fn network_stall_gates_growth_without_shrinking() {
        let mut c = AdaptiveController::new(cfg());
        let start = c.window();
        for _ in 0..10 {
            c.observe(ResourceSample { cpu_ratio: 0.10, memory_ratio: 0.10,
                db_queue_ratio: 0.10, network_ratio: 1.0, validation_queue_ratio: 0.20 });
        }
        assert_eq!(c.window(), start);
        assert_eq!(c.current_workers(), 4);
    }

    #[test]
    fn sustained_cpu_pressure_still_shrinks_the_window() {
        let mut c = AdaptiveController::new(cfg());
        for _ in 0..20 {
            c.observe(ResourceSample { cpu_ratio: 0.99, memory_ratio: 0.10,
                db_queue_ratio: 0.10, network_ratio: 0.0, validation_queue_ratio: 1.0 });
        }
        assert_eq!(c.window(), 16);
        assert_eq!(c.current_workers(), 1);
    }
}
