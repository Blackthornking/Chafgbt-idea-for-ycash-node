//! YORTAL adaptive synchronization components.
//! Adaptive synchronization: range sizing and concurrency respond to resource
//! pressure, while canonical state commitment remains strictly height-ordered.
pub mod adaptive;
pub mod range_scheduler;
pub mod telemetry;

// `pub use` here (not plain `use`) because crates/node and
// crates/ycash-android-node both refer to these as `pipeline::AdaptiveConfig`
// / `pipeline::PipelineEngine` etc. A plain `use` only resolves names inside
// this module and does not re-export them, which left `ycash_state::pipeline::AdaptiveConfig`
// unreachable from other crates despite `PipelineEngine::new` requiring one.
pub use adaptive::{AdaptiveConfig, AdaptiveController, ResourceSample};
pub use range_scheduler::{RangeId, RangeLease, RangeScheduler, RangeState};
pub use telemetry::{PipelineSnapshot, PipelineStats};

/// Ties the adaptive window controller, the multi-peer range scheduler, and
/// telemetry into the single engine described in
/// `PIPELINE_V0.22_IMPLEMENTATION.md`.
///
/// Scope note: this engine owns *scheduling policy* only -- which height
/// ranges exist, which peer currently leases each one, and how large the
/// sync window is allowed to get. It does not do peer discovery, header/body
/// fetch, or consensus validation; those remain in the network/consensus
/// layers. The Android and node coordinators drive this engine and keep the
/// canonical state commit strictly ordered.
pub struct PipelineEngine {
    adaptive: AdaptiveController,
    scheduler: RangeScheduler,
    stats: PipelineStats,
}

impl PipelineEngine {
    pub fn new(cfg: AdaptiveConfig) -> Self {
        let mut stats = PipelineStats::default();
        stats.start();
        stats.current_window = cfg.initial_window.clamp(cfg.min_window, cfg.max_window) as u64;
        stats.validation_workers = cfg.max_validation_workers.max(1) as u64;
        Self {
            adaptive: AdaptiveController::new(cfg),
            scheduler: RangeScheduler::default(),
            stats,
        }
    }

    /// Enqueue the next height range up to the current adaptive window,
    /// starting at `next_height` and bounded by `chain_tip`. Returns the
    /// height sync should resume planning from on the following call.
    pub fn plan_ranges(&mut self, next_height: u64, chain_tip: u64) -> u64 {
        let window = self.adaptive.window() as u64;
        let end = (next_height + window.saturating_sub(1)).min(chain_tip);
        // HeightRange is inclusive, so a single remaining height (end ==
        // next_height) is still a valid range and must be enqueued -- an
        // earlier version of this used `end > next_height` here, which
        // silently dropped the last height of every sync window.
        if end >= next_height && next_height <= chain_tip {
            self.scheduler.enqueue(next_height, end);
        }
        self.stats.current_window = window;
        end
    }

    /// Lease the next pending range to `peer`.
    pub fn claim(&mut self, peer: &str) -> Option<RangeLease> {
        self.scheduler.claim(peer)
    }

    /// Lease the next pending range whose end is at or below `max_end`.
    pub fn claim_upto(&mut self, peer: &str, max_end: u64) -> Option<RangeLease> {
        self.scheduler.claim_upto(peer, max_end)
    }

    /// Heights pending or leased right now (real "in flight" figure).
    pub fn outstanding_heights(&self) -> u64 {
        self.scheduler.outstanding_heights()
    }

    /// Number of ranges actually leased to peers right now.
    pub fn leased_ranges(&self) -> usize {
        self.scheduler.leased_ranges()
    }

    /// Number of planned ranges still waiting for a peer.
    pub fn pending_ranges(&self) -> usize {
        self.scheduler.pending_ranges()
    }

    /// Plan the current adaptive window as multiple independent ranges. The
    /// total number of heights remains bounded by the adaptive window; the
    /// window is merely partitioned so several peers can work concurrently.
    pub fn plan_parallel_ranges(&mut self, next_height: u64, chain_tip: u64, _workers: usize) -> Vec<RangeId> {
        if next_height > chain_tip { return Vec::new(); }
        // Scheduler ceiling for one range. Configurable via AdaptiveConfig
        // (was a hardcoded 100 here, which silently ignored the setting).
        let max_range_len: u64 = self.adaptive.max_range_len() as u64;

        let window = self.adaptive.window().max(1) as u64;
        let inflight_budget = self.adaptive.current_inflight().max(1);
        // The adaptive window is total ordered lookahead, not the size of every
        // network range. Partition it across the available range slots so a
        // small window cannot collapse into one head-of-line request. Keep
        // roughly 8..16 blocks per request where possible, while respecting the
        // scheduler's hard 100-block range ceiling.
        let desired_ranges = ((window + 15) / 16).max(2);
        let range_count = inflight_budget.min(desired_ranges as usize).max(1);
        let active_range_len = ((window + range_count as u64 - 1) / range_count as u64)
            .min(max_range_len).max(1);
        let worker_budget = self.adaptive.current_workers().max(1);
        let outstanding = self.scheduler.outstanding_heights();
        let capacity = (range_count as u64).saturating_mul(active_range_len);
        let available = capacity.saturating_sub(outstanding);
        if available == 0 {
            self.stats.current_window = window;
            self.stats.validation_workers = worker_budget as u64;
            return Vec::new();
        }

        // The adaptive window is a lookahead ceiling, while the scheduler's
        // actual capacity is bounded by the current partitioned range slots.
        // Start at the
        // first uncovered height instead of blindly enqueueing from next_height.
        // This makes repeated planning idempotent even while older ranges are
        // leased, queued, verified, or waiting behind the ordered commit.
        let target_end = (next_height + window - 1).min(chain_tip);
        let mut start = next_height;
        if let Some(covered_end) = self.scheduler.contiguous_covered_end(next_height) {
            start = covered_end.saturating_add(1);
        }
        if start > target_end {
            self.stats.current_window = window;
            self.stats.validation_workers = worker_budget as u64;
            return Vec::new();
        }

        let end = (start + available.min(target_end.saturating_sub(start) + 1) - 1).min(target_end);
        let total = end - start + 1;
        let max_ranges = range_count;
        let mut remaining = total;
        let mut cursor = start;
        let mut ids = Vec::new();
        while remaining > 0 && ids.len() < max_ranges {
            // Range length is adaptive up to the 100-block scheduler ceiling.
            // Concurrency still comes from multiple independent ranges, while
            // canonical state commit remains ordered.
            let len = remaining.min(active_range_len);
            let finish = (cursor + len - 1).min(end);
            if let Some(id) = self.scheduler.enqueue_if_disjoint(cursor, finish) {
                ids.push(id);
                remaining -= finish - cursor + 1;
                cursor = finish.saturating_add(1);
            } else {
                // A concurrent planner may have covered this interval. Move to
                // the next uncovered height rather than enqueueing a duplicate.
                cursor = cursor.saturating_add(1);
                if cursor > end { break; }
                remaining = end - cursor + 1;
            }
        }
        self.stats.current_window = window;
        self.stats.validation_workers = worker_budget as u64;
        self.stats.max_inflight_ranges = inflight_budget as u64;
        self.stats.blocks_in_flight = self.scheduler.outstanding_heights();
        self.stats.request_rounds += u64::from(!ids.is_empty());
        ids
    }

    pub fn range_end(&self, id: RangeId) -> Option<u64> {
        self.scheduler.range_end(id)
    }

    pub fn lease_age(&self, id: RangeId) -> Option<std::time::Duration> {
        self.scheduler.lease_age(id)
    }

    pub fn range_ids_at_start(&self, start: u64) -> Option<RangeId> {
        self.scheduler.id_at_start(start)
    }

    pub fn requeue_if_lease_stalled(&mut self, id: RangeId, max_age: std::time::Duration) -> bool {
        if self.scheduler.lease_age(id).map(|age| age >= max_age).unwrap_or(false) {
            self.scheduler.requeue(id);
            true
        } else { false }
    }

    pub fn is_current_lease(&self, id: RangeId, generation: u64) -> bool {
        self.scheduler.is_current_lease(id, generation)
    }

    pub fn range_terminal(&self, id: RangeId) -> bool {
        matches!(self.scheduler.state(id), None | Some(RangeState::Complete | RangeState::Quarantined))
    }

    /// Current adaptive window size (heights per planning round). Exposed so
    /// callers can size backpressure thresholds (e.g. how far ahead of the
    /// last commit it's safe to keep planning) off the same value the
    /// scheduler itself is using, instead of guessing a constant.
    pub fn window(&self) -> u64 {
        self.adaptive.window() as u64
    }

    /// Current adaptive lookahead, in blocks ahead of the commit tip.
    ///
    /// This *is* the adaptive window. It used to be `window * in-flight
    /// ranges`, which made a window of 16 report a lookahead of 80 and a
    /// window of 100 report 500 — telemetry that contradicted the planner,
    /// since in-flight ranges partition the window rather than multiplying it.
    pub fn lookahead(&self) -> u64 {
        self.adaptive.window().max(1) as u64
    }

    /// Smoothed throttling pressure (CPU / memory / DB only).
    pub fn current_pressure(&self) -> f64 { self.adaptive.smoothed_pressure() }

    /// Current validation workload demand. Reported separately from pressure.
    pub fn current_demand(&self) -> f64 { self.adaptive.current_demand() }

    /// If the range starting at `start` (normally the coordinator's
    /// `next_commit`) has been quarantined, requeue it so it can be claimed
    /// again. Returns `true` if a range was requeued.
    ///
    /// See `RangeScheduler::requeue` for why this exists: quarantine must
    /// not be a true dead end for the range sitting at the head of the
    /// commit order, or sync stalls there forever while every later range
    /// keeps piling into the validated-but-uncommitted buffer.
    pub fn requeue_if_quarantined_at(&mut self, start: u64) -> bool {
        if let Some(id) = self.scheduler.id_at_start(start) {
            if self.scheduler.state(id) == Some(RangeState::Quarantined) {
                self.scheduler.requeue(id);
                return true;
            }
        }
        false
    }

    /// Return a lease to Pending without a retry/quarantine count.
    pub fn requeue_lease(&mut self, id: RangeId) {
        self.scheduler.unlease(id);
    }

    /// Mark a range complete and fold its results into telemetry.
    pub fn complete(&mut self, id: RangeId, blocks_received: u64, bytes_received: u64) {
        self.scheduler.complete(id);
        self.stats.blocks_received += blocks_received;
        self.stats.bytes_received += bytes_received;
        self.stats.completed_ranges += 1;
        self.stats.blocks_in_flight = self.stats.blocks_in_flight.saturating_sub(blocks_received);
    }

    /// Release an unfinished lease (timeout/disconnect). Escalates to
    /// telemetry as a retry or, past the retry limit, a quarantine.
    pub fn release(&mut self, id: RangeId) {
        self.scheduler.release(id);
        match self.scheduler.state(id) {
            Some(RangeState::Quarantined) => self.stats.quarantined_ranges += 1,
            _ => self.stats.retried_ranges += 1,
        }
    }

    /// Feed a fresh resource sample; adjusts the adaptive window and returns
    /// the current telemetry snapshot (for dashboards/RPC).
    pub fn release_if_current(&mut self, id: RangeId, generation: u64) -> bool {
        if self.scheduler.is_current_lease(id, generation) { self.release(id); true } else { false }
    }

    pub fn observe(&mut self, sample: ResourceSample) -> PipelineSnapshot {
        self.stats.current_window = self.adaptive.observe(sample) as u64;
        self.stats.validation_workers = self.adaptive.current_workers() as u64;
        self.stats.max_inflight_ranges = self.adaptive.current_inflight() as u64;
        self.stats.snapshot()
    }

    /// NOTE: these two report the *current* adaptive budget, not the setting.
    /// The controller halves both once pressure crosses `low_watermark`, so a
    /// dashboard showing only these makes a config change look like it did
    /// nothing. Pair them with the `configured_*` accessors below.
    pub fn current_validation_workers(&self) -> usize { self.adaptive.current_workers().max(1) }

    pub fn max_inflight_ranges(&self) -> usize { self.adaptive.current_inflight().max(1) }

    /// Configured ceilings, straight from `AdaptiveConfig`. These change only
    /// when the settings change.
    pub fn configured_max_validation_workers(&self) -> usize { self.adaptive.max_validation_workers().max(1) }

    pub fn configured_max_inflight_ranges(&self) -> usize { self.adaptive.max_inflight_ranges().max(1) }

    pub fn configured_min_window(&self) -> usize { self.adaptive.min_window() }

    pub fn configured_max_window(&self) -> usize { self.adaptive.max_window() }

    pub fn configured_window_step(&self) -> usize { self.adaptive.window_step() }

    pub fn configured_max_range_len(&self) -> usize { self.adaptive.max_range_len() }

    pub fn configured_high_watermark(&self) -> f64 { self.adaptive.high_watermark() }

    pub fn configured_low_watermark(&self) -> f64 { self.adaptive.low_watermark() }

    pub fn snapshot(&self) -> PipelineSnapshot {
        self.stats.snapshot()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn current_validation_workers_follow_adaptive_controller() {
        let mut cfg = AdaptiveConfig::default();
        cfg.max_validation_workers = 4;
        let mut engine = PipelineEngine::new(cfg);

        assert_eq!(engine.current_validation_workers(), 4);

        engine.observe(ResourceSample {
            cpu_ratio: 0.95,
            memory_ratio: 0.20,
            db_queue_ratio: 0.10,
            network_ratio: 0.10,
            validation_queue_ratio: 0.10,
        });
        assert_eq!(engine.current_validation_workers(), 1);

        engine.observe(ResourceSample {
            cpu_ratio: 0.20,
            memory_ratio: 0.20,
            db_queue_ratio: 0.10,
            network_ratio: 0.10,
            validation_queue_ratio: 0.10,
        });
        assert_eq!(engine.current_validation_workers(), 4);
    }

    #[test]
    fn ranges_do_not_exceed_100_blocks() {
        let mut engine = PipelineEngine::new(AdaptiveConfig::default());
        let ids = engine.plan_parallel_ranges(1, 64, 4);
        assert_eq!(ids.len(), 4);
        for id in ids {
            let lease = engine.scheduler.state(id).expect("planned range");
            assert_ne!(lease, RangeState::Quarantined, "planned range was quarantined");
        }
        assert!(engine.outstanding_heights() <= 100);
    }

    #[test]
    fn scheduler_telemetry_distinguishes_leased_and_pending_ranges() {
        let mut engine = PipelineEngine::new(AdaptiveConfig {
            min_window: 16, initial_window: 100, max_window: 2000, step: 100,
            high_watermark: 0.90, low_watermark: 0.55,
            max_validation_workers: 1, max_inflight_ranges: 1, max_range_len: 100,
        });
        let ids = engine.plan_parallel_ranges(1, 16, 1);
        assert_eq!(ids.len(), 1);
        assert_eq!(engine.pending_ranges(), 1);
        assert_eq!(engine.leased_ranges(), 0);
        let lease = engine.claim_upto("peer-a", 16).expect("range claim");
        assert!(lease.range.len() <= 100);
        assert_eq!(engine.pending_ranges(), 0);
        assert_eq!(engine.leased_ranges(), 1);
        assert_eq!(engine.outstanding_heights(), 16);
    }

    #[test]
    fn small_window_can_use_two_network_slots() {
        let mut engine = PipelineEngine::new(AdaptiveConfig {
            min_window: 16, initial_window: 16, max_window: 2000, step: 100,
            high_watermark: 0.90, low_watermark: 0.55,
            max_validation_workers: 1, max_inflight_ranges: 2, max_range_len: 100,
        });
        let ids = engine.plan_parallel_ranges(1, 16, 1);
        assert_eq!(ids.len(), 2);
        assert_eq!(engine.outstanding_heights(), 16);
        for id in ids {
            assert!(engine.range_end(id).unwrap() - 0 < 100);
        }
    }
}

impl Default for PipelineEngine {
    fn default() -> Self {
        Self::new(AdaptiveConfig::default())
    }
}
