use blake2b_simd::Params;
use ycash_chain::{ParsedTransaction, TransparentInput};
use crate::{consensus_branch_id, ConsensusError};

pub const SIGHASH_ALL:u32 = 1;
pub const SIGHASH_NONE:u32 = 2;
pub const SIGHASH_SINGLE:u32 = 3;
pub const SIGHASH_ANYONECANPAY:u32 = 0x80;
pub const NOT_AN_INPUT:usize = usize::MAX;

fn b2(personal: &[u8;16], data:&[u8])->[u8;32] {
    let mut p=Params::new(); p.hash_length(32); p.personal(personal);
    let h=p.hash(data); let mut o=[0u8;32]; o.copy_from_slice(h.as_bytes()); o
}
fn ser_out(o:&ycash_chain::TransparentOutput, out:&mut Vec<u8>){
    out.extend_from_slice(&o.value.to_le_bytes());
    ycash_chain::write_compact_size(o.script_pubkey.len() as u64,out);
    out.extend_from_slice(&o.script_pubkey);
}
fn ser_input_prev(i:&TransparentInput,out:&mut Vec<u8>){out.extend_from_slice(&i.prev_txid);out.extend_from_slice(&i.prev_index.to_le_bytes());}
fn person(s:&str)->[u8;16]{let mut p=[0u8;16];p[..s.len()].copy_from_slice(s.as_bytes());p}

pub fn sapling_sighash(tx:&ParsedTransaction, hash_type:u32, input_index:Option<usize>, spent_value:Option<i64>, spent_script:Option<&[u8]>, height:u64)->Result<[u8;32],ConsensusError>{
    let base=hash_type & 0x1f;
    if base==SIGHASH_SINGLE && input_index.unwrap_or(0)>=tx.vout.len(){
        // ZIP-143/243 preserves the historical SIGHASH_SINGLE bug value.
        let mut one=[0u8;32]; one[0]=1; return Ok(one);
    }
    let zero=[0u8;32];
    let mut d=Vec::new();
    if hash_type & SIGHASH_ANYONECANPAY == 0 {
        let mut x=Vec::with_capacity(tx.vin.len()*36);
        for i in &tx.vin {ser_input_prev(i,&mut x)}
        d.extend_from_slice(&b2(&person("ZcashPrevoutHash"),&x));
    } else {d.extend_from_slice(&zero);}
    if hash_type & SIGHASH_ANYONECANPAY == 0 && base!=SIGHASH_SINGLE && base!=SIGHASH_NONE {
        let mut x=Vec::with_capacity(tx.vin.len()*4);
        for i in &tx.vin {x.extend_from_slice(&i.sequence.to_le_bytes())}
        d.extend_from_slice(&b2(&person("ZcashSequencHash"),&x));
    } else {d.extend_from_slice(&zero);}
    if base!=SIGHASH_SINGLE && base!=SIGHASH_NONE {
        let mut x=Vec::new(); for o in &tx.vout {ser_out(o,&mut x)}
        d.extend_from_slice(&b2(&person("ZcashOutputsHash"),&x));
    } else if base==SIGHASH_SINGLE {
        let mut x=Vec::new(); ser_out(&tx.vout[input_index.unwrap()],&mut x);
        d.extend_from_slice(&b2(&person("ZcashOutputsHash"),&x));
    } else {d.extend_from_slice(&zero);}
    if !tx.joinsplits.is_empty(){
        let mut x=Vec::new(); for js in &tx.joinsplits{x.extend_from_slice(&js.raw)} if let Some(pk)=tx.joinsplit_pubkey{x.extend_from_slice(&pk)}
        d.extend_from_slice(&b2(&person("ZcashJSplitsHash"),&x));
    } else {d.extend_from_slice(&zero);}
    if !tx.sapling_spends.is_empty(){
        let mut x=Vec::with_capacity(tx.sapling_spends.len()*320);
        for s in &tx.sapling_spends{x.extend_from_slice(&s.cv);x.extend_from_slice(&s.anchor);x.extend_from_slice(&s.nullifier);x.extend_from_slice(&s.rk);x.extend_from_slice(&s.zkproof)}
        d.extend_from_slice(&b2(&person("ZcashSSpendsHash"),&x));
    } else {d.extend_from_slice(&zero);}
    if !tx.sapling_outputs.is_empty(){
        let mut x=Vec::with_capacity(tx.sapling_outputs.len()*916);
        for o in &tx.sapling_outputs{x.extend_from_slice(&o.cv);x.extend_from_slice(&o.cmu);x.extend_from_slice(&o.ephemeral_key);x.extend_from_slice(&o.enc_ciphertext);x.extend_from_slice(&o.out_ciphertext);x.extend_from_slice(&o.zkproof)}
        d.extend_from_slice(&b2(&person("ZcashSOutputHash"),&x));
    } else {d.extend_from_slice(&zero);}
    // The header and group ID are always present for Sapling-era v4 txs.
    let header=(if tx.overwintered {tx.version|0x8000_0000}else{tx.version}).to_le_bytes();
    d.splice(0..0,header.iter().copied());
    let group=tx.version_group_id.unwrap_or(0).to_le_bytes();
    d.splice(4..4,group.iter().copied());
    d.extend_from_slice(&tx.lock_time.to_le_bytes());
    d.extend_from_slice(&tx.expiry_height.unwrap_or(0).to_le_bytes());
    d.extend_from_slice(&tx.value_balance.to_le_bytes());
    d.extend_from_slice(&hash_type.to_le_bytes());
    if let Some(n)=input_index {
        let i=tx.vin.get(n).ok_or_else(||ConsensusError::Invalid("sighash input index out of range".into()))?;
        ser_input_prev(i,&mut d);
        let script=spent_script.ok_or_else(||ConsensusError::Invalid("transparent sighash missing scriptCode".into()))?;
        ycash_chain::write_compact_size(script.len() as u64,&mut d); d.extend_from_slice(script);
        d.extend_from_slice(&spent_value.ok_or_else(||ConsensusError::Invalid("transparent sighash missing spent value".into()))?.to_le_bytes());
        d.extend_from_slice(&i.sequence.to_le_bytes());
    }
    let branch=consensus_branch_id(height).to_le_bytes();
    let mut personal=[0u8;16]; personal[..12].copy_from_slice(b"ZcashSigHash"); personal[12..].copy_from_slice(&branch);
    Ok(b2(&personal,&d))
}

pub fn sapling_transaction_sighash(tx:&ParsedTransaction,height:u64)->Result<[u8;32],ConsensusError>{
    sapling_sighash(tx,SIGHASH_ALL,None,None,None,height)
}
