package com.ycash.androidnode;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.StatFs;
import android.content.Intent;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.view.View;
import android.widget.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.*;
import java.util.Locale;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.json.JSONObject;
import org.json.JSONArray;
import android.content.SharedPreferences;

/**
 * Dedicated Ycash node monitor/control surface. Wallet UI intentionally excluded.
 *
 * This Activity talks only to the local status API (127.0.0.1:8834) and does not
 * open a gRPC channel itself. The node's YWallet-compatible lightwalletd surface
 * lives in crates/ycash-android-node and is documented here for CI diagnostics:
 *   - Service/method: CompactTxStreamer/GetLatestBlock
 *   - Content-Type: application/grpc
 *   - Negotiated header: grpc-accept-encoding
 *   - HTTP/2 stream teardown: RST_STREAM
 *   - HTTP/2 connection teardown: GOAWAY
 */
public class MainActivity extends Activity {
    TextView status, peer, height, headersHeight, targetHeight, blocksBehind, sync, syncPercent,
        pipelineState, pipelineWindow, inFlight, validationQueue, batchSize, headersRate, blocksRate,
        downloadRate, validationRate, commitRate, rxRate, avgValidation, avgCommit, lastBlock,
        activeWorkers, verifyingJobs, bufferedRanges, pipelineInFlightRanges, pipelinePendingRanges, pipelineConfig, handshakeStage, commitBreakdown, rangesCompleted, rangesRetried, rangesQuarantined, lastCommit, pipelineDiagnostic,
        cpuCores, reservedAndroidCore, maxAdaptiveWorkers, currentAdaptiveWorkers,
        uptime, dbSize, freeStorage, networkType, listeners, connectionSource, connectionEndpoint,
        connectionDetail, diagnostics, log, nodeLog, exportStatus, stateBreakdown, stateBottleneck, eta;
    ProgressBar syncProgress;
    View advancedSection;
    Button toggleAdvanced;
    Handler handler = new Handler();
    boolean running = false, advancedShown = false;
    SharedPreferences prefs;
    int consecutiveFailures = 0;
    static final int FAILURE_THRESHOLD = 5;
    long lastPollAt = 0;
    long lastHeight = -1, lastHeaders = -1, lastBlocks = -1, lastValidated = -1, lastHeaderBytes = -1, lastBlockBytes = -1, lastCommits = -1;
    String lastLogMessage = "", lastLogDetail = "", lastLogError = "";
    long lastLoggedHeight = -1, lastLoggedHeaders = -1, lastLoggedBlocks = -1, lastLoggedInFlight = -1;
    static final int NODE_LOG_MAX_LINES = 250;
    static final long NODE_LOG_MAX_BYTES = 256 * 1024;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        final Thread.UncaughtExceptionHandler previousHandler =
            Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            writeAppError("UNCAUGHT EXCEPTION", throwable);
            android.util.Log.e("YcashNode", "UNCAUGHT EXCEPTION", throwable);
            if (previousHandler != null) {
                previousHandler.uncaughtException(thread, throwable);
            }
        });

        setContentView(R.layout.activity_main);
        bind();
        prefs=getSharedPreferences("ycash_node",MODE_PRIVATE);

        toggleAdvanced.setOnClickListener(v -> {
            try {
                advancedShown = !advancedShown;
                if (advancedSection != null) {
                    advancedSection.setVisibility(
                        advancedShown ? View.VISIBLE : View.GONE
                    );
                }
                if (toggleAdvanced != null) {
                    toggleAdvanced.setText(
                        advancedShown ? "Hide diagnostics" : "Show diagnostics"
                    );
                }
                if (advancedShown) {
                    refreshDeviceStatsSafe();
                    refreshNodeLog();
                    refreshAppErrorLog();
                }
            } catch (Throwable t) {
                writeAppError("DIAGNOSTICS CLICK", t);
                safeSetText(log, "Diagnostics error: " +
                    t.getClass().getSimpleName() + " — " +
                    String.valueOf(t.getMessage()));
            }
        });

        findViewById(R.id.start).setOnClickListener(v -> {
            prefs.edit().putString(NodeService.PREF_MANUAL_PEER,
                    ((EditText)findViewById(R.id.manualPeer)).getText().toString().trim()).apply();
            Intent i=new Intent(this,NodeService.class); i.setAction(NodeService.START);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            running=true; consecutiveFailures=0; resetRates();
            status.setText("STARTING"); log.setText("Node: start requested; waiting for :8834/status");
            appendNodeLog(new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date()) + " | NODE START requested");
            pollStatus();
        });
        findViewById(R.id.stop).setOnClickListener(v -> {
            Intent i=new Intent(this,NodeService.class); i.setAction(NodeService.STOP); startService(i);
            running=false; status.setText("STOPPED"); sync.setText("Stopped");
            pipelineState.setText("IDLE"); log.setText("Node: stop requested"); resetRates();
            appendNodeLog(new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date()) + " | NODE STOP requested");
            activeWorkers.setText("0"); lastCommit.setText("never this run"); lastCommit.setTextColor(0xFF667085);
        });
        findViewById(R.id.test).setOnClickListener(v -> testNetwork());
        findViewById(R.id.exportChain).setOnClickListener(v -> startExportChain());
    }

    private void bind() {
        status=findViewById(R.id.status); peer=findViewById(R.id.peer); height=findViewById(R.id.height);
        headersHeight=findViewById(R.id.headersHeight); targetHeight=findViewById(R.id.targetHeight);
        blocksBehind=findViewById(R.id.blocksBehind); sync=findViewById(R.id.sync); syncPercent=findViewById(R.id.syncPercent);
        syncProgress=findViewById(R.id.syncProgress); pipelineState=findViewById(R.id.pipelineState);
        pipelineWindow=findViewById(R.id.pipelineWindow); inFlight=findViewById(R.id.inFlight);
        validationQueue=findViewById(R.id.validationQueue); batchSize=findViewById(R.id.batchSize);
        headersRate=findViewById(R.id.headersRate); blocksRate=findViewById(R.id.blocksRate);
        downloadRate=findViewById(R.id.downloadRate); validationRate=findViewById(R.id.validationRate);
        commitRate=findViewById(R.id.commitRate); rxRate=findViewById(R.id.rxRate);
        avgValidation=findViewById(R.id.avgValidation); avgCommit=findViewById(R.id.avgCommit);
        lastBlock=findViewById(R.id.lastBlock); uptime=findViewById(R.id.uptime);
        activeWorkers=findViewById(R.id.activeWorkers); verifyingJobs=findViewById(R.id.verifyingJobs); bufferedRanges=findViewById(R.id.bufferedRanges);
        cpuCores=findViewById(R.id.cpuCores); reservedAndroidCore=findViewById(R.id.reservedAndroidCore); maxAdaptiveWorkers=findViewById(R.id.maxAdaptiveWorkers); currentAdaptiveWorkers=findViewById(R.id.currentAdaptiveWorkers); pipelineInFlightRanges=findViewById(R.id.pipelineInFlightRanges); pipelinePendingRanges=findViewById(R.id.pipelinePendingRanges); pipelineConfig=findViewById(R.id.pipelineConfig); handshakeStage=findViewById(R.id.handshakeStage); commitBreakdown=findViewById(R.id.commitBreakdown); rangesCompleted=findViewById(R.id.rangesCompleted);
        rangesRetried=findViewById(R.id.rangesRetried); rangesQuarantined=findViewById(R.id.rangesQuarantined);
        lastCommit=findViewById(R.id.lastCommit);
        pipelineDiagnostic=findViewById(R.id.pipelineDiagnostic);
        dbSize=findViewById(R.id.dbSize); freeStorage=findViewById(R.id.freeStorage); networkType=findViewById(R.id.networkType);
        listeners=findViewById(R.id.listeners); connectionSource=findViewById(R.id.connectionSource);
        connectionEndpoint=findViewById(R.id.connectionEndpoint); connectionDetail=findViewById(R.id.connectionDetail); stateBreakdown=findViewById(R.id.stateBreakdown); stateBottleneck=findViewById(R.id.stateBottleneck); eta=findViewById(R.id.eta);
        diagnostics=findViewById(R.id.diagnostics); log=findViewById(R.id.log); exportStatus=findViewById(R.id.exportStatus);
        nodeLog=findViewById(R.id.nodeLog);
        loadNodeLog();
        toggleAdvanced=findViewById(R.id.toggleAdvanced);
        findViewById(R.id.clearNodeLog).setOnClickListener(v -> clearNodeLog());
        EditText manualPeer=findViewById(R.id.manualPeer);
        manualPeer.setText(prefsOrDefault(NodeService.PREF_MANUAL_PEER,""));
    }

    private String prefsOrDefault(String k,String d){ return getSharedPreferences("ycash_node",MODE_PRIVATE).getString(k,d); }
    private void resetRates(){ lastPollAt=0; lastHeight=lastHeaders=lastBlocks=lastValidated=lastHeaderBytes=lastBlockBytes=lastCommits=-1; }

    private void pollStatus(){
        if(!running)return;
        new Thread(() -> {
            try{
                HttpURLConnection c=(HttpURLConnection)new URL("http://127.0.0.1:8834/status").openConnection();
                c.setConnectTimeout(1500); c.setReadTimeout(1500); c.setRequestMethod("GET");
                if(c.getResponseCode()==200){
                    BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));
                    StringBuilder s=new StringBuilder(); String line; while((line=br.readLine())!=null)s.append(line);
                    JSONObject j=new JSONObject(s.toString()); runOnUiThread(() -> applyStatus(j));
                }
                c.disconnect();
            }catch(Exception e){
                consecutiveFailures++;
                if(consecutiveFailures==FAILURE_THRESHOLD) runOnUiThread(() -> {
                    status.setText("NODE NOT RESPONDING"); log.setText("No response from status API :8834");
                    appendNodeLog(new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date()) +
                        " | ERROR: status API :8834 not responding");
                });
            }
            handler.postDelayed(this::pollStatus,2000);
        }).start();
    }

    private void applyStatus(JSONObject j){
        try{
            consecutiveFailures=0;
            long now=System.currentTimeMillis(); double dt=lastPollAt>0?(now-lastPollAt)/1000.0:0;
            long h=j.optLong("height",-1), hh=j.optLong("headers_height",-1), blocks=j.optLong("blocks_received",0);
            long hb=j.optLong("header_bytes_received",0), bb=j.optLong("block_bytes_received",0), commits=j.optLong("db_commits",0);
            status.setText(j.optString("status","unknown").toUpperCase(Locale.US));
            peer.setText(String.valueOf(j.optInt("peers",0)));
            height.setText(h<0?"—":formatLong(h)); headersHeight.setText(hh<0?"—":formatLong(hh));
            long target=j.optLong("target_height",-1); targetHeight.setText(target<0?"—":formatLong(target));
            long behind=(h>=0&&target>=0)?Math.max(0,target-h):0; blocksBehind.setText(formatLong(behind));
            String syncText=j.optString("sync","unknown"); sync.setText(syncText);
            // Blocks progress with 2 decimals (1,760 of 3M used to round to "0%");
            // headers progress kept alongside. Bar has 10000 steps (0.01%).
            double blockPct=(target>0&&h>=0)?Math.min(100.0,Math.max(0.0,h*100.0/target)):0.0;
            double headerPct=(target>0&&hh>=0)?Math.min(100.0,Math.max(0.0,hh*100.0/target)):0.0;
            syncProgress.setProgress((int)Math.round(blockPct*100.0));
            syncPercent.setText(String.format(Locale.US,"%.2f%% · hdr %.2f%%",blockPct,headerPct));
            pipelineState.setText(behind>0?"ACTIVE · FETCH / VALIDATE / COMMIT":"LIVE · READY");
            pipelineWindow.setText(formatLong(j.optLong("current_window",0)));
            inFlight.setText(formatLong(j.optLong("blocks_in_flight",0)));
            pipelineInFlightRanges.setText(formatLong(j.optLong("pipeline_inflight_ranges",0)));
            pipelinePendingRanges.setText(formatLong(j.optLong("pipeline_pending_ranges",0)));
            // "current/configured". The left number is what the adaptive controller
            // is allowing under present pressure (it halves both above low_watermark);
            // the right number is the setting. Showing only the left one made a config
            // change look like it had been ignored.
            pipelineConfig.setText(String.format(Locale.US,
                "ranges %d/%d · verify %d/%d · window %d (%d–%d) · lookahead %d · commit %d · range %d",
                j.optLong("pipeline_max_inflight_ranges",0), j.optLong("pipeline_cfg_inflight_ranges",0),
                j.optLong("pipeline_max_validation_workers",0), j.optLong("pipeline_cfg_validation_workers",0),
                j.optLong("current_window",0), j.optLong("pipeline_cfg_min_window",0), j.optLong("pipeline_cfg_max_window",0),
                j.optLong("pipeline_lookahead",0), j.optLong("pipeline_commit_batch",0),
                j.optLong("pipeline_max_range_len",0)));
            validationQueue.setText(formatLong(j.optLong("validation_queue",0)));
            batchSize.setText(formatLong(j.optLong("batch_size",0)));
            long detectedCores = Math.max(1, Runtime.getRuntime().availableProcessors());
            long reserved = detectedCores > 1 ? 1 : 0;
            long deviceMaxWorkers = Math.max(1, detectedCores - reserved);
            long nativeMaxWorkers = j.optLong("pipeline_cfg_validation_workers", deviceMaxWorkers);
            long currentWorkers = j.optLong("active_block_workers", 0);
            cpuCores.setText(formatLong(detectedCores));
            reservedAndroidCore.setText(reserved == 1 ? "1 core" : "0 cores");
            maxAdaptiveWorkers.setText(formatLong(nativeMaxWorkers));
            currentAdaptiveWorkers.setText(formatLong(currentWorkers));
            activeWorkers.setText(formatLong(currentWorkers));
            verifyingJobs.setText(formatLong(j.optLong("verifying_jobs",0)));
            bufferedRanges.setText(formatLong(j.optLong("buffered_ranges",0)));
            String pipelineMessage=j.optString("message","");
            String pipelineError=j.optString("last_error","");
            String pd=!pipelineError.isEmpty()?"Pipeline error: "+pipelineError:(!pipelineMessage.isEmpty()?"Pipeline: "+pipelineMessage:"Pipeline diagnostic: waiting");
            pipelineDiagnostic.setText(pd);
            pipelineDiagnostic.setTextColor(!pipelineError.isEmpty()?0xFFB42318:0xFF667085);
            long retried=j.optLong("retried_ranges",0), quarantined=j.optLong("quarantined_ranges",0);
            rangesCompleted.setText(formatLong(j.optLong("completed_ranges",0)));
            rangesRetried.setText(formatLong(retried));
            rangesQuarantined.setText(formatLong(quarantined));
            // A worker retries a range when a peer times out or misbehaves mid-claim; that's
            // normal on a weak connection. A nonzero quarantined count means a range hit the
            // retry limit with no peer able to serve it -- the chain is genuinely stuck behind
            // it until a different peer becomes available, independent of headers still moving.
            rangesQuarantined.setTextColor(quarantined>0?0xFFB42318:0xFF111827);
            if(dt>0){
                headersRate.setText(rate(hh,lastHeaders,dt,"headers/s"));
                blocksRate.setText(rate(blocks,lastBlocks,dt,"blocks/s"));
                double blocksPerSecond = (lastBlocks >= 0 && blocks >= lastBlocks) ? (blocks-lastBlocks)/dt : 0.0;
                if (behind <= 0) {
                    eta.setText("Complete");
                } else if (blocksPerSecond > 0.0) {
                    eta.setText(formatEta(behind / blocksPerSecond));
                } else {
                    eta.setText("—");
                }
                downloadRate.setText(byteRate(bb,lastBlockBytes,dt));
                validationRate.setText(rate(j.optLong("blocks_validated",0),lastValidated,dt,"valid/s"));
                commitRate.setText(rate(commits,lastCommits,dt,"commits/s"));
                rxRate.setText(byteRate(hb+bb,(lastHeaderBytes<0||lastBlockBytes<0)?-1:lastHeaderBytes+lastBlockBytes,dt));
            }
            long valCount=j.optLong("blocks_validated",0), valMs=j.optLong("validation_ms_total",0);
            long commitCount=j.optLong("db_commits",0), commitMs=j.optLong("db_commit_ms_total",0);
            avgValidation.setText(valCount>0?String.format(Locale.US,"%.1f ms",(double)valMs/valCount):"—");
            avgCommit.setText(commitCount>0?String.format(Locale.US,"%.1f ms",(double)commitMs/commitCount):"—");
            long stateUs = j.optLong("last_state_validation_us",0);
            long unattributedUs = j.optLong("last_state_unattributed_us",0);
            long parentUs = j.optLong("last_parent_state_load_us",0);
            long blockParseUs = j.optLong("last_block_parse_us",0);
            long txParseUs = j.optLong("last_tx_parse_us",0);
            long txidUs = j.optLong("last_txid_us",0);
            long txConnectUs = j.optLong("last_tx_connect_us",0);
            long saplingUs = j.optLong("last_sapling_validate_us",0);
            long finalizeUs = j.optLong("last_block_finalize_us",0);
            long encodeUs = j.optLong("last_tree_encode_us",0);
            long readUs = j.optLong("last_read_transaction_us",0) + j.optLong("last_read_transaction_commit_us",0);
            long headerHashUs = j.optLong("last_header_hash_us",0);
            long connectorNewUs = j.optLong("last_connector_new_us",0);
            long blockRootUs = j.optLong("last_block_root_us",0);
            long connectorOtherUs = j.optLong("last_connector_other_us",0);
            long slowestBlockUs = j.optLong("last_slowest_block_us",0);
            long slowestBlockOtherUs = j.optLong("last_slowest_block_other_us",0);
            long slowestBlockHeight = j.optLong("last_slowest_block_height",0);
            long slowestTxUs = j.optLong("last_slowest_tx_us",0);
            long slowestTxOtherUs = j.optLong("last_slowest_tx_other_us",0);
            long slowestTxHeight = j.optLong("last_slowest_tx_height",0);
            long slowestTxIndex = j.optLong("last_slowest_tx_index",0);
            String[] names = {"Read transaction", "Parent state load", "Block parse", "TX parse", "TXID/hash", "TX connect", "Sapling validation", "Block finalization", "Tree/frontier encoding", "Unattributed", "Header/hash", "Connector setup", "Block root"};
            long[] values = {readUs,parentUs,blockParseUs,txParseUs,txidUs,txConnectUs,saplingUs,finalizeUs,encodeUs,unattributedUs,headerHashUs,connectorNewUs,blockRootUs};
            int best=0;
            for(int i=1;i<values.length;i++) if(values[i]>values[best]) best=i;
            if(stateUs>0){
                stateBottleneck.setText(String.format(Locale.US,
                    "BOTTLENECK: %s — %s of state validation (%s)",
                    names[best], pct(values[best],stateUs), micros(values[best])));
                stateBottleneck.setTextColor(values[best] > stateUs/2 ? 0xFFB42318 : 0xFF667085);
            } else {
                stateBottleneck.setText("Bottleneck: waiting for commit telemetry…");
                stateBottleneck.setTextColor(0xFF667085);
            }
            stateBreakdown.setText(String.format(Locale.US,
                "State validation total: %s\n" +
                "  Read transaction begin: %s (%s)\n" +
                "  Read transaction commit: %s (%s)\n" +
                "  Parent state load total: %s (%s)\n" +
                "    Parent frontier load: %s\n" +
                "    Sprout state load: %s\n" +
                "  Block parse: %s (%s)\n" +
                "  TX parse: %s (%s)\n" +
                "  TXID/hash: %s (%s)\n" +
                "  TX connect total: %s (%s)\n" +
                "    Sigops: %s\n" +
                "    BIP30: %s (%d checks)\n" +
                "    UTXO lookups: %s (%d lookups)\n" +
                "    Sprout requirements: %s\n" +
                "    Value/fee checks: %s\n" +
                "    Script checks: %s (%d inputs)\n" +
                "    Script parallel verification: %s (%d workers)\n" +
                "      Worker wall: %s\n" +
                "      Worker input work: %s\n" +
                "      Worker inputs: %s\n" +
                "      Thread create: %s · Thread join: %s\n" +
                "      Pool overhead: %s · Pool threads: %d\n" +
                "      Worker span: %s max / %s min\n" +
                "      Parallel wall gap: %s · span spread: %s\n" +
                "    Script input work: %s (sum across inputs)\n" +
                "    Slowest script input: %s (tx height %d, tx index %d, input %d)\n" +
                "    UTXO cache: %d hits / %d misses\n" +
                "    Parent state cache: %s · Sprout state cache: %s\n" +
                "    Coin state updates: %s\n" +
                "    Sprout apply: %s\n" +
                "  Sapling validation: %s (%s)\n" +
                "    Anchor lookups: %s (%d queries)\n" +
                "    Nullifier lookups: %s (%d queries)\n" +
                "    Sapling tree work: %s\n" +
                "    Empty-subtree hashes avoided: %s · root-cache hits: %s\n" +
                "  Block finalization: %s (%s)\n" +
                "  Tree/frontier encoding: %s (%s)\n" +
                "  Header/hash: %s (%s)\n" +
                "  Connector setup: %s (%s)\n" +
                "  Connector internal residual: %s (%s)\n" +
                "  Block root: %s (%s)\n" +
                "%s" +
                "  Slowest block: height %d, %s total, %s residual\n" +
                "  Slowest TX: height %d, index %d, %s total, %s residual\n" +
                "  Unattributed state time: %s (%s)",
                stageTime(j,"last_state_validation_us","last_state_validation_ms"),
                micros(j.optLong("last_read_transaction_us",0)), pct(j.optLong("last_read_transaction_us",0),stateUs),
                micros(j.optLong("last_read_transaction_commit_us",0)), pct(j.optLong("last_read_transaction_commit_us",0),stateUs),
                stageTime(j,"last_parent_state_load_us","last_parent_state_load_ms"), pct(parentUs,stateUs),
                micros(j.optLong("last_parent_frontier_load_us",0)),
                micros(j.optLong("last_sprout_state_load_us",0)),
                stageTime(j,"last_block_parse_us","last_block_parse_ms"), pct(blockParseUs,stateUs),
                micros(j.optLong("last_tx_parse_us",0)), pct(txParseUs,stateUs),
                micros(j.optLong("last_txid_us",0)), pct(txidUs,stateUs),
                stageTime(j,"last_tx_connect_us","last_tx_connect_ms"), pct(txConnectUs,stateUs),
                stageTime(j,"last_sigops_us","last_sigops_ms"),
                stageTime(j,"last_bip30_us","last_bip30_ms"), j.optLong("last_bip30_checks",0),
                stageTime(j,"last_utxo_lookup_us","last_utxo_lookup_ms"), j.optLong("last_utxo_lookups",0),
                stageTime(j,"last_sprout_requirements_us","last_sprout_requirements_ms"),
                stageTime(j,"last_value_checks_us","last_value_checks_ms"),
                stageTime(j,"last_script_us","last_script_ms"), j.optLong("last_script_checks",0),
                micros(j.optLong("last_script_parallel_us",0)), j.optLong("last_script_parallel_workers",0),
                j.optJSONArray("last_script_worker_wall_us") == null ? "[]" : j.optJSONArray("last_script_worker_wall_us").toString(),
                j.optJSONArray("last_script_worker_input_work_us") == null ? "[]" : j.optJSONArray("last_script_worker_input_work_us").toString(),
                j.optJSONArray("last_script_worker_inputs") == null ? "[]" : j.optJSONArray("last_script_worker_inputs").toString(),
                micros(j.optLong("last_script_spawn_us",0)), micros(j.optLong("last_script_join_us",0)),
                micros(j.optLong("last_script_pool_overhead_us",0)), j.optLong("last_script_pool_threads",0),
                micros(j.optLong("last_script_worker_max_us",0)), micros(j.optLong("last_script_worker_min_us",0)),
                micros(Math.max(0L, j.optLong("last_script_parallel_us",0) - j.optLong("last_script_worker_max_us",0))),
                micros(Math.max(0L, j.optLong("last_script_worker_max_us",0) - j.optLong("last_script_worker_min_us",0))),
                micros(j.optLong("last_script_input_work_us",0)),
                micros(j.optLong("last_script_slowest_input_us",0)), j.optLong("last_script_slowest_input_tx_height",0), j.optLong("last_script_slowest_input_tx_index",0), j.optLong("last_script_slowest_input_index",0),
                j.optLong("last_utxo_cache_hits",0), j.optLong("last_utxo_cache_misses",0),
                j.optBoolean("last_parent_state_cache_hit",false)?"HIT":"MISS",
                j.optBoolean("last_sprout_state_cache_hit",false)?"HIT":"MISS",
                stageTime(j,"last_coin_state_update_us","last_coin_state_update_ms"),
                stageTime(j,"last_sprout_apply_us","last_sprout_apply_ms"),
                stageTime(j,"last_sapling_validate_us","last_sapling_validate_ms"), pct(saplingUs,stateUs),
                stageTime(j,"last_sapling_anchor_lookup_us","last_sapling_anchor_lookup_ms"), j.optLong("last_sapling_anchor_queries",0),
                stageTime(j,"last_sapling_nullifier_lookup_us","last_sapling_nullifier_lookup_ms"), j.optLong("last_sapling_nullifier_queries",0),
                stageTime(j,"last_sapling_tree_update_us","last_sapling_tree_update_ms"),
                formatLong(j.optLong("last_sapling_empty_hashes_avoided",0)),
                formatLong(j.optLong("last_sapling_root_cache_hits",0)),
                micros(finalizeUs), pct(finalizeUs,stateUs),
                micros(encodeUs), pct(encodeUs,stateUs),
                micros(headerHashUs), pct(headerHashUs,stateUs),
                micros(connectorNewUs), pct(connectorNewUs,stateUs),
                micros(connectorOtherUs), pct(connectorOtherUs,stateUs),
                micros(blockRootUs), pct(blockRootUs,stateUs),
                rootDeepBreakdown(j, blockRootUs),
                slowestBlockHeight, micros(slowestBlockUs), micros(slowestBlockOtherUs),
                slowestTxHeight, slowestTxIndex, micros(slowestTxUs), micros(slowestTxOtherUs),
                micros(unattributedUs), pct(unattributedUs,stateUs)));

            // Rolling telemetry is maintained per committed batch by the native
            // node (not per UI poll), so fast commits cannot disappear between
            // the 2-second status refreshes.
            JSONObject rolling = j.optJSONObject("rolling_telemetry");
            if (rolling != null) {
                long rs = rolling.optLong("samples",0);
                long rb = rolling.optLong("blocks",0);
                long rtx = rolling.optLong("txs",0);
                long rstate = rolling.optLong("avg_state_validation_us_per_block",0);
                long rtxc = rolling.optLong("avg_tx_connect_us_per_block",0);
                long rscript = rolling.optLong("avg_script_us_per_block",0);
                long rparse = rolling.optLong("avg_script_parsing_us_per_block",0);
                long rhash = rolling.optLong("avg_signature_hash_preparation_us_per_block",0);
                long recdsa = rolling.optLong("avg_ecdsa_verification_us_per_block",0);
                long rinterp = rolling.optLong("avg_script_interpreter_us_per_block",0);
                long rcache = rolling.optLong("avg_script_cache_lookup_us_per_block",0);
                long rsync = rolling.optLong("avg_script_synchronization_us_per_block",0);
                long rsqlite = rolling.optLong("avg_sqlite_commit_us_per_block",0);
                long rdb = rolling.optLong("avg_db_write_us_per_block",0);
                long rblocksps = rolling.optLong("blocks_per_sec",0);
                String rollingText =
                    "\n\nROLLING PERFORMANCE — last " + formatLong(rb) + " committed blocks (" + rs + " batches, " + formatLong(rtx) + " txs)\n" +
                    "  Throughput: " + formatLong(rblocksps) + " blocks/s\n" +
                    "  Avg commit: " + micros(rolling.optLong("avg_commit_us_per_block",0)) + "\n" +
                    "  Avg state validation: " + micros(rstate) + " · TX connect: " + micros(rtxc) + " · Script: " + micros(rscript) + "\n" +
                    "  Script parsing: " + micros(rparse) + " · sighash prep: " + micros(rhash) + " · ECDSA: " + micros(recdsa) + "\n" +
                    "  Interpreter: " + micros(rinterp) + " · cache lookup: " + micros(rcache) + " · thread sync: " + micros(rsync) + "\n" +
                    "  SQLite COMMIT: " + micros(rsqlite) + " · DB write: " + micros(rdb) + "\n" +
                    "  Script stages are measured at their call sites; values are diagnostic only.";
                stateBreakdown.append(rollingText);
            }

            // Deep script-verification breakdown for the most recently committed batch.
            stateBreakdown.append(
                "\n\nSCRIPT VERIFICATION — last committed batch\n" +
                "  Input/UTXO extraction: " + micros(j.optLong("last_script_transaction_input_extraction_us",0)) + " (pre-script)\n" +
                "  scriptSig construction: " + micros(j.optLong("last_script_sig_construction_us",0)) + "\n" +
                "  scriptPubKey retrieval/key validation: " + micros(j.optLong("last_script_pubkey_retrieval_us",0)) + " (key validation portion)\n" +
                "  Script parsing: " + micros(j.optLong("last_script_parsing_us",0)) + "\n" +
                "  Signature/hash preparation: " + micros(j.optLong("last_signature_hash_preparation_us",0)) + "\n" +
                "  ECDSA verification: " + micros(j.optLong("last_ecdsa_verification_us",0)) + "\n" +
                "  Script interpreter execution: " + micros(j.optLong("last_script_interpreter_us",0)) + "\n" +
                "  Cache lookup/selection: " + micros(j.optLong("last_script_cache_lookup_us",0)) + "\n" +
                "  Synchronization/thread scheduling: " + micros(j.optLong("last_script_synchronization_us",0)));

            long dbWriteUs=j.optLong("last_db_write_us",0), sqliteUs=j.optLong("last_sqlite_commit_us",0);
            commitBreakdown.setText(String.format(Locale.US,
                "Last full ordered commit: %s\nState %s · DB write %s · SQLite COMMIT %s · rollback %d ms",
                micros(j.optLong("last_commit_total_us",0)),
                stageTime(j,"last_state_validation_us","last_state_validation_ms"),
                micros(dbWriteUs), micros(sqliteUs), j.optLong("last_rollback_ms",0)));
            long tipTime=j.optLong("tip_time",0); lastBlock.setText(tipTime>0?formatDuration(Math.max(0,System.currentTimeMillis()/1000-tipTime))+" ago":"—");
            // tip_time is the *committed* block's own header timestamp (a consensus field, not
            // wall-clock), so on a chain that's still far behind it stays old no matter how fast
            // sync is actually going. last_commit_unix is wall-clock time of the last successful
            // DB commit, which is what actually tells you whether the pipeline is stuck right now
            // -- this is the number that stays frozen in exactly the "headers moving, blocks not"
            // case that prompted adding this panel.
            long lastCommitUnix=j.optLong("last_commit_unix",0);
            if(lastCommitUnix<=0){
                lastCommit.setText("never this run");
                lastCommit.setTextColor(0xFF667085);
            }else{
                long secsSince=Math.max(0,System.currentTimeMillis()/1000-lastCommitUnix);
                lastCommit.setText(formatDuration(secsSince)+" ago");
                lastCommit.setTextColor(secsSince>120?0xFFB42318:0xFF111827);
            }
            uptime.setText(formatDuration(Math.max(0,j.optLong("uptime_seconds",0))));
            listeners.setText("P2P 8833 "+up(j.optBoolean("p2p_listening"))+"   RPC 8832 "+up(j.optBoolean("rpc_listening"))+"   API 8834 "+up(j.optBoolean("api_listening"))+"   YWallet gRPC 9067 "+up(j.optBoolean("lightwallet_listening")));
            connectionSource.setText(j.optString("connection_source","None"));
            connectionEndpoint.setText(j.optString("connection_endpoint","—"));
            connectionDetail.setText(j.optString("connection_detail","—"));
            handshakeStage.setText("Handshake: "+j.optString("handshake_stage","IDLE")+" · "+j.optLong("handshake_elapsed_ms",0)+" ms");
            diagnostics.setText("Outbound: "+j.optLong("outbound_attempts",0)+" attempts / "+j.optLong("outbound_handshakes",0)+" handshakes\n"+
                "Inbound: "+j.optLong("inbound_connections",0)+"   Known peers: "+j.optLong("known_peers",0)+"\n"+
                "Validated: "+j.optLong("blocks_validated",0)+" blocks   Indexed: "+j.optLong("txs_indexed",0)+" txs\n"+
                "Last block: "+formatBytes(j.optLong("last_block_bytes",0))+"   Last height: "+j.optLong("last_block_height",0)+"\n"+
                "Last error: "+j.optString("last_error","—"));
            log.setText(j.optString("message","status updated"));
            lastPollAt=now; lastHeight=h; lastHeaders=hh; lastBlocks=blocks; lastValidated=j.optLong("blocks_validated",0); lastHeaderBytes=hb; lastBlockBytes=bb; lastCommits=commits;
            if(advancedShown)refreshDeviceStats();
        }catch(Exception e){
            // Never swallow silently: one bad format string here used to abort the whole
            // update, freezing throughput, breakdown and network panels.
            android.util.Log.e("YcashNode","applyStatus failed",e);
            log.setText("UI status error: "+e.getClass().getSimpleName()+": "+e.getMessage());
            lastPollAt=System.currentTimeMillis();
        }
    }


    /**
     * The node already exposes live diagnostics through /status. Keep a small
     * persistent operator log in the Android app so connection, header-sync and
     * block-pipeline failures remain visible even when the Rust process does not
     * have a console attached.
     */
    private File nodeLogFile() {
        return new File(getFilesDir(), "node-live.log");
    }

    private void loadNodeLog() {
        try {
            File f = nodeLogFile();
            if (!f.exists()) {
                nodeLog.setText("Node log is empty. Start the node to capture live events.");
                return;
            }
            String text = readTextFile(f);
            nodeLog.setText(trimLogLines(text));
        } catch (Throwable t) {
            nodeLog.setText("Unable to read node log: " + t.getMessage());
            writeAppError("NODE LOG READ", t);
        }
    }

    private void appendNodeLog(String line) {
        try {
            File f = nodeLogFile();
            String old = f.exists() ? readTextFile(f) : "";
            String text = trimLogLines(old + line + "\n");
            writeTextFile(f, text);
            safeSetText(nodeLog, text);
        } catch (Throwable t) {
            safeSetText(nodeLog, "Node log write error: " + t.getMessage());
            writeAppError("NODE LOG WRITE", t);
        }
    }

    private String trimLogLines(String text) {
        String[] lines = text.split("\\r?\\n");
        int start = Math.max(0, lines.length - NODE_LOG_MAX_LINES);
        StringBuilder out = new StringBuilder();
        for (int i = start; i < lines.length; i++) {
            if (lines[i].length() == 0 && i == lines.length - 1) continue;
            out.append(lines[i]).append("\n");
        }
        String result = out.toString();
        while (result.getBytes().length > NODE_LOG_MAX_BYTES && result.length() > 0) {
            int nl = result.indexOf('\n');
            if (nl < 0) return "";
            result = result.substring(nl + 1);
        }
        return result;
    }

    private String readTextFile(File f) throws IOException {
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = r.readLine()) != null) b.append(line).append("\n");
        }
        return b.toString();
    }

    private void writeTextFile(File f, String text) throws IOException {
        try (FileWriter w = new FileWriter(f, false)) { w.write(text); }
    }

    private void clearNodeLog() {
        try {
            writeTextFile(nodeLogFile(), "");
            safeSetText(nodeLog, "Node log cleared.");
        } catch (Throwable t) {
            safeSetText(nodeLog, "Unable to clear node log: " + t.getMessage());
            writeAppError("NODE LOG CLEAR", t);
        }
    }

    private void logStatusEvent(JSONObject j) {
        try {
            String message = j.optString("message", "");
            String detail = j.optString("connection_detail", "");
            String error = j.optString("last_error", "");
            long h = j.optLong("height", 0);
            long hh = j.optLong("headers_height", 0);
            long blocks = j.optLong("blocks_received", 0);
            long in = j.optLong("blocks_in_flight", 0);
            boolean changed = !message.equals(lastLogMessage)
                || !detail.equals(lastLogDetail)
                || !error.equals(lastLogError)
                || h != lastLoggedHeight
                || hh != lastLoggedHeaders
                || blocks != lastLoggedBlocks
                || in != lastLoggedInFlight;
            if (!changed) return;

            StringBuilder line = new StringBuilder();
            line.append(new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date()));
            line.append(" | height=").append(h)
                .append(" headers=").append(hh)
                .append(" in_flight=").append(in)
                .append(" blocks=").append(blocks);
            if (!message.isEmpty()) line.append(" | ").append(message);
            if (!detail.isEmpty()) line.append(" | ").append(detail);
            if (!error.isEmpty()) line.append(" | ERROR: ").append(error);
            appendNodeLog(line.toString());

            lastLogMessage = message;
            lastLogDetail = detail;
            lastLogError = error;
            lastLoggedHeight = h;
            lastLoggedHeaders = hh;
            lastLoggedBlocks = blocks;
            lastLoggedInFlight = in;
        } catch (Throwable t) {
            writeAppError("NODE STATUS LOG", t);
        }
    }

    private String up(boolean v){return v?"UP":"DOWN";}
    private String rate(long now,long prev,double dt,String unit){ if(prev<0||now<prev)return"—"; return String.format(Locale.US,"%.1f %s",(now-prev)/dt,unit); }
    private String byteRate(long now,long prev,double dt){ if(prev<0||now<prev)return"—"; return formatBytesPerSecond((now-prev)/dt); }
    private String formatBytesPerSecond(double v){ if(v<1024)return String.format(Locale.US,"%.0f B/s",v); if(v<1024*1024)return String.format(Locale.US,"%.1f KB/s",v/1024); return String.format(Locale.US,"%.2f MB/s",v/(1024*1024)); }
    private String formatLong(long v){return String.format(Locale.US,"%,d",v);}
    private static String micros(long us){
        if(us<=0) return "0 µs";
        if(us<1000) return us+" µs";
        if(us<1000000) return String.format(Locale.US,"%.2f ms",us/1000.0);
        return String.format(Locale.US,"%.3f s",us/1000000.0);
    }
    private static String pct(long partUs,long totalUs){
        if(totalUs<=0||partUs<0) return "—";
        return String.format(Locale.US,"%.1f%%",(partUs*100.0)/totalUs);
    }
    private static String stageTime(JSONObject j,String usKey,String msKey){
        long us=j.optLong(usKey,-1);
        if(us>=0) return micros(us);
        return j.optLong(msKey,0)+" ms";
    }
    private static String rootDeepBreakdown(JSONObject j, long rootUs){
        JSONArray levels = j.optJSONArray("last_block_root_level_us");
        JSONArray hashes = j.optJSONArray("last_block_root_level_hashes");
        JSONArray empty = j.optJSONArray("last_block_root_empty_us");
        JSONArray emptyHashes = j.optJSONArray("last_block_root_empty_hashes");
        JSONArray rootHash = j.optJSONArray("last_block_root_hash_us");
        JSONArray rootHashes = j.optJSONArray("last_block_root_hashes");
        if(levels==null) return "";
        long emptyTotal=0, rootHashTotal=0, emptyHashCount=0, rootHashCount=0;
        for(int i=0;i<32;i++){
            emptyTotal += empty!=null ? empty.optLong(i,0) : 0;
            rootHashTotal += rootHash!=null ? rootHash.optLong(i,0) : 0;
            emptyHashCount += emptyHashes!=null ? emptyHashes.optLong(i,0) : 0;
            rootHashCount += rootHashes!=null ? rootHashes.optLong(i,0) : 0;
        }
        StringBuilder b=new StringBuilder();
        b.append("  Block root deep: ").append(micros(rootUs)).append("\n")
         .append("    Empty-subtree rebuild: ").append(micros(emptyTotal))
         .append(" (").append(pct(emptyTotal,rootUs)).append(", ")
         .append(emptyHashCount).append(" hashes)\n")
         .append("    Root Merkle hashes: ").append(micros(rootHashTotal))
         .append(" (").append(pct(rootHashTotal,rootUs)).append(", ")
         .append(rootHashCount).append(" hashes)\n")
         .append("    Per level: L:total/empty/root-hash\n");
        for(int i=0;i<32;i++){
            long v=levels.optLong(i,0);
            if(v>0){
                long eu=empty!=null?empty.optLong(i,0):0;
                long hu=rootHash!=null?rootHash.optLong(i,0):0;
                long hc=hashes!=null?hashes.optLong(i,0):0;
                b.append(String.format(Locale.US,
                    "      %02d: %s / %s / %s (%d hashes, %s)\n",
                    i,micros(v),micros(eu),micros(hu),hc,pct(v,rootUs)));
            }
        }
        return b.toString();
    }

    private static String formatEta(double seconds){
        if(!Double.isFinite(seconds) || seconds<0) return "—";
        long s=(long)Math.ceil(seconds);
        long d=s/86400; s%=86400;
        long h=s/3600; s%=3600;
        long m=s/60; s%=60;
        if(d>0) return d+"d "+h+"h "+m+"m";
        if(h>0) return h+"h "+m+"m";
        if(m>0) return m+"m "+s+"s";
        return s+"s";
    }
    private static String formatDuration(long s){long h=s/3600,m=(s%3600)/60,sec=s%60;if(h>0)return h+"h "+m+"m";if(m>0)return m+"m "+sec+"s";return sec+"s";}
    private static String formatBytes(long b){if(b<1024)return b+" B";if(b<1024*1024)return String.format(Locale.US,"%.1f KB",b/1024.0);if(b<1024*1024*1024)return String.format(Locale.US,"%.1f MB",b/(1024.0*1024));return String.format(Locale.US,"%.2f GB",b/(1024.0*1024*1024));}

    private void refreshDeviceStatsSafe(){
        safeSetText(dbSize, "Database: checking…");
        safeSetText(freeStorage, "Free storage: checking…");
        safeSetText(networkType, "Network: checking…");

        try {
            File db = new File(getFilesDir(), "ycash-node.sqlite");
            safeSetText(dbSize, db.exists() ? formatBytes(db.length()) : "—");
        } catch (Throwable t) {
            safeSetText(dbSize, "Database: ERROR " + t.getClass().getSimpleName());
            writeAppError("DATABASE DIAGNOSTIC", t);
        }

        try {
            StatFs s = new StatFs(getFilesDir().getAbsolutePath());
            safeSetText(freeStorage, formatBytes(s.getAvailableBytes()));
        } catch (Throwable t) {
            safeSetText(freeStorage, "Storage: ERROR " + t.getClass().getSimpleName());
            writeAppError("STORAGE DIAGNOSTIC", t);
        }

        try {
            ConnectivityManager cm =
                (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities c = cm == null ? null :
                cm.getNetworkCapabilities(cm.getActiveNetwork());
            String network = c == null ? "None" :
                c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi" :
                c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "Mobile" :
                "Other";
            safeSetText(networkType, network);
        } catch (Throwable t) {
            safeSetText(networkType, "Network: ERROR " + t.getClass().getSimpleName());
            writeAppError("NETWORK DIAGNOSTIC", t);
        }
    }

    // Kept as a compatibility wrapper for any existing callers.
    private void refreshDeviceStats(){
        refreshDeviceStatsSafe();
    }

    private void refreshNodeLog(){
        readDiagnosticFile(new File(getFilesDir(), "node.log"), "node.log", true);
    }

    private void refreshAppErrorLog(){
        readDiagnosticFile(new File(getFilesDir(), "app-error.log"), "app-error.log", false);
    }

    private void readDiagnosticFile(final File file, final String label, final boolean putInLog){
        new Thread(() -> {
            try {
                if (!file.exists()) {
                    if (putInLog) {
                        runOnUiThread(() -> safeSetText(log, label + ": not created yet"));
                    } else {
                        runOnUiThread(() -> safeSetText(diagnostics,
                            diagnosticsText() + "\n\n" + label + ": not created yet"));
                    }
                    return;
                }

                StringBuilder out = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                    String line;
                    int lines = 0;
                    while ((line = br.readLine()) != null) {
                        out.append(line).append('\n');
                        if (++lines >= 300) {
                            out.append("\n… log truncated at 300 lines …\n");
                            break;
                        }
                    }
                }

                String text = out.length() == 0 ? label + ": empty" : out.toString();
                if (putInLog) {
                    runOnUiThread(() -> safeSetText(log, text));
                } else {
                    runOnUiThread(() -> safeSetText(diagnostics,
                        diagnosticsText() + "\n\n===== " + label + " =====\n" + text));
                }
            } catch (Throwable t) {
                writeAppError("READ " + label, t);
                runOnUiThread(() -> {
                    if (putInLog) {
                        safeSetText(log, label + ": ERROR " +
                            t.getClass().getSimpleName() + " — " +
                            String.valueOf(t.getMessage()));
                    }
                });
            }
        }, "ycash-diagnostics").start();
    }

    private String diagnosticsText(){
        try {
            return diagnostics == null ? "" : String.valueOf(diagnostics.getText());
        } catch (Throwable ignored) {
            return "";
        }
    }

    private void safeSetText(final TextView view, final String text){
        try {
            if (view != null) view.setText(text);
        } catch (Throwable ignored) {
        }
    }

    private void writeAppError(String where, Throwable t){
        try {
            File file = new File(getFilesDir(), "app-error.log");
            try (FileWriter w = new FileWriter(file, true)) {
                w.write("\n===== " + System.currentTimeMillis() + " =====\n");
                w.write(where + "\n");
                w.write(t.toString() + "\n");
                StringWriter sw = new StringWriter();
                PrintWriter pw = new PrintWriter(sw);
                t.printStackTrace(pw);
                pw.flush();
                w.write(sw.toString());
                w.write("\n");
            }
        } catch (Throwable ignored) {
        }
    }

    private void testNetwork(){
        new Thread(() -> { long t=System.currentTimeMillis(); try{HttpURLConnection c=(HttpURLConnection)new URL("http://127.0.0.1:8834/status").openConnection();c.setConnectTimeout(3000);c.setReadTimeout(3000);int code=c.getResponseCode();c.disconnect();runOnUiThread(() -> log.setText("Status API: HTTP "+code+" · "+(System.currentTimeMillis()-t)+" ms"));}catch(Exception e){runOnUiThread(() -> log.setText("Status API test failed: "+e.getClass().getSimpleName()));}}).start();
    }

    private void startExportChain(){
        if(!running){exportStatus.setText("Export: start the node first");return;}
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        i.putExtra(Intent.EXTRA_TITLE,"ycash-chain-"+(System.currentTimeMillis()/1000)+".zip");
        exportStatus.setText("Export: choose destination…");
        try{startActivityForResult(i,1001);}catch(Exception e){exportStatus.setText("Export: file picker unavailable");}
    }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==1001&&c==RESULT_OK&&d!=null&&d.getData()!=null)exportChainTo(d.getData());else if(r==1001)exportStatus.setText("Export: cancelled");}
    private void exportChain(android.net.Uri dest){exportChainTo(dest);}

    /**
     * Downloads the chain snapshot from the node and compresses it into a .zip
     * (one entry: ycash-chain-height-N.sqlite) on the fly. Nothing is held in
     * memory and no uncompressed copy is written to shared storage -- bytes go
     * node -> Deflater -> chosen file. If anything fails the partial zip is
     * deleted so a broken archive is never left behind.
     */
    private void exportChainTo(android.net.Uri dest){
        exportStatus.setText("Export: creating snapshot…");
        new Thread(() -> {
            HttpURLConnection c=null;boolean ok=false;
            try{
                c=(HttpURLConnection)new URL("http://127.0.0.1:8834/export").openConnection();
                c.setConnectTimeout(5000);c.setReadTimeout(0);c.setRequestMethod("GET");
                if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());
                final long size=c.getContentLengthLong();
                String h=c.getHeaderField("X-Chain-Height");
                String entryName="ycash-chain-height-"+(h!=null?h.trim():"unknown")+".sqlite";
                long read=0,written;long lastUi=0;
                try(InputStream in=new BufferedInputStream(c.getInputStream(),256*1024);
                    OutputStream raw=getContentResolver().openOutputStream(dest,"w")){
                    if(raw==null)throw new IOException("destination unavailable");
                    CountingOutputStream counted=new CountingOutputStream(new BufferedOutputStream(raw,256*1024));
                    ZipOutputStream zip=new ZipOutputStream(counted);
                    // Block data is mostly already-random hashes/proofs; a high
                    // level burns battery for very little extra saving.
                    zip.setLevel(Deflater.BEST_SPEED);
                    zip.putNextEntry(new ZipEntry(entryName));
                    byte[] buf=new byte[256*1024];int n;
                    while((n=in.read(buf))!=-1){
                        zip.write(buf,0,n);read+=n;
                        long now=System.currentTimeMillis();
                        if(now-lastUi>500){lastUi=now;final long rd=read,wr=counted.count;
                            runOnUiThread(() -> exportStatus.setText("Export: zipping "+formatBytes(rd)+(size>0?" / "+formatBytes(size)+" ("+(rd*100/size)+"%)":"")+" → "+formatBytes(wr)));}
                    }
                    if(size>0&&read!=size)throw new IOException("snapshot truncated ("+read+" of "+size+" bytes)");
                    zip.closeEntry();zip.finish();zip.flush();
                    written=counted.count;
                }
                ok=true;
                final long rd=read,wr=written;
                runOnUiThread(() -> exportStatus.setText("Export: saved zip "+formatBytes(wr)+" (chain data "+formatBytes(rd)+")"));
            }catch(Exception e){
                runOnUiThread(() -> exportStatus.setText("Export: failed — "+e.getMessage()));
            }finally{
                if(c!=null)c.disconnect();
                if(!ok){try{android.provider.DocumentsContract.deleteDocument(getContentResolver(),dest);}catch(Exception ignored){}}
            }
        }).start();
    }

    /** Counts compressed bytes written, for the progress line. */
    private static final class CountingOutputStream extends FilterOutputStream{
        long count;
        CountingOutputStream(OutputStream o){super(o);}
        @Override public void write(int b)throws IOException{out.write(b);count++;}
        @Override public void write(byte[] b,int off,int len)throws IOException{out.write(b,off,len);count+=len;}
    }
}
