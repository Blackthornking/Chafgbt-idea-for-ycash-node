//! Fixed Zebra-style synchronization coordinator.
//!
//! The transport request is fixed at 48 blocks; the scheduler starts with
//! a 48-block lookahead and grows it adaptively in complete 48-block ranges.
//! Consensus/state validation remains owned by State and the single ordered
//! commit worker.

pub mod telemetry;
pub use telemetry::{PipelineSnapshot, PipelineStats};

use std::collections::{BTreeMap, HashMap};
use std::time::{Duration, Instant};

pub const MAX_BLOCKS_IN_TRANSIT_PER_PEER: usize = 48;
pub const MAX_PROSPECTIVE_BLOCKS: usize = 2000;

/// Keep adaptive windows aligned to complete transport ranges. The first
/// window is exactly 48; subsequent windows are 96, 144, 192, ...
fn align_window(value: u64, min_window: usize, max_window: usize, step: usize) -> u64 {
    let min = min_window.max(MAX_BLOCKS_IN_TRANSIT_PER_PEER) as u64;
    let max = max_window.max(min_window).max(MAX_BLOCKS_IN_TRANSIT_PER_PEER) as u64;
    let step = step.max(MAX_BLOCKS_IN_TRANSIT_PER_PEER) as u64;
    let value = value.clamp(min, max);
    let steps = value.saturating_sub(min) / step;
    min.saturating_add(steps.saturating_mul(step)).min(max)
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct BlockWindowId(pub u64);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct BlockWindow { pub start: u64, pub end: u64 }
impl BlockWindow { pub fn len(&self) -> u64 { self.end.saturating_sub(self.start)+1 } }

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BlockWindowState { Pending, Leased, Complete, Quarantined }

#[derive(Clone, Debug)]
pub struct BlockWindowLease {
    pub id: BlockWindowId,
    pub window: BlockWindow,
    pub peer: String,
    pub state: BlockWindowState,
    pub retries: u32,
    pub generation: u64,
    pub claimed_at: Option<Instant>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PipelineConfig {
    /// Fixed network request size. Larger adaptive windows are composed of
    /// multiple disjoint 48-block transport ranges.
    pub max_blocks_in_transit_per_peer: usize,
    /// Absolute adaptive lookahead ceiling.
    pub max_prospective_blocks: usize,
    /// Smallest adaptive lookahead; bootstrap is deliberately 48.
    pub min_window: usize,
    /// Initial adaptive lookahead; deliberately 48.
    pub initial_window: usize,
    /// Largest adaptive lookahead.
    pub max_window: usize,
    /// Adaptive growth/shrink step; normally 48.
    pub window_step: usize,
}
impl Default for PipelineConfig {
    fn default() -> Self {
        Self {
            max_blocks_in_transit_per_peer: MAX_BLOCKS_IN_TRANSIT_PER_PEER,
            max_prospective_blocks: MAX_PROSPECTIVE_BLOCKS,
            min_window: 48,
            initial_window: 48,
            max_window: 2000,
            window_step: 48,
        }
    }
}

pub struct PipelineEngine {
    cfg: PipelineConfig,
    next_id: u64,
    windows: BTreeMap<BlockWindowId, BlockWindowLease>,
    peer_load: HashMap<String, usize>,
    stats: PipelineStats,
    current_window: u64,
    successful_full_window_commits: u32,
}
impl PipelineEngine {
    pub fn new(cfg: PipelineConfig) -> Self {
        let mut stats=PipelineStats::default();
        stats.start();
        let min_window = cfg.min_window.max(MAX_BLOCKS_IN_TRANSIT_PER_PEER);
        let max_window = cfg.max_window.max(min_window)
            .min(cfg.max_prospective_blocks.max(min_window));
        let initial_window = cfg.initial_window.max(min_window).min(max_window);
        let current_window = align_window(initial_window, min_window, max_window, cfg.window_step);
        stats.current_window=current_window;
        stats.max_inflight_windows=((current_window as usize + MAX_BLOCKS_IN_TRANSIT_PER_PEER - 1)
            / MAX_BLOCKS_IN_TRANSIT_PER_PEER).max(1) as u64;
        Self {
            cfg, next_id:0, windows:BTreeMap::new(), peer_load:HashMap::new(), stats,
            current_window, successful_full_window_commits: 0,
        }
    }
    pub fn plan_windows(&mut self,next:u64,tip:u64,_workers:usize)->Vec<BlockWindowId>{
        if next>tip{return Vec::new()}

        // Hard scheduler invariant: the adaptive lookahead is split into
        // fixed 48-block transport ranges. The active range count is derived
        // from the current lookahead, so growth adds whole range slots only.
        // The old implementation
        // only bounded total block height, which allowed repeated planner
        // calls to create a fifth range (and made the dashboard show 5/4).
        // Count both pending and leased ranges here so the limit is enforced
        // at the point of creation, not merely reported by telemetry.
        if self.active_window_count() >= self.configured_max_inflight_windows() {
            return Vec::new();
        }

        let covered=self.outstanding_heights();
        let target = self.current_window.min(self.cfg.max_prospective_blocks.max(48) as u64);
        if covered >= target { return Vec::new(); }
        let mut start=next;
        while self.windows.values().any(|w| matches!(w.state,BlockWindowState::Pending|BlockWindowState::Leased|BlockWindowState::Quarantined)
            && w.window.start<=start && start<=w.window.end) { start+=1; }
        if start>tip { return Vec::new(); }
        let capacity=target.saturating_sub(covered);
        // Wire transport stays fixed at 48. Adaptive lookahead is composed
        // from multiple independent 48-block ranges.
        let len=(tip-start+1).min(MAX_BLOCKS_IN_TRANSIT_PER_PEER as u64).min(capacity);
        if len==0{return Vec::new()}
        let id=self.enqueue(start,start+len-1);
        self.stats.request_rounds+=1;
        self.stats.current_window=self.current_window;
        self.stats.max_inflight_windows=self.configured_max_inflight_windows() as u64;
        self.stats.blocks_in_flight=self.outstanding_heights();
        vec![id]
    }
    fn enqueue(&mut self,start:u64,end:u64)->BlockWindowId {
        let id=BlockWindowId(self.next_id); self.next_id+=1;
        self.windows.insert(id,BlockWindowLease{id,window:BlockWindow{start,end},peer:String::new(),
            state:BlockWindowState::Pending,retries:0,generation:0,claimed_at:None});
        id
    }
    pub fn claim(&mut self,p:&str)->Option<BlockWindowLease>{
        if self.peer_load.get(p).copied().unwrap_or(0) >= 1 { return None; }
        if self.leased_windows() >= self.configured_max_inflight_windows() { return None; }
        let id=self.windows.iter().find(|(_,w)|w.state==BlockWindowState::Pending).map(|(i,_)|*i)?;
        let w=self.windows.get_mut(&id)?;
        w.peer=p.to_owned(); w.state=BlockWindowState::Leased; w.generation+=1; w.claimed_at=Some(Instant::now());
        *self.peer_load.entry(p.to_owned()).or_default()+=1;
        Some(w.clone())
    }
    pub fn claim_upto(&mut self,p:&str,max_end:u64)->Option<BlockWindowLease>{
        if self.peer_load.get(p).copied().unwrap_or(0)>=1{return None}
        if self.leased_windows() >= self.configured_max_inflight_windows() { return None; }
        let id=self.windows.iter().find(|(_,w)|w.state==BlockWindowState::Pending && w.window.end<=max_end).map(|(i,_)|*i)?;
        let w=self.windows.get_mut(&id)?;
        w.peer=p.to_owned(); w.state=BlockWindowState::Leased; w.generation+=1; w.claimed_at=Some(Instant::now());
        *self.peer_load.entry(p.to_owned()).or_default()+=1; Some(w.clone())
    }
    pub fn complete(&mut self,id:BlockWindowId,blocks:u64,bytes:u64){
        if let Some(w)=self.windows.remove(&id){ if let Some(v)=self.peer_load.get_mut(&w.peer){*v=v.saturating_sub(1)} }
        self.stats.blocks_received+=blocks; self.stats.blocks_committed+=blocks;
        self.stats.bytes_received+=bytes; self.stats.completed_windows+=1;
        self.stats.blocks_in_flight=self.outstanding_heights();
    }
    pub fn release(&mut self,id:BlockWindowId){self.requeue(id,true);}
    pub fn release_if_current(&mut self,id:BlockWindowId,g:u64)->bool{
        if self.is_current_lease(id,g){self.release(id);true}else{false}
    }
    pub fn requeue_lease(&mut self,id:BlockWindowId){self.requeue(id,false);}
    fn requeue(&mut self,id:BlockWindowId,count_retry:bool){
        let mut quarantined=false;
        if let Some(w)=self.windows.get_mut(&id){
            let peer=w.peer.clone();
            if let Some(v)=self.peer_load.get_mut(&peer){*v=v.saturating_sub(1)}
            if count_retry {w.retries=w.retries.saturating_add(1)}
            w.peer.clear();w.claimed_at=None;w.generation+=1;
            w.state=if w.retries>=3{BlockWindowState::Quarantined}else{BlockWindowState::Pending};
            quarantined=w.state==BlockWindowState::Quarantined;
        }
        self.stats.retried_windows+=u64::from(count_retry);
        self.stats.quarantined_windows += u64::from(quarantined && count_retry);
    }
    pub fn is_current_lease(&self,id:BlockWindowId,g:u64)->bool{self.windows.get(&id).map(|w|w.state==BlockWindowState::Leased&&w.generation==g).unwrap_or(false)}
    pub fn window_end(&self,id:BlockWindowId)->Option<u64>{self.windows.get(&id).map(|w|w.window.end)}
    pub fn lease_age(&self,id:BlockWindowId)->Option<Duration>{self.windows.get(&id)?.claimed_at.map(|x|x.elapsed())}
    pub fn window_ids_at_start(&self,s:u64)->Option<BlockWindowId>{self.windows.values().find(|w|w.window.start==s).map(|w|w.id)}
    pub fn requeue_if_lease_stalled(&mut self,id:BlockWindowId,d:Duration)->bool{if self.lease_age(id).map(|x|x>=d).unwrap_or(false){self.requeue(id,false);true}else{false}}
    pub fn requeue_if_quarantined_at(&mut self,s:u64)->bool{if let Some(id)=self.window_ids_at_start(s){if self.windows.get(&id).map(|w|w.state==BlockWindowState::Quarantined).unwrap_or(false){self.requeue(id,false);return true}}false}
    pub fn outstanding_heights(&self)->u64{self.windows.values().filter(|w|matches!(w.state,BlockWindowState::Pending|BlockWindowState::Leased)).map(|w|w.window.len()).sum()}
    pub fn pending_windows(&self)->usize{self.windows.values().filter(|w|w.state==BlockWindowState::Pending).count()}
    pub fn leased_windows(&self)->usize{self.windows.values().filter(|w|w.state==BlockWindowState::Leased).count()}
    fn active_window_count(&self)->usize{
        self.windows.values().filter(|w| matches!(w.state, BlockWindowState::Pending | BlockWindowState::Leased)).count()
    }
    pub fn current_validation_workers(&self)->usize{self.configured_max_validation_workers()}
    /// Number of ranges currently leased to peers. This is a live value, not
    /// the configured ceiling. Zero is reported as zero so telemetry cannot
    /// manufacture a phantom in-flight range.
    pub fn max_inflight_windows(&self)->usize{self.leased_windows()}
    /// Fixed 48-block transport ranges within the 192-block lookahead.
    /// Keep this derived from the same constants used by planning so the
    /// displayed ceiling and the enforced ceiling cannot diverge.
    pub fn configured_max_inflight_windows(&self)->usize{
        ((self.current_window as usize + MAX_BLOCKS_IN_TRANSIT_PER_PEER - 1)
            / MAX_BLOCKS_IN_TRANSIT_PER_PEER).max(1)
    }
    pub fn transport_window(&self)->usize{MAX_BLOCKS_IN_TRANSIT_PER_PEER}
    pub fn configured_high_watermark(&self)->f64{1.0}
    pub fn configured_low_watermark(&self)->f64{0.0}
    /// Current adaptive lookahead. The wire request itself remains 48 blocks.
    pub fn window(&self)->u64{self.current_window}
    pub fn lookahead(&self)->u64{self.current_window}

    /// Increase only after three consecutive commits that filled the current
    /// adaptive window. This gives the 48-block bootstrap time to prove that
    /// fetch, validation, ordering, and commit are healthy.
    pub fn record_full_window_commit(&mut self, committed_blocks: usize) {
        if committed_blocks < self.current_window as usize {
            self.successful_full_window_commits = 0;
            return;
        }
        self.successful_full_window_commits = self.successful_full_window_commits.saturating_add(1);
        if self.successful_full_window_commits >= 3 {
            let step = self.cfg.window_step.max(MAX_BLOCKS_IN_TRANSIT_PER_PEER);
            let min_window = self.cfg.min_window.max(MAX_BLOCKS_IN_TRANSIT_PER_PEER);
            let max_window = self.cfg.max_window.max(min_window)
                .min(self.cfg.max_prospective_blocks.max(min_window));
            self.current_window = align_window(
                self.current_window.saturating_add(step),
                min_window, max_window, step,
            );
            self.successful_full_window_commits = 0;
            self.stats.current_window = self.current_window;
            self.stats.max_inflight_windows = self.configured_max_inflight_windows() as u64;
        }
    }

    /// Shrink after a canonical commit-stage failure, never below 48.
    pub fn record_commit_failure(&mut self) {
        let step = self.cfg.window_step.max(MAX_BLOCKS_IN_TRANSIT_PER_PEER);
        let min_window = self.cfg.min_window.max(MAX_BLOCKS_IN_TRANSIT_PER_PEER);
        self.current_window = align_window(
            self.current_window.saturating_sub(step),
            min_window, self.cfg.max_window.max(min_window), step,
        );
        self.successful_full_window_commits = 0;
        self.stats.current_window = self.current_window;
        self.stats.max_inflight_windows = self.configured_max_inflight_windows() as u64;
    }

    pub fn current_pressure(&self)->f64{0.0}
    pub fn current_demand(&self)->f64{0.0}
    pub fn configured_max_validation_workers(&self)->usize{std::thread::available_parallelism().map(|n|n.get().saturating_sub(1).max(1)).unwrap_or(1)}
    pub fn snapshot(&self)->PipelineSnapshot{self.stats.snapshot()}
}


#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn planner_starts_with_one_48_block_range() {
        let mut p = PipelineEngine::new(PipelineConfig::default());
        let ids = p.plan_windows(1, 500, 8);
        assert_eq!(ids.len(), 1);
        assert_eq!(p.window(), 48);
        assert_eq!(p.lookahead(), 48);
        assert_eq!(p.window_end(ids[0]), Some(48));
        assert_eq!(p.configured_max_inflight_windows(), 1);
        assert_eq!(p.pending_windows(), 1);
        assert!(p.plan_windows(49, 500, 8).is_empty());
    }

    #[test]
    fn three_full_48_block_commits_expand_window() {
        let mut p = PipelineEngine::new(PipelineConfig::default());
        p.record_full_window_commit(48);
        assert_eq!(p.window(), 48);
        p.record_full_window_commit(48);
        assert_eq!(p.window(), 48);
        p.record_full_window_commit(48);
        assert_eq!(p.window(), 96);
        assert_eq!(p.configured_max_inflight_windows(), 2);
    }

    #[test]
    fn commit_failure_never_reduces_below_48() {
        let mut p = PipelineEngine::new(PipelineConfig::default());
        p.record_commit_failure();
        assert_eq!(p.window(), 48);
    }
}
