use anyhow::Result;
use std::path::PathBuf;
use ycash_state::pipeline::{PipelineConfig, PipelineEngine};
use ycash_state::State;

mod sync;

#[tokio::main]
async fn main()->Result<()>{
 tracing_subscriber::fmt::init();
 let db=std::env::var_os("YCASH_NODE_DB").map(PathBuf::from).unwrap_or_else(||PathBuf::from("ycash-node.rocksdb"));
 let state=State::open(db)?;
 tracing::info!(tip=?state.tip_height()?,"Ycash Android Node state engine initialized");

 // Adaptive sync pipeline. TOML defaults are embedded so the packaged
 // binary starts with a 48-block window and cannot silently change transport size.
 let pipeline=PipelineEngine::new(load_pipeline_config());
 let cfg=sync::SyncConfig::default();
 if cfg.seeds.is_empty() {
     tracing::warn!("no sync seeds configured");
 }
 let handle=tokio::task::spawn_blocking(move||{
     sync::run_sync_loop(state,pipeline,cfg);
 });
 handle.await?;
 Ok(())
}

fn load_pipeline_config() -> PipelineConfig {
    let text = std::env::var_os("YCASH_PIPELINE_CONFIG")
        .and_then(|p| std::fs::read_to_string(p).ok())
        .unwrap_or_else(|| include_str!("../../../config/pipeline.toml").to_owned());
    let mut cfg = PipelineConfig::default();
    for line in text.lines() {
        let line = line.split('#').next().unwrap_or("").trim();
        let Some((key, value)) = line.split_once('=') else { continue };
        let value = value.trim().trim_matches('"');
        if let Ok(n) = value.parse::<usize>() {
            match key.trim() {
                "max_blocks_in_transit_per_peer" => cfg.max_blocks_in_transit_per_peer = n.clamp(1, 48),
                "max_prospective_blocks" => cfg.max_prospective_blocks = n.max(48),
                "min_window" => cfg.min_window = n.max(48),
                "initial_window" => cfg.initial_window = n.max(48),
                "max_window" => cfg.max_window = n.max(48),
                "window_step" => cfg.window_step = n.max(48),
                _ => {}
            }
        }
    }
    if cfg.max_blocks_in_transit_per_peer != 48 {
        tracing::warn!("max_blocks_in_transit_per_peer is fixed at 48 for this build");
        cfg.max_blocks_in_transit_per_peer = 48;
    }
    cfg
}
