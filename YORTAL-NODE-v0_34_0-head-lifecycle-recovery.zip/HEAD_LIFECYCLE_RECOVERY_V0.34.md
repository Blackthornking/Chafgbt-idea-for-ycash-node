# YORTAL v0.34.0 — Head Lifecycle Recovery

Implemented the full missing-parent hardening pass:

1. Added an explicit `HeadLifecycleTracker` with `FREE → CLAIMED → ARRIVED/VERIFYING → VERIFIED → QUEUED → COMMITTED/FREE` phases.
2. The watchdog can now recover a completely free head by reserving it for a healthy connected peer; socket I/O remains in peer sessions.
3. Added explicit `VERIFIED → QUEUED` lifecycle transition; scheduling no longer uses `candidate_present` telemetry.
4. Made late-arrival adoption obey the global lifecycle capacity.
5. Added transport-claim reconciliation after canonical/header rewinds so reorgs cannot leave obsolete transport claims occupying capacity.
6. Enforced contiguous canonical-header and parent-link invariants inside `State::put_headers_batch`, including genesis boundary validation.
7. Watchdog recovery covers free, stale transport, and stale verification lifecycle states.
8. Added deterministic head-recovery integration tests plus state-level header-invariant tests.
9. Updated `BUILD_ID.txt` to `v0.34.0-head-lifecycle-recovery`.
10. Added `tools/verify-head-recovery-v0.34.sh` static release checks.

The consensus rule remains ordered and single-writer. The changes are transport/lifecycle recovery and state-boundary validation only.
