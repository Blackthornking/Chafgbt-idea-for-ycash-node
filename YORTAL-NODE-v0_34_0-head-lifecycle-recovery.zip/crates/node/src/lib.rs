//! YORTAL synchronisation engine.
//!
//! ```text
//!   peers (n)                 verifier pool (m)        ordered gate (1)     writer (1)
//!   ┌──────────────┐  block   ┌──────────────────┐     ┌───────────────┐    ┌─────────┐
//!   │ ≤48 in flight│ ───────► │ semantic verify  │ ──► │ prospective   │ ─► │ one     │
//!   │ replenish on │  stream  │ (context-free,   │     │ tree + chain  │    │ Write   │
//!   │ each arrival │          │  out of order)   │     │ selection +   │    │ Batch   │
//!   └──────────────┘          └──────────────────┘     │ contextual    │    └─────────┘
//!                                                      │ rules, in     │
//!                                                      │ ancestry order│
//!                                                      └───────────────┘
//! ```
//!
//! Everything left of the gate is parallel and unordered. Everything from the
//! gate rightwards is single-threaded and strictly ordered by ancestry. That
//! split is the whole design: it is what lets the node use every core without
//! any consensus rule depending on how many cores there are, how many blocks a
//! peer had in flight, or how many blocks shared a WriteBatch.

use std::sync::atomic::Ordering;
use std::sync::Arc;

use anyhow::Result;
use ycash_state::state_service::{StateService, StateServiceHandle, SyncMetrics};
use ycash_state::State;

pub mod downloader;
pub mod peer_manager;
pub mod verifier;

pub use downloader::{
    BlockAssigner, BlockRequest, HeadLifecycleTracker, HeadPhase, HeadSnapshot, HeadStatus, InFlightRegistry, PeerDownloadSession, MAX_BLOCKS_IN_FLIGHT,
    MAX_BLOCKS_IN_TRANSIT_PER_PEER, REQUEST_TIMEOUT, CANONICAL_PARENT_RETRY_TIMEOUT,
};
pub use peer_manager::{PeerManager, PeerStats};
pub use verifier::{RawBlock, VerifierPool, ASSUME_VALID_HASH_DISPLAY, ASSUME_VALID_HEIGHT};

/// Transport and resource settings. None of these is a consensus parameter:
/// the same chain synchronised with any combination of them must produce the
/// same canonical state.
#[derive(Clone, Debug)]
pub struct SyncConfig {
    pub blocks_in_transit_per_peer: usize,
    pub max_blocks_in_flight: usize,
    pub prospective_capacity: usize,
    pub verifier_workers: usize,
    pub verifier_queue: usize,
    pub assume_valid: bool,
}

impl SyncConfig {
    /// How far above the canonical tip blocks may be requested.
    ///
    /// Held a margin below the candidate capacity so a full pipeline never
    /// evicts. The margin is one round of per-peer requests, which is the most
    /// that can land between two assignment passes.
    pub fn download_window(&self) -> usize {
        // One bounded global pipeline. Per-peer limits only divide the window;
        // they never multiply it.
        self.max_blocks_in_flight.min(self.prospective_capacity).max(1)
    }
}

impl Default for SyncConfig {
    fn default() -> Self {
        Self {
            blocks_in_transit_per_peer: 16,
            max_blocks_in_flight: 48,
            prospective_capacity: 48,
            verifier_workers: verifier::default_verifier_workers(),
            verifier_queue: 64,
            assume_valid: false,
        }
    }
}

impl SyncConfig {
    /// Read the transport settings from the environment, so they can be changed
    /// on a device without rebuilding. Consensus cannot be changed this way.
    pub fn from_env() -> Self {
        let mut cfg = Self::default();
        if let Some(v) = env_usize("YORTAL_BLOCKS_IN_TRANSIT_PER_PEER") {
            cfg.blocks_in_transit_per_peer = v.clamp(1, MAX_BLOCKS_IN_TRANSIT_PER_PEER);
        }
        if let Some(v) = env_usize("YORTAL_MAX_BLOCKS_IN_FLIGHT") {
            cfg.max_blocks_in_flight = v.clamp(cfg.blocks_in_transit_per_peer, 4096);
        }
        if let Some(v) = env_usize("YORTAL_PROSPECTIVE_BLOCKS") {
            cfg.prospective_capacity = v.clamp(cfg.blocks_in_transit_per_peer, 4096);
        }
        // Keep one bounded global pipeline. Claims cover transport, semantic
        // verification and prospective candidates, so max_blocks_in_flight is
        // deliberately NOT inflated by the number of peers. A multi-peer
        // downloader must not turn a 48-block window into 192+ blocks of RAM.
        cfg.max_blocks_in_flight = cfg.max_blocks_in_flight
            .clamp(cfg.blocks_in_transit_per_peer, 48);
        cfg.prospective_capacity = cfg.prospective_capacity
            .clamp(cfg.blocks_in_transit_per_peer, cfg.max_blocks_in_flight);
        if let Some(v) = env_usize("YORTAL_VERIFY_THREADS") {
            // 0 is the documented automatic mode. Do not clamp it to 1: that
            // silently disabled the device-derived verifier width on Android.
            cfg.verifier_workers = if v == 0 {
                verifier::default_verifier_workers()
            } else {
                v.clamp(1, 64)
            };
        }
        cfg.assume_valid = std::env::var("YCASH_ASSUME_VALID").ok().as_deref() == Some("1")
            && std::env::var("YCASH_FULL_VERIFY").ok().as_deref() != Some("1");
        cfg
    }
}

fn env_usize(name: &str) -> Option<usize> {
    std::env::var(name).ok().and_then(|v| v.trim().parse::<usize>().ok())
}

/// Everything the peer threads need, started once per process.
#[derive(Clone)]
pub struct SyncEngine {
    pub state: Arc<State>,
    pub peers: Arc<PeerManager>,
    pub registry: Arc<InFlightRegistry>,
    pub assigner: Arc<BlockAssigner>,
    pub verifiers: VerifierPool,
    pub gate: StateServiceHandle,
    pub metrics: Arc<SyncMetrics>,
    pub config: SyncConfig,
}

impl SyncEngine {
    /// Start the ordered state gate, the canonical writer and the verifier
    /// pool. Fails if a canonical writer already exists.
    pub fn start(state: Arc<State>, config: SyncConfig) -> Result<Self> {
        let metrics = SyncMetrics::new();
        // One lifecycle registry spans transport, semantic verification and
        // ordered publication. The state gate releases entries only after a
        // successful canonical write or an explicit discard.
        let registry = Arc::new(InFlightRegistry::new(config.max_blocks_in_flight));
        let lifecycle: ycash_state::state_service::CandidateLifecycleHook = {
            let registry = Arc::clone(&registry);
            Arc::new(move |event: ycash_state::state_service::CandidateLifecycleEvent, hashes: Vec<[u8; 32]>| {
                match event {
                    ycash_state::state_service::CandidateLifecycleEvent::Committed
                    | ycash_state::state_service::CandidateLifecycleEvent::Discarded => registry.release_many(&hashes),
                }
            })
        };
        let gate = StateService::spawn_with_lifecycle_hook(
            Arc::clone(&state),
            config.prospective_capacity,
            Arc::clone(&metrics),
            Some(lifecycle),
        )?;
        let verifiers = VerifierPool::spawn(
            config.verifier_workers,
            config.verifier_queue,
            gate.clone(),
            Arc::clone(&metrics),
            Arc::clone(&registry),
            config.assume_valid,
        )?;
        let assigner = Arc::new(BlockAssigner::new(
            Arc::clone(&state),
            Arc::clone(&registry),
            Arc::clone(&metrics),
            // Strictly *less* than the candidate set can hold.
            //
            // Every claimed block is either in transit or buffered, and every
            // claim lies inside this window, so buffered <= window. Keeping the
            // window below capacity therefore means eviction never happens at
            // all. Setting the two equal — which is what this was — guarantees
            // the opposite: the buffer sits permanently at capacity, every
            // arrival evicts a block, the eviction frees that block's claim,
            // and it is immediately re-requested. The chain still advances, in
            // bursts, while a large share of the bandwidth goes on re-fetching
            // blocks that were thrown away.
            config.download_window(),
        ));
        assigner.rewind_to_canonical()?;
        let peers = Arc::new(PeerManager::new());
        if let Ok(Some(tip)) = state.tip_height() {
            metrics
                .canonical_height
                .store(tip, std::sync::atomic::Ordering::Relaxed);
        }
        Ok(Self { state, peers, registry, assigner, verifiers, gate, metrics, config })
    }

    /// Per-peer request window.
    pub fn session(&self, peer: &str) -> PeerDownloadSession {
        PeerDownloadSession::new(
            peer,
            Arc::clone(&self.assigner),
            Arc::clone(&self.registry),
            Arc::clone(&self.peers),
            Arc::clone(&self.metrics),
        )
        .with_limit(self.config.blocks_in_transit_per_peer)
    }

    /// Run the transport-level canonical-head watchdog independently of peer
    /// socket loops. This matters on Android because a peer thread can be
    /// blocked in a socket read while the exact tip+1 request is stalled.
    /// Releasing/nominating the claim here does not touch consensus state; the
    /// next responsive peer will pick the head up on its normal request pass.
    pub fn watchdog_head_once(&self) -> Result<bool> {
        let canonical = self.assigner.canonical_height()?;
        let next_height = canonical.saturating_add(1);
        let Some(hash) = self.assigner.header_hash(next_height)? else { return Ok(false) };
        self.registry.set_head_target(next_height, hash);
        match self.registry.head_status(&hash) {
            HeadStatus::Free => {
                // The watchdog is also able to recover a completely unclaimed
                // head. It reserves the hash for a healthy connected peer; the
                // peer's normal assignment pass performs the actual getdata.
                let Some(peer) = self.peers.best_peer() else { return Ok(false) };
                let alternates = self.peers.peer_count() > 1;
                if !self.registry.reserve_head(hash, &peer, alternates) { return Ok(false); }
                self.metrics.set_missing_parent_in_flight(false);
                self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
                self.metrics.mark_parent_retry();
                self.metrics.trace_head(peer, "WATCHDOG_RESERVE", next_height, Some(hash), "head was free; watchdog nominated a peer for recovery");
                let _ = self.assigner.rewind_to_canonical();
                Ok(true)
            }
            HeadStatus::Transport { owner, age } => {
                let timeout = self.registry.head_retry_timeout(&hash, CANONICAL_PARENT_RETRY_TIMEOUT);
                if age < timeout { return Ok(false); }
                let alternate = self.peers.best_alternate(&owner);
                if !self.registry.reassign_head(&hash, &owner, alternate.clone()) { return Ok(false); }
                self.peers.update(&owner, |s| s.timeouts = s.timeouts.saturating_add(1));
                self.metrics.set_missing_parent_in_flight(false);
                self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                self.metrics.expired_requests.fetch_add(1, Ordering::Relaxed);
                self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
                self.metrics.mark_parent_retry();
                self.metrics.trace_head(owner.clone(), "WATCHDOG_REASSIGN", next_height, Some(hash), format!("head request exceeded {}s outside peer loop; next_peer={}", timeout.as_secs(), alternate.as_deref().unwrap_or("none")));
                let _ = self.assigner.rewind_to_canonical();
                Ok(true)
            }
            HeadStatus::Lifecycle { age } => {
                if age < downloader::HEAD_LIFECYCLE_TIMEOUT { return Ok(false); }
                if !self.registry.break_stale_lifecycle(&hash, downloader::HEAD_LIFECYCLE_TIMEOUT) { return Ok(false); }
                let Some(peer) = self.peers.best_peer() else { return Ok(true) };
                let alternates = self.peers.peer_count() > 1;
                let _ = self.registry.reserve_head(hash, &peer, alternates);
                self.metrics.set_missing_parent_in_flight(false);
                self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
                self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
                self.metrics.mark_parent_retry();
                self.metrics.trace_head(peer, "WATCHDOG_LIFECYCLE_RECOVERY", next_height, Some(hash), format!("head lifecycle stalled for {}s; lifecycle claim reset", age.as_secs()));
                let _ = self.assigner.rewind_to_canonical();
                Ok(true)
            }
        }
    }

    /// Handle one `block` message: match it to an outstanding request, free the
    /// slot and queue it for semantic verification.
    ///
    /// A block nobody asked for is ignored rather than trusted, and an unknown
    /// hash is never counted against the peer's window.
    pub fn on_block_message(&self, session: &mut PeerDownloadSession, raw: Vec<u8>) -> Result<bool> {
        let Some(hash) = block_hash(&raw) else { return Ok(false) };
        let bytes = raw.len();
        let Some(request) = session.on_block(&hash, bytes) else { return Ok(false) };
        let source_peer = session.peer().to_string();
        if let Err(e) = self.verifiers.submit(RawBlock { request: request.clone(), raw, source_peer }) {
            self.registry.release(&request.hash);
            return Err(e);
        }
        Ok(true)
    }

    /// Hashes to put in the next `getdata`, refilling the peer's window.
    pub fn next_requests(&self, session: &mut PeerDownloadSession) -> Result<Vec<[u8; 32]>> {
        // The canonical parent is special: later blocks cannot be committed
        // around it, so do not make tip+1 wait for the normal 90s transport
        // timeout. A short head retry lets another peer take over quickly.
        session.retry_canonical_parent(CANONICAL_PARENT_RETRY_TIMEOUT)?;
        session.expire_stale(REQUEST_TIMEOUT);
        session.top_up()
    }

    /// Record an exact canonical-head transport event for diagnostics.
    pub fn trace_head(&self, peer: impl Into<String>, event: impl Into<String>, height: u64, hash: Option<[u8; 32]>, detail: impl Into<String>) {
        self.metrics.trace_head(peer, event, height, hash, detail);
    }

    /// Nudge the ordered gate, e.g. after the header chain advanced.
    pub fn poke(&self) {
        self.gate.poke();
    }
}

/// Block hash: double SHA-256 over the header including its Equihash solution.
pub fn block_hash(raw: &[u8]) -> Option<[u8; 32]> {
    use sha2::{Digest, Sha256};
    let mut cursor = 140usize;
    let solution_len = read_compact_size(raw, &mut cursor)? as usize;
    let end = cursor.checked_add(solution_len)?;
    let header = raw.get(..end)?;
    let digest = Sha256::digest(Sha256::digest(header));
    let mut out = [0u8; 32];
    out.copy_from_slice(&digest);
    Some(out)
}

fn read_compact_size(raw: &[u8], cursor: &mut usize) -> Option<u64> {
    let first = *raw.get(*cursor)?;
    *cursor += 1;
    let value = match first {
        0xfd => {
            let v = u16::from_le_bytes(raw.get(*cursor..*cursor + 2)?.try_into().ok()?) as u64;
            *cursor += 2;
            v
        }
        0xfe => {
            let v = u32::from_le_bytes(raw.get(*cursor..*cursor + 4)?.try_into().ok()?) as u64;
            *cursor += 4;
            v
        }
        0xff => {
            let v = u64::from_le_bytes(raw.get(*cursor..*cursor + 8)?.try_into().ok()?);
            *cursor += 8;
            v
        }
        n => n as u64,
    };
    Some(value)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transport_settings_stay_inside_their_bounds() {
        let cfg = SyncConfig::default();
        assert_eq!(cfg.blocks_in_transit_per_peer, 16);
        assert_eq!(cfg.max_blocks_in_flight, 48);
        assert_eq!(cfg.prospective_capacity, 48);
        assert_eq!(cfg.download_window(), 48);
        assert!(cfg.verifier_workers >= 1);
    }

    #[test]
    fn compact_size_decodes_every_width() {
        let mut c = 0;
        assert_eq!(read_compact_size(&[0x10], &mut c), Some(0x10));
        c = 0;
        assert_eq!(read_compact_size(&[0xfd, 0x01, 0x02], &mut c), Some(0x0201));
        c = 0;
        assert_eq!(read_compact_size(&[0xfe, 1, 0, 0, 0], &mut c), Some(1));
    }
}
