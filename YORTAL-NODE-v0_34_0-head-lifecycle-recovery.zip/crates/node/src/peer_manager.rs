//! Peer connections and their health.
//!
//! The peer manager knows who is connected and how much work each peer owes.
//! It has no opinion about the canonical chain: a peer cannot make a block
//! valid, and no peer's response is treated as the chain.

use std::collections::HashMap;
use std::sync::Mutex;

#[derive(Clone, Debug, Default)]
pub struct PeerStats {
    pub in_flight: usize,
    pub requested: u64,
    pub received: u64,
    pub timeouts: u64,
}

/// Peer connections and their health. Owns no consensus decision.
#[derive(Default)]
pub struct PeerManager {
    peers: Mutex<HashMap<String, PeerStats>>,
}

impl PeerManager {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn connected(&self, peer: &str) {
        if let Ok(mut peers) = self.peers.lock() {
            peers.entry(peer.to_string()).or_default();
        }
    }

    pub fn disconnected(&self, peer: &str) {
        if let Ok(mut peers) = self.peers.lock() {
            peers.remove(peer);
        }
    }

    pub fn peer_count(&self) -> usize {
        self.peers.lock().map(|p| p.len()).unwrap_or(0)
    }

    pub fn total_in_flight(&self) -> usize {
        self.peers.lock().map(|p| p.values().map(|s| s.in_flight).sum()).unwrap_or(0)
    }

    /// Select the healthiest connected peer other than `exclude`: fewest
    /// request timeouts first, then the fewest requests already outstanding,
    /// then the name so the choice is deterministic. Used only for transport
    /// head hand-off; peer choice never affects consensus.
    ///
    /// Picking an arbitrary map entry (as this used to) could hand a stalled
    /// head to the very peer that was already failing to deliver.
    pub fn best_peer(&self) -> Option<String> {
        self.peers.lock().ok().and_then(|peers| {
            peers.iter().min_by(|(a_name, a), (b_name, b)| {
                (a.timeouts, a.in_flight, a_name.as_str()).cmp(&(b.timeouts, b.in_flight, b_name.as_str()))
            }).map(|(peer, _)| peer.clone())
        })
    }

    pub fn best_alternate(&self, exclude: &str) -> Option<String> {
        self.peers.lock().ok().and_then(|peers| {
            peers
                .iter()
                .filter(|(peer, _)| peer.as_str() != exclude)
                .min_by(|(a_name, a), (b_name, b)| {
                    (a.timeouts, a.in_flight, a_name.as_str()).cmp(&(b.timeouts, b.in_flight, b_name.as_str()))
                })
                .map(|(peer, _)| peer.clone())
        })
    }

    /// Kept for callers that only need "some other peer".
    pub fn alternate_peer(&self, exclude: &str) -> Option<String> {
        self.best_alternate(exclude)
    }

    pub fn snapshot(&self) -> Vec<(String, PeerStats)> {
        self.peers
            .lock()
            .map(|p| p.iter().map(|(k, v)| (k.clone(), v.clone())).collect())
            .unwrap_or_default()
    }

    pub(crate) fn update(&self, peer: &str, f: impl FnOnce(&mut PeerStats)) {
        if let Ok(mut peers) = self.peers.lock() {
            f(peers.entry(peer.to_string()).or_default());
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn head_hand_off_prefers_the_healthiest_other_peer() {
        let peers = PeerManager::new();
        peers.connected("peer-a");
        peers.connected("peer-b");
        peers.connected("peer-c");
        peers.update("peer-b", |s| s.timeouts = 3);
        peers.update("peer-c", |s| { s.timeouts = 0; s.in_flight = 4; });
        assert_eq!(peers.best_alternate("peer-a").as_deref(), Some("peer-c"));
        assert_eq!(peers.best_alternate("peer-c").as_deref(), Some("peer-a"));
        peers.disconnected("peer-b");
        peers.disconnected("peer-c");
        assert_eq!(peers.best_alternate("peer-a"), None);
    }

    #[test]
    fn peer_in_flight_counts_track_requests_and_completions() {
        let peers = PeerManager::new();
        peers.connected("peer-a");
        peers.update("peer-a", |s| s.in_flight = 48);
        assert_eq!(peers.total_in_flight(), 48);
        peers.update("peer-a", |s| s.in_flight -= 1);
        assert_eq!(peers.total_in_flight(), 47);
        peers.disconnected("peer-a");
        assert_eq!(peers.peer_count(), 0);
        assert_eq!(peers.total_in_flight(), 0);
    }
}
