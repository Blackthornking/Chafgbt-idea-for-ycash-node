//! RocksDB storage backend (Zebra-style column families + atomic WriteBatch).
//!
//! This module is **storage only**. It never decides whether a block, a
//! transaction, an anchor or a nullifier is valid: it stores the state that the
//! consensus/state-transition layer has already produced, and hands that state
//! back unchanged. Replacing this file with another key/value engine must not
//! change the canonical state produced by a given valid block sequence.
//!
//! Layout mirrors `zebra-state`'s finalized state: one column family per
//! logical index, keys ordered big-endian so height ranges are contiguous,
//! and one atomic `WriteBatch` per ordered commit (state changes + the
//! canonical tip marker become visible together).

use anyhow::{anyhow, bail, Context, Result};
use rocksdb::{
    BlockBasedOptions, BoundColumnFamily, Cache, ColumnFamilyDescriptor, DBCompressionType,
    DBWithThreadMode, Direction, IteratorMode, MultiThreaded, Options, SnapshotWithThreadMode,
    WriteBatch, WriteOptions,
};
use std::collections::HashSet;
use std::fs;
use std::io::Write as _;
use std::path::{Path, PathBuf};
use std::sync::Arc;

/// Multi-threaded mode: column-family handles are `Arc`-shared, so the
/// pipeline's reader threads and the single canonical writer can use the same
/// database handle.
pub type RocksDb = DBWithThreadMode<MultiThreaded>;
pub type Cf<'a> = Arc<BoundColumnFamily<'a>>;
pub type Snapshot<'a> = SnapshotWithThreadMode<'a, RocksDb>;

// ---------------------------------------------------------------------------
// Column families
// ---------------------------------------------------------------------------

/// `meta` -> small singleton values (tip hash/height, Sapling frontier, ...).
pub const CF_META: &str = "meta";
/// block hash -> [`BlockMeta`] (height, prev, work, canonical flag).
pub const CF_BLOCK: &str = "block_by_hash";
/// block hash -> raw serialized block.
pub const CF_BLOCK_RAW: &str = "block_raw_by_hash";
/// block hash -> concatenated txids of that block (rollback/index maintenance).
pub const CF_BLOCK_TXIDS: &str = "block_txids_by_hash";
/// height (BE) -> block hash. Present only for canonical (main-chain) blocks.
pub const CF_HASH_BY_HEIGHT: &str = "hash_by_height";
/// header hash -> [`HeaderRec`].
pub const CF_HEADER: &str = "header_by_hash";
/// height (BE) -> header hash. Present only for canonical headers.
pub const CF_HEADER_HASH_BY_HEIGHT: &str = "header_hash_by_height";
/// txid -> [`TxRec`] (owning block hash + raw transaction).
pub const CF_TX: &str = "tx_by_txid";
/// txid|vout (BE) -> [`CoinRec`].
pub const CF_UTXO: &str = "utxo_by_outpoint";
/// creation height (BE)|txid|vout -> () : rollback index.
pub const CF_UTXO_BY_HEIGHT: &str = "utxo_loc_by_height";
/// spent height (BE)|txid|vout -> () : unspend-on-reorg and pruning index.
pub const CF_UTXO_SPENT_BY_HEIGHT: &str = "utxo_loc_by_spent_height";
/// Sapling nullifier -> height (BE)|block hash.
pub const CF_SAPLING_NF: &str = "sapling_nullifiers";
/// block hash|nullifier -> () : rollback index.
pub const CF_SAPLING_NF_BY_BLOCK: &str = "sapling_nullifier_by_block";
/// block hash -> [`SaplingTreeRec`] (per-block root + encoded frontier).
pub const CF_SAPLING_TREE: &str = "sapling_note_commitment_tree";
/// Sapling anchor (root) -> lowest canonical height at which it appeared.
pub const CF_SAPLING_ANCHOR: &str = "sapling_anchors";
/// Sprout nullifier -> height (BE).
pub const CF_SPROUT_NF: &str = "sprout_nullifiers";
/// height (BE)|nullifier -> () : rollback index.
pub const CF_SPROUT_NF_BY_HEIGHT: &str = "sprout_nullifier_by_height";
/// block hash -> [`BlockStateRec`] (Sprout tree + ZIP 209 value pools).
pub const CF_BLOCK_STATE: &str = "sprout_block_state";
/// Sprout anchor (root) -> lowest height (BE)|encoded frontier.
pub const CF_SPROUT_ANCHOR: &str = "sprout_anchors";

/// Every column family the running code knows about. Unknown families found on
/// disk are opened and preserved, exactly like Zebra does.
pub const COLUMN_FAMILIES: &[&str] = &[
    CF_META,
    CF_BLOCK,
    CF_BLOCK_RAW,
    CF_BLOCK_TXIDS,
    CF_HASH_BY_HEIGHT,
    CF_HEADER,
    CF_HEADER_HASH_BY_HEIGHT,
    CF_TX,
    CF_UTXO,
    CF_UTXO_BY_HEIGHT,
    CF_UTXO_SPENT_BY_HEIGHT,
    CF_SAPLING_NF,
    CF_SAPLING_NF_BY_BLOCK,
    CF_SAPLING_TREE,
    CF_SAPLING_ANCHOR,
    CF_SPROUT_NF,
    CF_SPROUT_NF_BY_HEIGHT,
    CF_BLOCK_STATE,
    CF_SPROUT_ANCHOR,
];

// Meta keys.
pub const META_SCHEMA_VERSION: &str = "schema_version";
pub const META_TIP_HASH: &str = "tip_hash";
pub const META_TIP_HEIGHT: &str = "tip_height";
pub const META_SAPLING_FRONTIER: &str = "sapling_frontier";
pub const META_TX_COUNT: &str = "tx_count";
pub const META_SAPLING_ROOTS_FROM: &str = "sapling_roots_per_block_from";
/// Highest spent-height already pruned. Without it, every commit would
/// re-walk the tombstones left by earlier prunes at the bottom of the
/// spent-height index.
pub const META_PRUNE_FLOOR: &str = "utxo_prune_floor";

pub type OutPoint = ([u8; 32], u32);

// ---------------------------------------------------------------------------
// Key helpers (big-endian so height ranges iterate in numeric order)
// ---------------------------------------------------------------------------

pub fn height_key(height: u64) -> [u8; 8] {
    height.to_be_bytes()
}

pub fn outpoint_key(op: &OutPoint) -> [u8; 36] {
    let mut k = [0u8; 36];
    k[..32].copy_from_slice(&op.0);
    k[32..].copy_from_slice(&op.1.to_be_bytes());
    k
}

pub fn outpoint_from_key(key: &[u8]) -> Result<OutPoint> {
    if key.len() != 36 {
        bail!("invalid UTXO key length {}", key.len());
    }
    let mut txid = [0u8; 32];
    txid.copy_from_slice(&key[..32]);
    let vout = u32::from_be_bytes(key[32..36].try_into().unwrap());
    Ok((txid, vout))
}

/// height|txid|vout, used by both height indexes.
pub fn height_outpoint_key(height: u64, op: &OutPoint) -> [u8; 44] {
    let mut k = [0u8; 44];
    k[..8].copy_from_slice(&height.to_be_bytes());
    k[8..].copy_from_slice(&outpoint_key(op));
    k
}

pub fn height_outpoint_from_key(key: &[u8]) -> Result<(u64, OutPoint)> {
    if key.len() != 44 {
        bail!("invalid height/outpoint key length {}", key.len());
    }
    let height = u64::from_be_bytes(key[..8].try_into().unwrap());
    Ok((height, outpoint_from_key(&key[8..])?))
}

pub fn pair_key(a: &[u8; 32], b: &[u8; 32]) -> [u8; 64] {
    let mut k = [0u8; 64];
    k[..32].copy_from_slice(a);
    k[32..].copy_from_slice(b);
    k
}

pub fn height_hash_key(height: u64, hash: &[u8; 32]) -> [u8; 40] {
    let mut k = [0u8; 40];
    k[..8].copy_from_slice(&height.to_be_bytes());
    k[8..].copy_from_slice(hash);
    k
}

fn array32(bytes: &[u8], what: &str) -> Result<[u8; 32]> {
    <[u8; 32]>::try_from(bytes).map_err(|_| anyhow!("invalid {what} length {}", bytes.len()))
}

fn u64_at(bytes: &[u8], off: usize, what: &str) -> Result<u64> {
    let end = off + 8;
    if bytes.len() < end {
        bail!("truncated {what} record");
    }
    Ok(u64::from_le_bytes(bytes[off..end].try_into().unwrap()))
}

fn i64_at(bytes: &[u8], off: usize, what: &str) -> Result<i64> {
    Ok(u64_at(bytes, off, what)? as i64)
}

// ---------------------------------------------------------------------------
// Records
// ---------------------------------------------------------------------------

#[derive(Clone, Debug)]
pub struct BlockMeta {
    pub height: u64,
    pub prev: [u8; 32],
    pub work: [u8; 32],
    /// Whether the block is currently on the canonical chain. The authoritative
    /// canonical mapping is [`CF_HASH_BY_HEIGHT`]; this flag mirrors it so a
    /// hash lookup does not need a second read.
    pub canonical: bool,
}

impl BlockMeta {
    pub fn encode(&self) -> Vec<u8> {
        let mut v = Vec::with_capacity(73);
        v.extend_from_slice(&self.height.to_le_bytes());
        v.extend_from_slice(&self.prev);
        v.extend_from_slice(&self.work);
        v.push(self.canonical as u8);
        v
    }

    pub fn decode(b: &[u8]) -> Result<Self> {
        if b.len() < 73 {
            bail!("truncated block metadata record");
        }
        Ok(Self {
            height: u64::from_le_bytes(b[0..8].try_into().unwrap()),
            prev: array32(&b[8..40], "block prev hash")?,
            work: array32(&b[40..72], "block work")?,
            canonical: b[72] != 0,
        })
    }
}

#[derive(Clone, Debug)]
pub struct HeaderRec {
    pub height: u64,
    pub prev: [u8; 32],
    pub time: u32,
    pub bits: u32,
    pub work: [u8; 32],
    pub raw: Vec<u8>,
}

impl HeaderRec {
    pub fn encode(&self) -> Vec<u8> {
        let mut v = Vec::with_capacity(80 + self.raw.len());
        v.extend_from_slice(&self.height.to_le_bytes());
        v.extend_from_slice(&self.prev);
        v.extend_from_slice(&self.time.to_le_bytes());
        v.extend_from_slice(&self.bits.to_le_bytes());
        v.extend_from_slice(&self.work);
        v.extend_from_slice(&self.raw);
        v
    }

    pub fn decode(b: &[u8]) -> Result<Self> {
        if b.len() < 80 {
            bail!("truncated header record");
        }
        Ok(Self {
            height: u64::from_le_bytes(b[0..8].try_into().unwrap()),
            prev: array32(&b[8..40], "header prev hash")?,
            time: u32::from_le_bytes(b[40..44].try_into().unwrap()),
            bits: u32::from_le_bytes(b[44..48].try_into().unwrap()),
            work: array32(&b[48..80], "header work")?,
            raw: b[80..].to_vec(),
        })
    }
}

/// One transparent output, with the height that created it and (once spent)
/// the height that spent it. Identical logical model to the previous SQL row.
#[derive(Clone, Debug)]
pub struct CoinRec {
    pub value: i64,
    pub height: u64,
    pub coinbase: bool,
    pub spent_height: Option<u64>,
    pub script: Vec<u8>,
}

impl CoinRec {
    pub fn encode(&self) -> Vec<u8> {
        let mut v = Vec::with_capacity(26 + self.script.len());
        v.extend_from_slice(&self.value.to_le_bytes());
        v.extend_from_slice(&self.height.to_le_bytes());
        v.push(self.coinbase as u8);
        match self.spent_height {
            Some(h) => {
                v.push(1);
                v.extend_from_slice(&h.to_le_bytes());
            }
            None => {
                v.push(0);
                v.extend_from_slice(&0u64.to_le_bytes());
            }
        }
        v.extend_from_slice(&self.script);
        v
    }

    pub fn decode(b: &[u8]) -> Result<Self> {
        if b.len() < 26 {
            bail!("truncated UTXO record");
        }
        let spent_height = if b[17] != 0 { Some(u64_at(b, 18, "UTXO")?) } else { None };
        Ok(Self {
            value: i64_at(b, 0, "UTXO")?,
            height: u64_at(b, 8, "UTXO")?,
            coinbase: b[16] != 0,
            spent_height,
            script: b[26..].to_vec(),
        })
    }

    /// `height < as_of AND (spent_height IS NULL OR spent_height >= as_of)`:
    /// the state as of the first height of the committing batch. Same predicate
    /// the SQL backend used, so a batch that replaces an old branch still sees
    /// the correct ancestor state.
    pub fn unspent_as_of(&self, as_of: u64) -> bool {
        self.height < as_of && self.spent_height.map(|s| s >= as_of).unwrap_or(true)
    }
}

#[derive(Clone, Debug)]
pub struct TxRec {
    pub block_hash: [u8; 32],
    pub raw: Vec<u8>,
}

impl TxRec {
    pub fn encode(&self) -> Vec<u8> {
        let mut v = Vec::with_capacity(32 + self.raw.len());
        v.extend_from_slice(&self.block_hash);
        v.extend_from_slice(&self.raw);
        v
    }

    pub fn decode(b: &[u8]) -> Result<Self> {
        if b.len() < 32 {
            bail!("truncated transaction record");
        }
        Ok(Self { block_hash: array32(&b[..32], "tx block hash")?, raw: b[32..].to_vec() })
    }
}

#[derive(Clone, Debug)]
pub struct SaplingTreeRec {
    pub root: [u8; 32],
    pub height: u64,
    pub frontier: Vec<u8>,
}

impl SaplingTreeRec {
    pub fn encode(&self) -> Vec<u8> {
        let mut v = Vec::with_capacity(40 + self.frontier.len());
        v.extend_from_slice(&self.root);
        v.extend_from_slice(&self.height.to_le_bytes());
        v.extend_from_slice(&self.frontier);
        v
    }

    pub fn decode(b: &[u8]) -> Result<Self> {
        if b.len() < 40 {
            bail!("truncated Sapling tree record");
        }
        Ok(Self {
            root: array32(&b[..32], "Sapling root")?,
            height: u64_at(b, 32, "Sapling tree")?,
            frontier: b[40..].to_vec(),
        })
    }
}

#[derive(Clone, Debug)]
pub struct BlockStateRec {
    pub height: u64,
    pub sprout_root: [u8; 32],
    pub chain_sprout_value: i64,
    pub chain_sapling_value: i64,
    pub sprout_frontier: Vec<u8>,
}

impl BlockStateRec {
    pub fn encode(&self) -> Vec<u8> {
        let mut v = Vec::with_capacity(56 + self.sprout_frontier.len());
        v.extend_from_slice(&self.height.to_le_bytes());
        v.extend_from_slice(&self.sprout_root);
        v.extend_from_slice(&self.chain_sprout_value.to_le_bytes());
        v.extend_from_slice(&self.chain_sapling_value.to_le_bytes());
        v.extend_from_slice(&self.sprout_frontier);
        v
    }

    pub fn decode(b: &[u8]) -> Result<Self> {
        if b.len() < 56 {
            bail!("truncated block state record");
        }
        Ok(Self {
            height: u64_at(b, 0, "block state")?,
            sprout_root: array32(&b[8..40], "Sprout root")?,
            chain_sprout_value: i64_at(b, 40, "block state")?,
            chain_sapling_value: i64_at(b, 48, "block state")?,
            sprout_frontier: b[56..].to_vec(),
        })
    }
}

/// Sapling nullifier value: the height and block that spent it.
#[derive(Clone, Debug)]
pub struct NullifierRec {
    pub height: u64,
    pub block_hash: [u8; 32],
}

impl NullifierRec {
    pub fn encode(&self) -> Vec<u8> {
        let mut v = Vec::with_capacity(40);
        v.extend_from_slice(&self.height.to_le_bytes());
        v.extend_from_slice(&self.block_hash);
        v
    }

    pub fn decode(b: &[u8]) -> Result<Self> {
        if b.len() < 40 {
            bail!("truncated nullifier record");
        }
        Ok(Self { height: u64_at(b, 0, "nullifier")?, block_hash: array32(&b[8..40], "nullifier block hash")? })
    }
}

/// Sprout anchor value: lowest height at which the root appeared, plus the
/// encoded tree that produced it.
#[derive(Clone, Debug)]
pub struct SproutAnchorRec {
    pub height: u64,
    pub frontier: Vec<u8>,
}

impl SproutAnchorRec {
    pub fn encode(&self) -> Vec<u8> {
        let mut v = Vec::with_capacity(8 + self.frontier.len());
        v.extend_from_slice(&self.height.to_le_bytes());
        v.extend_from_slice(&self.frontier);
        v
    }

    pub fn decode(b: &[u8]) -> Result<Self> {
        if b.len() < 8 {
            bail!("truncated Sprout anchor record");
        }
        Ok(Self { height: u64_at(b, 0, "Sprout anchor")?, frontier: b[8..].to_vec() })
    }
}

// ---------------------------------------------------------------------------
// Database
// ---------------------------------------------------------------------------

/// Tuning targets a phone, not a server: bounded total memtable memory, a
/// shared block cache, and a small background job count.
const BLOCK_CACHE_MB: usize = 64;
const TOTAL_MEMTABLE_MB: usize = 96;
const HOT_WRITE_BUFFER_MB: usize = 16;
const COLD_WRITE_BUFFER_MB: usize = 4;
const ONE_MB: usize = 1024 * 1024;

pub struct Db {
    inner: RocksDb,
    path: PathBuf,
}

impl Db {
    /// Open (creating if needed) the RocksDB state directory.
    ///
    /// If `path` is an existing *file*, it is a legacy SQLite database from an
    /// older YORTAL build: it is moved aside so the node can start on a clean
    /// RocksDB state directory instead of failing to launch.
    pub fn open(path: &Path) -> Result<Self> {
        if path.is_file() {
            let legacy = path.with_extension("sqlite-legacy");
            let _ = fs::remove_file(&legacy);
            fs::rename(path, &legacy)
                .with_context(|| format!("moving legacy SQLite database to {}", legacy.display()))?;
            eprintln!(
                "[DB] legacy SQLite state moved to {} -- starting a fresh RocksDB state directory",
                legacy.display()
            );
        }
        fs::create_dir_all(path).with_context(|| format!("creating {}", path.display()))?;

        let cache = Cache::new_lru_cache(BLOCK_CACHE_MB * ONE_MB);
        let db_opts = Self::db_options(&cache);

        // Preserve any column family already on disk, then add the ones this
        // build knows about (Zebra does the same, so a downgrade cannot lose
        // data it does not understand).
        let mut names: Vec<String> = RocksDb::list_cf(&db_opts, path).unwrap_or_default();
        for name in COLUMN_FAMILIES {
            if !names.iter().any(|n| n == name) {
                names.push((*name).to_string());
            }
        }
        names.retain(|n| n != "default");

        let mut descriptors = vec![ColumnFamilyDescriptor::new("default", Self::cf_options(&cache, false))];
        for name in &names {
            let hot = matches!(
                name.as_str(),
                CF_UTXO | CF_UTXO_BY_HEIGHT | CF_UTXO_SPENT_BY_HEIGHT | CF_TX | CF_BLOCK_RAW
            );
            descriptors.push(ColumnFamilyDescriptor::new(name.as_str(), Self::cf_options(&cache, hot)));
        }

        let inner = RocksDb::open_cf_descriptors(&db_opts, path, descriptors)
            .with_context(|| format!("opening RocksDB state at {}", path.display()))?;

        Ok(Self { inner, path: path.to_path_buf() })
    }

    /// WAL on, fsync off: the same durability posture as the previous
    /// `PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL`. A process kill
    /// (the Android case) cannot lose a committed batch; only an OS/power loss
    /// can, and the tip marker is written in the same batch as the state it
    /// describes, so recovery is never half-applied.
    fn write_options() -> WriteOptions {
        let mut opts = WriteOptions::default();
        opts.set_sync(false);
        opts.disable_wal(false);
        opts
    }

    fn db_options(cache: &Cache) -> Options {
        let mut opts = Options::default();
        opts.create_if_missing(true);
        opts.create_missing_column_families(true);
        opts.set_compression_type(DBCompressionType::Lz4);
        // Bound the total memtable footprint across every column family. This
        // is the single most important knob on a phone: without it, 19 column
        // families each reserve their own write buffers.
        opts.set_db_write_buffer_size(TOTAL_MEMTABLE_MB * ONE_MB);
        opts.set_max_background_jobs(2);
        opts.set_max_total_wal_size((64 * ONE_MB) as u64);
        opts.set_bytes_per_sync(ONE_MB as u64);
        opts.set_keep_log_file_num(2);
        opts.set_max_log_file_size(4 * ONE_MB);
        opts.set_max_open_files(512);
        opts.set_table_cache_num_shard_bits(4);
        opts.set_block_based_table_factory(&Self::table_options(cache));
        opts
    }

    fn table_options(cache: &Cache) -> BlockBasedOptions {
        let mut bbt = BlockBasedOptions::default();
        // Ribbon filters, as recommended by RocksDB and used by Zebra.
        bbt.set_ribbon_filter(9.9);
        bbt.set_block_cache(cache);
        bbt.set_block_size(16 * 1024);
        bbt.set_cache_index_and_filter_blocks(true);
        bbt.set_pin_l0_filter_and_index_blocks_in_cache(true);
        bbt
    }

    fn cf_options(cache: &Cache, hot: bool) -> Options {
        let mut opts = Options::default();
        opts.set_compression_type(DBCompressionType::Lz4);
        opts.set_write_buffer_size(if hot { HOT_WRITE_BUFFER_MB } else { COLD_WRITE_BUFFER_MB } * ONE_MB);
        opts.set_max_write_buffer_number(2);
        opts.set_min_write_buffer_number_to_merge(1);
        opts.set_level_compaction_dynamic_level_bytes(true);
        opts.set_block_based_table_factory(&Self::table_options(cache));
        opts
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    pub fn cf(&self, name: &str) -> Result<Cf<'_>> {
        self.inner.cf_handle(name).ok_or_else(|| anyhow!("missing column family {name}"))
    }

    pub fn get(&self, cf: &Cf<'_>, key: &[u8]) -> Result<Option<Vec<u8>>> {
        Ok(self.inner.get_cf(cf, key)?)
    }

    pub fn get_in(&self, cf_name: &str, key: &[u8]) -> Result<Option<Vec<u8>>> {
        let cf = self.cf(cf_name)?;
        self.get(&cf, key)
    }

    pub fn meta(&self, key: &str) -> Result<Option<Vec<u8>>> {
        self.get_in(CF_META, key.as_bytes())
    }

    pub fn meta_u64(&self, key: &str) -> Result<Option<u64>> {
        match self.meta(key)? {
            Some(v) if v.len() >= 8 => Ok(Some(u64::from_le_bytes(v[..8].try_into().unwrap()))),
            _ => Ok(None),
        }
    }

    /// Consistent point-in-time view for the prepare phase.
    pub fn read_view(&self) -> Result<ReadView<'_>> {
        ReadView::new(self)
    }

    /// Apply one atomic batch. Everything in it becomes visible together.
    pub fn write(&self, batch: WriteBatch) -> Result<()> {
        self.inner.write_opt(batch, &Self::write_options())?;
        Ok(())
    }

    pub fn writer(&self) -> Result<Writer<'_>> {
        Writer::new(self)
    }

    /// Highest key/value in a height-keyed column family, or `None` when empty.
    pub fn last_height_entry(&self, cf_name: &str) -> Result<Option<(u64, Vec<u8>)>> {
        let cf = self.cf(cf_name)?;
        let mut it = self.inner.iterator_cf(&cf, IteratorMode::End);
        match it.next() {
            Some(Ok((k, v))) => {
                if k.len() < 8 {
                    bail!("invalid height key length {}", k.len());
                }
                Ok(Some((u64::from_be_bytes(k[..8].try_into().unwrap()), v.to_vec())))
            }
            Some(Err(e)) => Err(e.into()),
            None => Ok(None),
        }
    }

    /// Every key in `cf_name` whose big-endian height prefix is in
    /// `from..=to`, returned in ascending order.
    pub fn height_range_keys(&self, cf_name: &str, from: u64, to: u64) -> Result<Vec<Vec<u8>>> {
        let cf = self.cf(cf_name)?;
        let start = height_key(from);
        let mut out = Vec::new();
        let it = self.inner.iterator_cf(&cf, IteratorMode::From(&start[..], Direction::Forward));
        for item in it {
            let (k, _) = item?;
            if k.len() < 8 {
                bail!("invalid height key length {}", k.len());
            }
            let h = u64::from_be_bytes(k[..8].try_into().unwrap());
            if h > to {
                break;
            }
            out.push(k.to_vec());
        }
        Ok(out)
    }

    /// Key/value pairs whose key starts with `prefix`.
    pub fn prefix_scan(&self, cf_name: &str, prefix: &[u8]) -> Result<Vec<(Vec<u8>, Vec<u8>)>> {
        let cf = self.cf(cf_name)?;
        let mut out = Vec::new();
        let it = self.inner.iterator_cf(&cf, IteratorMode::From(prefix, Direction::Forward));
        for item in it {
            let (k, v) = item?;
            if !k.starts_with(prefix) {
                break;
            }
            out.push((k.to_vec(), v.to_vec()));
        }
        Ok(out)
    }

    /// Canonical block hash at `height`, or `None` if that height is not on the
    /// main chain.
    pub fn canonical_hash(&self, height: u64) -> Result<Option<[u8; 32]>> {
        match self.get_in(CF_HASH_BY_HEIGHT, &height_key(height))? {
            Some(v) => Ok(Some(array32(&v, "canonical block hash")?)),
            None => Ok(None),
        }
    }

    /// Canonical tip `(hash, height)` derived from the height index, not from a
    /// cached marker, so it is always the state actually on disk.
    pub fn canonical_tip(&self) -> Result<Option<([u8; 32], u64)>> {
        match self.last_height_entry(CF_HASH_BY_HEIGHT)? {
            Some((height, hash)) => Ok(Some((array32(&hash, "canonical tip hash")?, height))),
            None => Ok(None),
        }
    }

    pub fn canonical_header_tip(&self) -> Result<Option<([u8; 32], u64)>> {
        match self.last_height_entry(CF_HEADER_HASH_BY_HEIGHT)? {
            Some((height, hash)) => Ok(Some((array32(&hash, "canonical header hash")?, height))),
            None => Ok(None),
        }
    }

    pub fn block_meta(&self, hash: &[u8; 32]) -> Result<Option<BlockMeta>> {
        match self.get_in(CF_BLOCK, hash)? {
            Some(v) => Ok(Some(BlockMeta::decode(&v)?)),
            None => Ok(None),
        }
    }

    pub fn header(&self, hash: &[u8; 32]) -> Result<Option<HeaderRec>> {
        match self.get_in(CF_HEADER, hash)? {
            Some(v) => Ok(Some(HeaderRec::decode(&v)?)),
            None => Ok(None),
        }
    }

    pub fn canonical_header_hash(&self, height: u64) -> Result<Option<[u8; 32]>> {
        match self.get_in(CF_HEADER_HASH_BY_HEIGHT, &height_key(height))? {
            Some(v) => Ok(Some(array32(&v, "canonical header hash")?)),
            None => Ok(None),
        }
    }

    pub fn canonical_header(&self, height: u64) -> Result<Option<HeaderRec>> {
        match self.canonical_header_hash(height)? {
            Some(hash) => self.header(&hash),
            None => Ok(None),
        }
    }

    pub fn sapling_tree(&self, block_hash: &[u8; 32]) -> Result<Option<SaplingTreeRec>> {
        match self.get_in(CF_SAPLING_TREE, block_hash)? {
            Some(v) => Ok(Some(SaplingTreeRec::decode(&v)?)),
            None => Ok(None),
        }
    }

    pub fn sapling_anchor_height(&self, root: &[u8; 32]) -> Result<Option<u64>> {
        match self.get_in(CF_SAPLING_ANCHOR, root)? {
            Some(v) if v.len() >= 8 => Ok(Some(u64::from_be_bytes(v[..8].try_into().unwrap()))),
            Some(_) => bail!("truncated Sapling anchor record"),
            None => Ok(None),
        }
    }

    pub fn sprout_anchor(&self, root: &[u8; 32]) -> Result<Option<SproutAnchorRec>> {
        match self.get_in(CF_SPROUT_ANCHOR, root)? {
            Some(v) => Ok(Some(SproutAnchorRec::decode(&v)?)),
            None => Ok(None),
        }
    }

    pub fn block_state(&self, block_hash: &[u8; 32]) -> Result<Option<BlockStateRec>> {
        match self.get_in(CF_BLOCK_STATE, block_hash)? {
            Some(v) => Ok(Some(BlockStateRec::decode(&v)?)),
            None => Ok(None),
        }
    }

    pub fn block_txids(&self, block_hash: &[u8; 32]) -> Result<Vec<[u8; 32]>> {
        let Some(v) = self.get_in(CF_BLOCK_TXIDS, block_hash)? else { return Ok(Vec::new()) };
        if v.len() % 32 != 0 {
            bail!("invalid block txid index length {}", v.len());
        }
        let mut out = Vec::with_capacity(v.len() / 32);
        for chunk in v.chunks_exact(32) {
            out.push(array32(chunk, "block txid")?);
        }
        Ok(out)
    }

    pub fn utxo(&self, op: &OutPoint) -> Result<Option<CoinRec>> {
        match self.get_in(CF_UTXO, &outpoint_key(op))? {
            Some(v) => Ok(Some(CoinRec::decode(&v)?)),
            None => Ok(None),
        }
    }

    /// Flush memtables to SST files. Called before taking a checkpoint.
    pub fn flush(&self) -> Result<()> {
        self.inner.flush()?;
        Ok(())
    }

    /// Consistent checkpoint of the whole database into `dir` (hard links where
    /// possible, so it is cheap and does not stall the committer).
    pub fn checkpoint(&self, dir: &Path) -> Result<()> {
        use rocksdb::checkpoint::Checkpoint;
        if dir.exists() {
            fs::remove_dir_all(dir).ok();
        }
        let cp = Checkpoint::new(&self.inner)?;
        cp.create_checkpoint(dir)?;
        Ok(())
    }
}

// ---------------------------------------------------------------------------
// Read view (snapshot)
// ---------------------------------------------------------------------------

/// A consistent read-only view of the database.
///
/// The prepare phase of an ordered commit does all of its consensus/state work
/// against one of these, so the canonical writer is never blocked by
/// validation, and validation never observes a half-applied batch.
pub struct ReadView<'a> {
    db: &'a Db,
    snap: Snapshot<'a>,
    cf_utxo: Cf<'a>,
    cf_sprout_nf: Cf<'a>,
    cf_sprout_anchor: Cf<'a>,
    cf_block_state: Cf<'a>,
    cf_sapling_anchor: Cf<'a>,
    cf_sapling_nf: Cf<'a>,
    cf_sapling_tree: Cf<'a>,
    cf_hash_by_height: Cf<'a>,
    cf_block: Cf<'a>,
}

impl<'a> ReadView<'a> {
    fn new(db: &'a Db) -> Result<Self> {
        Ok(Self {
            snap: db.inner.snapshot(),
            cf_utxo: db.cf(CF_UTXO)?,
            cf_sprout_nf: db.cf(CF_SPROUT_NF)?,
            cf_sprout_anchor: db.cf(CF_SPROUT_ANCHOR)?,
            cf_block_state: db.cf(CF_BLOCK_STATE)?,
            cf_sapling_anchor: db.cf(CF_SAPLING_ANCHOR)?,
            cf_sapling_nf: db.cf(CF_SAPLING_NF)?,
            cf_sapling_tree: db.cf(CF_SAPLING_TREE)?,
            cf_hash_by_height: db.cf(CF_HASH_BY_HEIGHT)?,
            cf_block: db.cf(CF_BLOCK)?,
            db,
        })
    }

    pub fn db(&self) -> &'a Db {
        self.db
    }

    fn get(&self, cf: &Cf<'a>, key: &[u8]) -> Result<Option<Vec<u8>>> {
        Ok(self.snap.get_cf(cf, key)?)
    }

    /// One transparent output as of the snapshot.
    /// Read many outputs in one request.
    ///
    /// A transaction's inputs are resolved together, so they should be fetched
    /// together: MultiGet shares one index and filter traversal across the
    /// batch and keeps the block cache hot, where N separate point gets repeat
    /// that work N times. Telemetry on a busy block measured 34,147 sequential
    /// gets at ~813 us each -- 27.8 s in one commit, 95% of all state
    /// validation -- which is what this exists to remove.
    ///
    /// Results are returned in the order requested, so callers keep their
    /// index alignment. This is purely a read-path change: the same records
    /// are returned as the equivalent loop of [`ReadView::utxo`].
    pub fn utxos(&self, ops: &[OutPoint]) -> Result<Vec<Option<CoinRec>>> {
        self.utxos_timed(ops).map(|(out, _)| out)
    }

    /// MultiGet plus consensus-record decoding, with the returned duration
    /// covering only RocksDB's `multi_get_cf` call itself. This keeps storage
    /// latency separate from CoinRec decoding and cache/validation work.
    pub fn utxos_timed(&self, ops: &[OutPoint]) -> Result<(Vec<Option<CoinRec>>, u64)> {
        if ops.is_empty() {
            return Ok((Vec::new(), 0));
        }
        let keys: Vec<[u8; 36]> = ops.iter().map(outpoint_key).collect();
        let requests = keys.iter().map(|k| (&self.cf_utxo, k.as_slice()));
        let started = std::time::Instant::now();
        let raw = self.snap.multi_get_cf(requests).collect::<Vec<_>>();
        let rocksdb_us = started.elapsed().as_micros() as u64;
        let mut out = Vec::with_capacity(ops.len());
        for value in raw {
            match value? {
                Some(v) => out.push(Some(CoinRec::decode(&v)?)),
                None => out.push(None),
            }
        }
        Ok((out, rocksdb_us))
    }

    pub fn utxo(&self, op: &OutPoint) -> Result<Option<CoinRec>> {
        match self.get(&self.cf_utxo, &outpoint_key(op))? {
            Some(v) => Ok(Some(CoinRec::decode(&v)?)),
            None => Ok(None),
        }
    }

    /// Every stored output of `txid` (spent or not), for BIP30.
    pub fn utxos_of_tx(&self, txid: &[u8; 32]) -> Result<Vec<CoinRec>> {
        let mut out = Vec::new();
        let it = self.snap.iterator_cf(&self.cf_utxo, IteratorMode::From(&txid[..], Direction::Forward));
        for item in it {
            let (k, v) = item?;
            if !k.starts_with(txid) {
                break;
            }
            out.push(CoinRec::decode(&v)?);
        }
        Ok(out)
    }

    pub fn sprout_nullifier_height(&self, nf: &[u8; 32]) -> Result<Option<u64>> {
        match self.get(&self.cf_sprout_nf, nf)? {
            Some(v) if v.len() >= 8 => Ok(Some(u64::from_le_bytes(v[..8].try_into().unwrap()))),
            Some(_) => bail!("truncated Sprout nullifier record"),
            None => Ok(None),
        }
    }

    pub fn sprout_anchor(&self, root: &[u8; 32]) -> Result<Option<SproutAnchorRec>> {
        match self.get(&self.cf_sprout_anchor, root)? {
            Some(v) => Ok(Some(SproutAnchorRec::decode(&v)?)),
            None => Ok(None),
        }
    }

    pub fn block_state(&self, block_hash: &[u8; 32]) -> Result<Option<BlockStateRec>> {
        match self.get(&self.cf_block_state, block_hash)? {
            Some(v) => Ok(Some(BlockStateRec::decode(&v)?)),
            None => Ok(None),
        }
    }

    pub fn sapling_anchor_height(&self, root: &[u8; 32]) -> Result<Option<u64>> {
        match self.get(&self.cf_sapling_anchor, root)? {
            Some(v) if v.len() >= 8 => Ok(Some(u64::from_be_bytes(v[..8].try_into().unwrap()))),
            Some(_) => bail!("truncated Sapling anchor record"),
            None => Ok(None),
        }
    }

    pub fn sapling_nullifier(&self, nf: &[u8; 32]) -> Result<Option<NullifierRec>> {
        match self.get(&self.cf_sapling_nf, nf)? {
            Some(v) => Ok(Some(NullifierRec::decode(&v)?)),
            None => Ok(None),
        }
    }

    pub fn sapling_tree(&self, block_hash: &[u8; 32]) -> Result<Option<SaplingTreeRec>> {
        match self.get(&self.cf_sapling_tree, block_hash)? {
            Some(v) => Ok(Some(SaplingTreeRec::decode(&v)?)),
            None => Ok(None),
        }
    }

    pub fn canonical_hash(&self, height: u64) -> Result<Option<[u8; 32]>> {
        match self.get(&self.cf_hash_by_height, &height_key(height))? {
            Some(v) => Ok(Some(array32(&v, "canonical block hash")?)),
            None => Ok(None),
        }
    }

    pub fn is_canonical_block(&self, hash: &[u8; 32], height: u64) -> Result<bool> {
        Ok(self.canonical_hash(height)?.map(|h| h == *hash).unwrap_or(false))
    }

    pub fn block_meta(&self, hash: &[u8; 32]) -> Result<Option<BlockMeta>> {
        match self.get(&self.cf_block, hash)? {
            Some(v) => Ok(Some(BlockMeta::decode(&v)?)),
            None => Ok(None),
        }
    }

    /// Canonical tip as of the snapshot.
    pub fn canonical_tip(&self) -> Result<Option<([u8; 32], u64)>> {
        let mut it = self.snap.iterator_cf(&self.cf_hash_by_height, IteratorMode::End);
        match it.next() {
            Some(Ok((k, v))) => {
                if k.len() < 8 {
                    bail!("invalid height key length {}", k.len());
                }
                Ok(Some((array32(&v, "canonical tip hash")?, u64::from_be_bytes(k[..8].try_into().unwrap()))))
            }
            Some(Err(e)) => Err(e.into()),
            None => Ok(None),
        }
    }
}

// ---------------------------------------------------------------------------
// Writer (one atomic WriteBatch)
// ---------------------------------------------------------------------------

/// Accumulates one atomic canonical mutation. Nothing is visible until
/// [`Writer::commit`] succeeds.
pub struct Writer<'a> {
    db: &'a Db,
    batch: WriteBatch,
    /// Anchors removed by a rollback staged in this same batch. A new canonical
    /// block carrying the same root must rewrite them, so the anchor index is
    /// never left empty for a root that is still reachable.
    deleted_sapling_anchors: HashSet<[u8; 32]>,
    deleted_sprout_anchors: HashSet<[u8; 32]>,
    cf_meta: Cf<'a>,
    cf_block: Cf<'a>,
    cf_block_raw: Cf<'a>,
    cf_block_txids: Cf<'a>,
    cf_hash_by_height: Cf<'a>,
    cf_header: Cf<'a>,
    cf_header_hash_by_height: Cf<'a>,
    cf_tx: Cf<'a>,
    cf_utxo: Cf<'a>,
    cf_utxo_by_height: Cf<'a>,
    cf_utxo_spent: Cf<'a>,
    cf_sapling_nf: Cf<'a>,
    cf_sapling_nf_by_block: Cf<'a>,
    cf_sapling_tree: Cf<'a>,
    cf_sapling_anchor: Cf<'a>,
    cf_sprout_nf: Cf<'a>,
    cf_sprout_nf_by_height: Cf<'a>,
    cf_block_state: Cf<'a>,
    cf_sprout_anchor: Cf<'a>,
}

impl<'a> Writer<'a> {
    fn new(db: &'a Db) -> Result<Self> {
        Ok(Self {
            batch: WriteBatch::default(),
            deleted_sapling_anchors: HashSet::new(),
            deleted_sprout_anchors: HashSet::new(),
            cf_meta: db.cf(CF_META)?,
            cf_block: db.cf(CF_BLOCK)?,
            cf_block_raw: db.cf(CF_BLOCK_RAW)?,
            cf_block_txids: db.cf(CF_BLOCK_TXIDS)?,
            cf_hash_by_height: db.cf(CF_HASH_BY_HEIGHT)?,
            cf_header: db.cf(CF_HEADER)?,
            cf_header_hash_by_height: db.cf(CF_HEADER_HASH_BY_HEIGHT)?,
            cf_tx: db.cf(CF_TX)?,
            cf_utxo: db.cf(CF_UTXO)?,
            cf_utxo_by_height: db.cf(CF_UTXO_BY_HEIGHT)?,
            cf_utxo_spent: db.cf(CF_UTXO_SPENT_BY_HEIGHT)?,
            cf_sapling_nf: db.cf(CF_SAPLING_NF)?,
            cf_sapling_nf_by_block: db.cf(CF_SAPLING_NF_BY_BLOCK)?,
            cf_sapling_tree: db.cf(CF_SAPLING_TREE)?,
            cf_sapling_anchor: db.cf(CF_SAPLING_ANCHOR)?,
            cf_sprout_nf: db.cf(CF_SPROUT_NF)?,
            cf_sprout_nf_by_height: db.cf(CF_SPROUT_NF_BY_HEIGHT)?,
            cf_block_state: db.cf(CF_BLOCK_STATE)?,
            cf_sprout_anchor: db.cf(CF_SPROUT_ANCHOR)?,
            db,
        })
    }

    pub fn db(&self) -> &'a Db {
        self.db
    }

    // -- meta ---------------------------------------------------------------

    pub fn put_meta(&mut self, key: &str, value: &[u8]) {
        self.batch.put_cf(&self.cf_meta, key.as_bytes(), value);
    }

    pub fn put_meta_u64(&mut self, key: &str, value: u64) {
        self.batch.put_cf(&self.cf_meta, key.as_bytes(), value.to_le_bytes());
    }

    // -- blocks -------------------------------------------------------------

    pub fn put_block(&mut self, hash: &[u8; 32], meta: &BlockMeta, raw: &[u8], txids: &[[u8; 32]]) {
        self.batch.put_cf(&self.cf_block, hash, meta.encode());
        self.batch.put_cf(&self.cf_block_raw, hash, raw);
        if !txids.is_empty() {
            let mut flat = Vec::with_capacity(txids.len() * 32);
            for t in txids {
                flat.extend_from_slice(t);
            }
            self.batch.put_cf(&self.cf_block_txids, hash, flat);
        }
    }

    pub fn put_block_meta(&mut self, hash: &[u8; 32], meta: &BlockMeta) {
        self.batch.put_cf(&self.cf_block, hash, meta.encode());
    }

    pub fn set_canonical_block(&mut self, height: u64, hash: &[u8; 32]) {
        self.batch.put_cf(&self.cf_hash_by_height, height_key(height), hash);
    }

    pub fn clear_canonical_block(&mut self, height: u64) {
        self.batch.delete_cf(&self.cf_hash_by_height, height_key(height));
    }

    pub fn put_tx(&mut self, txid: &[u8; 32], rec: &TxRec) {
        self.batch.put_cf(&self.cf_tx, txid, rec.encode());
    }

    pub fn delete_tx(&mut self, txid: &[u8; 32]) {
        self.batch.delete_cf(&self.cf_tx, txid);
    }

    pub fn delete_block_txids(&mut self, hash: &[u8; 32]) {
        self.batch.delete_cf(&self.cf_block_txids, hash);
    }

    // -- headers ------------------------------------------------------------

    pub fn put_header(&mut self, hash: &[u8; 32], rec: &HeaderRec) {
        self.batch.put_cf(&self.cf_header, hash, rec.encode());
    }

    pub fn set_canonical_header(&mut self, height: u64, hash: &[u8; 32]) {
        self.batch.put_cf(&self.cf_header_hash_by_height, height_key(height), hash);
    }

    pub fn clear_canonical_header(&mut self, height: u64) {
        self.batch.delete_cf(&self.cf_header_hash_by_height, height_key(height));
    }

    // -- transparent UTXOs --------------------------------------------------

    /// Write a newly created output plus its creation-height index, and, when
    /// it is also spent by this batch, its spent-height index.
    pub fn put_utxo(&mut self, op: &OutPoint, coin: &CoinRec) {
        self.batch.put_cf(&self.cf_utxo, outpoint_key(op), coin.encode());
        self.batch.put_cf(&self.cf_utxo_by_height, height_outpoint_key(coin.height, op), b"");
        if let Some(spent) = coin.spent_height {
            self.batch.put_cf(&self.cf_utxo_spent, height_outpoint_key(spent, op), b"");
        }
    }

    /// Mark an already persisted output spent at `height`.
    pub fn spend_utxo(&mut self, op: &OutPoint, coin: &CoinRec) {
        self.batch.put_cf(&self.cf_utxo, outpoint_key(op), coin.encode());
        if let Some(spent) = coin.spent_height {
            self.batch.put_cf(&self.cf_utxo_spent, height_outpoint_key(spent, op), b"");
        }
    }

    pub fn delete_utxo(&mut self, op: &OutPoint, coin: &CoinRec) {
        self.batch.delete_cf(&self.cf_utxo, outpoint_key(op));
        self.batch.delete_cf(&self.cf_utxo_by_height, height_outpoint_key(coin.height, op));
        if let Some(spent) = coin.spent_height {
            self.batch.delete_cf(&self.cf_utxo_spent, height_outpoint_key(spent, op));
        }
    }

    pub fn clear_utxo_spent_index(&mut self, op: &OutPoint, spent_height: u64) {
        self.batch.delete_cf(&self.cf_utxo_spent, height_outpoint_key(spent_height, op));
    }

    // -- Sapling ------------------------------------------------------------

    pub fn put_sapling_nullifier(&mut self, nf: &[u8; 32], rec: &NullifierRec) {
        self.batch.put_cf(&self.cf_sapling_nf, nf, rec.encode());
        self.batch.put_cf(&self.cf_sapling_nf_by_block, pair_key(&rec.block_hash, nf), b"");
    }

    pub fn delete_sapling_nullifier(&mut self, nf: &[u8; 32], block_hash: &[u8; 32]) {
        self.batch.delete_cf(&self.cf_sapling_nf, nf);
        self.batch.delete_cf(&self.cf_sapling_nf_by_block, pair_key(block_hash, nf));
    }

    pub fn put_sapling_tree(&mut self, block_hash: &[u8; 32], rec: &SaplingTreeRec) {
        self.batch.put_cf(&self.cf_sapling_tree, block_hash, rec.encode());
    }

    pub fn delete_sapling_tree(&mut self, block_hash: &[u8; 32]) {
        self.batch.delete_cf(&self.cf_sapling_tree, block_hash);
    }

    pub fn put_sapling_anchor(&mut self, root: &[u8; 32], height: u64) {
        self.batch.put_cf(&self.cf_sapling_anchor, root, height.to_be_bytes());
    }

    pub fn delete_sapling_anchor(&mut self, root: &[u8; 32]) {
        self.batch.delete_cf(&self.cf_sapling_anchor, root);
        self.deleted_sapling_anchors.insert(*root);
    }

    pub fn sapling_anchor_deleted(&self, root: &[u8; 32]) -> bool {
        self.deleted_sapling_anchors.contains(root)
    }

    // -- Sprout -------------------------------------------------------------

    pub fn put_sprout_nullifier(&mut self, nf: &[u8; 32], height: u64) {
        self.batch.put_cf(&self.cf_sprout_nf, nf, height.to_le_bytes());
        self.batch.put_cf(&self.cf_sprout_nf_by_height, height_hash_key(height, nf), b"");
    }

    pub fn delete_sprout_nullifier(&mut self, nf: &[u8; 32], height: u64) {
        self.batch.delete_cf(&self.cf_sprout_nf, nf);
        self.batch.delete_cf(&self.cf_sprout_nf_by_height, height_hash_key(height, nf));
    }

    pub fn put_block_state(&mut self, block_hash: &[u8; 32], rec: &BlockStateRec) {
        self.batch.put_cf(&self.cf_block_state, block_hash, rec.encode());
    }

    pub fn delete_block_state(&mut self, block_hash: &[u8; 32]) {
        self.batch.delete_cf(&self.cf_block_state, block_hash);
    }

    pub fn put_sprout_anchor(&mut self, root: &[u8; 32], rec: &SproutAnchorRec) {
        self.batch.put_cf(&self.cf_sprout_anchor, root, rec.encode());
    }

    pub fn delete_sprout_anchor(&mut self, root: &[u8; 32]) {
        self.batch.delete_cf(&self.cf_sprout_anchor, root);
        self.deleted_sprout_anchors.insert(*root);
    }

    pub fn sprout_anchor_deleted(&self, root: &[u8; 32]) -> bool {
        self.deleted_sprout_anchors.contains(root)
    }

    // -- commit -------------------------------------------------------------

    pub fn is_empty(&self) -> bool {
        self.batch.is_empty()
    }

    pub fn len(&self) -> usize {
        self.batch.len()
    }

    /// Atomically publish everything accumulated in this writer.
    pub fn commit(self) -> Result<()> {
        self.db.write(self.batch)
    }
}

// ---------------------------------------------------------------------------
// Checkpoint export (single-file USTAR archive, no extra dependencies)
// ---------------------------------------------------------------------------

/// Take a consistent checkpoint of `db` and write it to `dest` as one
/// uncompressed tar archive. RocksDB is a directory, so the old "one SQLite
/// file" export becomes "one archive file"; the HTTP export path is otherwise
/// unchanged.
pub fn export_checkpoint_tar(db: &Db, dest: &Path) -> Result<()> {
    let staging = dest.with_extension("checkpoint-tmp");
    db.flush().ok();
    db.checkpoint(&staging)?;
    let result = write_tar(&staging, dest);
    let _ = fs::remove_dir_all(&staging);
    result
}

fn write_tar(dir: &Path, dest: &Path) -> Result<()> {
    let mut out = fs::File::create(dest).with_context(|| format!("creating {}", dest.display()))?;
    let mut files = Vec::new();
    collect_files(dir, dir, &mut files)?;
    files.sort();
    for rel in files {
        let full = dir.join(&rel);
        let data = fs::read(&full).with_context(|| format!("reading {}", full.display()))?;
        out.write_all(&tar_header(&rel, data.len() as u64)?)?;
        out.write_all(&data)?;
        let pad = (512 - (data.len() % 512)) % 512;
        if pad > 0 {
            out.write_all(&vec![0u8; pad])?;
        }
    }
    // Two zero blocks terminate a tar archive.
    out.write_all(&[0u8; 1024])?;
    out.flush()?;
    Ok(())
}

fn collect_files(root: &Path, dir: &Path, out: &mut Vec<String>) -> Result<()> {
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let path = entry.path();
        if path.is_dir() {
            collect_files(root, &path, out)?;
        } else {
            let rel = path
                .strip_prefix(root)
                .map_err(|_| anyhow!("checkpoint path escaped its directory"))?
                .to_string_lossy()
                .to_string();
            out.push(rel);
        }
    }
    Ok(())
}

fn tar_header(name: &str, size: u64) -> Result<[u8; 512]> {
    let mut h = [0u8; 512];
    let name_bytes = name.as_bytes();
    if name_bytes.len() > 99 {
        bail!("checkpoint file name too long for tar: {name}");
    }
    h[..name_bytes.len()].copy_from_slice(name_bytes);
    write_octal(&mut h[100..108], 0o644, 7);
    write_octal(&mut h[108..116], 0, 7);
    write_octal(&mut h[116..124], 0, 7);
    write_octal(&mut h[124..136], size, 11);
    write_octal(&mut h[136..148], 0, 11);
    h[148..156].copy_from_slice(b"        ");
    h[156] = b'0';
    h[257..262].copy_from_slice(b"ustar");
    h[263..265].copy_from_slice(b"00");
    let checksum: u32 = h.iter().map(|b| *b as u32).sum();
    write_octal(&mut h[148..154], checksum as u64, 6);
    h[154] = 0;
    h[155] = b' ';
    Ok(h)
}

fn write_octal(field: &mut [u8], value: u64, digits: usize) {
    let s = format!("{:0width$o}", value, width = digits);
    let bytes = s.as_bytes();
    let n = bytes.len().min(digits);
    field[..n].copy_from_slice(&bytes[bytes.len() - n..]);
    if digits < field.len() {
        field[digits] = 0;
    }
}
