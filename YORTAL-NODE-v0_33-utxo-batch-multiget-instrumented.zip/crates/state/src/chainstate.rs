//! Transparent UTXO set and Sprout shielded state for ordered block commits.
//!
//! Mirrors ycashd 4.5.0 `ConnectBlock` / `Consensus::CheckTxInputs` /
//! `ContextualCheckInputs` / `CCoinsViewCache::HaveShieldedRequirements`:
//! inputs exist and are unspent, coinbase maturity (100) and the
//! coinbase-must-be-shielded rule, value in >= value out, fees, script
//! verification (P2SH | CHECKLOCKTIMEVERIFY), block sigop limit, BIP30,
//! coinbase amount <= subsidy + fees, Sprout nullifiers and anchors
//! (including intermediate anchors inside one transaction), and the ZIP 209
//! Sprout/Sapling value-pool turnstile.
//!
//! Storage model (RocksDB): an output record is written once with the height
//! that created it and, when spent, the height that spent it. "State as of the batch's
//! first height H" is therefore `height < H AND (spent_height IS NULL OR
//! spent_height >= H)`, which stays correct even when the batch replaces an
//! old branch (rows at >= H are rolled back only after validation passes).
//! Spent rows are pruned once they are deeper than the 100-block maximum
//! reorg length ycashd itself enforces.

use anyhow::{anyhow, bail, Result};
use crate::db::{self, CoinRec, ReadView, Writer};
use std::collections::{HashMap, HashSet, VecDeque};
use std::sync::{Condvar, Mutex, OnceLock};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use rayon::prelude::*;
use ycash_chain::ParsedTransaction;
use ycash_consensus::{
    block_subsidy, is_coinbase, money_range, tx_shielded_value_in, tx_value_out, SproutTree, COINBASE_MATURITY,
    MAX_BLOCK_SIGOPS,
};

/// ycashd `MAX_REORG_LENGTH` is 99; keep spent outputs a little longer.
pub const SPENT_OUTPUT_RETENTION: u64 = 100;

// Global execution budget shared by the Android pipeline verifier and the
// ordered commit's script verifier.  Both stages previously created/use
// cores-1 workers independently, which could oversubscribe an 8-core device
// with 7 pipeline workers + 7 script workers.
static SCRIPT_WORKER_BUDGET: AtomicUsize = AtomicUsize::new(1);
static SCRIPT_WORKER_BUDGET_CONFIGURED: AtomicBool = AtomicBool::new(false);

pub fn set_script_worker_budget(limit: usize) {
    let limit = limit.max(1);
    SCRIPT_WORKER_BUDGET.store(limit, Ordering::Release);
    SCRIPT_WORKER_BUDGET_CONFIGURED.store(true, Ordering::Release);
}

/// Current shared script execution budget. This is the active permit count
/// target, not the size of the persistent Rayon pool. Before the pipeline has
/// explicitly configured a split, use the device-derived cores-1 default so
/// direct State callers are not accidentally serialized to one worker.
pub fn script_worker_budget() -> usize {
    if SCRIPT_WORKER_BUDGET_CONFIGURED.load(Ordering::Acquire) {
        SCRIPT_WORKER_BUDGET.load(Ordering::Acquire).max(1)
    } else {
        std::thread::available_parallelism().map(|n| n.get().saturating_sub(1).max(1)).unwrap_or(1)
    }
}

/// Fewest queued script checks worth handing to the thread pool.
pub const SCRIPT_SCATTER_THRESHOLD: usize = 64;

// The script execution budget is the size of the persistent Rayon pool below.
// There is no separate permit gate: the ordered state gate serialises block
// connection, so only one thread ever drives the pool, and a process-wide lock
// taken per input would only serialise the parallel section against itself.

pub type OutPoint = ([u8; 32], u32);

/// Bounded LRU cache of canonical UTXOs. The database remains authoritative;
/// this cache is only valid for the exact canonical parent tip. LRU touches are
/// collected during validation and applied at the commit publication boundary,
/// so cache hits never take a global cache lock.
#[derive(Debug, Clone)]
pub struct UtxoCache {
    map: HashMap<OutPoint, Coin>,
    order: VecDeque<OutPoint>,
}

impl UtxoCache {
    pub const MAX_ENTRIES: usize = 50_000;

    pub fn empty() -> Self { Self { map: HashMap::new(), order: VecDeque::new() } }

    pub fn get(&self, op: &OutPoint) -> Option<&Coin> { self.map.get(op) }

    pub fn insert(&mut self, op: OutPoint, coin: Coin) {
        if self.map.insert(op, coin).is_some() {
            if let Some(pos) = self.order.iter().position(|k| *k == op) { self.order.remove(pos); }
        }
        self.order.push_back(op);
        self.trim();
    }

    pub fn remove(&mut self, op: &OutPoint) {
        if self.map.remove(op).is_some() {
            if let Some(pos) = self.order.iter().position(|k| k == op) { self.order.remove(pos); }
        }
    }

    fn trim(&mut self) {
        while self.map.len() > Self::MAX_ENTRIES {
            let Some(oldest) = self.order.pop_front() else { break };
            self.map.remove(&oldest);
        }
    }

    #[cfg(test)]
    fn contains_key(&self, op: &OutPoint) -> bool { self.map.contains_key(op) }
}

/// Fine-grained timing for the ordered consensus/state connector.
///
/// These values intentionally cover only the state-validation phase; SQL write
/// and atomic-write timings are measured by `State::apply_prepared_commit`.
#[derive(Debug, Default, Clone, Copy)]
pub struct ConnectTiming {
    pub bip30_us: u64,
    pub sigops_us: u64,
    pub utxo_lookup_us: u64,
    pub sprout_requirements_us: u64,
    pub value_checks_us: u64,
    pub script_us: u64,
    pub coin_state_update_us: u64,
    pub sprout_apply_us: u64,
    pub tx_total_us: u64,
    pub bip30_ms: u64,
    pub sigops_ms: u64,
    pub tx_parse_us: u64,
    pub utxo_lookup_ms: u64,
    pub sprout_requirements_ms: u64,
    pub value_checks_ms: u64,
    pub script_ms: u64,
    pub coin_state_update_ms: u64,
    pub sprout_apply_ms: u64,
    pub tx_total_ms: u64,
    pub bip30_checks: u64,
    pub utxo_lookups: u64,
    pub script_checks: u64,
    pub script_parallel_workers: u64,
    pub script_parallel_us: u64,
    /// Sum of individual input verification CPU time (can exceed wall time
    /// when inputs execute concurrently), plus the slowest input location.
    pub script_input_work_us: u64,
    pub script_slowest_input_index: u64,
    pub script_slowest_input_us: u64,
    pub script_transaction_input_extraction_us: u64,
    pub script_sig_construction_us: u64,
    pub script_pubkey_retrieval_us: u64,
    pub script_parsing_us: u64,
    pub signature_hash_preparation_us: u64,
    pub ecdsa_verification_us: u64,
    pub script_interpreter_us: u64,
    pub script_cache_lookup_us: u64,
    pub script_synchronization_us: u64,
    pub script_permit_wait_us: u64,
    pub script_active_peak: u64,
    pub script_scheduler_gap_us: u64,
    /// Parallel-script wall-clock diagnostics. Each array slot is a Rayon worker index (up to 32).
    pub script_worker_wall_us: [u64; 32],
    pub script_worker_input_work_us: [u64; 32],
    pub script_worker_inputs: [u64; 32],
    pub script_spawn_us: u64,
    pub script_join_us: u64,
    /// Time inside the persistent verifier pool that is not covered by the
    /// longest worker span (dispatch/scheduler/wakeup overhead).
    pub script_pool_overhead_us: u64,
    pub script_pool_threads: u64,
    pub script_worker_max_us: u64,
    pub script_worker_min_us: u64,
}


#[derive(Clone, Debug)]
pub struct Coin {
    pub value: i64,
    pub script: Vec<u8>,
    pub height: u64,
    pub coinbase: bool,
}

#[derive(Clone, Debug)]
struct CoinEntry {
    coin: Coin,
    spent_height: Option<u64>,
    /// True when the entry already exists in canonical persistent state (DB or
    /// the canonical RAM cache). Cached entries must never be re-inserted, but
    /// a cached entry that becomes spent still needs its spent_height persisted.
    persisted: bool,
}

pub struct CoinsView<'a> {
    first_height: u64,
    entries: HashMap<OutPoint, CoinEntry>,
    batch_txids: HashSet<[u8; 32]>,
    cache: Option<&'a UtxoCache>,
    cache_touched: HashSet<OutPoint>,
    missing: HashSet<OutPoint>,
    pub cache_hits: u64,
    pub cache_misses: u64,
    /// Wall time spent inside RocksDB MultiGet for persistent UTXO misses.
    pub db_lookup_us: u64,
    /// Number of unique UTXO keys actually sent to RocksDB.
    pub db_lookup_keys: u64,
}

#[derive(Debug)]
pub struct PreparedUtxoChanges {
    entries: HashMap<OutPoint, CoinEntry>,
    cache_touched: Vec<OutPoint>,
}

impl PreparedUtxoChanges {
    pub(crate) fn empty() -> Self {
        Self { entries: HashMap::new(), cache_touched: Vec::new() }
    }

    /// Stage the prepared UTXO mutation set into the caller's atomic batch.
    /// No reads and no consensus decisions happen here.
    pub(crate) fn apply(&self, w: &mut Writer<'_>) -> Result<()> {
        for (op, e) in &self.entries {
            let rec = CoinRec {
                value: e.coin.value,
                height: e.coin.height,
                coinbase: e.coin.coinbase,
                spent_height: e.spent_height,
                script: e.coin.script.clone(),
            };
            if e.persisted {
                // Already on disk: only a new spend needs writing back.
                if e.spent_height.is_some() {
                    w.spend_utxo(op, &rec);
                }
            } else {
                w.put_utxo(op, &rec);
            }
        }
        Ok(())
    }

    /// Publish the already prepared UTXO delta into the canonical RAM cache.
    /// Existing hot entries touched during validation are promoted to the LRU
    /// tail; newly created outputs are also inserted at the tail.
    pub(crate) fn update_cache(&self, cache: &mut UtxoCache) {
        for (op, e) in &self.entries {
            if e.spent_height.is_some() {
                cache.remove(op);
            } else if !e.persisted {
                cache.insert(*op, e.coin.clone());
            }
        }
        if !self.cache_touched.is_empty() {
            // Rebuild the LRU order in one O(cache + touches) pass instead of
            // removing each touched key from the VecDeque individually. This
            // matters for high-input batches where thousands of cache hits may
            // otherwise turn promotion into O(n²) work.
            let touched: HashSet<OutPoint> = self.cache_touched.iter().copied().collect();
            cache.order.retain(|op| !touched.contains(op));
            for op in &self.cache_touched {
                if self.entries.get(op).map(|e| e.spent_height.is_none()).unwrap_or(false) && cache.map.contains_key(op) {
                    cache.order.push_back(*op);
                }
            }
        }
        cache.trim();
    }
}

impl<'a> CoinsView<'a> {
    /// Prepare the UTXO mutation set without touching the database.
    pub fn prepare_changes(&self) -> PreparedUtxoChanges {
        PreparedUtxoChanges { entries: self.entries.clone(), cache_touched: self.cache_touched.iter().copied().collect() }
    }

    pub fn new(first_height: u64, cache: Option<&'a UtxoCache>) -> Self {
        Self { first_height, entries: HashMap::new(), batch_txids: HashSet::new(), cache, cache_touched: HashSet::new(), missing: HashSet::new(), cache_hits: 0, cache_misses: 0, db_lookup_us: 0, db_lookup_keys: 0 }
    }

    /// Resolve a transaction's inputs against canonical state.
    ///
    /// Point lookups are the natural RocksDB form of the previous batched
    /// SELECT, and the per-input state semantics are unchanged: only records
    /// created below the batch height and unspent as of that height count,
    /// while intra-batch entries remain owned by `self.entries`.
    /// Resolve a set of transaction inputs. Cache hits are resolved first;
    /// every remaining unique key is fetched in one RocksDB MultiGet.
    pub fn prefetch(&mut self, db: &ReadView<'_>, ops: &[OutPoint]) -> Result<()> {
        self.prefetch_ops(db, ops)
    }

    /// Resolve all transparent inputs for an entire ordered commit batch before
    /// transaction-by-transaction consensus mutation begins. This is the key
    /// persistent-read optimization: one deduplicated MultiGet for the batch,
    /// while intra-batch outputs remain owned by `self.entries` as they are
    /// created during ordered connection.
    pub fn prefetch_batch(&mut self, db: &ReadView<'_>, ops: &[OutPoint]) -> Result<()> {
        self.prefetch_ops(db, ops)
    }

    fn prefetch_ops(&mut self, db: &ReadView<'_>, ops: &[OutPoint]) -> Result<()> {
        let mut wanted: Vec<OutPoint> = Vec::new();
        let mut seen = HashSet::new();
        for op in ops {
            if !seen.insert(*op) || self.entries.contains_key(op) || self.missing.contains(op) {
                continue;
            }
            if let Some(cache) = self.cache {
                if let Some(coin) = cache.get(op) {
                    self.cache_hits = self.cache_hits.saturating_add(1);
                    self.cache_touched.insert(*op);
                    self.entries.insert(*op, CoinEntry { coin: coin.clone(), spent_height: None, persisted: true });
                    continue;
                }
            }
            self.cache_misses = self.cache_misses.saturating_add(1);
            wanted.push(*op);
        }
        if wanted.is_empty() {
            return Ok(());
        }

        let (fetched, rocksdb_us) = db.utxos_timed(&wanted)?;
        self.db_lookup_us = self.db_lookup_us.saturating_add(rocksdb_us);
        self.db_lookup_keys = self.db_lookup_keys.saturating_add(wanted.len() as u64);
        for (op, record) in wanted.into_iter().zip(fetched.into_iter()) {
            match record {
                Some(rec) if rec.unspent_as_of(self.first_height) => {
                    let coin = Coin { value: rec.value, script: rec.script, height: rec.height, coinbase: rec.coinbase };
                    self.entries.insert(op, CoinEntry { coin, spent_height: None, persisted: true });
                }
                _ => {
                    self.missing.insert(op);
                }
            }
        }
        Ok(())
    }

    pub fn get(&mut self, db: &ReadView<'_>, op: &OutPoint) -> Result<Option<Coin>> {
        if let Some(e) = self.entries.get(op) {
            return Ok(if e.spent_height.is_none() { Some(e.coin.clone()) } else { None });
        }
        // A canonical RAM cache is only a positive cache: a hit is an unspent
        // coin known to belong to the exact parent canonical tip. Misses still
        // consult the database, so cache eviction can never create a false
        // negative.
        if let Some(cache) = self.cache {
            if let Some(coin) = cache.get(op) {
                self.cache_hits = self.cache_hits.saturating_add(1);
                self.cache_touched.insert(*op);
                self.entries.insert(*op, CoinEntry { coin: coin.clone(), spent_height: None, persisted: true });
                return Ok(Some(coin.clone()));
            }
        }
        if self.missing.contains(op) {
            return Ok(None);
        }
        self.cache_misses = self.cache_misses.saturating_add(1);
        match db.utxo(op)? {
            Some(rec) if rec.unspent_as_of(self.first_height) => {
                let coin = Coin { value: rec.value, script: rec.script, height: rec.height, coinbase: rec.coinbase };
                self.entries.insert(*op, CoinEntry { coin: coin.clone(), spent_height: None, persisted: true });
                Ok(Some(coin))
            }
            _ => {
                self.missing.insert(*op);
                Ok(None)
            }
        }
    }

    /// BIP30: a transaction may not overwrite one with unspent outputs.
    /// The outputs of one txid share a key prefix, so this is a short
    /// contiguous scan rather than a secondary index lookup.
    pub fn has_unspent_outputs_of(&self, db: &ReadView<'_>, txid: &[u8; 32]) -> Result<bool> {
        if self.batch_txids.contains(txid)
            && self.entries.iter().any(|(k, e)| k.0 == *txid && !e.persisted && e.spent_height.is_none())
        {
            return Ok(true);
        }
        let mut unspent_db: i64 = 0;
        for rec in db.utxos_of_tx(txid)? {
            if rec.unspent_as_of(self.first_height) {
                unspent_db += 1;
            }
        }
        if unspent_db == 0 {
            return Ok(false);
        }
        let spent_in_batch =
            self.entries.iter().filter(|(k, e)| k.0 == *txid && e.persisted && e.spent_height.is_some()).count() as i64;
        Ok(unspent_db > spent_in_batch)
    }

    #[cfg(test)]
    fn prepare_cache_hit_for_test(&mut self, op: &OutPoint) {
        if let Some(cache) = self.cache {
            if let Some(coin) = cache.get(op) {
                self.cache_hits = self.cache_hits.saturating_add(1);
                self.cache_touched.insert(*op);
                self.entries.insert(*op, CoinEntry { coin: coin.clone(), spent_height: None, persisted: true });
            }
        }
    }

    pub fn spend(&mut self, op: &OutPoint, height: u64) {
        if let Some(e) = self.entries.get_mut(op) {
            e.spent_height = Some(height);
        }
    }

    pub fn add(&mut self, op: OutPoint, coin: Coin) {
        self.batch_txids.insert(op.0);
        self.entries.insert(op, CoinEntry { coin, spent_height: None, persisted: false });
    }

    /// Publish the prepared cache delta.
    pub fn update_cache(&self, cache: &mut UtxoCache) { self.prepare_changes().update_cache(cache); }

    /// Stage the already prepared UTXO mutation set into the caller's atomic batch.
    pub fn flush(&self, w: &mut Writer<'_>) -> Result<()> {
        self.prepare_changes().apply(w)
    }
}

/// Sprout state carried through a batch.
pub struct SproutView {
    first_height: u64,
    pub tree: SproutTree,
    /// Final treestate of every block already processed in this batch.
    batch_roots: HashMap<[u8; 32], SproutTree>,
    batch_nullifiers: HashMap<[u8; 32], u64>,
    pub chain_sprout_value: i64,
    pub chain_sapling_value: i64,
    pub rows: Vec<BlockStateRow>,
}

#[derive(Clone, Debug)]
pub struct BlockStateRow {
    pub block_hash: [u8; 32],
    pub height: u64,
    pub sprout_root: [u8; 32],
    pub sprout_frontier: Vec<u8>,
    pub chain_sprout_value: i64,
    pub chain_sapling_value: i64,
}

#[derive(Debug)]
pub struct PreparedSproutChanges {
    nullifiers: HashMap<[u8; 32], u64>,
    rows: Vec<BlockStateRow>,
}

impl PreparedSproutChanges {
    pub(crate) fn empty() -> Self {
        Self { nullifiers: HashMap::new(), rows: Vec::new() }
    }

    pub(crate) fn apply(&self, w: &mut Writer<'_>) -> Result<()> {
        for (n, h) in &self.nullifiers {
            w.put_sprout_nullifier(n, *h);
        }
        // The anchor index keeps the lowest height at which each Sprout root
        // appeared, so an anchor lookup stays a single point read.
        let mut batch_anchors: HashMap<[u8; 32], u64> = HashMap::new();
        for r in &self.rows {
            w.put_block_state(
                &r.block_hash,
                &db::BlockStateRec {
                    height: r.height,
                    sprout_root: r.sprout_root,
                    chain_sprout_value: r.chain_sprout_value,
                    chain_sapling_value: r.chain_sapling_value,
                    sprout_frontier: r.sprout_frontier.clone(),
                },
            );
            let lower = match batch_anchors.get(&r.sprout_root) {
                Some(h) => *h > r.height,
                None => match w.db().sprout_anchor(&r.sprout_root)? {
                    Some(a) => a.height > r.height || w.sprout_anchor_deleted(&r.sprout_root),
                    None => true,
                },
            };
            if lower {
                batch_anchors.insert(r.sprout_root, r.height);
                w.put_sprout_anchor(
                    &r.sprout_root,
                    &db::SproutAnchorRec { height: r.height, frontier: r.sprout_frontier.clone() },
                );
            }
        }
        Ok(())
    }
}

impl SproutView {
    /// Prepare Sprout/nullifier mutations without touching the database.
    pub fn prepare_changes(&self) -> PreparedSproutChanges {
        PreparedSproutChanges {
            nullifiers: self.batch_nullifiers.clone(),
            rows: self.rows.clone(),
        }
    }

    /// Construct a Sprout view from an exact canonical-parent cache entry.
    /// This is equivalent to `load()` but avoids decoding the same persisted
    /// frontier for every sequential batch.
    pub fn from_cached(first_height: u64, tree: SproutTree, sprout_value: i64, sapling_value: i64) -> Self {
        Self {
            first_height,
            tree,
            batch_roots: HashMap::new(),
            batch_nullifiers: HashMap::new(),
            chain_sprout_value: sprout_value,
            chain_sapling_value: sapling_value,
            rows: Vec::new(),
        }
    }

    pub fn load(db: &ReadView<'_>, first_height: u64, prev: &[u8; 32]) -> Result<Self> {
        let (tree, sprout_value, sapling_value) = if first_height <= 1 {
            // The genesis block's transactions are never connected.
            (SproutTree::new(), 0, 0)
        } else {
            let state = db
                .block_state(prev)?
                .ok_or_else(|| anyhow!("missing Sprout/value-pool state for parent block"))?;
            if state.height != first_height - 1 {
                bail!(
                    "Sprout/value-pool state for parent block is at height {}, expected {}",
                    state.height,
                    first_height - 1
                );
            }
            let tree = SproutTree::decode(&state.sprout_frontier)
                .map_err(|e| anyhow!("invalid persisted Sprout frontier: {e:?}"))?;
            (tree, state.chain_sprout_value, state.chain_sapling_value)
        };
        Ok(Self {
            first_height,
            tree,
            batch_roots: HashMap::new(),
            batch_nullifiers: HashMap::new(),
            chain_sprout_value: sprout_value,
            chain_sapling_value: sapling_value,
            rows: Vec::new(),
        })
    }

    fn db_nullifier_exists(&self, db: &ReadView<'_>, nf: &[u8; 32]) -> Result<bool> {
        Ok(db.sprout_nullifier_height(nf)?.map(|h| h < self.first_height).unwrap_or(false))
    }

    fn anchor_tree(&self, db: &ReadView<'_>, anchor: &[u8; 32]) -> Result<Option<SproutTree>> {
        if let Some(t) = self.batch_roots.get(anchor) {
            return Ok(Some(t.clone()));
        }
        if *anchor == SproutTree::empty_root() {
            return Ok(Some(SproutTree::new()));
        }
        match db.sprout_anchor(anchor)? {
            Some(rec) if rec.height < self.first_height => Ok(Some(
                SproutTree::decode(&rec.frontier).map_err(|e| anyhow!("invalid persisted Sprout frontier: {e:?}"))?,
            )),
            _ => Ok(None),
        }
    }

    /// Sprout half of `HaveShieldedRequirements`.
    pub fn check_requirements(&self, db: &ReadView<'_>, tx: &ParsedTransaction) -> Result<()> {
        let mut intermediates: HashMap<[u8; 32], SproutTree> = HashMap::new();
        for js in &tx.joinsplits {
            for nf in &js.nullifiers {
                if self.batch_nullifiers.contains_key(nf) || self.db_nullifier_exists(db, nf)? {
                    bail!("bad-txns-joinsplit-requirements-not-met: Sprout nullifier already spent");
                }
            }
            let mut tree = match intermediates.get(&js.anchor) {
                Some(t) => t.clone(),
                None => self
                    .anchor_tree(db, &js.anchor)?
                    .ok_or_else(|| anyhow!("bad-txns-joinsplit-requirements-not-met: unknown Sprout anchor"))?,
            };
            for cm in &js.commitments {
                tree.append(*cm).map_err(|e| anyhow!("{e:?}"))?;
            }
            intermediates.entry(tree.root()).or_insert(tree);
        }
        Ok(())
    }

    /// Nullifiers, commitments and value pools after a tx is connected.
    pub fn apply(&mut self, tx: &ParsedTransaction, height: u64) -> Result<()> {
        for js in &tx.joinsplits {
            for nf in &js.nullifiers {
                self.batch_nullifiers.insert(*nf, height);
            }
            for cm in &js.commitments {
                self.tree.append(*cm).map_err(|e| anyhow!("{e:?}"))?;
            }
            self.chain_sprout_value = self
                .chain_sprout_value
                .checked_add(js.vpub_old)
                .and_then(|v| v.checked_sub(js.vpub_new))
                .ok_or_else(|| anyhow!("Sprout value pool overflow"))?;
        }
        self.chain_sapling_value = self
            .chain_sapling_value
            .checked_sub(tx.value_balance)
            .ok_or_else(|| anyhow!("Sapling value pool overflow"))?;
        Ok(())
    }

    pub fn finish_block(&mut self, block_hash: [u8; 32], height: u64) -> Result<()> {
        if self.chain_sprout_value < 0 {
            bail!("turnstile-violation-sprout-shielded-pool at height {height}");
        }
        if self.chain_sapling_value < 0 {
            bail!("turnstile-violation-sapling-shielded-pool at height {height}");
        }
        let root = self.tree.root();
        self.batch_roots.entry(root).or_insert_with(|| self.tree.clone());
        self.rows.push(BlockStateRow {
            block_hash,
            height,
            sprout_root: root,
            sprout_frontier: self.tree.encode(),
            chain_sprout_value: self.chain_sprout_value,
            chain_sapling_value: self.chain_sapling_value,
        });
        Ok(())
    }

    pub fn flush(&self, w: &mut Writer<'_>) -> Result<()> {
        self.prepare_changes().apply(w)
    }
}

fn txid_display(txid: &[u8; 32]) -> String {
    txid.iter().rev().map(|b| format!("{b:02x}")).collect()
}

/// One transparent input waiting to be verified.
///
/// Script verification is a pure function of the scriptSig, the prevout script,
/// the signature-hash data, the flags and the height: it reads no mutable
/// state and writes none. So *when* it runs is free, as long as every queued
/// check runs before the block is accepted. That is what lets a whole block's
/// checks go into a single parallel scatter while every stateful rule stays
/// sequential and in order.
///
/// The prevout script is copied because the coin it came from may be spent by
/// a later transaction in the same batch; everything else is borrowed from the
/// block's parsed transactions, which outlive the connector.
struct PendingScriptCheck<'b> {
    tx: &'b ParsedTransaction,
    precomputed: Option<&'b ycash_script::PrecomputedTxData>,
    txid: [u8; 32],
    tx_index: usize,
    input_index: usize,
    amount: i64,
    script_pubkey: Vec<u8>,
}

/// Per-block accumulator for fees, sigops, the coinbase amount and the
/// block's queued script checks.
pub struct BlockConnector<'b> {
    pub height: u64,
    pub consensus_branch_id: u32,
    pub verify_scripts: bool,
    fees: i64,
    sigops: u64,
    coinbase_value_out: i64,
    pending_scripts: Vec<PendingScriptCheck<'b>>,
    tx_index: usize,
}

impl<'b> BlockConnector<'b> {
    pub fn new(height: u64, verify_scripts: bool) -> Self {
        Self {
            height,
            consensus_branch_id: ycash_consensus::consensus_branch_id(height),
            verify_scripts,
            fees: 0,
            sigops: 0,
            coinbase_value_out: 0,
            pending_scripts: Vec::new(),
            tx_index: 0,
        }
    }

    /// Maximum CPU threads used by the persistent transparent-script verifier.
    ///
    /// This is deliberately separate from pipeline/block concurrency. The
    /// consensus state transition remains ordered; only independent script
    /// checks execute concurrently. The default reserves one logical CPU for
    /// Android/housekeeping and permits the remaining logical CPUs.
    const SCRIPT_PARALLEL_THRESHOLD: usize = 2;

    /// One persistent CPU pool for all transparent script verification.
    ///
    /// This intentionally mirrors the useful part of ycashd's CCheckQueue and
    /// Zebra's persistent Rayon execution model: worker threads live for the
    /// lifetime of the process rather than being created and joined for every
    /// transaction. Individual inputs are queued as independent Rayon jobs,
    /// allowing work stealing instead of fixed per-worker chunks.
    fn script_parallel_threshold() -> usize {
        std::env::var("YORTAL_SCRIPT_PARALLEL_THRESHOLD")
            .ok()
            .and_then(|v| v.parse::<usize>().ok())
            .map(|v| v.clamp(1, 8))
            .unwrap_or(Self::SCRIPT_PARALLEL_THRESHOLD)
    }

    fn script_pool() -> &'static rayon::ThreadPool {
        static POOL: OnceLock<rayon::ThreadPool> = OnceLock::new();
        POOL.get_or_init(|| {
            let available = std::thread::available_parallelism()
                .map(|n| n.get())
                .unwrap_or(1);
            let device_ceiling = available.saturating_sub(1).max(1);
            let workers = match std::env::var("YORTAL_SCRIPT_WORKERS").ok().and_then(|v| v.parse::<usize>().ok()) {
                Some(0) | None => device_ceiling,
                Some(v) => v.clamp(1, device_ceiling),
            };
            rayon::ThreadPoolBuilder::new()
                .num_threads(workers)
                .thread_name(|i| format!("yortal-script-{i}"))
                .build()
                .expect("failed to create persistent YORTAL script verifier pool")
        })
    }

    /// Verify all transparent inputs without mutating consensus state.
    ///
    /// Consensus safety boundary:
    /// * all UTXOs and transaction data are collected before this function;
    /// * every script check observes the same immutable transaction/prevout set;
    /// * only script verification is parallel;
    /// * `connect_tx()` performs all state mutation in strict transaction order.
    ///
    /// Scheduling model:
    /// * one direct check for tiny transactions;
    /// * otherwise one independent job per input;
    /// * a persistent bounded Rayon pool performs dynamic work stealing;
    /// * no per-transaction OS-thread spawn/join and no fixed input partitioning.
    fn verify_scripts_parallel(
        &self,
        tx: &ParsedTransaction,
        txid: &[u8; 32],
        prevouts: &[Coin],
        precomputed: Option<&ycash_script::PrecomputedTxData>,
    ) -> Result<(u64, u64, u64, u64, u64, ycash_script::ScriptVerifyTiming, [u64; 32], [u64; 32], [u64; 32], u64, u64, u64, u64, u64, u64, u64, u64)> {
        if tx.vin.is_empty() {
            return Ok((0, 0, 0, 0, 0, ycash_script::ScriptVerifyTiming::default(), [0;32], [0;32], [0;32], 0, 0, 0, 0, 0, 0, 0, 0));
        }
        if tx.vin.len() < Self::script_parallel_threshold() {
            let started = std::time::Instant::now();
            let input = &tx.vin[0];
            let coin = &prevouts[0];
            let sink = ycash_script::ScriptTimingSink::new();
            let checker = ycash_script::TransactionChecker {
                tx,
                n_in: 0,
                amount: coin.value,
                consensus_branch_id: self.consensus_branch_id,
                precomputed,
                timing: Some(&sink),
            };
            ycash_script::verify_script(
                &input.script_sig,
                &coin.script,
                ycash_script::BLOCK_SCRIPT_VERIFY_FLAGS,
                &checker,
            ).map_err(|e| anyhow!("mandatory-script-verify-flag-failed ({e:?}): tx {} input 0 at height {}", txid_display(txid), self.height))?;
            let us = started.elapsed().as_micros() as u64;
            let mut worker_wall_us = [0u64; 32];
            let mut worker_input_work_us = [0u64; 32];
            let mut worker_inputs = [0u64; 32];
            worker_wall_us[0] = us;
            worker_input_work_us[0] = us;
            worker_inputs[0] = 1;
            return Ok((1, us, us, 0, us, sink.snapshot(), worker_wall_us, worker_input_work_us, worker_inputs, 0, 0, us, us, 0, 0, 0, 0));
        }

        let pool = Self::script_pool();
        let pool_width = pool.current_num_threads();
        let started = std::time::Instant::now();

        // Each input is an independent job. Rayon dynamically schedules these
        // jobs across the persistent pool, so a worker that finishes early can
        // immediately take another input. This avoids the old [23,10,2,1]
        // fixed-chunk imbalance seen in the performance telemetry.
        let results = pool.install(|| {
            tx.vin.par_iter().enumerate().map(|(i, input)| {
                // No permit is taken here. The ordered state gate is the only
                // caller of connect_tx, so exactly one thread drives this pool,
                // and the pool's own thread count already bounds the width. The
                // old permit took a process-wide Mutex (twice, counting the
                // telemetry read) for every input, which serialised the inside
                // of the parallel section against itself.
                let permit_wait_us = 0u64;
                let worker_start_offset_us = started.elapsed().as_micros() as u64;
                let worker_idx = rayon::current_thread_index().unwrap_or(0).min(31);
                let active_after_permit = pool_width as u64;
                let sink = ycash_script::ScriptTimingSink::new();
                let coin = &prevouts[i];
                let checker = ycash_script::TransactionChecker {
                    tx,
                    n_in: i,
                    amount: coin.value,
                    consensus_branch_id: self.consensus_branch_id,
                    precomputed,
                    timing: Some(&sink),
                };
                let input_started = std::time::Instant::now();
                let result = ycash_script::verify_script(
                    &input.script_sig,
                    &coin.script,
                    ycash_script::BLOCK_SCRIPT_VERIFY_FLAGS,
                    &checker,
                );
                let input_us = input_started.elapsed().as_micros() as u64;
                let worker_end_offset_us = started.elapsed().as_micros() as u64;
                (i, worker_idx, result, input_us, worker_start_offset_us, worker_end_offset_us, permit_wait_us, active_after_permit, sink.snapshot())
            }).collect::<Vec<_>>()
        });

        let wall_us = started.elapsed().as_micros() as u64;
        let mut errors = Vec::new();
        let mut input_work_us = 0u64;
        let mut slow_idx = 0u64;
        let mut slow_us = 0u64;
        let mut telemetry = ycash_script::ScriptVerifyTiming::default();
        let mut worker_wall_us = [0u64; 32];
        let mut worker_input_work_us = [0u64; 32];
        let mut worker_inputs = [0u64; 32];
        let mut worker_first_start_us = [u64::MAX; 32];
        let mut worker_last_end_us = [0u64; 32];
        let mut permit_wait_us = 0u64;
        let mut active_peak = 0u64;
        for (i, worker, result, input_us, worker_start_us, worker_end_us, job_permit_wait_us, active_after_permit, sample) in results {
            permit_wait_us = permit_wait_us.saturating_add(job_permit_wait_us);
            active_peak = active_peak.max(active_after_permit);
            worker_input_work_us[worker] = worker_input_work_us[worker].saturating_add(input_us);
            worker_inputs[worker] = worker_inputs[worker].saturating_add(1);
            worker_first_start_us[worker] = worker_first_start_us[worker].min(worker_start_us);
            worker_last_end_us[worker] = worker_last_end_us[worker].max(worker_end_us);
            input_work_us = input_work_us.saturating_add(input_us);
            if input_us > slow_us { slow_us = input_us; slow_idx = i as u64; }
            telemetry.transaction_input_extraction_us = telemetry.transaction_input_extraction_us.saturating_add(sample.transaction_input_extraction_us);
            telemetry.script_sig_construction_us = telemetry.script_sig_construction_us.saturating_add(sample.script_sig_construction_us);
            telemetry.script_pubkey_retrieval_us = telemetry.script_pubkey_retrieval_us.saturating_add(sample.script_pubkey_retrieval_us);
            telemetry.script_parsing_us = telemetry.script_parsing_us.saturating_add(sample.script_parsing_us);
            telemetry.signature_hash_preparation_us = telemetry.signature_hash_preparation_us.saturating_add(sample.signature_hash_preparation_us);
            telemetry.ecdsa_verification_us = telemetry.ecdsa_verification_us.saturating_add(sample.ecdsa_verification_us);
            telemetry.script_interpreter_us = telemetry.script_interpreter_us.saturating_add(sample.script_interpreter_us);
            telemetry.cache_lookup_us = telemetry.cache_lookup_us.saturating_add(sample.cache_lookup_us);
            telemetry.synchronization_us = telemetry.synchronization_us.saturating_add(sample.synchronization_us);
            if let Err(e) = result { errors.push((i, e)); }
        }
        if let Some((i, e)) = errors.into_iter().min_by_key(|(i, _)| *i) {
            bail!("mandatory-script-verify-flag-failed ({e:?}): tx {} input {i} at height {}", txid_display(txid), self.height);
        }
        for i in 0..32 {
            if worker_first_start_us[i] != u64::MAX {
                worker_wall_us[i] = worker_last_end_us[i].saturating_sub(worker_first_start_us[i]);
            }
        }
        let max_worker_us = worker_wall_us.iter().copied().max().unwrap_or(0);
        let min_worker_us = worker_wall_us.iter().copied().filter(|v| *v != 0).min().unwrap_or(0);
        // The old fields are intentionally retained for API compatibility. No
        // OS threads are spawned or joined per transaction anymore.
        let spawn_us = 0;
        let join_us = 0;
        let scheduler_gap_us = wall_us.saturating_sub(max_worker_us);
        telemetry.synchronization_us = permit_wait_us;
        let actual_workers = script_worker_budget()
            .min(pool.current_num_threads())
            .min(tx.vin.len())
            .max(1);
        Ok((actual_workers as u64, wall_us, input_work_us, slow_idx, slow_us, telemetry, worker_wall_us, worker_input_work_us, worker_inputs, spawn_us, join_us, max_worker_us, min_worker_us, scheduler_gap_us, pool.current_num_threads() as u64, permit_wait_us, active_peak))
    }

    /// Run every transparent script check queued for this block, in one
    /// parallel scatter.
    ///
    /// Must be called before the block is accepted. Failure reporting stays
    /// deterministic: of all failing checks, the one with the lowest
    /// (transaction index, input index) is reported, which is the same check
    /// the old per-transaction path would have reported first.
    pub fn verify_pending_scripts(&mut self, timing: &mut ConnectTiming) -> Result<()> {
        if self.pending_scripts.is_empty() {
            return Ok(());
        }
        let checks = std::mem::take(&mut self.pending_scripts);
        let pool = Self::script_pool();
        let pool_width = pool.current_num_threads();
        let branch = self.consensus_branch_id;
        let started = std::time::Instant::now();

        struct CheckOutcome {
            tx_index: usize,
            input_index: usize,
            txid: [u8; 32],
            us: u64,
            worker: usize,
            error: Option<String>,
            timing: ycash_script::ScriptVerifyTiming,
        }

        // One check, wherever it runs. Identical work on the pool or on the
        // calling thread: this decides only where, never whether.
        let verify_one = |check: &PendingScriptCheck<'_>| -> CheckOutcome {
            let worker_started = std::time::Instant::now();
            let sink = ycash_script::ScriptTimingSink::new();
            let checker = ycash_script::TransactionChecker {
                tx: check.tx,
                n_in: check.input_index,
                amount: check.amount,
                consensus_branch_id: branch,
                precomputed: check.precomputed,
                timing: Some(&sink),
            };
            let result = ycash_script::verify_script(
                &check.tx.vin[check.input_index].script_sig,
                &check.script_pubkey,
                ycash_script::BLOCK_SCRIPT_VERIFY_FLAGS,
                &checker,
            );
            CheckOutcome {
                tx_index: check.tx_index,
                input_index: check.input_index,
                txid: check.txid,
                us: worker_started.elapsed().as_micros() as u64,
                worker: rayon::current_thread_index().unwrap_or(0).min(31),
                error: result.err().map(|e| format!("{e:?}")),
                timing: sink.snapshot(),
            }
        };

        // Below this many checks the scatter costs more than it saves: waking
        // and joining pool threads is fixed cost while the work is not.
        // Telemetry on early blocks showed 18 inputs spending 1.74 ms verifying
        // and 6.61 ms scheduling, with five of seven workers taking no work at
        // all. Small blocks now verify on the calling thread.
        let outcomes: Vec<CheckOutcome> = if checks.len() < SCRIPT_SCATTER_THRESHOLD {
            checks.iter().map(|c| verify_one(c)).collect()
        } else {
            pool.install(|| checks.par_iter().map(|c| verify_one(c)).collect())
        };

        let wall_us = started.elapsed().as_micros() as u64;

        let mut input_work_us = 0u64;
        let mut worker_max_us = 0u64;
        for outcome in &outcomes {
            input_work_us = input_work_us.saturating_add(outcome.us);
            let w = outcome.worker;
            timing.script_worker_wall_us[w] = timing.script_worker_wall_us[w].saturating_add(outcome.us);
            timing.script_worker_input_work_us[w] = timing.script_worker_input_work_us[w].saturating_add(outcome.us);
            timing.script_worker_inputs[w] = timing.script_worker_inputs[w].saturating_add(1);
            worker_max_us = worker_max_us.max(timing.script_worker_wall_us[w]);
            if outcome.us > timing.script_slowest_input_us {
                timing.script_slowest_input_us = outcome.us;
                timing.script_slowest_input_index = outcome.input_index as u64;
            }
            let t = &outcome.timing;
            timing.script_transaction_input_extraction_us = timing.script_transaction_input_extraction_us.saturating_add(t.transaction_input_extraction_us);
            timing.script_sig_construction_us = timing.script_sig_construction_us.saturating_add(t.script_sig_construction_us);
            timing.script_pubkey_retrieval_us = timing.script_pubkey_retrieval_us.saturating_add(t.script_pubkey_retrieval_us);
            timing.script_parsing_us = timing.script_parsing_us.saturating_add(t.script_parsing_us);
            timing.signature_hash_preparation_us = timing.signature_hash_preparation_us.saturating_add(t.signature_hash_preparation_us);
            timing.ecdsa_verification_us = timing.ecdsa_verification_us.saturating_add(t.ecdsa_verification_us);
            timing.script_interpreter_us = timing.script_interpreter_us.saturating_add(t.script_interpreter_us);
            timing.script_cache_lookup_us = timing.script_cache_lookup_us.saturating_add(t.cache_lookup_us);
        }
        timing.script_parallel_us = timing.script_parallel_us.saturating_add(wall_us);
        timing.script_input_work_us = timing.script_input_work_us.saturating_add(input_work_us);
        timing.script_us = timing.script_us.saturating_add(wall_us);
        timing.script_ms = timing.script_us / 1000;
        timing.script_parallel_workers = timing.script_parallel_workers.max(pool_width.min(outcomes.len()).max(1) as u64);
        timing.script_pool_threads = timing.script_pool_threads.max(pool_width as u64);
        timing.script_worker_max_us = timing.script_worker_max_us.max(worker_max_us);
        timing.script_active_peak = timing.script_active_peak.max(pool_width as u64);
        // Whatever the scatter did not spend inside a check is scheduling cost.
        timing.script_scheduler_gap_us = timing.script_scheduler_gap_us.saturating_add(wall_us.saturating_sub(worker_max_us));

        if let Some(failed) = outcomes
            .iter()
            .filter(|o| o.error.is_some())
            .min_by_key(|o| (o.tx_index, o.input_index))
        {
            bail!(
                "mandatory-script-verify-flag-failed ({}): tx {} input {} at height {}",
                failed.error.as_deref().unwrap_or("unknown"),
                txid_display(&failed.txid),
                failed.input_index,
                self.height
            );
        }
        Ok(())
    }

    /// Validate `tx` against the view, then connect it (spend inputs, add
    /// outputs, apply Sprout effects). Order follows `ConnectBlock`.
    pub fn connect_tx(
        &mut self,
        db: &ReadView<'_>,
        coins: &mut CoinsView,
        sprout: &mut SproutView,
        tx: &'b ParsedTransaction,
        txid: &[u8; 32],
        precomputed: Option<&'b ycash_script::PrecomputedTxData>,
        timing: &mut ConnectTiming,
    ) -> Result<()> {
        let tx_started = std::time::Instant::now();
        let h = self.height;
        let coinbase = is_coinbase(tx);

        let sigops_started = std::time::Instant::now();
        self.sigops += ycash_script::legacy_sig_op_count(tx) as u64;
        timing.sigops_us = timing.sigops_us.saturating_add(sigops_started.elapsed().as_micros() as u64);
        timing.sigops_ms = timing.sigops_us / 1000;
        if self.sigops > MAX_BLOCK_SIGOPS {
            bail!("bad-blk-sigops at height {h}");
        }
        let bip30_started = std::time::Instant::now();
        timing.bip30_checks += 1;
        if coins.has_unspent_outputs_of(db, txid)? {
            bail!("bad-txns-BIP30: tx {} at height {h}", txid_display(txid));
        }
        timing.bip30_us = timing.bip30_us.saturating_add(bip30_started.elapsed().as_micros() as u64);
        timing.bip30_ms = timing.bip30_us / 1000;

        if coinbase {
            self.coinbase_value_out = tx_value_out(tx).map_err(|e| anyhow!("{e:?}"))?;
        } else {
            let mut prevouts = Vec::with_capacity(tx.vin.len());
            let utxo_started = std::time::Instant::now();
            timing.utxo_lookups += tx.vin.len() as u64;
            let ops: Vec<OutPoint> = tx.vin.iter().map(|input| (input.prev_txid, input.prev_index)).collect();
            coins.prefetch(db, &ops)?;
            for input in &tx.vin {
                let op = (input.prev_txid, input.prev_index);
                let coin = coins.get(db, &op)?.ok_or_else(|| {
                    anyhow!(
                        "bad-txns-inputs-missingorspent: tx {} spends {}:{} at height {h}",
                        txid_display(txid),
                        txid_display(&input.prev_txid),
                        input.prev_index
                    )
                })?;
                prevouts.push(coin);
            }
            let utxo_elapsed_us = utxo_started.elapsed().as_micros() as u64;
            timing.utxo_lookup_us = timing.utxo_lookup_us.saturating_add(utxo_elapsed_us);
            // This is the actual transaction/input extraction from the canonical
            // UTXO view (including cache/RocksDB lookup). It is reported separately
            // from script execution because it occurs immediately before verify_script.
            timing.script_transaction_input_extraction_us = timing.script_transaction_input_extraction_us.saturating_add(utxo_elapsed_us);
            timing.utxo_lookup_ms = timing.utxo_lookup_us / 1000;

            let sprout_req_started = std::time::Instant::now();
            sprout.check_requirements(db, tx)?;
            timing.sprout_requirements_us = timing.sprout_requirements_us.saturating_add(sprout_req_started.elapsed().as_micros() as u64);
            timing.sprout_requirements_ms = timing.sprout_requirements_us / 1000;

            for (input, coin) in tx.vin.iter().zip(&prevouts) {
                if ycash_script::is_pay_to_script_hash(&coin.script) {
                    self.sigops += ycash_script::p2sh_sig_op_count(&coin.script, &input.script_sig) as u64;
                }
            }
            if self.sigops > MAX_BLOCK_SIGOPS {
                bail!("bad-blk-sigops at height {h}");
            }

            // Consensus::CheckTxInputs
            let value_started = std::time::Instant::now();
            let mut value_in: i64 = 0;
            for coin in &prevouts {
                if coin.coinbase {
                    if (h as i64) - (coin.height as i64) < COINBASE_MATURITY as i64 {
                        bail!("bad-txns-premature-spend-of-coinbase: tx {} at height {h}", txid_display(txid));
                    }
                    if !tx.vout.is_empty() {
                        bail!("bad-txns-coinbase-spend-has-transparent-outputs: tx {} at height {h}", txid_display(txid));
                    }
                }
                value_in = value_in
                    .checked_add(coin.value)
                    .filter(|v| money_range(coin.value) && money_range(*v))
                    .ok_or_else(|| anyhow!("bad-txns-inputvalues-outofrange at height {h}"))?;
            }
            value_in = value_in
                .checked_add(tx_shielded_value_in(tx).map_err(|e| anyhow!("{e:?}"))?)
                .filter(|v| money_range(*v))
                .ok_or_else(|| anyhow!("bad-txns-inputvalues-outofrange at height {h}"))?;
            let value_out = tx_value_out(tx).map_err(|e| anyhow!("{e:?}"))?;
            if value_in < value_out {
                bail!("bad-txns-in-belowout: tx {} at height {h} ({value_in} < {value_out})", txid_display(txid));
            }
            self.fees = self
                .fees
                .checked_add(value_in - value_out)
                .filter(|v| money_range(*v))
                .ok_or_else(|| anyhow!("bad-txns-fee-outofrange at height {h}"))?;
            timing.value_checks_us = timing.value_checks_us.saturating_add(value_started.elapsed().as_micros() as u64);
            timing.value_checks_ms = timing.value_checks_us / 1000;

            if self.verify_scripts {
                // Queue, do not verify. The block's checks are run in one
                // scatter by `verify_pending_scripts` once every transaction
                // has been connected; a per-transaction scatter spends more
                // time scheduling than verifying, because most transactions
                // have one or two inputs.
                timing.script_checks = timing.script_checks.saturating_add(tx.vin.len() as u64);
                self.pending_scripts.reserve(tx.vin.len());
                for (input_index, coin) in prevouts.iter().enumerate() {
                    self.pending_scripts.push(PendingScriptCheck {
                        tx,
                        precomputed,
                        txid: *txid,
                        tx_index: self.tx_index,
                        input_index,
                        amount: coin.value,
                        script_pubkey: coin.script.clone(),
                    });
                }
            }

            let coin_state_started = std::time::Instant::now();
            for input in &tx.vin {
                coins.spend(&(input.prev_txid, input.prev_index), h);
            }
            timing.coin_state_update_us = timing.coin_state_update_us.saturating_add(coin_state_started.elapsed().as_micros() as u64);
            timing.coin_state_update_ms = timing.coin_state_update_us / 1000;
        }

        let coin_state_started = std::time::Instant::now();
        for (n, out) in tx.vout.iter().enumerate() {
            if !ycash_script::is_unspendable(&out.script_pubkey) {
                coins.add(
                    (*txid, n as u32),
                    Coin { value: out.value, script: out.script_pubkey.clone(), height: h, coinbase },
                );
            }
        }
        timing.coin_state_update_us = timing.coin_state_update_us.saturating_add(coin_state_started.elapsed().as_micros() as u64);
            timing.coin_state_update_ms = timing.coin_state_update_us / 1000;
        let sprout_apply_started = std::time::Instant::now();
        sprout.apply(tx, h)?;
        timing.sprout_apply_us = timing.sprout_apply_us.saturating_add(sprout_apply_started.elapsed().as_micros() as u64);
        timing.sprout_apply_ms = timing.sprout_apply_us / 1000;
        self.next_tx();
        timing.tx_total_us = timing.tx_total_us.saturating_add(tx_started.elapsed().as_micros() as u64);
        timing.tx_total_ms = timing.tx_total_us / 1000;
        Ok(())
    }

    /// `bad-cb-amount`: coinbase may claim at most subsidy + fees.
    /// Advance the transaction counter. Called once per connected transaction.
    fn next_tx(&mut self) {
        self.tx_index = self.tx_index.saturating_add(1);
    }

    pub fn finish(&self) -> Result<()> {
        let limit = self
            .fees
            .checked_add(block_subsidy(self.height))
            .ok_or_else(|| anyhow!("block reward overflow"))?;
        if self.coinbase_value_out > limit {
            bail!(
                "bad-cb-amount at height {}: coinbase pays {} > subsidy+fees {}",
                self.height,
                self.coinbase_value_out,
                limit
            );
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn utxo_cache_hit_does_not_require_a_database() {
        let txid = [7u8; 32];
        let op = (txid, 0u32);
        let coin = Coin { value: 123, script: vec![0x51], height: 10, coinbase: false };
        let mut cache = UtxoCache::empty();
        cache.insert(op, coin.clone());
        let mut view = CoinsView::new(11, Some(&cache));
        // A cache hit is resolved before any database read, so no read view is
        // needed to observe it.
        view.prepare_cache_hit_for_test(&op);
        let got = view.entries.get(&op).unwrap().coin.clone();
        assert_eq!(got.value, coin.value);
        assert_eq!(view.cache_hits, 1);
        assert_eq!(view.cache_misses, 0);
    }

    #[test]
    fn utxo_cache_update_removes_spent_and_keeps_new() {
        let txid = [8u8; 32];
        let spent = ([1u8; 32], 0u32);
        let added = (txid, 1u32);
        let mut cache = UtxoCache::empty();
        cache.insert(spent, Coin { value: 1, script: vec![0x51], height: 1, coinbase: false });
        let mut view = CoinsView::new(2, None);
        view.entries.insert(spent, CoinEntry {
            coin: cache.get(&spent).unwrap().clone(),
            spent_height: Some(2),
            persisted: true,
        });
        view.add(added, Coin { value: 2, script: vec![0x51], height: 2, coinbase: false });
        view.update_cache(&mut cache);
        assert!(!cache.contains_key(&spent));
        assert!(cache.contains_key(&added));
    }

    #[test]
    fn coin_record_round_trips_and_honours_batch_height() {
        let rec = CoinRec {
            value: 5_000,
            height: 40,
            coinbase: true,
            spent_height: Some(90),
            script: vec![0x76, 0xa9],
        };
        let decoded = CoinRec::decode(&rec.encode()).unwrap();
        assert_eq!(decoded.value, rec.value);
        assert_eq!(decoded.height, rec.height);
        assert!(decoded.coinbase);
        assert_eq!(decoded.spent_height, Some(90));
        assert_eq!(decoded.script, rec.script);
        // Unspent as of height 90 (spent at 90), spent as of 91.
        assert!(decoded.unspent_as_of(90));
        assert!(!decoded.unspent_as_of(91));
        // Not yet created as of its own height.
        assert!(!decoded.unspent_as_of(40));
    }
}
