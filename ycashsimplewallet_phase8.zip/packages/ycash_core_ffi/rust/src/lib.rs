// The sync-status `json!({...})` literal in ycash_compat.rs has grown large
// enough (YTeleport-X telemetry fields) that it exceeds the default macro
// recursion limit during expansion. Raise it with headroom for future growth.
#![recursion_limit = "512"]

pub mod integration;
pub mod backend;
pub mod address;
pub mod ffi;
pub mod keys;
pub mod lightclient;
pub mod lightwallet;
pub mod network;
pub mod protocol;
pub mod sapling;
pub mod storage;
pub mod sync;
pub mod tx;
pub mod wallet;
pub mod read_only;
pub mod ycash_compat;

pub const ENGINE_VERSION: &str = "0.16.0-phase57";

pub mod upstream;
