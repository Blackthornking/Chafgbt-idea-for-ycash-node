//! YTeleport-X Phase 8 validation report helpers.
//!
//! Phase 8 is deliberately split into two classes of evidence:
//! - live observations from the real wallet/node scanner;
//! - local cryptographic/security checks inherited from Phase 7.
//!
//! This module does not turn an observation into an authentication claim.
//! BridgeSkip-X and ProofSkip-X remain NOT_YET_TESTED until their real
//! authenticated providers are connected.

use serde::Serialize;

pub const PASS: &str = "PASS";
pub const FAIL: &str = "FAIL";
pub const NOT_TESTED: &str = "NOT_YET_TESTED";

#[derive(Debug, Clone, Serialize)]
pub struct Phase8Check {
    pub name: String,
    pub status: String,
    pub value: String,
    pub detail: String,
}

impl Phase8Check {
    pub fn pass(name: impl Into<String>, value: impl Into<String>, detail: impl Into<String>) -> Self {
        Self { name: name.into(), status: PASS.into(), value: value.into(), detail: detail.into() }
    }

    pub fn fail(name: impl Into<String>, value: impl Into<String>, detail: impl Into<String>) -> Self {
        Self { name: name.into(), status: FAIL.into(), value: value.into(), detail: detail.into() }
    }

    pub fn not_tested(name: impl Into<String>, value: impl Into<String>, detail: impl Into<String>) -> Self {
        Self { name: name.into(), status: NOT_TESTED.into(), value: value.into(), detail: detail.into() }
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct Phase8Report {
    pub protocol: String,
    pub phase: String,
    pub live_data: bool,
    pub end_to_end_status: String,
    pub overall_status: String,
    pub checks: Vec<Phase8Check>,
    pub bridge_skip: Vec<Phase8Check>,
    pub proof_skip: Vec<Phase8Check>,
    pub verification: Vec<Phase8Check>,
    pub persistence: Vec<Phase8Check>,
    pub reorg_testing: Vec<Phase8Check>,
    pub performance: Vec<Phase8Check>,
}

impl Phase8Report {
    pub fn overall(&self) -> String {
        if self.checks.iter().any(|c| c.status == FAIL)
            || self.bridge_skip.iter().any(|c| c.status == FAIL)
            || self.proof_skip.iter().any(|c| c.status == FAIL)
            || self.verification.iter().any(|c| c.status == FAIL)
            || self.persistence.iter().any(|c| c.status == FAIL)
            || self.reorg_testing.iter().any(|c| c.status == FAIL)
            || self.performance.iter().any(|c| c.status == FAIL)
        {
            return FAIL.into();
        }
        if self.checks.iter().any(|c| c.status == NOT_TESTED)
            || self.bridge_skip.iter().any(|c| c.status == NOT_TESTED)
            || self.proof_skip.iter().any(|c| c.status == NOT_TESTED)
            || self.verification.iter().any(|c| c.status == NOT_TESTED)
            || self.persistence.iter().any(|c| c.status == NOT_TESTED)
            || self.reorg_testing.iter().any(|c| c.status == NOT_TESTED)
            || self.performance.iter().any(|c| c.status == NOT_TESTED)
        {
            return NOT_TESTED.into();
        }
        PASS.into()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn empty() -> Phase8Report {
        Phase8Report {
            protocol: "YTeleport-X".into(),
            phase: "Phase 8".into(),
            live_data: true,
            end_to_end_status: NOT_TESTED.into(),
            overall_status: NOT_TESTED.into(),
            checks: vec![Phase8Check::pass("live", "1", "ok")],
            bridge_skip: vec![Phase8Check::not_tested("skip", "NOT_YET_TESTED", "locked")],
            proof_skip: vec![],
            verification: vec![],
            persistence: vec![],
            reorg_testing: vec![],
            performance: vec![],
        }
    }

    #[test]
    fn overall_is_not_tested_when_a_path_is_unexercised() {
        assert_eq!(empty().overall(), NOT_TESTED);
    }

    #[test]
    fn overall_fails_if_any_check_fails() {
        let mut r = empty();
        r.bridge_skip[0] = Phase8Check::fail("skip", "FAIL", "bad");
        assert_eq!(r.overall(), FAIL);
    }

    #[test]
    fn overall_passes_only_when_every_path_is_pass() {
        let mut r = empty();
        r.bridge_skip[0] = Phase8Check::pass("skip", "1", "gate exercised");
        assert_eq!(r.overall(), PASS);
    }
}
