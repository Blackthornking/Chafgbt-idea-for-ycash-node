import 'dart:async';
import 'package:flutter/material.dart';
import '../core/config.dart';
import '../core/wallet.dart';

/// YTeleport-X telemetry page.
///
/// This page deliberately distinguishes measured values from values that the
/// native YTeleport-X engine has not exposed yet. It must never manufacture a
/// peer count, proof count, root, or speed reading just to make the dashboard
/// look complete.
class YTeleportStats extends StatefulWidget {
  final SimpleWallet wallet;
  const YTeleportStats({super.key, required this.wallet});

  @override
  State<YTeleportStats> createState() => _YTeleportStatsState();
}

class _YTeleportStatsState extends State<YTeleportStats> {
  StreamSubscription? _sub;
  SimpleSyncStatus? _status;
  Map<String, dynamic>? _server;
  String? _serverError;
  DateTime? _updated;
  Map<String, dynamic>? _phase7;
  bool _phase7Running = false;

  @override
  void initState() {
    super.initState();
    _status = null;
    _sub = widget.wallet.status.stream.listen((s) {
      if (!mounted) return;
      setState(() {
        _status = s;
        _updated = DateTime.now();
      });
    });
    _refreshServer();
    _runPhase7SelfTest();
  }

  Future<void> _runPhase7SelfTest() async {
    if (_phase7Running) return;
    setState(() => _phase7Running = true);
    try {
      final report = await widget.wallet.yteleportPhase7SelfTestAsync();
      if (!mounted) return;
      setState(() { _phase7 = report; _phase7Running = false; _updated = DateTime.now(); });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _phase7Running = false;
        _phase7 = {'passed': false, 'checks': [{'name': 'native self-test', 'passed': false, 'detail': '$e'}]};
      });
    }
  }

  Future<void> _refreshServer() async {
    try {
      final info = await widget.wallet.serverInfoAsync();
      if (!mounted) return;
      setState(() {
        _server = info;
        _serverError = null;
        _updated = DateTime.now();
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _serverError = '$e');
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  String _v(Object? value) {
    if (value == null) return 'Not reported';
    final s = value.toString();
    return s.isEmpty ? 'Not reported' : s;
  }

  String _root(Object? value) {
    if (value == null) return 'Not available';
    final s = value.toString();
    if (s.isEmpty) return 'Not available';
    return s.length > 22 ? '${s.substring(0, 22)}…' : s;
  }

  Widget _section(BuildContext context, String title, List<Widget> children) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
        child: Text(title, style: Theme.of(context).textTheme.titleSmall),
      ),
      Card(
        margin: const EdgeInsets.symmetric(horizontal: 12),
        child: Column(children: children),
      ),
    ]);
  }

  Widget _stat(String title, String value, {String? detail, IconData? icon}) {
    return ListTile(
      dense: true,
      leading: icon == null ? null : Icon(icon, size: 21),
      title: Text(title),
      subtitle: detail == null ? null : Text(detail),
      trailing: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 180),
        child: Text(value, textAlign: TextAlign.right),
      ),
    );
  }

  String _shortHash(String hash) {
    if (hash.length <= 16) return hash;
    return '${hash.substring(0, 8)}…${hash.substring(hash.length - 8)}';
  }

  @override
  Widget build(BuildContext context) {
    final s = _status;
    final remaining = s == null ? null : (s.tip - s.height).clamp(0, 1 << 62);
    final server = _server;

    return Scaffold(
      appBar: AppBar(
        title: const Text('YTeleport-X statistics'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: () { _refreshServer(); _runPhase7SelfTest(); },
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: ListView(children: [
        _section(context, 'Protocol', [
          _stat('Mode', 'YTeleport-X telemetry', icon: Icons.rocket_launch_outlined,
            detail: 'Client-side authenticated synchronization dashboard'),
          _stat('Protocol version', 'v1'),
          _stat('Transport', _v(server?['transport'] ?? 'Existing wallet transport')),
          _stat('Network', _v(server?['network'] ?? 'Not reported')),
          _stat('Dedicated server required', 'No'),
        ]),
        _section(context, 'Peer transport', [
          _stat('Peers discovered', 'Not reported', detail: 'Native peer-manager telemetry is not exposed yet', icon: Icons.hub_outlined),
          _stat('Peers connected', 'Not reported'),
          _stat('Ready peers', 'Not reported'),
          _stat('Peer quorum', 'Not reported'),
          _stat('Banned peers', 'Not reported'),
          _stat('Average peer latency', 'Not reported'),
        ]),
        _section(context, 'Authenticated chain', [
          _stat('Local height', s == null ? 'Waiting…' : '${s.height}', icon: Icons.link),
          _stat('Network tip', s == null ? 'Waiting…' : '${s.tip}'),
          _stat('Remaining', remaining == null ? 'Waiting…' : '$remaining blocks'),
          _stat('ChainRoot', 'Not available', detail: 'YTeleport ChainRoot is not promoted from peer/scanner data'),
          _stat('Scanner anchor height', s == null ? 'Waiting…' : '${s.height}'),
          _stat('Scanner anchor hash', s?.yteleportAnchorHash == null ? 'Not available' : _shortHash(s!.yteleportAnchorHash!)),
          _stat('Consensus-validated anchor', 'Not reported', detail: 'Requires an explicit Ycash consensus-header proof'),
          _stat('Cross-peer agreement', 'Not reported'),
        ]),
        _section(context, 'Authenticated state', [
          _stat('StateRoot', 'Not available', icon: Icons.account_tree_outlined),
          _stat('Scanner transitions observed', s == null ? '0' : '${s.yteleportScannedBlocks}'),
          _stat('Verified YTeleport transitions', '0', detail: 'No StateTransitionProof is accepted from the live scanner yet'),
          _stat('Rejected transitions', s == null ? '0' : '${s.yteleportRejectedTransitions}'),
          _stat('TransitionProof failures', '0', detail: 'Live proof telemetry is not wired'),
        ]),
        _section(context, 'Compression / skipping', [
          _stat('BridgeSkip-X transitions', '0', icon: Icons.compress, detail: 'Safe selector is present; production state-tree skipping remains disabled'),
          _stat('ProofSkip-X operations', '0', detail: 'ProofSkip is fail-closed and disabled'),
          _stat('Authenticated delta bytes', 'Not reported'),
          _stat('Compressed proof bytes', 'Not reported'),
          _stat('Compression ratio', 'Not reported'),
          _stat('Reused proof work', 'Not reported'),
        ]),
        _section(context, 'Reorg / safety', [
          _stat('Reorgs detected', s == null ? '0' : '${s.yteleportReorgs}', icon: Icons.account_tree),
          _stat('Reorg proofs verified', '0', detail: 'Live YTeleport reorg-proof telemetry is not wired'),
          _stat('Invalid proofs rejected', s == null ? '0' : '${s.yteleportRejectedTransitions}'),
          _stat('Invalid anchors rejected', '0', detail: 'Peer/header rejection telemetry is not exposed'),
          _stat('Fail-closed events', s == null ? '0' : '${s.yteleportRejectedTransitions + s.yteleportReorgs}'),
        ]),
        _section(context, 'Automatic Phase 7 validation', [
          _stat('Status', _phase7Running ? 'Running…' : (_phase7?['passed'] == true ? 'PASS' : 'FAIL'), icon: _phase7Running ? Icons.sync : Icons.verified_user_outlined,
            detail: 'Runs automatically when this page opens; no wallet state is changed'),
          _stat('Checks', _phase7 == null ? 'Waiting…' : '${(_phase7!['checks'] as List? ?? const []).length}'),
          _stat('Elapsed', _phase7 == null ? 'Waiting…' : '${_phase7!['elapsed_ms'] ?? '—'} ms'),
          if (_phase7 != null)
            ...((_phase7!['checks'] as List? ?? const []).map((raw) {
              final c = Map<String, dynamic>.from(raw as Map);
              return _stat(c['name']?.toString() ?? 'check', c['passed'] == true ? 'PASS' : 'FAIL', detail: c['detail']?.toString());
            })),
        ]),
        _section(context, 'Current scanner', [
          _stat('Phase', s == null ? 'Waiting…' : s.phase, icon: Icons.speed),
          _stat('Blocks/sec', s == null ? '—' : s.blocksPerSec.toStringAsFixed(1)),
          _stat('Current batch', s == null ? '—' : '${s.currentBatchSize} blocks'),
          _stat('Workers', s == null ? '—' : '${s.workerCount}'),
          _stat('Prefetch depth', s == null ? '—' : '${s.prefetchDepth} ranges'),
          _stat('Downloaded', s == null ? '—' : '${s.downloadedBytes} bytes'),
        ]),
        _section(context, 'Trust boundary', [
          _stat('Peer data', 'UNTRUSTED', icon: Icons.shield_outlined),
          _stat('Consensus validation', 'Required'),
          _stat('Proof validation', 'Required'),
          _stat('Wallet commit', 'After verification'),
          _stat('Private keys sent to peers', 'Never'),
        ]),
        if (_serverError != null)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('Server telemetry unavailable: $_serverError',
              style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
          child: Text(
            _updated == null
              ? 'Waiting for telemetry…'
              : 'Last updated ${_updated!.toLocal().toString().substring(0, 19)}. '
                'Values marked “Not reported” are intentionally not inferred.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ]),
    );
  }
}

