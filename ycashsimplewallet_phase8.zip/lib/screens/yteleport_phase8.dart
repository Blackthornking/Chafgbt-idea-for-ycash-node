import 'dart:async';
import 'package:flutter/material.dart';
import '../core/wallet.dart';

/// Phase 8 validation dashboard.
///
/// Unlike a feature checklist, this page reports measured evidence and keeps
/// unavailable live paths explicitly marked as NOT YET TESTED. In particular,
/// BridgeSkip-X and ProofSkip-X cannot become PASS merely because their code
/// exists; they need real authenticated inputs.
class YTeleportPhase8 extends StatefulWidget {
  final SimpleWallet wallet;
  const YTeleportPhase8({super.key, required this.wallet});

  @override
  State<YTeleportPhase8> createState() => _YTeleportPhase8State();
}

class _YTeleportPhase8State extends State<YTeleportPhase8> {
  Map<String, dynamic>? _report;
  Timer? _timer;
  bool _running = false;
  DateTime? _updated;

  @override
  void initState() {
    super.initState();
    _refresh();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) => _refresh());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _refresh() async {
    if (_running) return;
    _running = true;
    try {
      final r = await widget.wallet.yteleportPhase8ValidationAsync();
      if (!mounted) return;
      setState(() {
        _report = r;
        _updated = DateTime.now();
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _report = {
          'overall_status': 'FAIL',
          'end_to_end_status': 'FAIL',
          'checks': [
            {'name': 'phase 8 validation', 'status': 'FAIL', 'value': 'FAIL', 'detail': '$e'}
          ],
        };
        _updated = DateTime.now();
      });
    } finally {
      _running = false;
    }
  }

  String _s(Object? v, [String fallback = 'Not reported']) {
    if (v == null) return fallback;
    final s = v.toString();
    return s.isEmpty ? fallback : s;
  }

  String _status(Map<String, dynamic>? r) => _s(r?['overall_status'], 'NOT_YET_TESTED');

  IconData _statusIcon(String status) {
    switch (status) {
      case 'PASS':
        return Icons.check_circle_outline;
      case 'FAIL':
        return Icons.cancel_outlined;
      default:
        return Icons.warning_amber_outlined;
    }
  }

  Widget _row(Map<String, dynamic> raw) {
    final status = _s(raw['status'], 'NOT_YET_TESTED');
    return ListTile(
      dense: true,
      leading: Icon(_statusIcon(status), size: 21),
      title: Text(_s(raw['name'], 'test')),
      subtitle: Text(_s(raw['detail'], '')),
      trailing: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 150),
        child: Text(_s(raw['value'], status), textAlign: TextAlign.right),
      ),
    );
  }

  List<Map<String, dynamic>> _list(String key) {
    final value = _report?[key];
    if (value is! List) return const [];
    return value.whereType<Map>().map((m) => Map<String, dynamic>.from(m)).toList();
  }

  Widget _section(String title, List<Widget> children) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
        child: Text(title, style: Theme.of(context).textTheme.titleSmall),
      ),
      Card(
        margin: const EdgeInsets.symmetric(horizontal: 12),
        child: Column(children: children),
      ),
    ]);
  }

  Widget _testSection(String title, String key) {
    final rows = _list(key);
    return _section(title, [
      if (rows.isEmpty)
        const ListTile(title: Text('Not yet tested'))
      else
        ...rows.map(_row),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final r = _report;
    final overall = _status(r);
    final node = r?['node'] is Map ? Map<String, dynamic>.from(r!['node'] as Map) : null;
    final sync = r?['sync'] is Map ? Map<String, dynamic>.from(r!['sync'] as Map) : null;

    return Scaffold(
      appBar: AppBar(
        title: const Text('YTeleport-X Phase 8'),
        actions: [
          IconButton(
            tooltip: 'Refresh validation',
            onPressed: _running ? null : _refresh,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: ListView(children: [
        _section('Overall Phase 8 status', [
          ListTile(
            leading: Icon(_statusIcon(overall), size: 28),
            title: Text(overall == 'NOT_YET_TESTED' ? 'Not yet tested' : overall),
            subtitle: Text(_s(r?['phase'], 'Live scanner integration validation')),
            trailing: _running ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : null,
          ),
          ListTile(
            title: const Text('End-to-end test status'),
            trailing: Text(_s(r?['end_to_end_status'], 'NOT_YET_TESTED')),
          ),
          ListTile(
            title: const Text('Elapsed'),
            trailing: Text('${_s(r?['elapsed_ms'], '—')} ms'),
          ),
        ]),

        _section('Node connectivity', [
          ListTile(
            leading: const Icon(Icons.dns_outlined),
            title: const Text('Connected'),
            trailing: Text(_s(node?['connected'], 'Not reported')),
          ),
          ListTile(title: const Text('Network'), trailing: Text(_s(node?['network']))),
          ListTile(title: const Text('Node height'), trailing: Text(_s(node?['height']))),
        ]),

        _section('Sync status', [
          ListTile(title: const Text('Wallet height'), trailing: Text(_s(sync?['wallet_height']))),
          ListTile(title: const Text('Blocks remaining'), trailing: Text(_s(sync?['remaining']))),
          ListTile(title: const Text('Scanner transitions observed'), trailing: Text(_s(sync?['scanner_transitions_observed'], '0'))),
          ListTile(title: const Text('Scanner phase'), trailing: Text(_s(sync?['phase']))),
        ]),

        _testSection('BridgeSkip-X', 'bridge_skip'),
        _testSection('ProofSkip-X', 'proof_skip'),
        _testSection('Verification', 'verification'),
        _testSection('Persistence', 'persistence'),
        _testSection('Reorg testing', 'reorg_testing'),
        _testSection('Performance', 'performance'),

        _section('End-to-end test status', [
          _row({
            'name': 'end-to-end gate',
            'status': _s(r?['end_to_end_status'], 'NOT_YET_TESTED'),
            'value': _s(r?['end_to_end_status'], 'NOT_YET_TESTED'),
            'detail': 'PASS requires every production Phase 8 path to have been exercised; unconnected skip paths remain not tested.',
          }),
        ]),

        _section('Trust boundary', [
          const ListTile(title: Text('ChainRoot promoted'), trailing: Text('No')),
          const ListTile(title: Text('StateRoot promoted'), trailing: Text('No')),
          const ListTile(title: Text('Wallet commit'), trailing: Text('After verification')),
          const ListTile(title: Text('Private keys sent to peers'), trailing: Text('Never')),
        ]),

        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
          child: Text(
            _updated == null
                ? 'Waiting for Phase 8 telemetry…'
                : 'Last updated ${_updated!.toLocal().toString().substring(0, 19)}. '
                  'PASS means the check was actually exercised; NOT_YET_TESTED is not treated as success.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ]),
    );
  }
}
