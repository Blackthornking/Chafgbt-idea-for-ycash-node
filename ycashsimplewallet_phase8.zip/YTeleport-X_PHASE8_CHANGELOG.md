# YTeleport-X Phase 8 — Live Scanner Integration Boundary

Implemented the next safe integration step after Phase 7.

## What changed

- Wired YTeleport-X telemetry into the existing native Ycash scanner status path.
- Exposed the scanner's exact last committed block hash as an anchor identifier.
- Added cumulative scanner-observed transition counts.
- Added rejection and reorg counters to the same native status snapshot.
- Exposed these values to the Flutter wallet and displayed them on the YTeleport-X statistics page.
- Kept ChainRoot and StateRoot unavailable until their actual authenticated derivation is connected.
- Kept `verified_transitions` at zero because the live scanner does not yet consume `StateTransitionProof` objects.
- Kept BridgeSkip-X execution at zero because the existing bridge cache has no authenticated Ycash tree-transition provider yet.
- Kept ProofSkip-X disabled and fail-closed.

## Security boundary

The existing Ycash scanner remains authoritative. A scanner-accepted block is telemetry about local authenticated scanning, not a substitute for YTeleport `StateTransitionProof` verification or an independent Ycash consensus-header verifier.

No wallet state, signing behavior, key material, or transaction serialization is changed.

## Remaining Phase 9 target

Connect a real Ycash consensus-header adapter and authenticated commitment-tree state source. Only after those inputs are available should live ChainRoot/StateRoot and verified StateTransitionProof telemetry be promoted from `Not available` to measured values. BridgeSkip-X can then consume an actually verified tree transition; ProofSkip remains locked until its independent proof-security gate passes.

## Phase 8 validation dashboard

Added a dedicated **YTeleport-X Phase 8 validation** page under Settings. It
runs a read-only validation snapshot and reports:

- node connectivity and node height
- wallet sync height, remaining blocks and observed scanner transitions
- BridgeSkip-X attempts/success/rejection/fallback state
- ProofSkip-X attempts/success/rejection/fallback state
- proof verification, invalid-data rejection and fail-closed checks
- durable checkpoint, note and transaction-record persistence
- reorg observations and recovery-test status
- measured blocks/sec and scan time, plus skip-time savings when available
- explicit PASS / FAIL / NOT YET TESTED end-to-end state

The page intentionally does **not** mark production BridgeSkip-X or ProofSkip-X
as passing. Those paths remain fail-closed until a real authenticated
state-tree/proof provider is connected. The live scanner/node evidence and the
existing Phase 7 cryptographic gate are reported separately so implementation
presence cannot be confused with successful live execution.
