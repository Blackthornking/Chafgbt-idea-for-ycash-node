//! Transparent UTXO set and Sprout shielded state for ordered block commits.
//!
//! Mirrors ycashd 4.5.0 `ConnectBlock` / `Consensus::CheckTxInputs` /
//! `ContextualCheckInputs` / `CCoinsViewCache::HaveShieldedRequirements`:
//! inputs exist and are unspent, coinbase maturity (100) and the
//! coinbase-must-be-shielded rule, value in >= value out, fees, script
//! verification (P2SH | CHECKLOCKTIMEVERIFY), block sigop limit, BIP30,
//! coinbase amount <= subsidy + fees, Sprout nullifiers and anchors
//! (including intermediate anchors inside one transaction), and the ZIP 209
//! Sprout/Sapling value-pool turnstile.
//!
//! Storage model: an output row is written once with the height that created
//! it and, when spent, the height that spent it. "State as of the batch's
//! first height H" is therefore `height < H AND (spent_height IS NULL OR
//! spent_height >= H)`, which stays correct even when the batch replaces an
//! old branch (rows at >= H are rolled back only after validation passes).
//! Spent rows are pruned once they are deeper than the 100-block maximum
//! reorg length ycashd itself enforces.

use anyhow::{anyhow, bail, Result};
use crate::rocks_backend::{ReadDb, WriteCtx, outpoint_key, height_outpoint_key, root_height_key, encode_utxo, decode_utxo, encode_block_state, decode_block_state};
use std::collections::{HashMap, HashSet, VecDeque};
use std::sync::{Condvar, Mutex, OnceLock};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use rayon::prelude::*;
use ycash_chain::ParsedTransaction;
use ycash_consensus::{
    block_subsidy, is_coinbase, money_range, tx_shielded_value_in, tx_value_out, SproutTree, COINBASE_MATURITY,
    MAX_BLOCK_SIGOPS,
};

/// ycashd `MAX_REORG_LENGTH` is 99; keep spent outputs a little longer.
pub const SPENT_OUTPUT_RETENTION: u64 = 100;

// Global execution budget shared by the Android pipeline verifier and the
// ordered commit's script verifier.  Both stages previously created/use
// cores-1 workers independently, which could oversubscribe an 8-core device
// with 7 pipeline workers + 7 script workers.
static SCRIPT_WORKER_BUDGET: AtomicUsize = AtomicUsize::new(1);
static SCRIPT_WORKER_BUDGET_CONFIGURED: AtomicBool = AtomicBool::new(false);
static SCRIPT_GATE: OnceLock<(Mutex<usize>, Condvar)> = OnceLock::new();

pub fn set_script_worker_budget(limit: usize) {
    let limit = limit.max(1);
    SCRIPT_WORKER_BUDGET.store(limit, Ordering::Release);
    SCRIPT_WORKER_BUDGET_CONFIGURED.store(true, Ordering::Release);
    let (_, cv) = SCRIPT_GATE.get_or_init(|| (Mutex::new(0), Condvar::new()));
    cv.notify_all();
}

/// Current shared script execution budget. This is the active permit count
/// target, not the size of the persistent Rayon pool. Before the pipeline has
/// explicitly configured a split, use the device-derived cores-1 default so
/// direct State callers are not accidentally serialized to one worker.
pub fn script_worker_budget() -> usize {
    if SCRIPT_WORKER_BUDGET_CONFIGURED.load(Ordering::Acquire) {
        SCRIPT_WORKER_BUDGET.load(Ordering::Acquire).max(1)
    } else {
        std::thread::available_parallelism().map(|n| n.get().saturating_sub(1).max(1)).unwrap_or(1)
    }
}

fn script_budget_limit() -> usize { script_worker_budget() }

struct ScriptPermit {
    wait_us: u64,
}
impl ScriptPermit {
    fn acquire() -> Self {
        let (mu, cv) = SCRIPT_GATE.get_or_init(|| (Mutex::new(0), Condvar::new()));
        let wait_started = std::time::Instant::now();
        let mut active = mu.lock().unwrap();
        loop {
            let limit = script_budget_limit();
            if *active < limit {
                *active += 1;
                return Self { wait_us: wait_started.elapsed().as_micros() as u64 };
            }
            active = cv.wait(active).unwrap();
        }
    }

    fn wait_us(&self) -> u64 { self.wait_us }
}
impl Drop for ScriptPermit {
    fn drop(&mut self) {
        if let Some((mu, cv)) = SCRIPT_GATE.get() {
            let mut active = mu.lock().unwrap();
            *active = active.saturating_sub(1);
            cv.notify_one();
        }
    }
}

pub type OutPoint = ([u8; 32], u32);

/// Bounded LRU cache of canonical UTXOs. The database remains authoritative;
/// this cache is only valid for the exact canonical parent tip. LRU touches are
/// collected during validation and applied at the commit publication boundary,
/// so cache hits never take a global cache lock.
#[derive(Debug, Clone)]
pub struct UtxoCache {
    map: HashMap<OutPoint, Coin>,
    order: VecDeque<OutPoint>,
}

impl UtxoCache {
    pub const MAX_ENTRIES: usize = 50_000;

    pub fn empty() -> Self { Self { map: HashMap::new(), order: VecDeque::new() } }

    pub fn get(&self, op: &OutPoint) -> Option<&Coin> { self.map.get(op) }

    pub fn insert(&mut self, op: OutPoint, coin: Coin) {
        if self.map.insert(op, coin).is_some() {
            if let Some(pos) = self.order.iter().position(|k| *k == op) { self.order.remove(pos); }
        }
        self.order.push_back(op);
        self.trim();
    }

    pub fn remove(&mut self, op: &OutPoint) {
        if self.map.remove(op).is_some() {
            if let Some(pos) = self.order.iter().position(|k| k == op) { self.order.remove(pos); }
        }
    }

    fn trim(&mut self) {
        while self.map.len() > Self::MAX_ENTRIES {
            let Some(oldest) = self.order.pop_front() else { break };
            self.map.remove(&oldest);
        }
    }

    #[cfg(test)]
    fn contains_key(&self, op: &OutPoint) -> bool { self.map.contains_key(op) }
}

/// Fine-grained timing for the ordered consensus/state connector.
///
/// These values intentionally cover only the state-validation phase; RocksDB write
/// and RocksDB batch commit timings are measured by `State::commit_blocks_batch`.
#[derive(Debug, Default, Clone, Copy)]
pub struct ConnectTiming {
    pub bip30_us: u64,
    pub sigops_us: u64,
    pub utxo_lookup_us: u64,
    pub sprout_requirements_us: u64,
    pub value_checks_us: u64,
    pub script_us: u64,
    pub coin_state_update_us: u64,
    pub sprout_apply_us: u64,
    pub tx_total_us: u64,
    pub bip30_ms: u64,
    pub sigops_ms: u64,
    pub tx_parse_us: u64,
    pub utxo_lookup_ms: u64,
    pub sprout_requirements_ms: u64,
    pub value_checks_ms: u64,
    pub script_ms: u64,
    pub coin_state_update_ms: u64,
    pub sprout_apply_ms: u64,
    pub tx_total_ms: u64,
    pub bip30_checks: u64,
    pub utxo_lookups: u64,
    pub script_checks: u64,
    pub script_parallel_workers: u64,
    pub script_parallel_us: u64,
    /// Sum of individual input verification CPU time (can exceed wall time
    /// when inputs execute concurrently), plus the slowest input location.
    pub script_input_work_us: u64,
    pub script_slowest_input_index: u64,
    pub script_slowest_input_us: u64,
    pub script_transaction_input_extraction_us: u64,
    pub script_sig_construction_us: u64,
    pub script_pubkey_retrieval_us: u64,
    pub script_parsing_us: u64,
    pub signature_hash_preparation_us: u64,
    pub ecdsa_verification_us: u64,
    pub script_interpreter_us: u64,
    pub script_cache_lookup_us: u64,
    pub script_synchronization_us: u64,
    pub script_permit_wait_us: u64,
    pub script_active_peak: u64,
    pub script_scheduler_gap_us: u64,
    /// Parallel-script wall-clock diagnostics. Each array slot is a Rayon worker index (up to 32).
    pub script_worker_wall_us: [u64; 32],
    pub script_worker_input_work_us: [u64; 32],
    pub script_worker_inputs: [u64; 32],
    pub script_spawn_us: u64,
    pub script_join_us: u64,
    /// Time inside the persistent verifier pool that is not covered by the
    /// longest worker span (dispatch/scheduler/wakeup overhead).
    pub script_pool_overhead_us: u64,
    pub script_pool_threads: u64,
    pub script_worker_max_us: u64,
    pub script_worker_min_us: u64,
}


#[derive(Clone, Debug)]
pub struct Coin {
    pub value: i64,
    pub script: Vec<u8>,
    pub height: u64,
    pub coinbase: bool,
}

#[derive(Clone, Debug)]
struct CoinEntry {
    coin: Coin,
    spent_height: Option<u64>,
    /// True when the entry already exists in canonical persistent state (DB or
    /// the canonical RAM cache). Cached entries must never be re-inserted, but
    /// a cached entry that becomes spent still needs its spent_height persisted.
    persisted: bool,
}

pub struct CoinsView<'a> {
    first_height: u64,
    entries: HashMap<OutPoint, CoinEntry>,
    batch_txids: HashSet<[u8; 32]>,
    cache: Option<&'a UtxoCache>,
    cache_touched: HashSet<OutPoint>,
    missing: HashSet<OutPoint>,
    pub cache_hits: u64,
    pub cache_misses: u64,
}

#[derive(Debug)]
pub struct PreparedUtxoChanges {
    entries: HashMap<OutPoint, CoinEntry>,
    cache_touched: Vec<OutPoint>,
}

impl PreparedUtxoChanges {
    pub(crate) fn empty() -> Self {
        Self { entries: HashMap::new(), cache_touched: Vec::new() }
    }

    pub(crate) fn apply(&self, db: &mut WriteCtx<'_>) -> Result<()> {
        for (op, e) in &self.entries {
            let key = outpoint_key(&op.0, op.1);
            if e.persisted {
                if let Some(h) = e.spent_height {
                    let value = encode_utxo(e.coin.value, &e.coin.script, e.coin.height, e.coin.coinbase, Some(h));
                    db.put("utxos", &key, &value)?;
                    db.put("utxo_spent", &height_outpoint_key(h, &op.0, op.1), &[])?;
                }
            } else {
                let value = encode_utxo(e.coin.value, &e.coin.script, e.coin.height, e.coin.coinbase, e.spent_height);
                db.put("utxos", &key, &value)?;
                db.put("utxo_height", &height_outpoint_key(e.coin.height, &op.0, op.1), &[])?;
                if let Some(h) = e.spent_height { db.put("utxo_spent", &height_outpoint_key(h, &op.0, op.1), &[])?; }
            }
        }
        Ok(())
    }

    /// Publish the already prepared UTXO delta into the canonical RAM cache.
    /// Existing hot entries touched during validation are promoted to the LRU
    /// tail; newly created outputs are also inserted at the tail.
    pub(crate) fn update_cache(&self, cache: &mut UtxoCache) {
        for (op, e) in &self.entries {
            if e.spent_height.is_some() {
                cache.remove(op);
            } else {
                cache.insert(*op, e.coin.clone());
            }
        }
        if !self.cache_touched.is_empty() {
            // Rebuild the LRU order in one O(cache + touches) pass instead of
            // removing each touched key from the VecDeque individually. This
            // matters for high-input batches where thousands of cache hits may
            // otherwise turn promotion into O(n²) work.
            let touched: HashSet<OutPoint> = self.cache_touched.iter().copied().collect();
            cache.order.retain(|op| !touched.contains(op));
            for op in &self.cache_touched {
                if self.entries.get(op).map(|e| e.spent_height.is_none()).unwrap_or(false) && cache.map.contains_key(op) {
                    cache.order.push_back(*op);
                }
            }
        }
        cache.trim();
    }
}

impl<'a> CoinsView<'a> {
    /// Prepare the UTXO mutation set without touching RocksDB.
    pub fn prepare_changes(&self) -> PreparedUtxoChanges {
        PreparedUtxoChanges { entries: self.entries.clone(), cache_touched: self.cache_touched.iter().copied().collect() }
    }

    pub fn new(first_height: u64, cache: Option<&'a UtxoCache>) -> Self {
        Self { first_height, entries: HashMap::new(), batch_txids: HashSet::new(), cache, cache_touched: HashSet::new(), missing: HashSet::new(), cache_hits: 0, cache_misses: 0 }
    }

    /// Prefetch a transaction's missing UTXOs in bounded RocksDB batches. This
    /// reduces statement dispatch/VM overhead on high-input blocks while
    /// preserving the exact per-input state semantics: only canonical DB rows
    /// below the batch height are considered, and intra-batch entries remain
    /// owned by `self.entries`.
    pub fn prefetch(&mut self, db: &ReadDb<'_>, ops: &[OutPoint]) -> Result<()> {
        let mut pending=Vec::new(); let mut seen=HashSet::new();
        for op in ops {
            if !seen.insert(*op) || self.entries.contains_key(op) || self.missing.contains(op) { continue; }
            if let Some(cache)=self.cache { if let Some(coin)=cache.get(op) { self.cache_hits+=1; self.cache_touched.insert(*op); self.entries.insert(*op,CoinEntry{coin:coin.clone(),spent_height:None,persisted:true}); continue; } }
            self.cache_misses+=1; pending.push(*op);
        }
        const CHUNK:usize=256;
        for chunk in pending.chunks(CHUNK) {
            let keys:Vec<Vec<u8>>=chunk.iter().map(|op|outpoint_key(&op.0,op.1).to_vec()).collect();
            let rows=db.multi_get("utxos",&keys)?;
            for (op,row) in chunk.iter().zip(rows.into_iter()) {
                match row {
                    Some(v)=>{let (value,script,height,coinbase,spent)=decode_utxo(&v)?;if height<self.first_height&&spent.map(|h|h>=self.first_height).unwrap_or(true){self.entries.insert(*op,CoinEntry{coin:Coin{value,script,height,coinbase},spent_height:None,persisted:true});}else{self.missing.insert(*op);}},
                    None=>{self.missing.insert(*op);}
                }
            }
        }
        Ok(())
    }

    pub fn get(&mut self, db: &ReadDb<'_>, op: &OutPoint) -> Result<Option<Coin>> {
        if let Some(e)=self.entries.get(op) { return Ok(if e.spent_height.is_none(){Some(e.coin.clone())}else{None}); }
        if let Some(cache)=self.cache { if let Some(coin)=cache.get(op) { self.cache_hits+=1; self.cache_touched.insert(*op); self.entries.insert(*op,CoinEntry{coin:coin.clone(),spent_height:None,persisted:true}); return Ok(Some(coin.clone())); } }
        if self.missing.contains(op){return Ok(None)}
        self.cache_misses+=1;
        match db.get("utxos", &outpoint_key(&op.0,op.1))? {
            Some(v)=>{let (value,script,height,coinbase,spent)=decode_utxo(&v)?; if height<self.first_height && spent.map(|h|h>=self.first_height).unwrap_or(true){let c=Coin{value,script,height,coinbase};self.entries.insert(*op,CoinEntry{coin:c.clone(),spent_height:None,persisted:true});Ok(Some(c))}else{self.missing.insert(*op);Ok(None)}}
            None=>{self.missing.insert(*op);Ok(None)}
        }
    }

    /// BIP30: a transaction may not overwrite one with unspent outputs.
    pub fn has_unspent_outputs_of(&self, db: &ReadDb<'_>, txid: &[u8;32]) -> Result<bool> {
        if self.batch_txids.contains(txid) && self.entries.iter().any(|(k,e)| k.0==*txid && !e.persisted && e.spent_height.is_none()) { return Ok(true); }
        // Dedicated tx-existence index: BIP30 only needs to know whether any output is live.
        let mut live_count=0usize;
        let prefix=*txid;
        for (k,v) in db.prefix("utxos", &prefix)? {
            if k.len()!=36 || &k[..32]!=txid { continue; }
            let (_,_,height,_,spent)=decode_utxo(&v)?;
            if height<self.first_height && spent.map(|h|h>=self.first_height).unwrap_or(true) { live_count+=1; }
        }
        let spent_in_batch=self.entries.iter().filter(|(k,e)|k.0==*txid && e.persisted && e.spent_height.is_some()).count();
        Ok(live_count>spent_in_batch)
    }

    pub fn spend(&mut self, op: &OutPoint, height: u64) {
        if let Some(e) = self.entries.get_mut(op) {
            e.spent_height = Some(height);
        }
    }

    pub fn add(&mut self, op: OutPoint, coin: Coin) {
        self.batch_txids.insert(op.0);
        self.entries.insert(op, CoinEntry { coin, spent_height: None, persisted: false });
    }

    /// Publish the prepared cache delta.
    pub fn update_cache(&self, cache: &mut UtxoCache) { self.prepare_changes().update_cache(cache); }

    /// Apply the already prepared UTXO mutation set inside the caller's atomic transaction.
    pub fn flush(&self, db: &mut WriteCtx<'_>) -> Result<()> {
        self.prepare_changes().apply(db)
    }
}

/// Sprout state carried through a batch.
pub struct SproutView {
    first_height: u64,
    pub tree: SproutTree,
    /// Final treestate of every block already processed in this batch.
    batch_roots: HashMap<[u8; 32], SproutTree>,
    batch_nullifiers: HashMap<[u8; 32], u64>,
    pub chain_sprout_value: i64,
    pub chain_sapling_value: i64,
    pub rows: Vec<BlockStateRow>,
}

#[derive(Clone, Debug)]
pub struct BlockStateRow {
    pub block_hash: [u8; 32],
    pub height: u64,
    pub sprout_root: [u8; 32],
    pub sprout_frontier: Vec<u8>,
    pub chain_sprout_value: i64,
    pub chain_sapling_value: i64,
}

#[derive(Debug)]
pub struct PreparedSproutChanges {
    nullifiers: HashMap<[u8; 32], u64>,
    rows: Vec<BlockStateRow>,
}

impl PreparedSproutChanges {
    pub(crate) fn empty() -> Self {
        Self { nullifiers: HashMap::new(), rows: Vec::new() }
    }

    pub(crate) fn apply(&self, db: &mut WriteCtx<'_>) -> Result<()> {
        for (n,h) in &self.nullifiers { db.put("sprout_nullifiers", n, &h.to_be_bytes())?; db.put("sprout_nullifiers_height", &h.to_be_bytes(), n)?; }
        for r in &self.rows {
            let v=encode_block_state(r.height,&r.sprout_root,&r.sprout_frontier,r.chain_sprout_value,r.chain_sapling_value);
            db.put("block_state", &r.block_hash, &v)?;
            db.put("block_state_height", &r.height.to_be_bytes(), &r.block_hash)?;
            db.put("sprout_root_index", &root_height_key(&r.sprout_root, r.height), &r.block_hash)?;
        }
        Ok(())
    }
}

impl SproutView {
    /// Prepare Sprout/nullifier mutations without touching RocksDB.
    pub fn prepare_changes(&self) -> PreparedSproutChanges {
        PreparedSproutChanges {
            nullifiers: self.batch_nullifiers.clone(),
            rows: self.rows.clone(),
        }
    }

    /// Construct a Sprout view from an exact canonical-parent cache entry.
    /// This is equivalent to `load()` but avoids decoding the same persisted
    /// frontier for every sequential batch.
    pub fn from_cached(first_height: u64, tree: SproutTree, sprout_value: i64, sapling_value: i64) -> Self {
        Self {
            first_height,
            tree,
            batch_roots: HashMap::new(),
            batch_nullifiers: HashMap::new(),
            chain_sprout_value: sprout_value,
            chain_sapling_value: sapling_value,
            rows: Vec::new(),
        }
    }

    pub fn load(db: &ReadDb<'_>, first_height: u64, prev: &[u8; 32]) -> Result<Self> {
        let (tree, sprout_value, sapling_value) = if first_height <= 1 {
            // The genesis block's transactions are never connected.
            (SproutTree::new(), 0, 0)
        } else {
            let v=db.get("block_state", prev)?.ok_or_else(|| anyhow!("missing Sprout/value-pool state for parent block"))?;
            let (_,_,a,b,f)=decode_block_state(&v)?;
            let t=SproutTree::decode(&f).map_err(|e| anyhow!("invalid persisted Sprout frontier: {e:?}"))?;
            (t,a,b)
        };
        Ok(Self {
            first_height,
            tree,
            batch_roots: HashMap::new(),
            batch_nullifiers: HashMap::new(),
            chain_sprout_value: sprout_value,
            chain_sapling_value: sapling_value,
            rows: Vec::new(),
        })
    }

    fn db_nullifier_exists(&self, db: &ReadDb<'_>, nf: &[u8;32]) -> Result<bool> {
        if let Some(v)=db.get("sprout_nullifiers",nf)? { let h=u64::from_be_bytes(v.try_into().map_err(|_|anyhow!("invalid Sprout nullifier height"))?); return Ok(h<self.first_height); }
        Ok(false)
    }

    fn anchor_tree(&self, db: &ReadDb<'_>, anchor: &[u8;32]) -> Result<Option<SproutTree>> {
        if let Some(t)=self.batch_roots.get(anchor){return Ok(Some(t.clone()));}
        if *anchor==SproutTree::empty_root(){return Ok(Some(SproutTree::new()));}
        let mut best: Option<(u64,Vec<u8>)> = None;
        for (k, bh) in db.prefix("sprout_root_index", anchor)? {
            if k.len()!=40 { continue; }
            let h=u64::from_be_bytes(k[32..40].try_into().unwrap());
            if h>=self.first_height { break; }
            if let Some(v)=db.get("block_state", &bh)? { let (_,root,_,_,frontier)=decode_block_state(&v)?; if root==*anchor { best=Some((h,frontier)); } }
        }
        Ok(match best { Some((_,f))=>Some(SproutTree::decode(&f).map_err(|e|anyhow!("invalid persisted Sprout frontier: {e:?}"))?), None=>None })
    }

    /// Sprout half of `HaveShieldedRequirements`.
    pub fn check_requirements(&self, db: &ReadDb<'_>, tx: &ParsedTransaction) -> Result<()> {
        let mut intermediates: HashMap<[u8; 32], SproutTree> = HashMap::new();
        for js in &tx.joinsplits {
            for nf in &js.nullifiers {
                if self.batch_nullifiers.contains_key(nf) || self.db_nullifier_exists(db, nf)? {
                    bail!("bad-txns-joinsplit-requirements-not-met: Sprout nullifier already spent");
                }
            }
            let mut tree = match intermediates.get(&js.anchor) {
                Some(t) => t.clone(),
                None => self
                    .anchor_tree(db, &js.anchor)?
                    .ok_or_else(|| anyhow!("bad-txns-joinsplit-requirements-not-met: unknown Sprout anchor"))?,
            };
            for cm in &js.commitments {
                tree.append(*cm).map_err(|e| anyhow!("{e:?}"))?;
            }
            intermediates.entry(tree.root()).or_insert(tree);
        }
        Ok(())
    }

    /// Nullifiers, commitments and value pools after a tx is connected.
    pub fn apply(&mut self, tx: &ParsedTransaction, height: u64) -> Result<()> {
        for js in &tx.joinsplits {
            for nf in &js.nullifiers {
                self.batch_nullifiers.insert(*nf, height);
            }
            for cm in &js.commitments {
                self.tree.append(*cm).map_err(|e| anyhow!("{e:?}"))?;
            }
            self.chain_sprout_value = self
                .chain_sprout_value
                .checked_add(js.vpub_old)
                .and_then(|v| v.checked_sub(js.vpub_new))
                .ok_or_else(|| anyhow!("Sprout value pool overflow"))?;
        }
        self.chain_sapling_value = self
            .chain_sapling_value
            .checked_sub(tx.value_balance)
            .ok_or_else(|| anyhow!("Sapling value pool overflow"))?;
        Ok(())
    }

    pub fn finish_block(&mut self, block_hash: [u8; 32], height: u64) -> Result<()> {
        if self.chain_sprout_value < 0 {
            bail!("turnstile-violation-sprout-shielded-pool at height {height}");
        }
        if self.chain_sapling_value < 0 {
            bail!("turnstile-violation-sapling-shielded-pool at height {height}");
        }
        let root = self.tree.root();
        self.batch_roots.entry(root).or_insert_with(|| self.tree.clone());
        self.rows.push(BlockStateRow {
            block_hash,
            height,
            sprout_root: root,
            sprout_frontier: self.tree.encode(),
            chain_sprout_value: self.chain_sprout_value,
            chain_sapling_value: self.chain_sapling_value,
        });
        Ok(())
    }

    pub fn flush(&self, db: &mut WriteCtx<'_>) -> Result<()> {
        self.prepare_changes().apply(db)
    }
}

fn txid_display(txid: &[u8; 32]) -> String {
    txid.iter().rev().map(|b| format!("{b:02x}")).collect()
}

/// Per-block accumulator for fees, sigops and the coinbase amount.
pub struct BlockConnector {
    pub height: u64,
    pub consensus_branch_id: u32,
    pub verify_scripts: bool,
    fees: i64,
    sigops: u64,
    coinbase_value_out: i64,
}

impl BlockConnector {
    pub fn new(height: u64, verify_scripts: bool) -> Self {
        Self {
            height,
            consensus_branch_id: ycash_consensus::consensus_branch_id(height),
            verify_scripts,
            fees: 0,
            sigops: 0,
            coinbase_value_out: 0,
        }
    }

    /// Maximum CPU threads used by the persistent transparent-script verifier.
    ///
    /// This is deliberately separate from pipeline/block concurrency. The
    /// consensus state transition remains ordered; only independent script
    /// checks execute concurrently. The default reserves one logical CPU for
    /// Android/housekeeping and permits the remaining logical CPUs.
    const SCRIPT_PARALLEL_THRESHOLD: usize = 2;

    /// One persistent CPU pool for all transparent script verification.
    ///
    /// This intentionally mirrors the useful part of ycashd's CCheckQueue and
    /// Zebra's persistent Rayon execution model: worker threads live for the
    /// lifetime of the process rather than being created and joined for every
    /// transaction. Individual inputs are queued as independent Rayon jobs,
    /// allowing work stealing instead of fixed per-worker chunks.
    fn script_parallel_threshold() -> usize {
        std::env::var("YORTAL_SCRIPT_PARALLEL_THRESHOLD")
            .ok()
            .and_then(|v| v.parse::<usize>().ok())
            .map(|v| v.clamp(1, 8))
            .unwrap_or(Self::SCRIPT_PARALLEL_THRESHOLD)
    }

    fn script_pool() -> &'static rayon::ThreadPool {
        static POOL: OnceLock<rayon::ThreadPool> = OnceLock::new();
        POOL.get_or_init(|| {
            let available = std::thread::available_parallelism()
                .map(|n| n.get())
                .unwrap_or(1);
            let device_ceiling = available.saturating_sub(1).max(1);
            let workers = match std::env::var("YORTAL_SCRIPT_WORKERS").ok().and_then(|v| v.parse::<usize>().ok()) {
                Some(0) | None => device_ceiling,
                Some(v) => v.clamp(1, device_ceiling),
            };
            rayon::ThreadPoolBuilder::new()
                .num_threads(workers)
                .thread_name(|i| format!("yortal-script-{i}"))
                .build()
                .expect("failed to create persistent YORTAL script verifier pool")
        })
    }

    /// Verify all transparent inputs without mutating consensus state.
    ///
    /// Consensus safety boundary:
    /// * all UTXOs and transaction data are collected before this function;
    /// * every script check observes the same immutable transaction/prevout set;
    /// * only script verification is parallel;
    /// * `connect_tx()` performs all state mutation in strict transaction order.
    ///
    /// Scheduling model:
    /// * one direct check for tiny transactions;
    /// * otherwise one independent job per input;
    /// * a persistent bounded Rayon pool performs dynamic work stealing;
    /// * no per-transaction OS-thread spawn/join and no fixed input partitioning.
    fn verify_scripts_parallel(
        &self,
        tx: &ParsedTransaction,
        txid: &[u8; 32],
        prevouts: &[Coin],
        precomputed: Option<&ycash_script::PrecomputedTxData>,
    ) -> Result<(u64, u64, u64, u64, u64, ycash_script::ScriptVerifyTiming, [u64; 32], [u64; 32], [u64; 32], u64, u64, u64, u64, u64, u64, u64, u64)> {
        if tx.vin.is_empty() {
            return Ok((0, 0, 0, 0, 0, ycash_script::ScriptVerifyTiming::default(), [0;32], [0;32], [0;32], 0, 0, 0, 0, 0, 0, 0, 0));
        }
        if tx.vin.len() < Self::script_parallel_threshold() {
            let started = std::time::Instant::now();
            let input = &tx.vin[0];
            let coin = &prevouts[0];
            let sink = ycash_script::ScriptTimingSink::new();
            let checker = ycash_script::TransactionChecker {
                tx,
                n_in: 0,
                amount: coin.value,
                consensus_branch_id: self.consensus_branch_id,
                precomputed,
                timing: Some(&sink),
            };
            ycash_script::verify_script(
                &input.script_sig,
                &coin.script,
                ycash_script::BLOCK_SCRIPT_VERIFY_FLAGS,
                &checker,
            ).map_err(|e| anyhow!("mandatory-script-verify-flag-failed ({e:?}): tx {} input 0 at height {}", txid_display(txid), self.height))?;
            let us = started.elapsed().as_micros() as u64;
            let mut worker_wall_us = [0u64; 32];
            let mut worker_input_work_us = [0u64; 32];
            let mut worker_inputs = [0u64; 32];
            worker_wall_us[0] = us;
            worker_input_work_us[0] = us;
            worker_inputs[0] = 1;
            return Ok((1, us, us, 0, us, sink.snapshot(), worker_wall_us, worker_input_work_us, worker_inputs, 0, 0, us, us, 0, 0, 0, 0));
        }

        let pool = Self::script_pool();
        let started = std::time::Instant::now();

        // Each input is an independent job. Rayon dynamically schedules these
        // jobs across the persistent pool, so a worker that finishes early can
        // immediately take another input. This avoids the old [23,10,2,1]
        // fixed-chunk imbalance seen in the performance telemetry.
        let results = pool.install(|| {
            tx.vin.par_iter().enumerate().map(|(i, input)| {
                let permit = ScriptPermit::acquire();
                let permit_wait_us = permit.wait_us();
                let worker_start_offset_us = started.elapsed().as_micros() as u64;
                let worker_idx = rayon::current_thread_index().unwrap_or(0).min(31);
                let active_after_permit = {
                    let (mu, _) = SCRIPT_GATE.get().expect("script gate initialized");
                    *mu.lock().unwrap() as u64
                };
                let sink = ycash_script::ScriptTimingSink::new();
                let coin = &prevouts[i];
                let checker = ycash_script::TransactionChecker {
                    tx,
                    n_in: i,
                    amount: coin.value,
                    consensus_branch_id: self.consensus_branch_id,
                    precomputed,
                    timing: Some(&sink),
                };
                let input_started = std::time::Instant::now();
                let result = ycash_script::verify_script(
                    &input.script_sig,
                    &coin.script,
                    ycash_script::BLOCK_SCRIPT_VERIFY_FLAGS,
                    &checker,
                );
                let input_us = input_started.elapsed().as_micros() as u64;
                let worker_end_offset_us = started.elapsed().as_micros() as u64;
                (i, worker_idx, result, input_us, worker_start_offset_us, worker_end_offset_us, permit_wait_us, active_after_permit, sink.snapshot())
            }).collect::<Vec<_>>()
        });

        let wall_us = started.elapsed().as_micros() as u64;
        let mut errors = Vec::new();
        let mut input_work_us = 0u64;
        let mut slow_idx = 0u64;
        let mut slow_us = 0u64;
        let mut telemetry = ycash_script::ScriptVerifyTiming::default();
        let mut worker_wall_us = [0u64; 32];
        let mut worker_input_work_us = [0u64; 32];
        let mut worker_inputs = [0u64; 32];
        let mut worker_first_start_us = [u64::MAX; 32];
        let mut worker_last_end_us = [0u64; 32];
        let mut permit_wait_us = 0u64;
        let mut active_peak = 0u64;
        for (i, worker, result, input_us, worker_start_us, worker_end_us, job_permit_wait_us, active_after_permit, sample) in results {
            permit_wait_us = permit_wait_us.saturating_add(job_permit_wait_us);
            active_peak = active_peak.max(active_after_permit);
            worker_input_work_us[worker] = worker_input_work_us[worker].saturating_add(input_us);
            worker_inputs[worker] = worker_inputs[worker].saturating_add(1);
            worker_first_start_us[worker] = worker_first_start_us[worker].min(worker_start_us);
            worker_last_end_us[worker] = worker_last_end_us[worker].max(worker_end_us);
            input_work_us = input_work_us.saturating_add(input_us);
            if input_us > slow_us { slow_us = input_us; slow_idx = i as u64; }
            telemetry.transaction_input_extraction_us = telemetry.transaction_input_extraction_us.saturating_add(sample.transaction_input_extraction_us);
            telemetry.script_sig_construction_us = telemetry.script_sig_construction_us.saturating_add(sample.script_sig_construction_us);
            telemetry.script_pubkey_retrieval_us = telemetry.script_pubkey_retrieval_us.saturating_add(sample.script_pubkey_retrieval_us);
            telemetry.script_parsing_us = telemetry.script_parsing_us.saturating_add(sample.script_parsing_us);
            telemetry.signature_hash_preparation_us = telemetry.signature_hash_preparation_us.saturating_add(sample.signature_hash_preparation_us);
            telemetry.ecdsa_verification_us = telemetry.ecdsa_verification_us.saturating_add(sample.ecdsa_verification_us);
            telemetry.script_interpreter_us = telemetry.script_interpreter_us.saturating_add(sample.script_interpreter_us);
            telemetry.cache_lookup_us = telemetry.cache_lookup_us.saturating_add(sample.cache_lookup_us);
            telemetry.synchronization_us = telemetry.synchronization_us.saturating_add(sample.synchronization_us);
            if let Err(e) = result { errors.push((i, e)); }
        }
        if let Some((i, e)) = errors.into_iter().min_by_key(|(i, _)| *i) {
            bail!("mandatory-script-verify-flag-failed ({e:?}): tx {} input {i} at height {}", txid_display(txid), self.height);
        }
        for i in 0..32 {
            if worker_first_start_us[i] != u64::MAX {
                worker_wall_us[i] = worker_last_end_us[i].saturating_sub(worker_first_start_us[i]);
            }
        }
        let max_worker_us = worker_wall_us.iter().copied().max().unwrap_or(0);
        let min_worker_us = worker_wall_us.iter().copied().filter(|v| *v != 0).min().unwrap_or(0);
        // The old fields are intentionally retained for API compatibility. No
        // OS threads are spawned or joined per transaction anymore.
        let spawn_us = 0;
        let join_us = 0;
        let scheduler_gap_us = wall_us.saturating_sub(max_worker_us);
        telemetry.synchronization_us = permit_wait_us;
        let actual_workers = script_worker_budget()
            .min(pool.current_num_threads())
            .min(tx.vin.len())
            .max(1);
        Ok((actual_workers as u64, wall_us, input_work_us, slow_idx, slow_us, telemetry, worker_wall_us, worker_input_work_us, worker_inputs, spawn_us, join_us, max_worker_us, min_worker_us, scheduler_gap_us, pool.current_num_threads() as u64, permit_wait_us, active_peak))
    }

    /// Validate `tx` against the view, then connect it (spend inputs, add
    /// outputs, apply Sprout effects). Order follows `ConnectBlock`.
    pub fn connect_tx(
        &mut self,
        db: &ReadDb<'_>,
        coins: &mut CoinsView,
        sprout: &mut SproutView,
        tx: &ParsedTransaction,
        txid: &[u8; 32],
        precomputed: Option<&ycash_script::PrecomputedTxData>,
        timing: &mut ConnectTiming,
    ) -> Result<()> {
        let tx_started = std::time::Instant::now();
        let h = self.height;
        let coinbase = is_coinbase(tx);

        let sigops_started = std::time::Instant::now();
        self.sigops += ycash_script::legacy_sig_op_count(tx) as u64;
        timing.sigops_us = timing.sigops_us.saturating_add(sigops_started.elapsed().as_micros() as u64);
        timing.sigops_ms = timing.sigops_us / 1000;
        if self.sigops > MAX_BLOCK_SIGOPS {
            bail!("bad-blk-sigops at height {h}");
        }
        let bip30_started = std::time::Instant::now();
        timing.bip30_checks += 1;
        if coins.has_unspent_outputs_of(db, txid)? {
            bail!("bad-txns-BIP30: tx {} at height {h}", txid_display(txid));
        }
        timing.bip30_us = timing.bip30_us.saturating_add(bip30_started.elapsed().as_micros() as u64);
        timing.bip30_ms = timing.bip30_us / 1000;

        if coinbase {
            self.coinbase_value_out = tx_value_out(tx).map_err(|e| anyhow!("{e:?}"))?;
        } else {
            let mut prevouts = Vec::with_capacity(tx.vin.len());
            let utxo_started = std::time::Instant::now();
            timing.utxo_lookups += tx.vin.len() as u64;
            let ops: Vec<OutPoint> = tx.vin.iter().map(|input| (input.prev_txid, input.prev_index)).collect();
            coins.prefetch(db, &ops)?;
            for input in &tx.vin {
                let op = (input.prev_txid, input.prev_index);
                let coin = coins.get(db, &op)?.ok_or_else(|| {
                    anyhow!(
                        "bad-txns-inputs-missingorspent: tx {} spends {}:{} at height {h}",
                        txid_display(txid),
                        txid_display(&input.prev_txid),
                        input.prev_index
                    )
                })?;
                prevouts.push(coin);
            }
            let utxo_elapsed_us = utxo_started.elapsed().as_micros() as u64;
            timing.utxo_lookup_us = timing.utxo_lookup_us.saturating_add(utxo_elapsed_us);
            // This is the actual transaction/input extraction from the canonical
            // UTXO view (including cache/RocksDB lookup). It is reported separately
            // from script execution because it occurs immediately before verify_script.
            timing.script_transaction_input_extraction_us = timing.script_transaction_input_extraction_us.saturating_add(utxo_elapsed_us);
            timing.utxo_lookup_ms = timing.utxo_lookup_us / 1000;

            let sprout_req_started = std::time::Instant::now();
            sprout.check_requirements(db, tx)?;
            timing.sprout_requirements_us = timing.sprout_requirements_us.saturating_add(sprout_req_started.elapsed().as_micros() as u64);
            timing.sprout_requirements_ms = timing.sprout_requirements_us / 1000;

            for (input, coin) in tx.vin.iter().zip(&prevouts) {
                if ycash_script::is_pay_to_script_hash(&coin.script) {
                    self.sigops += ycash_script::p2sh_sig_op_count(&coin.script, &input.script_sig) as u64;
                }
            }
            if self.sigops > MAX_BLOCK_SIGOPS {
                bail!("bad-blk-sigops at height {h}");
            }

            // Consensus::CheckTxInputs
            let value_started = std::time::Instant::now();
            let mut value_in: i64 = 0;
            for coin in &prevouts {
                if coin.coinbase {
                    if (h as i64) - (coin.height as i64) < COINBASE_MATURITY as i64 {
                        bail!("bad-txns-premature-spend-of-coinbase: tx {} at height {h}", txid_display(txid));
                    }
                    if !tx.vout.is_empty() {
                        bail!("bad-txns-coinbase-spend-has-transparent-outputs: tx {} at height {h}", txid_display(txid));
                    }
                }
                value_in = value_in
                    .checked_add(coin.value)
                    .filter(|v| money_range(coin.value) && money_range(*v))
                    .ok_or_else(|| anyhow!("bad-txns-inputvalues-outofrange at height {h}"))?;
            }
            value_in = value_in
                .checked_add(tx_shielded_value_in(tx).map_err(|e| anyhow!("{e:?}"))?)
                .filter(|v| money_range(*v))
                .ok_or_else(|| anyhow!("bad-txns-inputvalues-outofrange at height {h}"))?;
            let value_out = tx_value_out(tx).map_err(|e| anyhow!("{e:?}"))?;
            if value_in < value_out {
                bail!("bad-txns-in-belowout: tx {} at height {h} ({value_in} < {value_out})", txid_display(txid));
            }
            self.fees = self
                .fees
                .checked_add(value_in - value_out)
                .filter(|v| money_range(*v))
                .ok_or_else(|| anyhow!("bad-txns-fee-outofrange at height {h}"))?;
            timing.value_checks_us = timing.value_checks_us.saturating_add(value_started.elapsed().as_micros() as u64);
            timing.value_checks_ms = timing.value_checks_us / 1000;

            if self.verify_scripts {
                timing.script_checks = timing.script_checks.saturating_add(tx.vin.len() as u64);
                let (workers, script_us, input_work_us, slow_input_index, slow_input_us, script_timing, worker_wall_us, worker_input_work_us, worker_inputs, spawn_us, join_us, worker_max_us, worker_min_us, scheduler_gap_us, pool_threads, permit_wait_us, active_peak) = self.verify_scripts_parallel(tx, txid, &prevouts, precomputed)?;
                timing.script_parallel_workers = timing.script_parallel_workers.max(workers);
                timing.script_parallel_us = timing.script_parallel_us.saturating_add(script_us);
                timing.script_input_work_us = timing.script_input_work_us.saturating_add(input_work_us);
                timing.script_transaction_input_extraction_us = timing.script_transaction_input_extraction_us.saturating_add(script_timing.transaction_input_extraction_us);
                timing.script_sig_construction_us = timing.script_sig_construction_us.saturating_add(script_timing.script_sig_construction_us);
                timing.script_pubkey_retrieval_us = timing.script_pubkey_retrieval_us.saturating_add(script_timing.script_pubkey_retrieval_us);
                timing.script_parsing_us = timing.script_parsing_us.saturating_add(script_timing.script_parsing_us);
                timing.signature_hash_preparation_us = timing.signature_hash_preparation_us.saturating_add(script_timing.signature_hash_preparation_us);
                timing.ecdsa_verification_us = timing.ecdsa_verification_us.saturating_add(script_timing.ecdsa_verification_us);
                timing.script_interpreter_us = timing.script_interpreter_us.saturating_add(script_timing.script_interpreter_us);
                timing.script_cache_lookup_us = timing.script_cache_lookup_us.saturating_add(script_timing.cache_lookup_us);
                timing.script_synchronization_us = timing.script_synchronization_us.saturating_add(script_timing.synchronization_us);
                timing.script_permit_wait_us = timing.script_permit_wait_us.saturating_add(permit_wait_us);
                timing.script_active_peak = timing.script_active_peak.max(active_peak);
                timing.script_scheduler_gap_us = timing.script_scheduler_gap_us.saturating_add(scheduler_gap_us);
                for i in 0..32 {
                    timing.script_worker_wall_us[i] = timing.script_worker_wall_us[i].saturating_add(worker_wall_us[i]);
                    timing.script_worker_input_work_us[i] = timing.script_worker_input_work_us[i].saturating_add(worker_input_work_us[i]);
                    timing.script_worker_inputs[i] = timing.script_worker_inputs[i].saturating_add(worker_inputs[i]);
                }
                timing.script_spawn_us = timing.script_spawn_us.saturating_add(spawn_us);
                timing.script_join_us = timing.script_join_us.saturating_add(join_us);
                timing.script_pool_overhead_us = timing.script_pool_overhead_us.saturating_add(scheduler_gap_us);
                timing.script_pool_threads = timing.script_pool_threads.max(pool_threads);
                timing.script_worker_max_us = timing.script_worker_max_us.max(worker_max_us);
                if timing.script_worker_min_us == 0 { timing.script_worker_min_us = worker_min_us; } else if worker_min_us != 0 { timing.script_worker_min_us = timing.script_worker_min_us.min(worker_min_us); }
                if slow_input_us > timing.script_slowest_input_us {
                    timing.script_slowest_input_index = slow_input_index;
                    timing.script_slowest_input_us = slow_input_us;
                }
                timing.script_us = timing.script_us.saturating_add(script_us);
                timing.script_ms = timing.script_us / 1000;
            }

            let coin_state_started = std::time::Instant::now();
            for input in &tx.vin {
                coins.spend(&(input.prev_txid, input.prev_index), h);
            }
            timing.coin_state_update_us = timing.coin_state_update_us.saturating_add(coin_state_started.elapsed().as_micros() as u64);
            timing.coin_state_update_ms = timing.coin_state_update_us / 1000;
        }

        let coin_state_started = std::time::Instant::now();
        for (n, out) in tx.vout.iter().enumerate() {
            if !ycash_script::is_unspendable(&out.script_pubkey) {
                coins.add(
                    (*txid, n as u32),
                    Coin { value: out.value, script: out.script_pubkey.clone(), height: h, coinbase },
                );
            }
        }
        timing.coin_state_update_us = timing.coin_state_update_us.saturating_add(coin_state_started.elapsed().as_micros() as u64);
            timing.coin_state_update_ms = timing.coin_state_update_us / 1000;
        let sprout_apply_started = std::time::Instant::now();
        sprout.apply(tx, h)?;
        timing.sprout_apply_us = timing.sprout_apply_us.saturating_add(sprout_apply_started.elapsed().as_micros() as u64);
        timing.sprout_apply_ms = timing.sprout_apply_us / 1000;
        timing.tx_total_us = timing.tx_total_us.saturating_add(tx_started.elapsed().as_micros() as u64);
        timing.tx_total_ms = timing.tx_total_us / 1000;
        Ok(())
    }

    /// `bad-cb-amount`: coinbase may claim at most subsidy + fees.
    pub fn finish(&self) -> Result<()> {
        let limit = self
            .fees
            .checked_add(block_subsidy(self.height))
            .ok_or_else(|| anyhow!("block reward overflow"))?;
        if self.coinbase_value_out > limit {
            bail!(
                "bad-cb-amount at height {}: coinbase pays {} > subsidy+fees {}",
                self.height,
                self.coinbase_value_out,
                limit
            );
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{SystemTime, UNIX_EPOCH};
    use rocksdb::{Options, DB};
    use crate::rocks_backend::CF_NAMES;

    fn temp_path() -> std::path::PathBuf {
        std::env::temp_dir().join(format!("yortal-rocks-test-{}-{}", std::process::id(), SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos()))
    }

    #[test]
    fn rocksdb_column_families_are_created() {
        let p=temp_path();
        let s=State::open(&p).unwrap();
        for name in CF_NAMES { assert!(s.db.cf_handle(name).is_some(), "missing CF {name}"); }
        drop(s);
        let _=DB::destroy(&Options::default(),&p);
    }
}
