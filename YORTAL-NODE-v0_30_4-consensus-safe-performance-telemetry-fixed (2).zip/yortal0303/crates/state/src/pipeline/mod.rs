//! YORTAL adaptive synchronization components.
//! The default configuration is deliberately sequential for consensus bring-up: one
//! validation worker and one in-flight range behind the ordered commit barrier.
pub mod adaptive;
pub mod range_scheduler;
pub mod telemetry;

// `pub use` here (not plain `use`) because crates/node and
// crates/ycash-android-node both refer to these as `pipeline::AdaptiveConfig`
// / `pipeline::PipelineEngine` etc. A plain `use` only resolves names inside
// this module and does not re-export them, which left `ycash_state::pipeline::AdaptiveConfig`
// unreachable from other crates despite `PipelineEngine::new` requiring one.
pub use adaptive::{AdaptiveConfig, AdaptiveController, ResourceSample};
pub use range_scheduler::{RangeId, RangeLease, RangeScheduler, RangeState};
pub use telemetry::{PipelineSnapshot, PipelineStats};

/// Ties the adaptive window controller, the multi-peer range scheduler, and
/// telemetry into the single engine described in
/// `PIPELINE_V0.22_IMPLEMENTATION.md`.
///
/// Scope note: this engine owns *scheduling policy* only -- which height
/// ranges exist, which peer currently leases each one, and how large the
/// sync window is allowed to get. It does not itself do peer discovery,
/// header/body fetch, or block validation; those live in the network and
/// consensus crates and are expected to drive this engine via `plan_ranges`,
/// `claim`, `complete`, `release`, and `observe`. That wiring (peer scoring,
/// the actual header/body fetch loop, and the ordered commit path into
/// `State::commit_block`) is not implemented yet -- it needs its own pass
/// once the network crate has more than a single handshake.
pub struct PipelineEngine {
    adaptive: AdaptiveController,
    scheduler: RangeScheduler,
    stats: PipelineStats,
}

impl PipelineEngine {
    pub fn new(cfg: AdaptiveConfig) -> Self {
        let mut stats = PipelineStats::default();
        stats.start();
        Self {
            adaptive: AdaptiveController::new(cfg),
            scheduler: RangeScheduler::default(),
            stats,
        }
    }

    /// Enqueue the next height range up to the current adaptive window,
    /// starting at `next_height` and bounded by `chain_tip`. Returns the
    /// height sync should resume planning from on the following call.
    pub fn plan_ranges(&mut self, next_height: u64, chain_tip: u64) -> u64 {
        let window = self.adaptive.window() as u64;
        let end = (next_height + window.saturating_sub(1)).min(chain_tip);
        // HeightRange is inclusive, so a single remaining height (end ==
        // next_height) is still a valid range and must be enqueued -- an
        // earlier version of this used `end > next_height` here, which
        // silently dropped the last height of every sync window.
        if end >= next_height && next_height <= chain_tip {
            self.scheduler.enqueue(next_height, end);
        }
        self.stats.current_window = window;
        end
    }

    /// Lease the next pending range to `peer`.
    pub fn claim(&mut self, peer: &str) -> Option<RangeLease> {
        self.scheduler.claim(peer)
    }

    /// Lease the next pending range whose end is at or below `max_end`.
    pub fn claim_upto(&mut self, peer: &str, max_end: u64) -> Option<RangeLease> {
        self.scheduler.claim_upto(peer, max_end)
    }

    /// Heights pending or leased right now (real "in flight" figure).
    pub fn outstanding_heights(&self) -> u64 {
        self.scheduler.outstanding_heights()
    }

    /// Number of ranges actually leased to peers right now.
    pub fn leased_ranges(&self) -> usize {
        self.scheduler.leased_ranges()
    }

    /// Number of planned ranges still waiting for a peer.
    pub fn pending_ranges(&self) -> usize {
        self.scheduler.pending_ranges()
    }

    /// Plan the current adaptive window as multiple independent ranges. The
    /// total number of heights remains bounded by the adaptive window; the
    /// window is merely partitioned so several peers can work concurrently.
    pub fn plan_parallel_ranges(&mut self, next_height: u64, chain_tip: u64, workers: usize) -> Vec<RangeId> {
        if next_height > chain_tip { return Vec::new(); }
        let window = self.adaptive.window().max(1) as u64;
        let end = (next_height + window - 1).min(chain_tip);
        let total = end - next_height + 1;
        // Keep each range small. One huge getdata (e.g. 256 blocks when only
        // one peer was connected at planning time) can't finish inside the
        // fetch deadline on mobile data, so it fails on every peer, hits the
        // retry limit, quarantines, and wedges the commit order.
        // Match ycashd's MAX_BLOCKS_IN_TRANSIT_PER_PEER. The adaptive window's
        // size is a global lookahead, not a per-peer getdata batch.
        const MAX_RANGE_LEN: u64 = 16;
        let by_size = ((total + MAX_RANGE_LEN - 1) / MAX_RANGE_LEN) as usize;
        let count = workers.max(1).max(by_size).min(total as usize);
        let chunk = (total + count as u64 - 1) / count as u64;
        let mut ids = Vec::new();
        let mut start = next_height;
        while start <= end {
            let finish = (start + chunk - 1).min(end);
            ids.push(self.scheduler.enqueue(start, finish));
            start = finish + 1;
        }
        self.stats.current_window = window;
        self.stats.validation_workers = workers.max(1) as u64;
        self.stats.blocks_in_flight = total;
        self.stats.request_rounds += 1;
        ids
    }

    pub fn lease_age(&self, id: RangeId) -> Option<std::time::Duration> {
        self.scheduler.lease_age(id)
    }

    pub fn range_ids_at_start(&self, start: u64) -> Option<RangeId> {
        self.scheduler.id_at_start(start)
    }

    pub fn requeue_if_lease_stalled(&mut self, id: RangeId, max_age: std::time::Duration) -> bool {
        if self.scheduler.lease_age(id).map(|age| age >= max_age).unwrap_or(false) {
            self.scheduler.requeue(id);
            true
        } else { false }
    }

    pub fn is_current_lease(&self, id: RangeId, generation: u64) -> bool {
        self.scheduler.is_current_lease(id, generation)
    }

    pub fn range_terminal(&self, id: RangeId) -> bool {
        matches!(self.scheduler.state(id), None | Some(RangeState::Complete | RangeState::Quarantined))
    }

    /// Current adaptive window size (heights per planning round). Exposed so
    /// callers can size backpressure thresholds (e.g. how far ahead of the
    /// last commit it's safe to keep planning) off the same value the
    /// scheduler itself is using, instead of guessing a constant.
    pub fn window(&self) -> u64 {
        self.adaptive.window() as u64
    }

    /// If the range starting at `start` (normally the coordinator's
    /// `next_commit`) has been quarantined, requeue it so it can be claimed
    /// again. Returns `true` if a range was requeued.
    ///
    /// See `RangeScheduler::requeue` for why this exists: quarantine must
    /// not be a true dead end for the range sitting at the head of the
    /// commit order, or sync stalls there forever while every later range
    /// keeps piling into the validated-but-uncommitted buffer.
    pub fn requeue_if_quarantined_at(&mut self, start: u64) -> bool {
        if let Some(id) = self.scheduler.id_at_start(start) {
            if self.scheduler.state(id) == Some(RangeState::Quarantined) {
                self.scheduler.requeue(id);
                return true;
            }
        }
        false
    }

    /// Return a lease to Pending without a retry/quarantine count.
    pub fn requeue_lease(&mut self, id: RangeId) {
        self.scheduler.unlease(id);
    }

    /// Mark a range complete and fold its results into telemetry.
    pub fn complete(&mut self, id: RangeId, blocks_received: u64, bytes_received: u64) {
        self.scheduler.complete(id);
        self.stats.blocks_received += blocks_received;
        self.stats.bytes_received += bytes_received;
        self.stats.completed_ranges += 1;
        self.stats.blocks_in_flight = self.stats.blocks_in_flight.saturating_sub(blocks_received);
    }

    /// Release an unfinished lease (timeout/disconnect). Escalates to
    /// telemetry as a retry or, past the retry limit, a quarantine.
    pub fn release(&mut self, id: RangeId) {
        self.scheduler.release(id);
        match self.scheduler.state(id) {
            Some(RangeState::Quarantined) => self.stats.quarantined_ranges += 1,
            _ => self.stats.retried_ranges += 1,
        }
    }

    /// Feed a fresh resource sample; adjusts the adaptive window and returns
    /// the current telemetry snapshot (for dashboards/RPC).
    pub fn release_if_current(&mut self, id: RangeId, generation: u64) -> bool {
        if self.scheduler.is_current_lease(id, generation) { self.release(id); true } else { false }
    }

    pub fn observe(&mut self, sample: ResourceSample) -> PipelineSnapshot {
        self.stats.current_window = self.adaptive.observe(sample) as u64;
        self.stats.snapshot()
    }

    pub fn max_validation_workers(&self) -> usize { self.adaptive.max_validation_workers().max(1) }

    pub fn max_inflight_ranges(&self) -> usize { self.adaptive.max_inflight_ranges().max(1) }

    pub fn snapshot(&self) -> PipelineSnapshot {
        self.stats.snapshot()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ranges_do_not_exceed_16_blocks() {
        let mut engine = PipelineEngine::new(AdaptiveConfig::default());
        let ids = engine.plan_parallel_ranges(1, 64, 4);
        assert_eq!(ids.len(), 4);
        for id in ids {
            let lease = engine.scheduler.state(id).expect("planned range");
            assert_ne!(lease, RangeState::Quarantined, "planned range was quarantined");
        }
        assert_eq!(engine.outstanding_heights(), 16);
    }

    #[test]
    fn scheduler_telemetry_distinguishes_leased_and_pending_ranges() {
        let mut engine = PipelineEngine::new(AdaptiveConfig {
            min_window: 16, initial_window: 16, max_window: 16, step: 1,
            high_watermark: 0.90, low_watermark: 0.55,
            max_validation_workers: 1, max_inflight_ranges: 1,
        });
        let ids = engine.plan_parallel_ranges(1, 16, 1);
        assert_eq!(ids.len(), 1);
        assert_eq!(engine.pending_ranges(), 1);
        assert_eq!(engine.leased_ranges(), 0);
        let lease = engine.claim_upto("peer-a", 16).expect("range claim");
        assert_eq!(lease.range.len(), 16);
        assert_eq!(engine.pending_ranges(), 0);
        assert_eq!(engine.leased_ranges(), 1);
        assert_eq!(engine.outstanding_heights(), 16);
    }

    #[test]
    fn small_window_does_not_create_oversized_range() {
        let mut engine = PipelineEngine::new(AdaptiveConfig {
            min_window: 64, initial_window: 64, max_window: 64, step: 1,
            high_watermark: 0.90, low_watermark: 0.55,
            max_validation_workers: 1, max_inflight_ranges: 1,
        });
        let ids = engine.plan_parallel_ranges(1, 17, 1);
        assert_eq!(ids.len(), 2);
        assert_eq!(engine.outstanding_heights(), 17);
    }
}

impl Default for PipelineEngine {
    fn default() -> Self {
        Self::new(AdaptiveConfig::default())
    }
}
