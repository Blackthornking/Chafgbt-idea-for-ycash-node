#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
P="$ROOT/crates/ycash-android-node/src/pipeline_sync.rs"
E="$ROOT/crates/state/src/pipeline/mod.rs"
C="$ROOT/config/pipeline.toml"
[[ -f "$P" && -f "$E" && -f "$C" ]]
! grep -RInE 'AdaptiveController|AdaptiveConfig|RangeScheduler|RangeLease|RangeId|RangeState|plan_parallel_ranges|max_range_len|max_inflight_ranges' \
  "$ROOT/crates" "$ROOT/config" "$ROOT/android-app/app/src/main/java"
grep -Eq '^max_blocks_in_transit_per_peer[[:space:]]*=[[:space:]]*48' "$C"
grep -Eq '^max_prospective_blocks[[:space:]]*=[[:space:]]*192' "$C"
grep -q 'MAX_BLOCKS_IN_TRANSIT_PER_PEER: usize = 48' "$E"
grep -q 'MAX_PROSPECTIVE_BLOCKS: usize = 192' "$E"
grep -q 'prepare_commit_batch' "$P"
grep -q 'apply_prepared_commit' "$P"
grep -q 'commit_active' "$P"
grep -q 'state.prepare_commit_batch' "$P"
grep -q 'state.apply_prepared_commit' "$P"
grep -q 'getdata' "$P"
echo 'PASS: fixed 48-block transport pipeline, bounded prospective queue, and single ordered state writer'
