//! Fixed Zebra-style synchronization coordinator.
//!
//! The transport scheduler is deliberately non-adaptive: a block window is
//! fixed at 48 blocks. This is a networking/backpressure value only.
//! Consensus/state validation remains owned by State and the single ordered
//! commit worker.

pub mod telemetry;
pub use telemetry::{PipelineSnapshot, PipelineStats};

use std::collections::{BTreeMap, HashMap};
use std::time::{Duration, Instant};

pub const MAX_BLOCKS_IN_TRANSIT_PER_PEER: usize = 48;
pub const MAX_PROSPECTIVE_BLOCKS: usize = 192;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct BlockWindowId(pub u64);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct BlockWindow { pub start: u64, pub end: u64 }
impl BlockWindow { pub fn len(&self) -> u64 { self.end.saturating_sub(self.start)+1 } }

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BlockWindowState { Pending, Leased, Complete, Quarantined }

#[derive(Clone, Debug)]
pub struct BlockWindowLease {
    pub id: BlockWindowId,
    pub window: BlockWindow,
    pub peer: String,
    pub state: BlockWindowState,
    pub retries: u32,
    pub generation: u64,
    pub claimed_at: Option<Instant>,
}

#[derive(Clone, Copy, Debug)]
pub struct PipelineConfig {
    pub max_blocks_in_transit_per_peer: usize,
    pub max_prospective_blocks: usize,
}
impl Default for PipelineConfig {
    fn default() -> Self {
        Self { max_blocks_in_transit_per_peer: MAX_BLOCKS_IN_TRANSIT_PER_PEER,
               max_prospective_blocks: MAX_PROSPECTIVE_BLOCKS }
    }
}

pub struct PipelineEngine {
    cfg: PipelineConfig,
    next_id: u64,
    windows: BTreeMap<BlockWindowId, BlockWindowLease>,
    peer_load: HashMap<String, usize>,
    stats: PipelineStats,
}
impl PipelineEngine {
    pub fn new(cfg: PipelineConfig) -> Self {
        let mut stats=PipelineStats::default();
        stats.start();
        stats.current_window=MAX_BLOCKS_IN_TRANSIT_PER_PEER as u64;
        stats.max_inflight_windows=1;
        Self { cfg, next_id:0, windows:BTreeMap::new(), peer_load:HashMap::new(), stats }
    }
    pub fn plan_windows(&mut self,next:u64,tip:u64,_workers:usize)->Vec<BlockWindowId>{
        if next>tip{return Vec::new()}
        let covered=self.outstanding_heights();
        if covered >= self.cfg.max_prospective_blocks as u64 { return Vec::new(); }
        let mut start=next;
        while self.windows.values().any(|w| matches!(w.state,BlockWindowState::Pending|BlockWindowState::Leased|BlockWindowState::Quarantined)
            && w.window.start<=start && start<=w.window.end) { start+=1; }
        if start>tip { return Vec::new(); }
        let capacity=(self.cfg.max_prospective_blocks as u64).saturating_sub(covered);
        let len=(tip-start+1).min(MAX_BLOCKS_IN_TRANSIT_PER_PEER as u64).min(capacity);
        if len==0{return Vec::new()}
        let id=self.enqueue(start,start+len-1);
        self.stats.request_rounds+=1;
        self.stats.current_window=len;
        self.stats.blocks_in_flight=self.outstanding_heights();
        vec![id]
    }
    fn enqueue(&mut self,start:u64,end:u64)->BlockWindowId {
        let id=BlockWindowId(self.next_id); self.next_id+=1;
        self.windows.insert(id,BlockWindowLease{id,window:BlockWindow{start,end},peer:String::new(),
            state:BlockWindowState::Pending,retries:0,generation:0,claimed_at:None});
        id
    }
    pub fn claim(&mut self,p:&str)->Option<BlockWindowLease>{
        if self.peer_load.get(p).copied().unwrap_or(0) >= 1 { return None; }
        let id=self.windows.iter().find(|(_,w)|w.state==BlockWindowState::Pending).map(|(i,_)|*i)?;
        let w=self.windows.get_mut(&id)?;
        w.peer=p.to_owned(); w.state=BlockWindowState::Leased; w.generation+=1; w.claimed_at=Some(Instant::now());
        *self.peer_load.entry(p.to_owned()).or_default()+=1;
        Some(w.clone())
    }
    pub fn claim_upto(&mut self,p:&str,max_end:u64)->Option<BlockWindowLease>{
        let id=self.windows.iter().find(|(_,w)|w.state==BlockWindowState::Pending && w.window.end<=max_end).map(|(i,_)|*i)?;
        if self.peer_load.get(p).copied().unwrap_or(0)>=1{return None}
        let w=self.windows.get_mut(&id)?;
        w.peer=p.to_owned(); w.state=BlockWindowState::Leased; w.generation+=1; w.claimed_at=Some(Instant::now());
        *self.peer_load.entry(p.to_owned()).or_default()+=1; Some(w.clone())
    }
    pub fn complete(&mut self,id:BlockWindowId,blocks:u64,bytes:u64){
        if let Some(w)=self.windows.remove(&id){ if let Some(v)=self.peer_load.get_mut(&w.peer){*v=v.saturating_sub(1)} }
        self.stats.blocks_received+=blocks; self.stats.blocks_committed+=blocks;
        self.stats.bytes_received+=bytes; self.stats.completed_windows+=1;
        self.stats.blocks_in_flight=self.outstanding_heights();
    }
    pub fn release(&mut self,id:BlockWindowId){self.requeue(id,true);}
    pub fn release_if_current(&mut self,id:BlockWindowId,g:u64)->bool{
        if self.is_current_lease(id,g){self.release(id);true}else{false}
    }
    pub fn requeue_lease(&mut self,id:BlockWindowId){self.requeue(id,false);}
    fn requeue(&mut self,id:BlockWindowId,count_retry:bool){
        let mut quarantined=false;
        if let Some(w)=self.windows.get_mut(&id){
            let peer=w.peer.clone();
            if let Some(v)=self.peer_load.get_mut(&peer){*v=v.saturating_sub(1)}
            if count_retry {w.retries=w.retries.saturating_add(1)}
            w.peer.clear();w.claimed_at=None;w.generation+=1;
            w.state=if w.retries>=3{BlockWindowState::Quarantined}else{BlockWindowState::Pending};
            quarantined=w.state==BlockWindowState::Quarantined;
        }
        self.stats.retried_windows+=u64::from(count_retry);
        self.stats.quarantined_windows += u64::from(quarantined && count_retry);
    }
    pub fn is_current_lease(&self,id:BlockWindowId,g:u64)->bool{self.windows.get(&id).map(|w|w.state==BlockWindowState::Leased&&w.generation==g).unwrap_or(false)}
    pub fn window_end(&self,id:BlockWindowId)->Option<u64>{self.windows.get(&id).map(|w|w.window.end)}
    pub fn lease_age(&self,id:BlockWindowId)->Option<Duration>{self.windows.get(&id)?.claimed_at.map(|x|x.elapsed())}
    pub fn window_ids_at_start(&self,s:u64)->Option<BlockWindowId>{self.windows.values().find(|w|w.window.start==s).map(|w|w.id)}
    pub fn requeue_if_lease_stalled(&mut self,id:BlockWindowId,d:Duration)->bool{if self.lease_age(id).map(|x|x>=d).unwrap_or(false){self.requeue(id,false);true}else{false}}
    pub fn requeue_if_quarantined_at(&mut self,s:u64)->bool{if let Some(id)=self.window_ids_at_start(s){if self.windows.get(&id).map(|w|w.state==BlockWindowState::Quarantined).unwrap_or(false){self.requeue(id,false);return true}}false}
    pub fn outstanding_heights(&self)->u64{self.windows.values().filter(|w|matches!(w.state,BlockWindowState::Pending|BlockWindowState::Leased)).map(|w|w.window.len()).sum()}
    pub fn pending_windows(&self)->usize{self.windows.values().filter(|w|w.state==BlockWindowState::Pending).count()}
    pub fn leased_windows(&self)->usize{self.windows.values().filter(|w|w.state==BlockWindowState::Leased).count()}
    pub fn current_validation_workers(&self)->usize{self.configured_max_validation_workers()}
    pub fn max_inflight_windows(&self)->usize{self.leased_windows().max(1)}
    pub fn configured_max_inflight_windows(&self)->usize{self.cfg.max_prospective_blocks/MAX_BLOCKS_IN_TRANSIT_PER_PEER}
    pub fn transport_window(&self)->usize{MAX_BLOCKS_IN_TRANSIT_PER_PEER}
    pub fn configured_high_watermark(&self)->f64{1.0}
    pub fn configured_low_watermark(&self)->f64{0.0}
    pub fn window(&self)->u64{MAX_BLOCKS_IN_TRANSIT_PER_PEER as u64}
    pub fn lookahead(&self)->u64{self.cfg.max_prospective_blocks as u64}
    pub fn current_pressure(&self)->f64{0.0}
    pub fn current_demand(&self)->f64{0.0}
    pub fn configured_max_validation_workers(&self)->usize{std::thread::available_parallelism().map(|n|n.get().saturating_sub(1).max(1)).unwrap_or(1)}
    pub fn snapshot(&self)->PipelineSnapshot{self.stats.snapshot()}
}
