//! Consensus-neutral multi-peer range scheduler.
//! Ranges are leases. Slow/dead peers can have their unfinished lease returned
//! to the scheduler and assigned to another peer.

use std::collections::{BTreeMap, HashMap};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct RangeId(pub u64);

#[derive(Debug, Clone, Copy)]
pub struct HeightRange {
    pub start: u64,
    pub end: u64, // inclusive
}

impl HeightRange {
    pub fn len(&self) -> u64 { self.end.saturating_sub(self.start) + 1 }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RangeState { Pending, Leased, Complete, Quarantined }

#[derive(Debug, Clone)]
pub struct RangeLease {
    pub id: RangeId,
    pub range: HeightRange,
    pub peer: String,
    pub state: RangeState,
    pub retries: u32,
}

#[derive(Debug, Default)]
pub struct RangeScheduler {
    next_id: u64,
    ranges: BTreeMap<RangeId, RangeLease>,
    peer_load: HashMap<String, usize>,
}

impl RangeScheduler {
    pub fn enqueue(&mut self, start: u64, end: u64) -> RangeId {
        let id = RangeId(self.next_id);
        self.next_id += 1;
        self.ranges.insert(id, RangeLease {
            id, range: HeightRange { start, end },
            peer: String::new(),
            state: RangeState::Pending,
            retries: 0,
        });
        id
    }

    pub fn claim(&mut self, peer: &str) -> Option<RangeLease> {
        self.claim_upto(peer, u64::MAX)
    }

    /// Claim the lowest pending range that this peer can actually serve
    /// (its whole range is at or below the height the peer advertised).
    /// Handing a range above a peer's own tip to that peer guarantees a
    /// timeout/notfound, burns a retry, and drops the connection.
    pub fn claim_upto(&mut self, peer: &str, max_end: u64) -> Option<RangeLease> {
        let id = self.ranges.iter()
            .find(|(_, r)| r.state == RangeState::Pending && r.range.end <= max_end)
            .map(|(id, _)| *id)?;
        let r = self.ranges.get_mut(&id)?;
        r.peer = peer.to_owned();
        r.state = RangeState::Leased;
        *self.peer_load.entry(peer.to_owned()).or_default() += 1;
        Some(r.clone())
    }

    pub fn complete(&mut self, id: RangeId) {
        if let Some(r) = self.ranges.get_mut(&id) {
            r.state = RangeState::Complete;
            if let Some(v) = self.peer_load.get_mut(&r.peer) { *v = v.saturating_sub(1); }
        }
        // Drop finished ranges. They used to stay in the map forever, so every
        // claim/lookup scanned tens of thousands of completed entries by the
        // time sync reached millions of heights. `state()` returns None for a
        // removed id, which callers treat as complete.
        self.ranges.remove(&id);
    }

    /// Requeues an unfinished lease. After repeated failures, quarantine it
    /// for diagnostic/duplicate-fetch handling rather than silently accepting it.
    pub fn release(&mut self, id: RangeId) {
        if let Some(r) = self.ranges.get_mut(&id) {
            if let Some(v) = self.peer_load.get_mut(&r.peer) { *v = v.saturating_sub(1); }
            r.retries += 1;
            r.peer.clear();
            r.state = if r.retries >= 3 {
                RangeState::Quarantined
            } else {
                RangeState::Pending
            };
        }
    }

    pub fn state(&self, id: RangeId) -> Option<RangeState> {
        self.ranges.get(&id).map(|r| r.state)
    }

    /// Find the range whose lease begins at `start`, if any. Used by the
    /// commit coordinator to look up "the range currently blocking
    /// `next_commit`" without needing to track its `RangeId` separately.
    pub fn id_at_start(&self, start: u64) -> Option<RangeId> {
        self.ranges.iter().find(|(_, r)| r.range.start == start).map(|(id, _)| *id)
    }

    /// Give a range another shot at being claimed, resetting its retry
    /// count. Unlike `release`, this always lands back on `Pending`, even if
    /// the range was previously `Quarantined`.
    ///
    /// Ranges can never be safely skipped -- every height must be committed
    /// in order for consensus -- so once the range blocking `next_commit`
    /// hits the retry limit in `release`, it must not be left `Quarantined`
    /// forever: nothing else in the pipeline knows how to unstick it, and
    /// every range validated behind it would otherwise buffer up
    /// unboundedly waiting for a commit that can never happen. Requeuing it
    /// is the safe failure mode: keep retrying (ideally against a different
    /// peer next time) rather than deadlocking the whole sync.
    pub fn requeue(&mut self, id: RangeId) {
        if let Some(r) = self.ranges.get_mut(&id) {
            r.retries = 0;
            r.peer.clear();
            r.state = RangeState::Pending;
        }
    }

    /// Number of heights still waiting to be fetched or currently being fetched.
    pub fn outstanding_heights(&self) -> u64 {
        self.ranges.values()
            .filter(|r| matches!(r.state, RangeState::Pending | RangeState::Leased))
            .map(|r| r.range.len())
            .sum()
    }

    pub fn pending_or_leased(&self) -> usize {
        self.ranges.values().filter(|r| matches!(r.state, RangeState::Pending | RangeState::Leased)).count()
    }
}
