//! Transport: peer bookkeeping and the streaming block downloader.
//!
//! The downloader owns one rule and nothing else: at most
//! [`MAX_BLOCKS_IN_TRANSIT_PER_PEER`] outstanding block requests per peer, with
//! a slot replenished the moment a block arrives rather than when a whole group
//! completes. It never declares a block valid and never chooses the canonical
//! chain.
//!
//! There are no ranges here. A range makes the slowest block in a group hold up
//! the other 47; streaming requests do not, which is the single biggest
//! throughput difference against the design it replaces.

use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use anyhow::{anyhow, Result};
use crate::peer_manager::PeerManager;
use ycash_state::state_service::SyncMetrics;
use ycash_state::State;

/// Outstanding block requests allowed per peer. Transport backpressure only:
/// changing it changes throughput and memory, never consensus acceptance.
pub const MAX_BLOCKS_IN_TRANSIT_PER_PEER: usize = 48;

/// Global ceiling on blocks claimed but not yet canonical. Resource bound.
pub const MAX_BLOCKS_IN_FLIGHT: usize = 192;

/// A peer that sends nothing for a requested block this long loses the claim,
/// so the hash can be requested from someone else. The block is not rejected:
/// a failed download never poisons a hash.
pub const REQUEST_TIMEOUT: Duration = Duration::from_secs(90);

/// A request for the exact next canonical block is retried much sooner than a
/// normal transport request. Later blocks may be buffered, but they cannot be
/// committed until this parent arrives, so head-of-line recovery is latency
/// critical and remains a transport-only policy.
pub const CANONICAL_PARENT_RETRY_TIMEOUT: Duration = Duration::from_secs(8);

/// One block the downloader has asked for, with the header-derived context its
/// semantic verification needs. Gathering this in bulk at assignment time keeps
/// the verifier threads off the database entirely.
#[derive(Clone, Debug)]
pub struct BlockRequest {
    pub height: u64,
    pub hash: [u8; 32],
    /// Cumulative chain work at this height, from the verified header chain.
    pub work: [u8; 32],
    /// Median time past, as consensus defines it for this height.
    pub median_time_past: u32,
}

/// Global claim registry: the same block hash is never in flight twice, and the
/// total number of claimed blocks stays bounded.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum LifecycleState {
    Transport,
    Verifying,
    Verified,
}

/// Global block lifecycle registry. A hash stays occupied from the first
/// transport claim until semantic verification has either rejected it or the
/// ordered state service has successfully published/discarded it. This is the
/// key invariant that prevents a fast downloader from re-requesting a block
/// while the verifier is still processing it.
pub struct InFlightRegistry {
    entries: Mutex<HashMap<[u8; 32], LifecycleState>>,
    capacity: usize,
    pub duplicates: AtomicU64,
}

impl InFlightRegistry {
    pub fn new(capacity: usize) -> Self {
        Self { entries: Mutex::new(HashMap::new()), capacity: capacity.max(1), duplicates: AtomicU64::new(0) }
    }

    pub fn len(&self) -> usize {
        self.entries.lock().map(|c| c.len()).unwrap_or(0)
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    pub fn spare_capacity(&self) -> usize {
        self.capacity.saturating_sub(self.len())
    }

    /// True for every non-terminal lifecycle state. A verified prospective
    /// block is deliberately still considered claimed until canonical state
    /// publishes or discards it.
    pub fn is_claimed(&self, hash: &[u8; 32]) -> bool {
        self.entries.lock().map(|c| c.contains_key(hash)).unwrap_or(false)
    }

    /// Claim a hash. Fails if it is already in any lifecycle state or the
    /// global bound is hit.
    pub fn claim(&self, hash: [u8; 32]) -> bool {
        let Ok(mut entries) = self.entries.lock() else { return false };
        if entries.len() >= self.capacity {
            return false;
        }
        if entries.contains_key(&hash) {
            self.duplicates.fetch_add(1, Ordering::Relaxed);
            return false;
        }
        entries.insert(hash, LifecycleState::Transport);
        true
    }

    /// Transition transport ownership to the verifier without freeing the
    /// global lifecycle slot.
    pub fn mark_verifying(&self, hash: &[u8; 32]) -> bool {
        let Ok(mut entries) = self.entries.lock() else { return false };
        match entries.get_mut(hash) {
            Some(state @ LifecycleState::Transport) => { *state = LifecycleState::Verifying; true }
            _ => false,
        }
    }

    /// Semantic verification succeeded. Keep the hash occupied while the
    /// ordered state gate holds it prospectively.
    pub fn mark_verified(&self, hash: &[u8; 32]) -> bool {
        let Ok(mut entries) = self.entries.lock() else { return false };
        match entries.get_mut(hash) {
            Some(state @ LifecycleState::Verifying) => { *state = LifecycleState::Verified; true }
            _ => false,
        }
    }

    /// Release a terminal lifecycle entry: semantic rejection, state-queue
    /// failure, contextual rejection, publication failure, or successful
    /// canonical publication.
    pub fn release(&self, hash: &[u8; 32]) {
        if let Ok(mut entries) = self.entries.lock() {
            entries.remove(hash);
        }
    }

    pub fn release_many(&self, hashes: &[[u8; 32]]) {
        if let Ok(mut entries) = self.entries.lock() {
            for hash in hashes { entries.remove(hash); }
        }
    }
}

/// Chooses which blocks to request next, from the verified header chain above
/// the canonical tip.
///
/// Header ancestry decides only what is *worth asking for*. The state service
/// remains the authority on validity, so a wrong guess here costs bandwidth and
/// nothing else.
pub struct BlockAssigner {
    state: Arc<State>,
    registry: Arc<InFlightRegistry>,
    metrics: Arc<SyncMetrics>,
    cursor: Mutex<u64>,
}

impl BlockAssigner {
    pub fn new(state: Arc<State>, registry: Arc<InFlightRegistry>, metrics: Arc<SyncMetrics>) -> Self {
        Self { state, registry, metrics, cursor: Mutex::new(0) }
    }

    /// Reset the scan position to just above the canonical tip. Called after a
    /// commit run or a reorganisation so skipped heights are revisited.
    pub fn rewind_to_canonical(&self) -> Result<()> {
        let tip = self.state.tip_height()?.unwrap_or(0);
        if let Ok(mut cursor) = self.cursor.lock() {
            *cursor = tip;
        }
        Ok(())
    }

    /// Claim up to `want` blocks for one peer, with their verification context
    /// read in bulk.
    pub fn assign(&self, want: usize) -> Result<Vec<BlockRequest>> {
        let want = want.min(self.registry.spare_capacity());
        if want == 0 {
            return Ok(Vec::new());
        }
        let canonical = self.state.tip_height()?.unwrap_or(0);
        let header_tip = self.state.header_height()?.unwrap_or(0);
        self.metrics.raise_header_height(header_tip);
        if header_tip <= canonical {
            return Ok(Vec::new());
        }

        // Always try the exact next canonical block first. The forward cursor
        // may already be hundreds of blocks ahead because those blocks were
        // successfully buffered; that must never starve the one block needed
        // to advance canonical state.
        let next_height = canonical.saturating_add(1);
        let head_already_buffered = self.metrics.missing_parent.lock()
            .map(|m| m.height == next_height && m.candidate_present)
            .unwrap_or(false);
        if !head_already_buffered {
            if let Some(raw_hash) = self.state.header_hash_by_height(next_height)? {
                let hash = hash32(raw_hash, "header hash")?;
                if self.registry.is_claimed(&hash) {
                    self.metrics.set_missing_parent_in_flight(true);
                } else if let Some(request) = self.request_at_height(next_height)? {
                    if self.registry.claim(request.hash) {
                        self.metrics.set_missing_parent_in_flight(false);
                        let mut out = Vec::with_capacity(want);
                        out.push(request);
                        if out.len() < want {
                            out.extend(self.assign_forward(want - out.len(), canonical, header_tip)?);
                        }
                        return Ok(out);
                    }
                    self.metrics.set_missing_parent_in_flight(true);
                }
            }
        }

        self.assign_forward(want, canonical, header_tip)
    }

    fn request_at_height(&self, height: u64) -> Result<Option<BlockRequest>> {
        let Some(hash) = self.state.header_hash_by_height(height)? else { return Ok(None) };
        let Some(work) = self.state.header_work_by_height(height)? else { return Ok(None) };
        let mtp = median_time_past_range(&self.state, height, height)?
            .get(&height).copied().unwrap_or(0);
        Ok(Some(BlockRequest { height, hash: hash32(hash, "header hash")?, work: hash32(work, "chain work")?, median_time_past: mtp }))
    }

    fn assign_forward(&self, want: usize, canonical: u64, header_tip: u64) -> Result<Vec<BlockRequest>> {
        let mut cursor = {
            let Ok(mut c) = self.cursor.lock() else { return Ok(Vec::new()) };
            if *c < canonical {
                *c = canonical;
            }
            *c
        };

        // Scan a bounded window so a run of already-claimed heights cannot make
        // this loop unbounded.
        let start = cursor + 1;
        let end = (start + (MAX_BLOCKS_IN_FLIGHT as u64) * 2).min(header_tip);
        if start > end {
            // Everything in the window is claimed; wait for it to drain.
            return Ok(Vec::new());
        }

        let hashes = self.state.header_hashes_range(start, end)?;
        let works = self.state.header_works_range(start, end)?;
        let mtps = median_time_past_range(&self.state, start, end)?;

        let mut out = Vec::with_capacity(want);
        for height in start..=end {
            if out.len() >= want {
                break;
            }
            let (Some(hash), Some(work)) = (hashes.get(&height).copied(), works.get(&height).copied()) else {
                break;
            };
            cursor = height;
            if !self.registry.claim(hash) {
                continue;
            }
            out.push(BlockRequest {
                height,
                hash,
                work,
                median_time_past: mtps.get(&height).copied().unwrap_or(0),
            });
        }
        if let Ok(mut c) = self.cursor.lock() {
            if cursor > *c {
                *c = cursor;
            }
        }
        Ok(out)
    }

    pub fn canonical_height(&self) -> Result<u64> {
        Ok(self.state.tip_height()?.unwrap_or(0))
    }

    pub fn header_hash(&self, height: u64) -> Result<Option<[u8; 32]>> {
        Ok(self.state.header_hash_by_height(height)?.and_then(|raw| hash32(raw, "header hash").ok()))
    }
}

fn hash32(raw: Vec<u8>, what: &str) -> Result<[u8; 32]> {
    if raw.len() != 32 {
        return Err(anyhow!("{what} has invalid length {}", raw.len()));
    }
    let mut out = [0u8; 32];
    out.copy_from_slice(&raw);
    Ok(out)
}

/// Median time past for every height in `start..=end`, from one range read.
///
/// This is the same quantity the consensus layer expects; computing it in bulk
/// here is a database-access optimisation, not a rule change.
pub fn median_time_past_range(state: &State, start: u64, end: u64) -> Result<HashMap<u64, u32>> {
    let from = start.saturating_sub(11).max(1);
    let times: HashMap<u64, u32> = state.header_times_range(from, end)?.into_iter().collect();
    let mut out = HashMap::new();
    for height in start..=end {
        let floor = height.saturating_sub(11);
        let mut window = Vec::with_capacity(11);
        if floor == 0 && height > 0 {
            window.push(ycash_consensus::GENESIS_TIME);
        }
        for h in floor.max(1)..height {
            if let Some(t) = times.get(&h) {
                window.push(*t);
            }
        }
        let median = if window.is_empty() {
            0
        } else {
            window.sort_unstable();
            window[window.len() / 2]
        };
        out.insert(height, median);
    }
    Ok(out)
}

/// One peer's outstanding requests.
pub struct PeerDownloadSession {
    peer: String,
    assigner: Arc<BlockAssigner>,
    registry: Arc<InFlightRegistry>,
    peers: Arc<PeerManager>,
    metrics: Arc<SyncMetrics>,
    in_flight: HashMap<[u8; 32], (BlockRequest, Instant)>,
    limit: usize,
}

impl PeerDownloadSession {
    pub fn new(
        peer: impl Into<String>,
        assigner: Arc<BlockAssigner>,
        registry: Arc<InFlightRegistry>,
        peers: Arc<PeerManager>,
        metrics: Arc<SyncMetrics>,
    ) -> Self {
        let peer = peer.into();
        peers.connected(&peer);
        Self {
            peer,
            assigner,
            registry,
            peers,
            metrics,
            in_flight: HashMap::new(),
            limit: MAX_BLOCKS_IN_TRANSIT_PER_PEER,
        }
    }

    /// Override the per-peer transport limit. Provided so the same chain can be
    /// synchronised at 16, 48 or 64 blocks per peer and compared: consensus
    /// results must be identical.
    pub fn with_limit(mut self, limit: usize) -> Self {
        self.limit = limit.clamp(1, MAX_BLOCKS_IN_TRANSIT_PER_PEER);
        self
    }

    pub fn peer(&self) -> &str {
        &self.peer
    }

    pub fn in_flight(&self) -> usize {
        self.in_flight.len()
    }

    /// Fill the peer's request window back up to the limit. Returns the hashes
    /// to put in a `getdata`, which is empty when the window is full, the global
    /// bound is reached, or the header chain has nothing further to offer.
    pub fn top_up(&mut self) -> Result<Vec<[u8; 32]>> {
        debug_assert!(self.in_flight.len() <= self.limit);
        let free = self.limit.saturating_sub(self.in_flight.len());
        if free == 0 {
            return Ok(Vec::new());
        }
        let assigned = self.assigner.assign(free)?;
        let mut hashes = Vec::with_capacity(assigned.len());
        let now = Instant::now();
        let canonical = self.assigner.canonical_height().unwrap_or(0);
        for request in assigned {
            if request.height == canonical.saturating_add(1) {
                self.metrics.trace_head(
                    self.peer.clone(),
                    "CLAIMED",
                    request.height,
                    Some(request.hash),
                    "canonical_height + 1 assigned to this peer",
                );
                self.metrics.set_missing_parent_in_flight(true);
            }
            hashes.push(request.hash);
            self.metrics.raise_download_height(request.height);
            self.in_flight.insert(request.hash, (request, now));
        }
        if !hashes.is_empty() {
            let count = hashes.len() as u64;
            self.peers.update(&self.peer, |s| {
                s.in_flight = self.in_flight.len();
                s.requested = s.requested.saturating_add(count);
            });
            self.metrics
                .blocks_in_flight_total
                .store(self.peers.total_in_flight() as u64, Ordering::Relaxed);
        }
        Ok(hashes)
    }

    /// A block arrived. Frees exactly one slot, immediately: the caller tops up
    /// again without waiting for the other 47.
    pub fn on_block(&mut self, hash: &[u8; 32], bytes: usize) -> Option<BlockRequest> {
        let (request, _) = self.in_flight.remove(hash)?;
        // The transport slot is free, but the global lifecycle slot is not:
        // keep ownership until semantic verification and ordered publication
        // finish. This prevents immediate duplicate getdata for a block that
        // is still inside the verifier.
        if !self.registry.mark_verifying(hash) {
            return None;
        }
        self.peers.update(&self.peer, |s| {
            s.in_flight = self.in_flight.len();
            s.received = s.received.saturating_add(1);
        });
        self.metrics.blocks_downloaded.fetch_add(1, Ordering::Relaxed);
        self.metrics.last_received_height.fetch_max(request.height, Ordering::Relaxed);
        if self.assigner.canonical_height().map(|h| request.height == h.saturating_add(1)).unwrap_or(false) {
            self.metrics.trace_head(
                self.peer.clone(),
                "ARRIVED",
                request.height,
                Some(request.hash),
                format!("block bytes={bytes}; request claim released; queued for semantic verification"),
            );
            // Keep the head marked in-flight: the transport slot is free, but
            // semantic verification now owns the lifecycle and must finish
            // before another peer can claim the same hash.
            self.metrics.set_missing_parent_in_flight(true);
        }
        self.metrics.bytes_downloaded.fetch_add(bytes as u64, Ordering::Relaxed);
        self.metrics
            .blocks_in_flight_total
            .store(self.peers.total_in_flight() as u64, Ordering::Relaxed);
        Some(request)
    }

    /// Retry the exact block immediately following the canonical tip.
    ///
    /// Only the session currently holding that request can release it. The
    /// next peer that asks for work will see the canonical height again because
    /// the assigner always prioritises tip+1 before its normal forward cursor.
    /// This prevents one slow peer from holding the entire ordered pipeline
    /// behind a 90-second timeout.
    pub fn retry_canonical_parent(&mut self, timeout: Duration) -> Result<bool> {
        let canonical = self.assigner.canonical_height()?;
        let next_height = canonical.saturating_add(1);
        let Some(hash) = self.assigner.header_hash(next_height)? else {
            return Ok(false);
        };
        let Some((_, sent)) = self.in_flight.get(&hash) else {
            return Ok(false);
        };
        if sent.elapsed() <= timeout {
            return Ok(false);
        }

        self.in_flight.remove(&hash);
        self.registry.release(&hash);
        self.peers.update(&self.peer, |s| {
            s.in_flight = self.in_flight.len();
            s.timeouts = s.timeouts.saturating_add(1);
        });
        self.metrics.set_missing_parent_in_flight(false);
        self.metrics.trace_head(
            self.peer.clone(),
            "RETRY_TIMEOUT",
            next_height,
            Some(hash),
            format!("head request exceeded {}s; claim released for another peer", timeout.as_secs()),
        );
        self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
        self.metrics.expired_requests.fetch_add(1, Ordering::Relaxed);
        self.metrics.parent_retry_height.store(next_height, Ordering::Relaxed);
        self.metrics.parent_retry_unix_ms.store(
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_millis() as u64)
                .unwrap_or(0),
            Ordering::Relaxed,
        );
        self.metrics.mark_parent_retry();
        let _ = self.assigner.rewind_to_canonical();
        Ok(true)
    }

    /// Drop claims this peer has not delivered in time, so another peer can
    /// fetch them.
    pub fn expire_stale(&mut self, timeout: Duration) -> usize {
        let now = Instant::now();
        let stale: Vec<[u8; 32]> = self
            .in_flight
            .iter()
            .filter(|(_, (_, sent))| now.duration_since(*sent) > timeout)
            .map(|(hash, _)| *hash)
            .collect();
        let canonical = self.assigner.canonical_height().unwrap_or(0);
        let next_height = canonical.saturating_add(1);
        for hash in &stale {
            if let Some((request, sent)) = self.in_flight.get(hash) {
                if request.height == next_height {
                    self.metrics.set_missing_parent_in_flight(false);
                    self.metrics.trace_head(
                        self.peer.clone(),
                        "RETRY_STALE",
                        request.height,
                        Some(*hash),
                        format!("normal request timeout after {}s", sent.elapsed().as_secs()),
                    );
                }
            }
            self.in_flight.remove(hash);
            self.registry.release(hash);
        }
        if !stale.is_empty() {
            let count = stale.len() as u64;
            self.peers.update(&self.peer, |s| {
                s.in_flight = self.in_flight.len();
                s.timeouts = s.timeouts.saturating_add(count);
            });
            self.metrics.expired_requests.fetch_add(count, Ordering::Relaxed);
            let _ = self.assigner.rewind_to_canonical();
        }
        stale.len()
    }

    /// Release exactly one requested hash, used for a peer's `notfound` reply.
    /// Older code expired the entire peer window on one `notfound`, causing
    /// unrelated requests to churn and making head-of-line recovery harder to trace.
    pub fn release_hash(&mut self, hash: &[u8; 32], reason: &str) -> bool {
        let Some((request, _)) = self.in_flight.remove(hash) else { return false };
        self.registry.release(hash);
        let canonical = self.assigner.canonical_height().unwrap_or(0);
        if request.height == canonical.saturating_add(1) {
            self.metrics.trace_head(
                self.peer.clone(),
                "NOTFOUND",
                request.height,
                Some(*hash),
                reason,
            );
            self.metrics.set_missing_parent_in_flight(false);
            self.metrics.parent_retries.fetch_add(1, Ordering::Relaxed);
            self.metrics.parent_retry_height.store(request.height, Ordering::Relaxed);
            self.metrics.mark_parent_retry();
            let _ = self.assigner.rewind_to_canonical();
        }
        self.peers.update(&self.peer, |s| s.in_flight = self.in_flight.len());
        self.metrics.blocks_in_flight_total.store(self.peers.total_in_flight() as u64, Ordering::Relaxed);
        true
    }

    /// Give up every claim, e.g. when the connection ends.
    pub fn release_all(&mut self) {
        let canonical = self.assigner.canonical_height().unwrap_or(0);
        let next_height = canonical.saturating_add(1);
        for (hash, (request, _)) in self.in_flight.iter() {
            if request.height == next_height {
                self.metrics.trace_head(
                    self.peer.clone(),
                    "DISCONNECT_RELEASE",
                    request.height,
                    Some(*hash),
                    "peer session ended while canonical head request was outstanding",
                );
                self.metrics.set_missing_parent_in_flight(false);
            }
            self.registry.release(hash);
        }
        self.in_flight.clear();
        self.peers.disconnected(&self.peer);
        self.metrics
            .blocks_in_flight_total
            .store(self.peers.total_in_flight() as u64, Ordering::Relaxed);
        let _ = self.assigner.rewind_to_canonical();
    }
}

impl Drop for PeerDownloadSession {
    fn drop(&mut self) {
        self.release_all();
    }
}

pub fn not_requested(hash: &[u8; 32]) -> anyhow::Error {
    anyhow!("peer sent a block that was not requested: {}", hex_hash(hash))
}

pub fn hex_hash(hash: &[u8; 32]) -> String {
    let mut s = String::with_capacity(64);
    for b in hash.iter().rev() {
        s.push_str(&format!("{b:02x}"));
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn lifecycle_claim_is_held_through_verification_until_terminal_release() {
        let registry = InFlightRegistry::new(2);
        let hash = [9u8; 32];
        assert!(registry.claim(hash));
        assert!(!registry.claim(hash));
        assert!(registry.mark_verifying(&hash));
        assert!(!registry.claim(hash));
        assert!(registry.mark_verified(&hash));
        assert!(!registry.claim(hash));
        registry.release(&hash);
        assert!(registry.claim(hash));
    }

    #[test]
    fn the_registry_refuses_a_second_claim_on_one_hash() {
        let registry = InFlightRegistry::new(8);
        assert!(registry.claim([7u8; 32]));
        assert!(!registry.claim([7u8; 32]));
        registry.release(&[7u8; 32]);
        assert!(registry.claim([7u8; 32]));
    }

    #[test]
    fn the_registry_enforces_the_global_bound() {
        let registry = InFlightRegistry::new(2);
        assert!(registry.claim([1u8; 32]));
        assert!(registry.claim([2u8; 32]));
        assert!(!registry.claim([3u8; 32]));
        assert_eq!(registry.spare_capacity(), 0);
        registry.release(&[1u8; 32]);
        assert!(registry.claim([3u8; 32]));
    }

    #[test]
    fn the_per_peer_window_never_exceeds_the_transport_limit() {
        assert_eq!(MAX_BLOCKS_IN_TRANSIT_PER_PEER, 48);
        assert!(MAX_BLOCKS_IN_FLIGHT >= MAX_BLOCKS_IN_TRANSIT_PER_PEER);
    }
}
