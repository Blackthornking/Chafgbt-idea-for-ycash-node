//! Wires the v0.23 concurrent multi-peer block pipeline (`ycash_state::pipeline`,
//! the same engine `crates/node` already uses) into the Android node's
//! outbound peer connections.
//!
//! Header sync stays owned by a single peer at a time (`sync_owner` in
//! `main.rs`) -- the header chain is one canonical, strictly ordered stream,
//! and that part of the design was already correct. The gap was on the block
//! side: `download_blocks()` only ran after `sync_headers()` fully returned,
//! on the *same* single connection, even though `peer_supervisor` already
//! keeps up to 12 other peers connected and idle in their ping/keepalive
//! loop the whole time.
//!
//! This module lets every connected peer -- not just the header owner --
//! claim and validate a disjoint height range the moment headers exist ahead
//! of the local block tip, in parallel with the header owner's ongoing
//! header sync. A single coordinator (guarded by the same mutex as the
//! scheduler) still applies commits to `State` strictly in height order, so
//! out-of-order validation across peers can never produce an out-of-order
//! canonical chain -- matching the safety invariant in
//! `V0.23_CONCURRENT_PIPELINE.md`.

use std::collections::BTreeMap;
use std::io::ErrorKind;
use std::net::TcpStream;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use ycash_chain::{genesis_hash_internal, txid};
use ycash_consensus::{validate_for_commit_opts, Context, UNSUPPORTED_PREFIX};
use ycash_network::runtime::{getdata_payload, unix_time};
use ycash_state::pipeline::{range_scheduler::RangeLease, AdaptiveConfig, PipelineEngine};
use ycash_state::{BlockCommit, State};

use crate::runtime::SharedState;
use crate::{is_timeout, mtp, read_message, send};

/// Assume-valid checkpoint: the last mainnet entry in `checkpointData`
/// (ycash 4.5.0 `src/chainparams.cpp`). Like ycashd with checkpoints enabled
/// (its default), blocks at or below it skip transparent script checks and
/// Sprout Groth16 proofs; PoW, merkle, coinbase, UTXO/value accounting,
/// anchors, nullifiers, joinSplitSig and Sapling proofs are still verified.
/// It only activates when our PoW-verified header at that height matches.
/// Set YCASH_FULL_VERIFY=1 to verify every script from genesis.
pub const ASSUME_VALID_HEIGHT: u64 = 2_250_000;
pub const ASSUME_VALID_HASH_DISPLAY: &str = "000003f98b7497fdcd8a6b6d10a93a887c5d47127e24a9dc3a40cb65754d21e7";

fn assume_valid_active(state: &State) -> bool {
    if std::env::var("YCASH_FULL_VERIFY").ok().as_deref() == Some("1") { return false; }
    if ASSUME_VALID_HEIGHT == 0 || ASSUME_VALID_HASH_DISPLAY.len() != 64 { return false; }
    let Ok(bytes) = hex::decode(ASSUME_VALID_HASH_DISPLAY) else { return false };
    let mut internal = [0u8; 32];
    for i in 0..32 { internal[i] = bytes[31 - i]; }
    matches!(state.header_hash_by_height(ASSUME_VALID_HEIGHT), Ok(Some(v)) if v.as_slice() == internal)
}

/// Error kind used for "this node can't validate this block yet". Not the
/// peer's fault: don't release/retry the range and don't drop the connection.
pub fn is_node_unsupported(e: &std::io::Error) -> bool {
    e.kind() == ErrorKind::Unsupported
}

/// Pipeline diagnostics are intentionally plain stderr so they are visible in
/// Android/logcat builds without requiring a tracing dependency in this crate.
/// Every line starts with [PIPELINE] and includes a stage/range where possible.
fn pipeline_log(stage: &str, detail: impl std::fmt::Display) {
    eprintln!("[PIPELINE] stage={} {}", stage, detail);
}

/// Cloneable handle shared across every peer connection so height ranges are
/// claimed exactly once and committed exactly once, in order.
#[derive(Clone)]
pub struct BlockPipeline {
    inner: Arc<Mutex<Inner>>,
    /// Serialises the ordered commit path. The DB write used to run while
    /// holding `inner`, so every peer trying to claim, release or buffer a
    /// range sat blocked for the whole SQLite commit. Now only threads that
    /// finished a range wait here; claiming keeps flowing.
    commit_lock: Arc<Mutex<()>>,
}

struct Inner {
    engine: PipelineEngine,
    /// Next height the coordinator is waiting to commit, in strict order.
    next_commit: u64,
    /// Validated-but-not-yet-committed ranges, keyed by their start height,
    /// so a later range that finishes first can wait for an earlier one.
    buffered: BTreeMap<u64, (RangeLease, Vec<BlockCommit>, u64)>,
    /// High-water mark already handed to the scheduler, so we don't
    /// re-enqueue the same heights every time a peer calls `ensure_planned`.
    planned_up_to: u64,
    /// Set when the head-of-line range needs a validation backend this node
    /// doesn't have. Sync stops there instead of cycling through peers.
    halted: Option<String>,
}

impl BlockPipeline {
    /// `next_commit` should be the current validated block tip + 1.
    pub fn new(next_commit: u64) -> Self {
        pipeline_log("INIT", format_args!(
            "next_commit={} assume_valid_height={} full_verify={}",
            next_commit, ASSUME_VALID_HEIGHT,
            std::env::var("YCASH_FULL_VERIFY").ok().as_deref() == Some("1")
        ));
        Self {
            inner: Arc::new(Mutex::new(Inner {
                engine: PipelineEngine::new(AdaptiveConfig::default()),
                next_commit,
                buffered: BTreeMap::new(),
                planned_up_to: next_commit.saturating_sub(1),
                halted: None,
            })),
            commit_lock: Arc::new(Mutex::new(())),
        }
    }

    /// Make sure claimable ranges exist up to `chain_tip` (normally
    /// `headers_height`). Cheap to call repeatedly -- it only enqueues new
    /// ranges past whatever was already planned.
    pub fn ensure_planned(&self, chain_tip: u64, workers: usize) {
        let mut g = self.inner.lock().unwrap();
        if workers != 1 {
            pipeline_log("CONFIG_MISMATCH", format_args!(
                "ensure_planned received workers={} (STRICT sequential mode expects 1); chain_tip={} next_commit={} planned_up_to={}",
                workers, chain_tip, g.next_commit, g.planned_up_to
            ));
        }

        // A range that hit the retry limit is marked `Quarantined`, which
        // `claim()` never picks up again. Since every height must commit in
        // order, that permanently wedges `next_commit` at this range and
        // every range validated behind it -- however many peers keep
        // finishing further-ahead work -- just accumulates in `buffered`
        // forever. Give the head-of-line range another shot each time we're
        // asked to plan more work, rather than deadlocking sync on it.
        //
        // `g` is a `MutexGuard`, so `g.engine.method(g.next_commit)` forces
        // two separate `DerefMut`/`Deref` calls through the guard for the
        // receiver and the argument -- the borrow checker can't see those as
        // disjoint field accesses the way it would for a plain struct, and
        // rejects it (E0502). Reading the field into a local first sidesteps
        // that: only one deref of `g` is live at a time.
        let next_commit = g.next_commit;
        g.engine.requeue_if_quarantined_at(next_commit);

        if chain_tip <= g.planned_up_to {
            return;
        }

        // Backpressure: cap how far ahead of the last *committed* height we
        // let the scheduler plan. Without this, a single slow/stuck range
        // near `next_commit` doesn't slow anything down -- the other
        // workers keep claiming and validating further-ahead ranges as fast
        // as headers arrive, and all of that piles up in `buffered` with
        // nowhere to go until the stuck range finally clears. Capping the
        // lookahead means workers idle (in_flight -> 0) instead of the
        // validated-but-uncommitted queue growing without bound.
        let max_lookahead = g.engine.window().max(1);
        if g.planned_up_to.saturating_sub(g.next_commit) > max_lookahead {
            pipeline_log("LOOKAHEAD", format_args!(
                "unexpected planned distance={} window={} next_commit={} planned_up_to={}",
                g.planned_up_to.saturating_sub(g.next_commit), max_lookahead, g.next_commit, g.planned_up_to
            ));
        }
        if g.planned_up_to.saturating_sub(g.next_commit) >= max_lookahead {
            return;
        }

        let next = g.next_commit.max(g.planned_up_to.saturating_add(1));
        if next <= chain_tip {
            pipeline_log("PLAN", format_args!(
                "request next={} chain_tip={} workers={} window={}",
                next, chain_tip, workers, g.engine.window()
            ));
            let ids = g.engine.plan_parallel_ranges(next, chain_tip, workers.max(1));
            let snap = g.engine.snapshot();
            pipeline_log("PLAN_RESULT", format_args!(
                "ranges={} next={} planned_end_candidate={} window={} workers={} in_flight={}",
                ids.len(), next,
                next.saturating_add(snap.window.saturating_sub(1)).min(chain_tip),
                snap.window, snap.workers, g.engine.outstanding_heights()
            ));
            // `plan_parallel_ranges` only plans one adaptive window.  The old
            // code advanced `planned_up_to` all the way to `chain_tip`, even
            // when only the first window was actually enqueued. That made a
            // header tip look fully planned after scheduling only the first
            // window, so subsequent calls skipped the remaining heights.
            // Track the end of the window that was really enqueued instead.
            g.planned_up_to = next
                .saturating_add(snap.window.saturating_sub(1))
                .min(chain_tip);
        }
    }

    /// Try to claim one pending range for `peer_label` and, if one is
    /// available, fetch + validate it over `stream` and fold it into the
    /// commit path. Returns `Ok(true)` if a range was processed, `Ok(false)`
    /// if nothing was available to claim right now.
    pub fn run_once(
        &self,
        stream: &mut TcpStream,
        state: &Arc<State>,
        live: &SharedState,
        peer_label: &str,
        peer_height: Option<u64>,
    ) -> std::io::Result<bool> {
        // Only hand this peer work it can actually serve. A peer still
        // syncing (or on a stale tip) answers getdata above its height with
        // `notfound` or silence -- the range then times out, burns a retry,
        // the connection is dropped, and after three of those the range is
        // quarantined. That was the stop/start pattern.
        let max_end = peer_height.unwrap_or(u64::MAX);
        let lease = {
            let mut g = self.inner.lock().unwrap();
            if let Some(reason) = g.halted.clone() {
                drop(g);
                live.write().unwrap().message = reason;
                return Ok(false);
            }
            g.engine.claim_upto(peer_label, max_end)
        };
        let Some(lease) = lease else { return Ok(false) };

        pipeline_log("CLAIM", format_args!(
            "peer={} range={}..{} generation={} next_commit={} peer_height={:?}",
            peer_label, lease.range.start, lease.range.end, lease.generation,
            self.inner.lock().unwrap().next_commit, peer_height
        ));

        {
            // blocks_in_flight/current_window are already tracked by the
            // engine itself (set in plan_parallel_ranges, decremented in
            // complete()) -- just mirror its snapshot rather than keeping a
            // second counter here.
            let (snap, outstanding) = { let g = self.inner.lock().unwrap(); (g.engine.snapshot(), g.engine.outstanding_heights()) };
            let mut st = live.write().unwrap();
            st.blocks_in_flight = outstanding;
            st.active_block_workers = snap.workers;
            st.current_window = snap.window;
            st.completed_ranges = snap.completed_ranges;
            st.retried_ranges = snap.retried_ranges;
            st.quarantined_ranges = snap.quarantined_ranges;
            st.message = format!(
                "{} claimed heights {}..{}",
                peer_label, lease.range.start, lease.range.end
            );
        }

        pipeline_log("FETCH_START", format_args!(
            "peer={} range={}..{} count={}",
            peer_label, lease.range.start, lease.range.end, lease.range.end.saturating_sub(lease.range.start)+1
        ));
        match fetch_and_validate(stream, state, &lease) {
            Ok((blocks, bytes)) => {
                pipeline_log("VALIDATED_RANGE", format_args!(
                    "peer={} range={}..{} blocks={} bytes={}",
                    peer_label, lease.range.start, lease.range.end, blocks.len(), bytes
                ));
                self.complete(lease, blocks, bytes, state, live);
                Ok(true)
            }
            Err(e) if is_node_unsupported(&e) => {
                // Deterministic: every peer would fail identically. Halt the
                // pipeline, keep the peer, don't count a retry.
                pipeline_log("UNSUPPORTED", format_args!(
                    "peer={} range={}..{} error={:?}",
                    peer_label, lease.range.start, lease.range.end, e
                ));
                let reason = format!("block sync halted: {}", e);
                {
                    let mut g = self.inner.lock().unwrap();
                    g.engine.requeue_lease(lease.id);
                    g.halted = Some(reason.clone());
                }
                let mut st = live.write().unwrap();
                st.last_error = reason.clone();
                st.message = reason;
                Ok(false)
            }
            Err(e) => {
                pipeline_log("RANGE_ERROR", format_args!(
                    "peer={} range={}..{} kind={:?} error={}",
                    peer_label, lease.range.start, lease.range.end, e.kind(), e
                ));
                let (snap, outstanding) = {
                    let mut g = self.inner.lock().unwrap();
                    g.engine.release(lease.id);
                    // If the range we just gave up on is the one blocking
                    // commits, make it claimable again right away instead of
                    // waiting for the next planning call.
                    let nc = g.next_commit;
                    g.engine.requeue_if_quarantined_at(nc);
                    (g.engine.snapshot(), g.engine.outstanding_heights())
                };
                // Mirror immediately: a range going to retry/quarantine here
                // (peer timed out or sent bad data) is exactly the signal
                // that should show up on the dashboard even if no range
                // completes again for a while.
                let mut st = live.write().unwrap();
                st.blocks_in_flight = outstanding;
                st.active_block_workers = snap.workers;
                st.current_window = snap.window;
                st.completed_ranges = snap.completed_ranges;
                st.retried_ranges = snap.retried_ranges;
                st.quarantined_ranges = snap.quarantined_ranges;
                Err(e)
            }
        }
    }

    fn complete(
        &self,
        lease: RangeLease,
        blocks: Vec<BlockCommit>,
        bytes: u64,
        state: &Arc<State>,
        live: &SharedState,
    ) {
        {
            let mut g = self.inner.lock().unwrap();
            // Capture the range before moving `lease` into the buffered item.
            // RangeLease is not Copy, so logging its fields after the insert
            // causes E0382 (borrow of moved value). Keeping the scalar range
            // values also makes the diagnostic log independent of ownership.
            let range_start = lease.range.start;
            let range_end = lease.range.end;
            g.buffered.insert(range_start, (lease, blocks, bytes));
            let (q, out) = (g.buffered.len() as u64, g.engine.outstanding_heights());
            pipeline_log("BUFFER", format_args!(
                "range={}..{} buffered_ranges={} in_flight={} next_commit={}",
                range_start, range_end, q, out, g.next_commit
            ));
            drop(g);
            let mut st = live.write().unwrap();
            st.validation_queue = q;
            st.blocks_in_flight = out;
        }
        // One committer at a time keeps commits strictly in height order.
        // Whoever holds this drains every buffered range that is contiguous
        // with next_commit, including ones other threads buffered meanwhile.
        let _commit = self.commit_lock.lock().unwrap();
        loop {
            let item = {
                let mut g = self.inner.lock().unwrap();
                match g.buffered.keys().next().copied() {
                    Some(k) if k == g.next_commit => g.buffered.remove(&k),
                    _ => None,
                }
            };
            let Some((lease, blocks, bytes)) = item else { break };

            // DB write happens with NO pipeline lock held.
            pipeline_log("COMMIT_START", format_args!(
                "range={}..{} blocks={} expected_next_commit={}",
                lease.range.start, lease.range.end, blocks.len(), lease.range.start
            ));
            let started = Instant::now();
            if let Err(e) = state.commit_blocks_batch(&blocks) {
                // These blocks already matched our PoW-verified headers, so a
                // consensus failure here is deterministic -- refetching from
                // another peer gives the same bytes. Halt with the reason
                // instead of cycling the range through every peer.
                pipeline_log("COMMIT_ERROR", format_args!(
                    "range={}..{} error={}",
                    lease.range.start, lease.range.end, e
                ));
                let reason = format!(
                    "block sync halted: commit {}..{} failed: {}",
                    lease.range.start, lease.range.end, e
                );
                {
                    let mut g = self.inner.lock().unwrap();
                    g.engine.requeue_lease(lease.id);
                    g.halted = Some(reason.clone());
                }
                let mut st = live.write().unwrap();
                st.last_error = reason.clone();
                st.message = reason;
                break;
            }
            let commit_ms = started.elapsed().as_millis() as u64;
            pipeline_log("COMMIT_OK", format_args!(
                "range={}..{} commit_ms={} blocks={}",
                lease.range.start, lease.range.end, commit_ms, blocks.len()
            ));

            let (snap, queue, outstanding) = {
                let mut g = self.inner.lock().unwrap();
                g.engine.complete(lease.id, blocks.len() as u64, bytes);
                g.next_commit = lease.range.end + 1;
                (g.engine.snapshot(), g.buffered.len() as u64, g.engine.outstanding_heights())
            };
            let Some(last) = blocks.last() else { continue };
            let tip_time = state.header_time(last.height).ok().flatten().unwrap_or(0);
            let mut st = live.write().unwrap();
            st.local_height = last.height;
            st.tip_time = tip_time;
            st.blocks_received = st.blocks_received.saturating_add(blocks.len() as u64);
            st.blocks_validated = st.blocks_validated.saturating_add(blocks.len() as u64);
            st.block_bytes_received = st.block_bytes_received.saturating_add(bytes);
            st.db_commits = st.db_commits.saturating_add(1);
            st.db_commit_ms_total = st.db_commit_ms_total.saturating_add(commit_ms);
            st.txs_indexed = st
                .txs_indexed
                .saturating_add(blocks.iter().map(|b| b.txs.len() as u64).sum());
            st.blocks_in_flight = outstanding;
            st.batch_size = blocks.len() as u64;
            st.validation_queue = queue;
            st.active_block_workers = snap.workers;
            st.current_window = snap.window;
            st.completed_ranges = snap.completed_ranges;
            st.retried_ranges = snap.retried_ranges;
            st.quarantined_ranges = snap.quarantined_ranges;
            st.last_commit_unix = unix_time();
            st.message = format!(
                "committed heights {}..{} ({} concurrent workers)",
                lease.range.start, lease.range.end, snap.workers
            );
        }
    }
}

/// Block hash straight from the raw block bytes: sha256d over the 140-byte
/// fixed header, the solution length and the solution. Same bytes
/// `BlockHeader::serialize()` produces, without decoding the whole block.
fn raw_block_hash(raw: &[u8]) -> Option<[u8; 32]> {
    use sha2::{Digest, Sha256};
    let mut i = 140usize;
    let sol_len = ycash_network::runtime::read_compact_size(raw, &mut i).ok()? as usize;
    let end = i.checked_add(sol_len)?;
    let header = raw.get(..end)?;
    let a = Sha256::digest(header);
    let b = Sha256::digest(a);
    let mut out = [0u8; 32];
    out.copy_from_slice(&b);
    Some(out)
}

fn fetch_and_validate(
    stream: &mut TcpStream,
    state: &Arc<State>,
    lease: &RangeLease,
) -> std::io::Result<(Vec<BlockCommit>, u64)> {
    // One query for the whole range instead of one locked lookup + full
    // header decode + rehash per height.
    let mut requests = Vec::new();
    {
        pipeline_log("HEADER_LOOKUP", format_args!(
            "range={}..{}",
            lease.range.start, lease.range.end
        ));
        let hashes = state
            .header_hashes_range(lease.range.start, lease.range.end)
            .map_err(|e| ioe(&e.to_string()))?;
        for h in lease.range.start..=lease.range.end {
            let hash = hashes
                .get(&h)
                .copied()
                .ok_or_else(|| ioe("missing header for claimed range"))?;
            requests.push((h, hash));
        }
    }
    let by_hash: std::collections::HashMap<[u8; 32], u64> =
        requests.iter().map(|(h, hash)| (*hash, *h)).collect();
    let hashes: Vec<[u8; 32]> = requests.iter().map(|(_, h)| *h).collect();
    let assume_valid_ok = lease.range.start <= ASSUME_VALID_HEIGHT && assume_valid_active(state);
    pipeline_log("VALIDATION_MODE", format_args!(
        "range={}..{} assume_valid_active={} checkpoint_height={} full_verify_env={}",
        lease.range.start, lease.range.end, assume_valid_ok, ASSUME_VALID_HEIGHT,
        std::env::var("YCASH_FULL_VERIFY").ok().as_deref() == Some("1")
    ));
    if assume_valid_ok {
        state.set_assume_valid_height(ASSUME_VALID_HEIGHT);
    }
    pipeline_log("GETDATA", format_args!(
        "range={}..{} requested_blocks={}",
        lease.range.start, lease.range.end, hashes.len()
    ));
    send(stream, "getdata", &getdata_payload(&hashes))
        .map_err(|e| phase_error("getdata send", e))?;

    let mut done = std::collections::HashSet::new();
    let mut blocks = Vec::with_capacity(requests.len());
    let mut bytes = 0u64;
    let mut idle = 0u32;
    // `idle` only counts consecutive *silence* (read timeouts) and resets on
    // any message at all, including ones that don't advance `done` (ping,
    // addr, inv). A peer that accepts our getdata but never actually sends
    // the requested blocks -- while still being "alive" enough to ping --
    // can hold this claim hostage forever: idle keeps resetting, the range
    // never times out, never gets released, and never shows up as retried
    // or quarantined. This wall-clock deadline is a backstop that fires
    // regardless of what the peer sends in the meantime.
    // Progress deadline: the peer must deliver at least one *requested*
    // block every 60s. A fixed total deadline killed big ranges that were
    // downloading fine but slowly on mobile data; resetting on any message
    // let a chatty-but-useless peer hold the range forever. Resetting only
    // on real progress covers both.
    // ycashd's minimum block timeout after Blossom is 0.5 * 75s * 4 = 150s.
    // Give the Android transport a small margin rather than the old 60s
    // deadline, which could disconnect a healthy peer before ycashd would.
    const PROGRESS_TIMEOUT: Duration = Duration::from_secs(180);
    let mut deadline = Instant::now() + PROGRESS_TIMEOUT;
    while done.len() < requests.len() {
        if Instant::now() >= deadline {
            pipeline_log("PROGRESS_TIMEOUT", format_args!(
                "range={}..{} received={}/{} idle_timeouts={} ",
                lease.range.start, lease.range.end, done.len(), requests.len(), idle
            ));
            return Err(ioe(&format!(
                "peer made no progress on range {}..{} for 180s (received {}/{} blocks)",
                lease.range.start, lease.range.end, done.len(), requests.len()
            )));
        }
        let (cmd, payload) = match read_message(stream) {
            Ok(v) => v,
            Err(e) if is_timeout(&e) => {
                idle += 1;
                if idle >= 8 {
                    pipeline_log("READ_TIMEOUT", format_args!(
                        "range={}..{} consecutive_timeouts={} received={}/{}",
                        lease.range.start, lease.range.end, idle, done.len(), requests.len()
                    ));
                    return Err(ioe("peer stopped sending blocks for claimed range"));
                }
                continue;
            }
            Err(e) => return Err(phase_error("block stream read", e)),
        };
        idle = 0;
        // While a peer keeps us busy with a range, the session loop never
        // gets to see its pings. Answer pings inline, as ycashd's network
        // thread does while a peer has block requests in flight.
        // (20 min), so after a long good run every worker connection was
        // being cut at once -- all their ranges failed together, retried,
        // quarantined, and sync stalled. Answer pings here.
        if cmd == "ping" {
            send(stream, "pong", &payload)
                .map_err(|e| phase_error("block-stream pong send", e))?;
            continue;
        }
        // Peer doesn't have (some of) these blocks: fail now so another peer
        // can take the range, instead of sitting out the whole timeout.
        if cmd == "notfound" {
            pipeline_log("NOTFOUND", format_args!(
                "range={}..{} received={}/{}",
                lease.range.start, lease.range.end, done.len(), requests.len()
            ));
            return Err(ioe(&format!(
                "peer sent notfound for range {}..{}",
                lease.range.start, lease.range.end
            )));
        }
        if cmd != "block" {
            continue;
        }
        // Previously every incoming block was fully parsed once per
        // outstanding height (up to 32 full decodes per block) just to find
        // which height it was. Hash the header bytes once and look it up.
        let matched = raw_block_hash(&payload)
            .and_then(|hash| by_hash.get(&hash).copied())
            .filter(|h| !done.contains(h));
        // An unrequested block (a new-tip relay, or a late duplicate) is not
        // an error -- it used to fail the whole range and drop the peer.
        let Some(height) = matched else { continue };
        deadline = Instant::now() + PROGRESS_TIMEOUT;
        let expected_hash = requests.iter().find(|(h, _)| *h == height).map(|(_, h)| *h).unwrap();
        let mtp_time = mtp(state, height);
        let ctx = Context {
            height,
            prev_height: height.saturating_sub(1),
            median_time_past: mtp_time,
        };
        let assume_valid = height <= ASSUME_VALID_HEIGHT && assume_valid_ok;
        let validated = validate_for_commit_opts(&payload, ctx, assume_valid).map_err(|e| {
            let msg = format!("{e:?}");
            let kind = if msg.contains(UNSUPPORTED_PREFIX) { ErrorKind::Unsupported } else { ErrorKind::InvalidData };
            pipeline_log("VALIDATION_ERROR", format_args!(
                "range={}..{} height={} assume_valid={} raw_bytes={} error={}",
                lease.range.start, lease.range.end, height, assume_valid, payload.len(), msg
            ));
            std::io::Error::new(kind, format!("block {height}: {msg}"))
        })?;
        if validated.txs.is_empty() {
            return Err(ioe("consensus decoder returned zero transactions"));
        }
        let work = state
            .header_work_by_height(height)
            .map_err(|e| ioe(&e.to_string()))?
            .ok_or_else(|| ioe("missing header chain work"))?;
        let work: [u8; 32] = work.try_into().map_err(|_| ioe("invalid chain work"))?;
        // prev hash is already in the range map (or one cheap lookup at the
        // range start) -- no need to fetch and decode the previous header.
        let prev_hash: [u8; 32] = if height == 1 {
            genesis_hash_internal()
        } else if let Some((_, h)) = requests.iter().find(|(h, _)| *h == height - 1) {
            *h
        } else {
            state
                .header_hash_by_height(height - 1)
                .map_err(|e| ioe(&e.to_string()))?
                .and_then(|v| <[u8; 32]>::try_from(v.as_slice()).ok())
                .ok_or_else(|| ioe("missing previous header"))?
        };
        let txs: Vec<([u8; 32], Vec<u8>)> = validated
            .txs
            .iter()
            .map(|t| (txid(t), t.clone()))
            .collect();
        bytes += payload.len() as u64;
        blocks.push(BlockCommit {
            height,
            hash: expected_hash,
            prev: prev_hash,
            work,
            raw: payload.clone(),
            txs,
        });
        done.insert(height);
        pipeline_log("BLOCK_OK", format_args!(
            "range={}..{} height={} progress={}/{} txs={}",
            lease.range.start, lease.range.end, height, done.len(), requests.len(), validated.txs.len()
        ));
    }
    blocks.sort_by_key(|b| b.height);
    Ok((blocks, bytes))
}

fn ioe(s: &str) -> std::io::Error {
    std::io::Error::new(ErrorKind::InvalidData, s.to_string())
}

fn phase_error(phase: &str, e: std::io::Error) -> std::io::Error {
    std::io::Error::new(e.kind(), format!("{}: {}", phase, e))
}
