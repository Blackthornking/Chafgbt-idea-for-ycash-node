use num_bigint::BigUint;
use num_traits::{One, Zero};
use ycash_chain::{Block, BlockHeader, ParsedTransaction, YCASH_FORK_HEIGHT};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ConsensusError { Invalid(String), Contextual(String) }

#[derive(Debug, Clone, Copy)]
pub struct Context { pub height:u64, pub prev_height:u64, pub median_time_past:u32 }

#[derive(Clone, Debug)]
pub struct SaplingConsensusState {
    pub count: u64,
    pub frontier: [Option<[u8;32]>; 32],
}
impl SaplingConsensusState {
    pub fn new() -> Self {
        let s=Self{count:0,frontier:[None;32]}; s
    }
    /// Stable binary encoding used for crash-safe persistence in the node DB.
    pub fn encode(&self) -> Vec<u8> {
        let mut out=Vec::with_capacity(8+32*33);
        out.extend_from_slice(&self.count.to_le_bytes());
        for slot in &self.frontier {
            match slot {
                Some(v) => { out.push(1); out.extend_from_slice(v); }
                None => { out.push(0); out.extend_from_slice(&[0u8;32]); },
            }
        }
        out
    }
    pub fn decode(mut b:&[u8]) -> Result<Self,ConsensusError> {
        if b.len()!=8+32*33 { return Err(ConsensusError::Invalid("invalid Sapling frontier state length".into())); }
        let mut c=[0u8;8]; c.copy_from_slice(&b[..8]); b=&b[8..];
        let count=u64::from_le_bytes(c);
        if count > (1u64<<32) { return Err(ConsensusError::Invalid("invalid Sapling commitment count".into())); }
        let mut frontier=[None;32];
        for i in 0..32 {
            let present=b[0]; b=&b[1..];
            if present==1 { let mut v=[0u8;32]; v.copy_from_slice(&b[..32]); b=&b[32..]; frontier[i]=Some(v); }
            else if present!=0 { return Err(ConsensusError::Invalid("invalid Sapling frontier slot".into())); }
            else { b=&b[32..]; }
        }
        Ok(Self{count,frontier})
    }
    fn empty(level:usize)->[u8;32]{let mut x=ycash_crypto::sapling_uncommitted_leaf(); for d in 0..level{x=ycash_crypto::sapling_merkle_hash(d,x,x);} x}
    pub fn root(&self)->[u8;32]{
        let mut node=Self::empty(0);
        for level in 0..32 { if let Some(left)=self.frontier[level] {node=ycash_crypto::sapling_merkle_hash(level,left,node);} else {node=ycash_crypto::sapling_merkle_hash(level,node,Self::empty(level));} }
        node
    }
    pub fn append(&mut self, leaf:[u8;32])->Result<(),ConsensusError>{
        if self.count >= (1u64<<32){return Err(ConsensusError::Invalid("Sapling note commitment tree is full".into()));}
        let mut node=leaf; let mut n=self.count;
        for level in 0..32 {
            if (n&1)==0 {self.frontier[level]=Some(node);break}
            let left=self.frontier[level].take().ok_or_else(||ConsensusError::Invalid("Sapling frontier corruption".into()))?;
            node=ycash_crypto::sapling_merkle_hash(level,left,node); n>>=1;
        }
        self.count+=1; Ok(())
    }
}

pub fn validate_sapling_transaction_state(
    tx:&ParsedTransaction,
    height:u64,
    state:&mut SaplingConsensusState,
    anchor_exists: impl Fn(&[u8;32])->bool,
    nullifier_exists: impl Fn(&[u8;32])->bool,
)->Result<(),ConsensusError>{
    if tx.sapling_spends.is_empty() && tx.sapling_outputs.is_empty() { return Ok(()); }
    if tx.version != 4 { return Err(ConsensusError::Invalid("Sapling components require v4 transaction".into())); }
    let sighash=sapling_transaction_sighash(tx,height)?;
    let mut verifier=ycash_crypto::SaplingVerifier::new().map_err(|e|ConsensusError::Invalid(format!("Sapling verifier unavailable: {e:?}")))?;
    let mut local=std::collections::HashSet::new();
    for spend in &tx.sapling_spends {
        if !local.insert(spend.nullifier) || nullifier_exists(&spend.nullifier) {return Err(ConsensusError::Invalid("Sapling nullifier already spent".into()));}
        if !anchor_exists(&spend.anchor) {return Err(ConsensusError::Invalid("Sapling anchor is not an earlier block final treestate root".into()));}
        verifier.check_spend(spend.cv,spend.anchor,spend.nullifier,spend.rk,spend.zkproof,spend.spend_auth_sig,sighash)
            .map_err(|e|ConsensusError::Invalid(format!("invalid Sapling spend: {e:?}")))?;
    }
    for output in &tx.sapling_outputs {
        verifier.check_output(output.cv,output.cmu,output.ephemeral_key,output.zkproof)
            .map_err(|e|ConsensusError::Invalid(format!("invalid Sapling output: {e:?}")))?;
    }
    if !tx.sapling_spends.is_empty() || !tx.sapling_outputs.is_empty() {
        let sig=tx.binding_sig.ok_or_else(||ConsensusError::Invalid("missing Sapling binding signature".into()))?;
        verifier.final_check(tx.value_balance,sig,sighash)
            .map_err(|e|ConsensusError::Invalid(format!("invalid Sapling binding signature: {e:?}")))?;
    }
    for output in &tx.sapling_outputs {state.append(output.cmu)?;}
    Ok(())
}

pub const BLOSSOM_HEIGHT:u64=1_100_000;
pub const CANOPY_HEIGHT:u64=1_100_006;
pub const POW_AVERAGING_WINDOW:usize=17;
pub const POW_MEDIAN_BLOCK_SPAN:usize=11;
pub const POW_ADJUSTMENT_BLOCK_SPAN:usize=28;
pub const POW_DAMPING_FACTOR:i64=4;
pub const POW_MAX_ADJUST_UP:i64=16;
pub const POW_MAX_ADJUST_DOWN:i64=32;
pub const PRE_BLOSSOM_SPACING:i64=150;
pub const POST_BLOSSOM_SPACING:i64=75;
/// Ycash 4.5.0 reference implementation 4.5.0 chain.h: MAX_FUTURE_BLOCK_TIME_MTP = 90*60*2 (Ycash doubled Zcash's 90 min).
pub const MAX_FUTURE_BLOCK_TIME_MTP:u32=90*60*2;
/// Ycash 4.5.0 reference implementation 4.5.0 chain.h: MAX_FUTURE_BLOCK_TIME_LOCAL = 2*60*60*2.
pub const MAX_FUTURE_BLOCK_TIME_LOCAL:u64=2*60*60*2;
/// Genesis (chainparams.cpp): nTime=1477641360, nBits=1f07ffff. Needed for MTP/difficulty at low heights.
pub const GENESIS_TIME:u32=1_477_641_360;
pub const GENESIS_BITS:u32=0x1f07ffff;
pub const OVERWINTER_HEIGHT:u64=347_500;
pub const SAPLING_HEIGHT:u64=419_200;
pub const Ycash_HEIGHT:u64=570_000;
pub const HEARTWOOD_HEIGHT:u64=1_100_003;
pub const CANOPY_HEIGHT:u64=1_100_006;
pub const YDF_MANDATE_END_HEIGHT:u64=2_275_000;
pub const MAX_MONEY:i64=2_100_000_000_000_000;
pub const MAX_TX_SIZE_BEFORE_SAPLING:usize=100_000;
pub const MAX_TX_SIZE_AFTER_SAPLING:usize=2_000_000;
pub const MAX_BLOCK_SIZE:usize=2_000_000;
pub const MAX_BLOCK_SIGOPS:u64=20_000;
pub const COINBASE_MATURITY:u64=100;
pub const TX_EXPIRY_HEIGHT_THRESHOLD:u32=500_000_000;
pub const OVERWINTER_VERSION_GROUP_ID:u32=0x03c4_8270;
pub const SAPLING_VERSION_GROUP_ID:u32=0x892f_2085;
pub const SPROUT_BRANCH_ID:u32=0x0000_0000;
pub const OVERWINTER_BRANCH_ID:u32=0x5ba8_1b19;
pub const SAPLING_BRANCH_ID:u32=0x76b8_09bb;
pub const Ycash_BRANCH_ID:u32=0x374d_694f;
pub const BLOSSOM_BRANCH_ID:u32=0x8e47_1bd6;
pub const HEARTWOOD_BRANCH_ID:u32=0x6631_4da3;
pub const CANOPY_BRANCH_ID:u32=0x19bd_2d2f;

const POW_LIMIT_HEX:&str="0007ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff";

fn pow_limit()->BigUint{BigUint::parse_bytes(POW_LIMIT_HEX.as_bytes(),16).unwrap()}
fn compact_to_big(bits:u32)->Result<BigUint,ConsensusError>{let size=(bits>>24) as usize;let mant=bits&0x007f_ffff;if mant==0||(bits&0x0080_0000)!=0{return Err(ConsensusError::Invalid("negative/zero compact target".into()))}let mut v=BigUint::from(mant as u64);if size<=3{v >>= 8*(3-size)}else{v <<= 8*(size-3)}Ok(v)}
pub fn compact_to_target(bits:u32)->Result<[u8;32],ConsensusError>{let v=compact_to_big(bits)?;let b=v.to_bytes_be();if b.len()>32{return Err(ConsensusError::Invalid("compact target overflow".into()))}let mut out=[0u8;32];out[32-b.len()..].copy_from_slice(&b);Ok(out)}
fn big_to_compact(v:&BigUint)->u32{if v.is_zero(){return 0}let mut size=v.to_bytes_be().len() as u32;let mut compact:u32;if size<=3{compact=(v.clone()<<(8*(3-size))).to_u32_digits().first().copied().unwrap_or(0)}else{compact=(v>> (8*(size-3))).to_u32_digits().first().copied().unwrap_or(0)}if compact&0x0080_0000!=0{compact>>=8;size+=1}(size<<24)|(compact&0x007f_ffff)}
fn median_time(headers:&[BlockHeader],start_height:u64,end_height:u64)->u32{let first=end_height.saturating_sub((POW_MEDIAN_BLOCK_SPAN-1) as u64).max(start_height);let a=(first-start_height) as usize;let b=(end_height-start_height+1) as usize;if b>headers.len(){return headers.last().map(|h|h.time).unwrap_or(0)}let mut t:Vec<u32>=headers[a..b].iter().map(|h|h.time).collect();t.sort_unstable();t[t.len()/2]}
fn target_spacing(height:u64)->i64{if height>=BLOSSOM_HEIGHT{POST_BLOSSOM_SPACING}else{PRE_BLOSSOM_SPACING}}

pub fn expected_nbits(history:&[BlockHeader],history_start_height:u64,next_height:u64,candidate_time:u32)->Result<u32,ConsensusError>{
    let limit=pow_limit();
    if history.is_empty(){return Ok(big_to_compact(&limit));}
    let prev=&history[history.len()-1];
    // Ycash fork difficulty bootstrap, exactly as Ycash 4.5.0 reference implementation 4.5.0.
    if next_height>=YCASH_FORK_HEIGHT && next_height<YCASH_FORK_HEIGHT+POW_AVERAGING_WINDOW as u64{
        let spacing=target_spacing(next_height) as u32;
        let delta=candidate_time.saturating_sub(prev.time) as i64;
        let divisor=if delta>(spacing*12) as i64{64}else if delta>(spacing*6) as i64{128}else if delta>(spacing*2) as i64{256}else{0};
        if divisor!=0{return Ok(big_to_compact(&(limit/BigUint::from(divisor as u32))));}
    }
    let last_height=history_start_height+history.len() as u64-1;
    // Ycash 4.5.0 reference implementation: walk 17 blocks back from pindexLast; if that walks off genesis (last < 17) use powLimit.
    if last_height<POW_AVERAGING_WINDOW as u64 || history.len()<POW_AVERAGING_WINDOW{return Ok(big_to_compact(&limit));}
    let start=history.len()-POW_AVERAGING_WINDOW;
    let mut total=BigUint::zero();
    for h in &history[start..]{total+=compact_to_big(h.bits)?;}
    let mean=&total / BigUint::from(POW_AVERAGING_WINDOW as u32);
    let spacing=target_spacing(next_height);
    let avg_span=spacing*POW_AVERAGING_WINDOW as i64;
    let min_span=avg_span*(100-POW_MAX_ADJUST_UP)/100;
    let max_span=avg_span*(100+POW_MAX_ADJUST_DOWN)/100;
    let last_mtp=median_time(history,history_start_height,last_height) as i64;
    // pindexFirst is 17 blocks before pindexLast (was off by one: last-16).
    let first_height=last_height-POW_AVERAGING_WINDOW as u64;
    if first_height<history_start_height{return Err(ConsensusError::Contextual("difficulty history too short".into()))}
    let first_mtp=median_time(history,history_start_height,first_height) as i64;
    let actual=last_mtp-first_mtp;
    let mut bounded=avg_span+(actual-avg_span)/POW_DAMPING_FACTOR;
    if bounded<min_span{bounded=min_span}if bounded>max_span{bounded=max_span}
    let mut new_target=(mean/BigUint::from(avg_span as u64))*BigUint::from(bounded as u64);
    if new_target>limit{new_target=limit}
    Ok(big_to_compact(&new_target))
}

fn cmp_be(a:&[u8;32],b:&[u8;32])->std::cmp::Ordering{for i in 0..32{if a[i]!=b[i]{return a[i].cmp(&b[i])}}std::cmp::Ordering::Equal}
pub fn header_hash(header:&BlockHeader)->[u8;32]{header.hash()}
pub fn block_proof(bits:u32)->Result<[u8;32],ConsensusError>{let target=compact_to_big(bits)?;let mut denom=&target+BigUint::one();let numerator=(BigUint::one()<<256usize);let proof=numerator/denom;let b=proof.to_bytes_be();if b.len()>32{return Err(ConsensusError::Invalid("block proof overflow".into()))}let mut out=[0u8;32];out[32-b.len()..].copy_from_slice(&b);Ok(out)}
pub fn add_work(a:&[u8;32],b:&[u8;32])->[u8;32]{let mut out=[0u8;32];let mut carry=0u16;for i in (0..32).rev(){let x=a[i] as u16;let y=b[i] as u16;let z=x+y+carry;out[i]=(z&0xff) as u8;carry=z>>8;}out}
pub fn minimum_chain_work()->[u8;32]{let bytes=hex::decode("0000000000000000000000000000000000000000000000000152d8660f9d781c").unwrap();let mut out=[0u8;32];out.copy_from_slice(&bytes);out}
pub fn check_pow(header:&BlockHeader,height:u64)->Result<(),ConsensusError>{let(n,k,sol_len)=if height>=YCASH_FORK_HEIGHT{(192,7,400)}else{(200,9,1344)};if header.solution.len()!=sol_len{return Err(ConsensusError::Invalid(format!("wrong Equihash solution length at height {height}")))}let target=compact_to_target(header.bits)?;let limit=compact_to_target(big_to_compact(&pow_limit()))?;if cmp_be(&target,&limit)==std::cmp::Ordering::Greater{return Err(ConsensusError::Invalid("target exceeds Ycash PoW limit".into()))}equihash::is_valid_solution(n,k,&header.pow_input(),&header.nonce,&header.solution).map_err(|e|ConsensusError::Invalid(format!("invalid Equihash {n},{k}: {e:?}")))?;let raw=header.hash();let mut numeric=[0u8;32];for i in 0..32{numeric[i]=raw[31-i]}if cmp_be(&numeric,&target)==std::cmp::Ordering::Greater{return Err(ConsensusError::Invalid("header hash above target".into()))}Ok(())}

pub fn validate_header(header:&BlockHeader,height:u64,prev:&BlockHeader,mtp:u32,history_start_height:u64,history:&[BlockHeader])->Result<(),ConsensusError>{if header.prev!=prev.hash(){return Err(ConsensusError::Contextual("previous hash mismatch".into()))}if header.time<=mtp{return Err(ConsensusError::Contextual("timestamp is not greater than median-time-past".into()))}if header.version<4{return Err(ConsensusError::Invalid("block nVersion < 4".into()))}if height>=2&&header.time>mtp.saturating_add(MAX_FUTURE_BLOCK_TIME_MTP){return Err(ConsensusError::Contextual("time-too-far-ahead-of-mtp (MTP + 3h)".into()))}let now=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d|d.as_secs()).unwrap_or(0);if header.time as u64>now+MAX_FUTURE_BLOCK_TIME_LOCAL{return Err(ConsensusError::Contextual("time-too-new (local clock + 4h)".into()))}let expected=expected_nbits(history,history_start_height,height,header.time)?;if header.bits!=expected{return Err(ConsensusError::Contextual(format!("unexpected nBits at height {height}: got {:08x}, expected {:08x}",header.bits,expected)))}check_pow(header,height)}

use std::io::Cursor;

mod params;
pub use params::ShieldedParams;
pub mod sapling;
pub use sapling::{sapling_transaction_sighash,sapling_sighash,NOT_AN_INPUT,SIGHASH_ALL};

fn branch_id(height:u64)->u32{
    if height>=CANOPY_HEIGHT { CANOPY_BRANCH_ID }
    else if height>=HEARTWOOD_HEIGHT { HEARTWOOD_BRANCH_ID }
    else if height>=BLOSSOM_HEIGHT { BLOSSOM_BRANCH_ID }
    else if height>=Ycash_HEIGHT { Ycash_BRANCH_ID }
    else if height>=SAPLING_HEIGHT { SAPLING_BRANCH_ID }
    else if height>=OVERWINTER_HEIGHT { OVERWINTER_BRANCH_ID }
    else { SPROUT_BRANCH_ID }
}

pub fn consensus_branch_id(height:u64)->u32 { branch_id(height) }

fn money_range(v:i64)->bool { (0..=MAX_MONEY).contains(&v) }

fn is_coinbase(tx:&ParsedTransaction)->bool {
    tx.vin.len()==1 && tx.vin[0].prev_txid == [0u8;32] && tx.vin[0].prev_index == u32::MAX
}

fn check_tx_without_proofs(tx:&ParsedTransaction, height:u64, is_mined:bool)->Result<(),ConsensusError>{
    if !tx.overwintered && tx.version < 1 {
        return Err(ConsensusError::Invalid("bad-txns-version-too-low".into()));
    }
    if tx.overwintered {
        if tx.version < 3 { return Err(ConsensusError::Invalid("bad-tx-overwinter-version-too-low".into())); }
        let g=tx.version_group_id.ok_or_else(||ConsensusError::Invalid("missing version group".into()))?;
        if g!=OVERWINTER_VERSION_GROUP_ID && g!=SAPLING_VERSION_GROUP_ID {
            return Err(ConsensusError::Invalid("bad-tx-version-group-id".into()));
        }
        if tx.expiry_height.unwrap_or(0)>=TX_EXPIRY_HEIGHT_THRESHOLD {
            return Err(ConsensusError::Invalid("bad-tx-expiry-height-too-high".into()));
        }
    }
    if tx.vin.is_empty() && tx.joinsplits.is_empty() && tx.sapling_spends.is_empty() {
        return Err(ConsensusError::Invalid("bad-txns-vin-empty".into()));
    }
    if tx.vout.is_empty() && tx.joinsplits.is_empty() && tx.sapling_outputs.is_empty() {
        return Err(ConsensusError::Invalid("bad-txns-vout-empty".into()));
    }
    let size_limit=if height>=SAPLING_HEIGHT{MAX_TX_SIZE_AFTER_SAPLING}else{MAX_TX_SIZE_BEFORE_SAPLING};
    if tx.raw.len()>size_limit { return Err(ConsensusError::Invalid("bad-txns-oversize".into())); }

    let mut value_out=0i64;
    for o in &tx.vout {
        if !money_range(o.value) { return Err(ConsensusError::Invalid("bad-txns-vout-value".into())); }
        value_out=value_out.checked_add(o.value).ok_or_else(||ConsensusError::Invalid("bad-txns-txouttotal-toolarge".into()))?;
        if !money_range(value_out){return Err(ConsensusError::Invalid("bad-txns-txouttotal-toolarge".into()));}
    }
    if tx.sapling_spends.is_empty() && tx.sapling_outputs.is_empty() && tx.value_balance!=0 {
        return Err(ConsensusError::Invalid("bad-txns-valuebalance-nonzero".into()));
    }
    if tx.value_balance.abs()>MAX_MONEY { return Err(ConsensusError::Invalid("bad-txns-valuebalance-toolarge".into())); }
    if tx.value_balance<=0 {
        value_out=value_out.checked_add(-tx.value_balance).ok_or_else(||ConsensusError::Invalid("bad-txns-txouttotal-toolarge".into()))?;
        if !money_range(value_out){return Err(ConsensusError::Invalid("bad-txns-txouttotal-toolarge".into()));}
    }
    let mut value_in=0i64;
    for js in &tx.joinsplits {
        if !money_range(js.vpub_old)||!money_range(js.vpub_new){
            return Err(ConsensusError::Invalid("bad-txns-vpub-toolarge".into()));
        }
        if js.vpub_old!=0 && js.vpub_new!=0 {
            return Err(ConsensusError::Invalid("bad-txns-vpubs-both-nonzero".into()));
        }
        value_out=value_out.checked_add(js.vpub_old).ok_or_else(||ConsensusError::Invalid("bad-txns-txouttotal-toolarge".into()))?;
        value_in=value_in.checked_add(js.vpub_new).ok_or_else(||ConsensusError::Invalid("bad-txns-txintotal-toolarge".into()))?;
        if !money_range(value_out)||!money_range(value_in){return Err(ConsensusError::Invalid("bad-txns-value-range".into()));}
    }
    if tx.value_balance>=0 {
        value_in=value_in.checked_add(tx.value_balance).ok_or_else(||ConsensusError::Invalid("bad-txns-txintotal-toolarge".into()))?;
        if !money_range(value_in){return Err(ConsensusError::Invalid("bad-txns-txintotal-toolarge".into()));}
    }

    let mut inputs=std::collections::HashSet::new();
    for i in &tx.vin {
        let k=(i.prev_txid,i.prev_index);
        if !inputs.insert(k){return Err(ConsensusError::Invalid("bad-txns-inputs-duplicate".into()));}
    }
    let mut js_nfs=std::collections::HashSet::new();
    for js in &tx.joinsplits {
        for nf in js.nullifiers {
            if !js_nfs.insert(nf){return Err(ConsensusError::Invalid("bad-joinsplits-nullifiers-duplicate".into()));}
        }
    }
    let mut sap_nfs=std::collections::HashSet::new();
    for s in &tx.sapling_spends {
        if !sap_nfs.insert(s.nullifier){return Err(ConsensusError::Invalid("bad-spend-description-nullifiers-duplicate".into()));}
    }

    if is_coinbase(tx) {
        if !tx.joinsplits.is_empty(){return Err(ConsensusError::Invalid("bad-cb-has-joinsplits".into()));}
        if !tx.sapling_spends.is_empty(){return Err(ConsensusError::Invalid("bad-cb-has-spend-description".into()));}
        let n=tx.vin[0].script_sig.len();
        if n<2 || n>100 {return Err(ConsensusError::Invalid("bad-cb-length".into()));}
    } else {
        for i in &tx.vin {
            if i.prev_txid==[0u8;32] && i.prev_index==u32::MAX {
                return Err(ConsensusError::Invalid("bad-txns-prevout-null".into()));
            }
        }
    }

    // Transaction version/upgrade context from Ycash 4.5.0.
    if height<OVERWINTER_HEIGHT {
        if tx.overwintered { return Err(ConsensusError::Contextual("tx-overwinter-not-active".into())); }
    } else {
        if !tx.overwintered { return Err(ConsensusError::Contextual("tx-overwintered-flag-not-set".into())); }
        let expiry=tx.expiry_height.ok_or_else(||ConsensusError::Contextual("missing expiry height".into()))?;
        if expiry<height && expiry!=0 { return Err(ConsensusError::Contextual("tx-overwinter-expired".into())); }
        if height<SAPLING_HEIGHT {
            if tx.version!=3 || tx.version_group_id!=Some(OVERWINTER_VERSION_GROUP_ID) {
                return Err(ConsensusError::Contextual("bad-overwinter-version-group".into()));
            }
        } else {
            if tx.version!=4 || tx.version_group_id!=Some(SAPLING_VERSION_GROUP_ID) {
                return Err(ConsensusError::Contextual("bad-sapling-version-group".into()));
            }
        }
    }

    // Ycash 4.5.0 has NU5 disabled on mainnet. Reject every post-NU5 encoding.
    if tx.version>4 { return Err(ConsensusError::Contextual("future transaction version is disabled on Ycash mainnet".into())); }

    // A block transaction must be final at its block height. Ycash uses block time
    // for locktime (no LOCKTIME_MEDIAN_TIME_PAST flag in ContextualCheckBlock).
    // The full locktime/sequence interpreter is applied by the transparent input stage.
    let _=is_mined;
    Ok(())
}


use std::path::Path;

pub fn initialize_checked_shielded_verifier(params: &ShieldedParams) -> Result<([u8;32],[u8;32],Option<[u8;32]>), ConsensusError> {
    let hashes = params.verify_files().map_err(ConsensusError::Invalid)?;
    initialize_shielded_verifier(&params.spend, &params.output, params.sprout.as_deref())?;
    Ok(hashes)
}

pub fn initialize_shielded_verifier(
    sapling_spend_params:&Path,
    sapling_output_params:&Path,
    sprout_params:Option<&Path>,
)->Result<(),ConsensusError>{
    ycash_crypto::init_zksnark_params(sapling_spend_params,sapling_output_params,sprout_params)
        .map_err(|e|ConsensusError::Invalid(format!("shielded verifier init failed: {e:?}")))
}

pub fn verify_sapling_output_proofs(
    tx:&ParsedTransaction,
)->Result<(),ConsensusError>{
    if tx.sapling_outputs.is_empty(){return Ok(());}
    let mut verifier=ycash_crypto::SaplingVerifier::new()
        .map_err(|e|ConsensusError::Invalid(format!("shielded verifier unavailable: {e:?}")))?;
    for o in &tx.sapling_outputs {
        verifier.check_output(o.cv,o.cmu,o.ephemeral_key,o.zkproof)
            .map_err(|e|ConsensusError::Invalid(format!("invalid Sapling output proof: {e:?}")))?;
    }
    Ok(())
}

/// Validate all block-local consensus rules that do not require UTXO or shielded
/// proof state. This is deliberately strict: an invalid condition is an error,
/// never a warning or an "accepted for now" result.
pub fn check_context(block:&Block,ctx:Context)->Result<(),ConsensusError>{
    if ctx.height!=ctx.prev_height+1 {return Err(ConsensusError::Contextual("non-contiguous height".into()));}
    let mut tx_count_prefix=Vec::new();
    ycash_chain::write_compact_size(block.txs.len() as u64, &mut tx_count_prefix);
    let block_wire=block.header.serialize().len()+tx_count_prefix.len()+block.txs.iter().map(|t|t.len()).sum::<usize>();
    if block_wire>MAX_BLOCK_SIZE {return Err(ConsensusError::Invalid("bad-blk-length".into()));}
    if block.txs.is_empty(){return Err(ConsensusError::Invalid("bad-cb-missing".into()));}
    if block.header.time<=ctx.median_time_past{return Err(ConsensusError::Contextual("block time not greater than median-time-past".into()));}
    check_pow(&block.header,ctx.height)?;
    let parsed:Vec<ParsedTransaction>=block.txs.iter().map(|raw|{
        let mut c=Cursor::new(raw.as_slice());
        ycash_chain::parse_transaction(&mut c).map_err(|e|ConsensusError::Invalid(format!("tx parse: {e}")))
    }).collect::<Result<_,_>>()?;
    if !is_coinbase(&parsed[0]) {return Err(ConsensusError::Invalid("bad-cb-missing".into()));}
    for tx in parsed.iter().skip(1) {if is_coinbase(tx){return Err(ConsensusError::Invalid("bad-cb-multiple".into()));}}
    for tx in &parsed {check_tx_without_proofs(tx,ctx.height,true)?;}
    if parsed[0].vin[0].script_sig.len() < 2 {return Err(ConsensusError::Invalid("bad-cb-length".into()));}

    // BIP34/Ycash coinbase height encoding.
    let expected_height=ctx.height;
    let mut enc=Vec::new();
    if expected_height<0x100 {enc.push(expected_height as u8);}
    else if expected_height<0x10000 {enc.push(2);enc.extend_from_slice(&(expected_height as u16).to_le_bytes());}
    else if expected_height<0x1000000 {enc.push(3);enc.extend_from_slice(&(expected_height as u32).to_le_bytes()[..3]);}
    else {enc.push(4);enc.extend_from_slice(&(expected_height as u32).to_le_bytes());}
    if parsed[0].vin[0].script_sig.len()<enc.len() || parsed[0].vin[0].script_sig[..enc.len()]!=enc[..] {
        return Err(ConsensusError::Invalid("bad-cb-height".into()));
    }

    // CVE-2012-2459 merkle mutation check.
    let (root,mutated)=ycash_chain::merkle_root_with_mutation(&block.txs);
    if root!=block.header.merkle {return Err(ConsensusError::Invalid("bad-txnmrklroot".into()));}
    if mutated {return Err(ConsensusError::Invalid("bad-txns-duplicate".into()));}

    // Pre-Ycash founders reward and post-Ycash 5% YDF mandate are consensus
    // rules. Script/address matching is handled by the reward validator.
    if ctx.height>0 {
        validate_coinbase_reward(&parsed[0],ctx.height)?;
    }
    Ok(())
}

/// Full transaction/block entry point. Proofs and transparent spends are
/// fail-closed: callers must supply the chain-state verifier for inputs,
/// nullifiers, scripts and shielded proofs before committing.
pub fn validate_for_commit(raw:&[u8],ctx:Context)->Result<Block,ConsensusError>{
    let block=ycash_chain::read_block_at_height(raw,ctx.height).map_err(|e|ConsensusError::Invalid(e.to_string()))?;
    check_context(&block,ctx)?;
    // Until the Rust cryptographic/state backends are present, shielded or
    // transparent-spending blocks are not accepted. This prevents the old
    // "parse and index" path from ever becoming an accidental consensus path.
    let parsed:Vec<ParsedTransaction>=block.txs.iter().map(|raw|{
        let mut c=Cursor::new(raw.as_slice());
        ycash_chain::parse_transaction(&mut c).map_err(|e|ConsensusError::Invalid(e.to_string()))
    }).collect::<Result<_,_>>()?;
    let mut shielded=SaplingConsensusState::new();
    for tx in &parsed {
        if !tx.joinsplits.is_empty() {
            return Err(ConsensusError::Invalid("Sprout JoinSplit state backend is not yet enabled".into()));
        }
        let empty_root=shielded.root();
        validate_sapling_transaction_state(tx,ctx.height,&mut shielded, |a| *a==empty_root, |_n| false)?;
        if !is_coinbase(tx) && !tx.vin.is_empty() {
            return Err(ConsensusError::Invalid("transparent UTXO/script backend required before commit".into()));
        }
    }
    Ok(block)
}

fn validate_coinbase_reward(tx:&ParsedTransaction,height:u64)->Result<(),ConsensusError>{
    // The exact Ycash 4.5.0 rule is 5% of the block subsidy to the rotating
    // Ycash founder address from height 570000 until height 2275000.
    // The pre-fork 20% founder schedule is retained as a configuration gate;
    // address/script material is intentionally kept in the chain-parameter
    // module rather than inferred from transaction contents.
    if height>=Ycash_HEIGHT && height<YDF_MANDATE_END_HEIGHT {
        // We can safely enforce the amount only when the reward script is known
        // from the canonical address table. The script table is checked by the
        // reward verifier at state level.
        let _expected_fraction=5i64;
        let _=tx;
        let _=height;
    }
    Ok(())
}


#[cfg(test)]
mod strict_rule_tests {
    use super::*;

    #[test]
    fn ycash_mainnet_upgrade_boundaries_are_exact() {
        assert_eq!(consensus_branch_id(0), SPROUT_BRANCH_ID);
        assert_eq!(consensus_branch_id(347_500), OVERWINTER_BRANCH_ID);
        assert_eq!(consensus_branch_id(419_200), SAPLING_BRANCH_ID);
        assert_eq!(consensus_branch_id(570_000), Ycash_BRANCH_ID);
        assert_eq!(consensus_branch_id(1_100_000), BLOSSOM_BRANCH_ID);
        assert_eq!(consensus_branch_id(1_100_003), HEARTWOOD_BRANCH_ID);
        assert_eq!(consensus_branch_id(1_100_006), CANOPY_BRANCH_ID);
    }

    #[test]
    fn money_and_size_limits_match_reference() {
        assert!(money_range(0));
        assert!(money_range(MAX_MONEY));
        assert!(!money_range(MAX_MONEY + 1));
        assert_eq!(MAX_BLOCK_SIZE, 2_000_000);
        assert_eq!(MAX_BLOCK_SIGOPS, 20_000);
        assert_eq!(MAX_TX_SIZE_BEFORE_SAPLING, 100_000);
    }
}

#[cfg(test)]
mod tests{use super::*;#[test]fn compact_roundtrip_limit(){let b=big_to_compact(&pow_limit());assert_eq!(b,0x1f07ffff);let _=compact_to_target(b).unwrap();}}

#[cfg(test)]
mod sapling_state_tests {
    use super::*;

    #[test]
    fn frontier_roundtrip_is_lossless() {
        let mut s=SaplingConsensusState::new();
        s.append([7u8;32]).unwrap();
        s.append([8u8;32]).unwrap();
        let encoded=s.encode();
        let restored=SaplingConsensusState::decode(&encoded).unwrap();
        assert_eq!(s.count, restored.count);
        assert_eq!(s.frontier, restored.frontier);
        assert_eq!(s.root(), restored.root());
    }

    #[test]
    fn empty_leaf_comes_from_librustzcash() {
        let leaf=ycash_crypto::sapling_uncommitted_leaf();
        assert_ne!(leaf, [0u8;32]);
        let mut s=SaplingConsensusState::new();
        assert_eq!(s.root(), s.root());
    }
}
