//! YORTAL adaptive parallel synchronization components.
pub mod adaptive;
pub mod range_scheduler;
pub mod telemetry;

// `pub use` here (not plain `use`) because crates/node and
// crates/ycash-android-node both refer to these as `pipeline::AdaptiveConfig`
// / `pipeline::PipelineEngine` etc. A plain `use` only resolves names inside
// this module and does not re-export them, which left `ycash_state::pipeline::AdaptiveConfig`
// unreachable from other crates despite `PipelineEngine::new` requiring one.
pub use adaptive::{AdaptiveConfig, AdaptiveController, ResourceSample};
pub use range_scheduler::{RangeId, RangeLease, RangeScheduler, RangeState};
pub use telemetry::{PipelineSnapshot, PipelineStats};

/// Ties the adaptive window controller, the multi-peer range scheduler, and
/// telemetry into the single engine described in
/// `PIPELINE_V0.22_IMPLEMENTATION.md`.
///
/// Scope note: this engine owns *scheduling policy* only -- which height
/// ranges exist, which peer currently leases each one, and how large the
/// sync window is allowed to get. It does not itself do peer discovery,
/// header/body fetch, or block validation; those live in the network and
/// consensus crates and are expected to drive this engine via `plan_ranges`,
/// `claim`, `complete`, `release`, and `observe`. That wiring (peer scoring,
/// the actual header/body fetch loop, and the ordered commit path into
/// `State::commit_block`) is not implemented yet -- it needs its own pass
/// once the network crate has more than a single handshake.
pub struct PipelineEngine {
    adaptive: AdaptiveController,
    scheduler: RangeScheduler,
    stats: PipelineStats,
}

impl PipelineEngine {
    pub fn new(cfg: AdaptiveConfig) -> Self {
        let mut stats = PipelineStats::default();
        stats.start();
        Self {
            adaptive: AdaptiveController::new(cfg),
            scheduler: RangeScheduler::default(),
            stats,
        }
    }

    /// Enqueue the next height range up to the current adaptive window,
    /// starting at `next_height` and bounded by `chain_tip`. Returns the
    /// height sync should resume planning from on the following call.
    pub fn plan_ranges(&mut self, next_height: u64, chain_tip: u64) -> u64 {
        let window = self.adaptive.window() as u64;
        let end = (next_height + window.saturating_sub(1)).min(chain_tip);
        // HeightRange is inclusive, so a single remaining height (end ==
        // next_height) is still a valid range and must be enqueued -- an
        // earlier version of this used `end > next_height` here, which
        // silently dropped the last height of every sync window.
        if end >= next_height && next_height <= chain_tip {
            self.scheduler.enqueue(next_height, end);
        }
        self.stats.current_window = window;
        end
    }

    /// Lease the next pending range to `peer`.
    pub fn claim(&mut self, peer: &str) -> Option<RangeLease> {
        self.scheduler.claim(peer)
    }

    /// Plan the current adaptive window as multiple independent ranges. The
    /// total number of heights remains bounded by the adaptive window; the
    /// window is merely partitioned so several peers can work concurrently.
    pub fn plan_parallel_ranges(&mut self, next_height: u64, chain_tip: u64, workers: usize) -> Vec<RangeId> {
        if next_height > chain_tip { return Vec::new(); }
        let window = self.adaptive.window().max(1) as u64;
        let end = (next_height + window - 1).min(chain_tip);
        let count = workers.max(1).min((end - next_height + 1) as usize);
        let total = end - next_height + 1;
        let chunk = (total + count as u64 - 1) / count as u64;
        let mut ids = Vec::new();
        let mut start = next_height;
        while start <= end {
            let finish = (start + chunk - 1).min(end);
            ids.push(self.scheduler.enqueue(start, finish));
            start = finish + 1;
        }
        self.stats.current_window = window;
        self.stats.validation_workers = count as u64;
        self.stats.blocks_in_flight = total;
        self.stats.request_rounds += 1;
        ids
    }

    pub fn range_terminal(&self, id: RangeId) -> bool {
        matches!(self.scheduler.state(id), Some(RangeState::Complete | RangeState::Quarantined))
    }

    /// Mark a range complete and fold its results into telemetry.
    pub fn complete(&mut self, id: RangeId, blocks_received: u64, bytes_received: u64) {
        self.scheduler.complete(id);
        self.stats.blocks_received += blocks_received;
        self.stats.bytes_received += bytes_received;
        self.stats.completed_ranges += 1;
        self.stats.blocks_in_flight = self.stats.blocks_in_flight.saturating_sub(blocks_received);
    }

    /// Release an unfinished lease (timeout/disconnect). Escalates to
    /// telemetry as a retry or, past the retry limit, a quarantine.
    pub fn release(&mut self, id: RangeId) {
        self.scheduler.release(id);
        match self.scheduler.state(id) {
            Some(RangeState::Quarantined) => self.stats.quarantined_ranges += 1,
            _ => self.stats.retried_ranges += 1,
        }
    }

    /// Feed a fresh resource sample; adjusts the adaptive window and returns
    /// the current telemetry snapshot (for dashboards/RPC).
    pub fn observe(&mut self, sample: ResourceSample) -> PipelineSnapshot {
        self.stats.current_window = self.adaptive.observe(sample) as u64;
        self.stats.snapshot()
    }

    pub fn snapshot(&self) -> PipelineSnapshot {
        self.stats.snapshot()
    }
}

impl Default for PipelineEngine {
    fn default() -> Self {
        Self::new(AdaptiveConfig::default())
    }
}
