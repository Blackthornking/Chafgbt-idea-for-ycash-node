#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
P="$ROOT/crates/ycash-android-node/src/pipeline_sync.rs"
E="$ROOT/crates/state/src/pipeline/mod.rs"
A="$ROOT/crates/state/src/pipeline/adaptive.rs"
S="$ROOT/crates/state/src/chainstate.rs"
R="$ROOT/crates/ycash-android-node/src/runtime.rs"
M="$ROOT/crates/ycash-android-node/src/main.rs"
J="$ROOT/android-app/app/src/main/java/com/ycash/androidnode/MainActivity.java"
X="$ROOT/android-app/app/src/main/res/layout/activity_main.xml"
C="$ROOT/config/pipeline.toml"

grep -q 'start_adaptive_sampler' "$P"
grep -q 'TryRecvError::Empty' "$P"
grep -q 'active_range_len' "$E"
grep -q 'max(s.network_ratio)' "$A"
grep -q 'set_script_worker_budget' "$S"
grep -q 'pipeline_bottleneck' "$R"
grep -q 'pipeline_bottleneck' "$M"
grep -q 'pipelineBottleneck' "$J"
grep -q 'pipelinePressure' "$X"
grep -Eq '^max_range_len[[:space:]]*=[[:space:]]*100([[:space:]]*(#.*)?)?$' "$C"
grep -Eq '^max_validation_workers[[:space:]]*=[[:space:]]*0' "$C"
grep -Eq '^max_inflight_ranges[[:space:]]*=[[:space:]]*0' "$C"
! grep -q 'network_ratio = 0.0' "$P"
! grep -q 'let max_blocks = { let g = self.inner.lock' "$P"

echo 'PASS: fully adaptive Android pipeline scheduling, shared CPU budget, and bottleneck telemetry checks'
