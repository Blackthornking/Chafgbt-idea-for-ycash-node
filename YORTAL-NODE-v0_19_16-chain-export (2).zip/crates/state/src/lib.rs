use anyhow::{bail,Result};
use rusqlite::{params,Connection};
use std::path::Path;
use std::sync::Mutex;

#[derive(Debug,Clone)]
pub struct Tip{pub hash:Vec<u8>,pub height:u64,pub work:[u8;32]}
pub struct State{db:Mutex<Connection>}
impl State{
 pub fn open(p:impl AsRef<Path>)->Result<Self>{let db=Connection::open(p)?;let has_work:bool=db.prepare("PRAGMA table_info(headers)").and_then(|mut q|{let mut rows=q.query([])?;let mut found=false;while let Some(r)=rows.next()?{let n:String=r.get(1)?;if n=="work"{found=true;break;}}Ok(found)}).unwrap_or(true);if !has_work{let _=db.execute("DROP TABLE IF EXISTS headers",[]);}db.execute_batch("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY,v BLOB NOT NULL); CREATE TABLE IF NOT EXISTS blocks(hash BLOB PRIMARY KEY,height INTEGER NOT NULL,prev BLOB NOT NULL,work BLOB NOT NULL,raw BLOB NOT NULL,main_chain INTEGER NOT NULL DEFAULT 0); CREATE TABLE IF NOT EXISTS headers(hash BLOB PRIMARY KEY,height INTEGER NOT NULL,prev BLOB NOT NULL,time INTEGER NOT NULL,bits INTEGER NOT NULL,work BLOB NOT NULL,raw BLOB NOT NULL,main_chain INTEGER NOT NULL DEFAULT 0); CREATE INDEX IF NOT EXISTS headers_height ON headers(height); CREATE INDEX IF NOT EXISTS blocks_height ON blocks(height); CREATE INDEX IF NOT EXISTS blocks_prev ON blocks(prev); CREATE TABLE IF NOT EXISTS undo(block_hash BLOB PRIMARY KEY,height INTEGER NOT NULL,undo BLOB NOT NULL); CREATE TABLE IF NOT EXISTS txs(txid BLOB PRIMARY KEY,block_hash BLOB NOT NULL,raw BLOB NOT NULL); CREATE TABLE IF NOT EXISTS nullifiers(n BLOB PRIMARY KEY,block_hash BLOB NOT NULL); CREATE TABLE IF NOT EXISTS utxos(txid BLOB NOT NULL,vout INTEGER NOT NULL,value BLOB NOT NULL,script BLOB NOT NULL,block_hash BLOB NOT NULL,PRIMARY KEY(txid,vout));")?;Ok(Self{db:Mutex::new(db)})}
 pub fn put_block(&self,height:u64,hash:&[u8],prev:&[u8],work:&[u8],raw:&[u8])->Result<()>{if hash.len()!=32||prev.len()!=32||work.len()!=32{bail!("invalid hash/work length")};let db=self.db.lock().unwrap();db.execute("INSERT OR REPLACE INTO blocks(hash,height,prev,work,raw,main_chain) VALUES(?1,?2,?3,?4,?5,0)",params![hash,height,prev,work,raw])?;Ok(())}
 pub fn commit_block(&self,height:u64,hash:&[u8],prev:&[u8],work:&[u8],raw:&[u8],txs:&[([u8;32],Vec<u8>)])->Result<()>{
  if hash.len()!=32||prev.len()!=32||work.len()!=32{bail!("invalid hash/work length");}
  let db=self.db.lock().unwrap(); let tx=db.unchecked_transaction()?;
  tx.execute("UPDATE blocks SET main_chain=0 WHERE main_chain=1 AND height>=?1",params![height])?;
  tx.execute("INSERT OR REPLACE INTO blocks(hash,height,prev,work,raw,main_chain) VALUES(?1,?2,?3,?4,?5,1)",params![hash,height,prev,work,raw])?;
  tx.execute("DELETE FROM txs WHERE block_hash=?1",params![hash])?;
  for (txid,txraw) in txs {
   tx.execute("INSERT OR REPLACE INTO txs(txid,block_hash,raw) VALUES(?1,?2,?3)",params![txid.as_slice(),hash,txraw])?;
  }
  tx.execute("INSERT OR REPLACE INTO meta(k,v) VALUES('tip_hash',?1)",params![hash])?;
  tx.execute("INSERT OR REPLACE INTO meta(k,v) VALUES('tip_height',?1)",params![height.to_le_bytes().to_vec()])?;
  tx.commit()?; Ok(())
 }
 pub fn transaction_count(&self)->Result<u64>{let db=self.db.lock().unwrap();Ok(db.query_row("SELECT COUNT(*) FROM txs",[],|r|r.get::<_,i64>(0))? as u64)}
 pub fn set_tip(&self,tip:&Tip)->Result<()>{let db=self.db.lock().unwrap();let tx=db.unchecked_transaction()?;tx.execute("UPDATE blocks SET main_chain=0 WHERE main_chain=1",[])?;tx.execute("UPDATE blocks SET main_chain=1 WHERE hash=?1",params![&tip.hash])?;tx.execute("INSERT OR REPLACE INTO meta(k,v) VALUES('tip_hash',?1)",params![&tip.hash])?;tx.execute("INSERT OR REPLACE INTO meta(k,v) VALUES('tip_height',?1)",params![tip.height.to_le_bytes().to_vec()])?;tx.commit()?;Ok(())}
 pub fn tip_height(&self)->Result<Option<u64>>{let db=self.db.lock().unwrap();let r=db.query_row("SELECT MAX(height) FROM blocks WHERE main_chain=1",[],|r|r.get::<_,Option<i64>>(0))?;Ok(r.map(|x|x as u64))}
 pub fn has_block(&self,hash:&[u8])->Result<bool>{let db=self.db.lock().unwrap();Ok(db.query_row("SELECT EXISTS(SELECT 1 FROM blocks WHERE hash=?1)",params![hash],|r|r.get(0))?)}
 pub fn put_header(&self,height:u64,hash:&[u8],prev:&[u8],time:u32,bits:u32,work:&[u8],raw:&[u8])->Result<()>{if hash.len()!=32||prev.len()!=32||work.len()!=32{bail!("invalid header hash/work length")};let db=self.db.lock().unwrap();db.execute("UPDATE headers SET main_chain=0 WHERE height>=?1 AND hash<>?2 AND main_chain=1",params![height,hash])?;db.execute("INSERT OR REPLACE INTO headers(hash,height,prev,time,bits,work,raw,main_chain) VALUES(?1,?2,?3,?4,?5,?6,?7,1)",params![hash,height,prev,time,bits,work,raw])?;Ok(())}
 pub fn header_by_height(&self,height:u64)->Result<Option<Vec<u8>>>{let db=self.db.lock().unwrap();let r=db.query_row("SELECT raw FROM headers WHERE height=?1 AND main_chain=1",params![height],|r|r.get(0));match r{Ok(v)=>Ok(Some(v)),Err(rusqlite::Error::QueryReturnedNoRows)=>Ok(None),Err(e)=>Err(e.into())}} pub fn tip_hash(&self)->Result<Option<Vec<u8>>>{let db=self.db.lock().unwrap();let r=db.query_row("SELECT hash FROM blocks WHERE main_chain=1 ORDER BY height DESC LIMIT 1",[],|r|r.get(0));match r{Ok(v)=>Ok(Some(v)),Err(rusqlite::Error::QueryReturnedNoRows)=>Ok(None),Err(e)=>Err(e.into())}}
 pub fn header_height_by_hash(&self,hash:&[u8])->Result<Option<u64>>{let db=self.db.lock().unwrap();let r=db.query_row("SELECT height FROM headers WHERE hash=?1",params![hash],|r|r.get::<_,i64>(0));match r{Ok(v)=>Ok(Some(v as u64)),Err(rusqlite::Error::QueryReturnedNoRows)=>Ok(None),Err(e)=>Err(e.into())}}
 pub fn header_height(&self)->Result<Option<u64>>{let db=self.db.lock().unwrap();let r=db.query_row("SELECT MAX(height) FROM headers WHERE main_chain=1",[],|r|r.get::<_,Option<i64>>(0))?;Ok(r.map(|x|x as u64))}
 pub fn header_hash_by_height(&self,height:u64)->Result<Option<Vec<u8>>>{let db=self.db.lock().unwrap();let r=db.query_row("SELECT hash FROM headers WHERE height=?1 AND main_chain=1",params![height],|r|r.get(0));match r{Ok(v)=>Ok(Some(v)),Err(rusqlite::Error::QueryReturnedNoRows)=>Ok(None),Err(e)=>Err(e.into())}}
 pub fn header_work_by_height(&self,height:u64)->Result<Option<Vec<u8>>>{let db=self.db.lock().unwrap();let r=db.query_row("SELECT work FROM headers WHERE height=?1 AND main_chain=1",params![height],|r|r.get(0));match r{Ok(v)=>Ok(Some(v)),Err(rusqlite::Error::QueryReturnedNoRows)=>Ok(None),Err(e)=>Err(e.into())}}
 pub fn locator_hashes(&self)->Result<Vec<[u8;32]>>{let tip=self.header_height()?.unwrap_or(0);let mut heights=Vec::new();let mut h=tip;let mut step=1u64;while h>0&&heights.len()<10{heights.push(h);h=h.saturating_sub(1);}step=2;while h>0&&heights.len()<32{heights.push(h);h=h.saturating_sub(step);step=step.saturating_mul(2);}heights.push(0);heights.sort_unstable();heights.dedup();heights.reverse();let mut out=Vec::new();for h in heights{if let Some(v)=self.header_hash_by_height(h)?{if v.len()==32{let mut a=[0u8;32];a.copy_from_slice(&v);out.push(a);}}else if h==0{out.push(ycash_chain::genesis_hash_internal());}}Ok(out)}
 /// Writes a complete, consistent copy of the local chain database (headers, blocks, transactions --
 /// everything downloaded and validated so far) to `dest` using SQLite's `VACUUM INTO`. This is safe to
 /// call while the node keeps syncing: it runs under the same connection-wide lock as every other
 /// read/write here, so the copy can never observe a half-written row, at the cost of briefly pausing
 /// sync while the snapshot is written. `dest` must not already exist -- callers should pick a fresh
 /// path (e.g. a per-request temp file) and remove it themselves once they're done with the copy.
 pub fn export_snapshot(&self, dest: &Path) -> Result<()> {
  let path = match dest.to_str() { Some(s) => s, None => bail!("destination path is not valid UTF-8") };
  let db = self.db.lock().unwrap();
  db.execute("VACUUM INTO ?1", params![path])?;
  Ok(())
 }
}
