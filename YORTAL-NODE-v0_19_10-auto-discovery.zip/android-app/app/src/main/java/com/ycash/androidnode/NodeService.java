package com.ycash.androidnode;

import android.app.*;
import android.content.*;
import android.os.*;
import java.io.*;

public class NodeService extends Service {
    static final String START="START", STOP="STOP";
    static final String PREF_MANUAL_PEER="manual_peer";
    // Must match the filename placed under app/src/main/jniLibs/<abi>/ (see tools/package-node-binary.sh).
    // The "lib" prefix and ".so" suffix are required by Android's APK packager to treat this as a
    // native library, which is what makes it end up in an OS location apps are allowed to exec from.
    static final String NATIVE_LIB_NAME="libycashandroidnode.so";
    static final String LEGACY_ASSET_NAME="ycash-android-node";
    static java.lang.Process process;
    public void onCreate(){super.onCreate();}
    public int onStartCommand(Intent i,int flags,int id){
        if(i!=null && STOP.equals(i.getAction())){ stopNode(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY; }
        if(Build.VERSION.SDK_INT>=26) startForeground(7, notification());
        if(process==null || !process.isAlive()) startNode();
        return START_STICKY;
    }
    void startNode(){ new Thread(()->{
        File log=new File(getFilesDir(),"node.log");
        try {
            File bin=resolveBinary(log);
            File dataDir=getFilesDir();
            ProcessBuilder pb=new ProcessBuilder(bin.getAbsolutePath()); pb.directory(dataDir);
            java.util.Map<String,String> env=pb.environment();
            String dbPath=new File(dataDir,"ycash-node.sqlite").getAbsolutePath();
            env.put("YCASH_NODE_DB", dbPath);
            // Explicit, not just inferred from YCASH_NODE_DB's parent, so peer_supervisor()'s directory
            // choice can't silently change if the db path convention ever changes.
            env.put("YCASH_DATA_DIR", dataDir.getAbsolutePath());
            // Belt-and-braces: harmless for this Rust binary (it doesn't consult HOME), but keeps this
            // service safe if the binary is ever swapped back to something that does.
            env.put("HOME", dataDir.getAbsolutePath());
            String auto=discoverPeers(log);
            if(!auto.isEmpty()) env.put("YCASH_AUTO_PEER", auto);
            String manual=getSharedPreferences("ycash_node",MODE_PRIVATE).getString(PREF_MANUAL_PEER,"").trim();
            if(!manual.isEmpty()){
                // Accept "ip" or "ip:port"; default Ycash mainnet port 8833. Rust splits on , and ;
                StringBuilder sb=new StringBuilder();
                for(String part:manual.split("[,;\\s]+")){ if(part.isEmpty()) continue; if(sb.length()>0) sb.append(',');
                    sb.append(part.contains(":")?part:part+":8833"); }
                env.put("YCASH_PEER", sb.toString());
                appendLog(log, "Manual peers: "+sb);
            }
            pb.redirectErrorStream(true); pb.redirectOutput(log);
            process=pb.start();
            int exitCode=process.waitFor();
            appendLog(log, "PROCESS EXITED with code "+exitCode+
                (exitCode==0 ? "" : " (non-zero exit almost always means it never reached the point of opening the P2P/status ports)"));
        } catch(Exception e) {
            appendLog(log, "START ERROR: "+e+
                (e instanceof IOException ? " -- if this is a permission/exec error, the binary is most likely still in getFilesDir()/assets instead of jniLibs; Android 10+ blocks executing files an app wrote to its own private data directory." : ""));
        }
    }).start(); }

    /**
     * Prefer the binary Android's PackageManager installed from jniLibs (nativeLibraryDir) -- that's
     * the one location on API 29+ apps are still permitted to exec from. Only fall back to copying the
     * legacy asset into getFilesDir() when no packaged native binary is present, since that path is
     * known to fail with EACCES/"Permission denied" on modern Android and only ever worked on very old,
     * unenforced devices.
     */
    private File resolveBinary(File log) throws IOException {
        File nativeLib=new File(getApplicationInfo().nativeLibraryDir, NATIVE_LIB_NAME);
        if (nativeLib.exists()) {
            return nativeLib;
        }
        appendLog(log, "WARNING: "+NATIVE_LIB_NAME+" not found in nativeLibraryDir; falling back to legacy "+
            "assets+chmod approach, which is expected to fail with a permission/exec error on Android 10+.");
        File bin=new File(getFilesDir(), LEGACY_ASSET_NAME);
        if(!bin.exists()){ try(InputStream in=getAssets().open(LEGACY_ASSET_NAME); OutputStream out=new FileOutputStream(bin)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);} }
        bin.setExecutable(true,false);
        return bin;
    }

    /**
     * Automatic peer discovery, no manual IP needed:
     *  1. seed.ycash.xyz through the phone's DNS (what ycashd does),
     *  2. the same name through DNS-over-HTTPS (Cloudflare, Google), in case the mobile
     *     network's DNS is failing or filtering it,
     *  3. IPs of known Ycash service hosts, tried on P2P port 8833, because operators often run
     *     ycashd on the same server. These are best guesses; the Rust node only counts a peer
     *     after a real VERSION/VERACK handshake, so a wrong guess just fails and is skipped.
     */
    private String discoverPeers(File log){
        java.util.LinkedHashSet<String> out=new java.util.LinkedHashSet<>();
        String[] seeds={"seed.ycash.xyz"};
        String[] serviceHosts={"ycash.xyz","lite.ycash.xyz","lightwalletd.ycash.xyz","node.ycash.xyz","yecblockexplorer.com"};
        for(String h:seeds){ addAll(out, systemDns(h), log, "system DNS "+h); addAll(out, doh(h), log, "DoH "+h); }
        for(String h:serviceHosts){ java.util.List<String> ips=systemDns(h); if(ips.isEmpty()) ips=doh(h); addAll(out, ips, log, "service host "+h); }
        StringBuilder sb=new StringBuilder();
        for(String ip:out){ if(sb.length()>0) sb.append(','); sb.append(ip).append(":8833"); }
        appendLog(log, "Auto-discovery candidates: "+(sb.length()==0?"none":sb));
        return sb.toString();
    }
    private static void addAll(java.util.Set<String> out, java.util.List<String> ips, File log, String label){
        appendLog(log, label+" -> "+(ips.isEmpty()?"no result":ips)); out.addAll(ips);
    }
    private static java.util.List<String> systemDns(String host){
        java.util.List<String> r=new java.util.ArrayList<>();
        try{ for(java.net.InetAddress a:java.net.InetAddress.getAllByName(host)) if(a instanceof java.net.Inet4Address) r.add(a.getHostAddress()); }catch(Exception ignored){}
        return r;
    }
    private static java.util.List<String> doh(String host){
        String[] urls={"https://cloudflare-dns.com/dns-query?type=A&name=","https://dns.google/resolve?type=A&name="};
        java.util.List<String> r=new java.util.ArrayList<>();
        for(String u:urls){
            try{
                java.net.HttpURLConnection c=(java.net.HttpURLConnection)new java.net.URL(u+host).openConnection();
                c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setRequestProperty("Accept","application/dns-json");
                StringBuilder body=new StringBuilder();
                try(BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()))){ String line; while((line=br.readLine())!=null) body.append(line); }
                java.util.regex.Matcher m=java.util.regex.Pattern.compile("\"type\"\\s*:\\s*1\\s*,[^}]*?\"data\"\\s*:\\s*\"(\\d+\\.\\d+\\.\\d+\\.\\d+)\"").matcher(body);
                while(m.find()) if(!r.contains(m.group(1))) r.add(m.group(1));
                if(!r.isEmpty()) break;
            }catch(Exception ignored){}
        }
        return r;
    }

    private static void appendLog(File log, String line) {
        try (FileWriter w=new FileWriter(log, true)) { w.write(line+"\n"); } catch(Exception ignored) {}
    }
    void stopNode(){ if(process!=null && process.isAlive()) process.destroy(); process=null; }
    Notification notification(){ String ch="ycash-node"; if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(ch,"Ycash Node",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(c);} return new Notification.Builder(this,ch).setContentTitle("Ycash Android Node").setContentText("Ycash node is running").setSmallIcon(android.R.drawable.stat_sys_download_done).setOngoing(true).build(); }
    public IBinder onBind(Intent i){return null;} public void onDestroy(){stopNode();super.onDestroy();}
}
