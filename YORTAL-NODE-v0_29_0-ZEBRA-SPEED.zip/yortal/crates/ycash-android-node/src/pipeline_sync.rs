//! YORTAL v0.29 "ZEBRA-SPEED" parallel block pipeline.
//!
//! Same staged shape as Zebra's sync, built on the existing Ycash consensus
//! code. NO consensus rule is added, removed or reordered -- only *where* and
//! *when* each existing check runs changes.
//!
//! ```text
//!  up to 12 peers            N verifier threads          1 committer thread
//!  ┌───────────────┐  jobs   ┌──────────────────┐ ranges ┌─────────────────────┐
//!  │ claim range   │ ──────► │ validate_for_    │ ─────► │ reorder buffer      │
//!  │ getdata ≤16   │ bounded │ commit_opts()    │        │ contiguous ranges → │
//!  │ hash-match    │ channel │ (Equihash-free:  │        │ ONE commit_blocks_  │
//!  │ load ctx      │         │  merkle, Sapling │        │ batch() of ≤256 blk │
//!  └───────────────┘         │  proofs, sigs)   │        │ (UTXO/nullifier/    │
//!        ▲                   └──────────────────┘        │  anchor/value, in   │
//!        └──── backpressure: channel full = peers wait   │  strict height order│
//!                                                        └─────────────────────┘
//! ```
//!
//! Stage 1 (network): each connected peer claims a disjoint ≤16-block range
//! (ycashd's MAX_BLOCKS_IN_TRANSIT_PER_PEER), downloads it, matches each block
//! to our PoW-verified header by hash, and loads everything a verifier needs
//! (median-time-past, chain work, prev hash) in three range queries. It does
//! no validation, so the socket goes straight back to fetching.
//!
//! Stage 2 (verify): contextless checks are independent per block, so they run
//! on every core. Verifier threads never touch SQLite, so they never wait on a
//! commit.
//!
//! Stage 3 (commit): exactly one thread applies blocks, strictly in height
//! order, coalescing contiguous validated ranges into larger batches -- far
//! fewer SQLite transactions than one per 16-block range. All stateful rules
//! still run inside `State::commit_blocks_batch`, unchanged.
//!
//! Tunables (env): YORTAL_VERIFY_THREADS, YORTAL_LOOKAHEAD, YORTAL_COMMIT_BATCH.

use std::collections::{BTreeMap, HashMap, HashSet};
use std::io::ErrorKind;
use std::net::TcpStream;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::mpsc::{sync_channel, Receiver, SyncSender};
use std::sync::{Arc, Condvar, Mutex};
use std::time::{Duration, Instant};

use ycash_chain::{genesis_hash_internal, txid};
use ycash_consensus::{validate_for_commit_opts, Context, GENESIS_TIME, UNSUPPORTED_PREFIX};
use ycash_network::runtime::{getdata_payload, unix_time};
use ycash_state::pipeline::{range_scheduler::RangeLease, AdaptiveConfig, PipelineEngine};
use ycash_state::{BlockCommit, State};

use crate::runtime::SharedState;
use crate::{is_timeout, read_message, send};

/// Assume-valid checkpoint: the last mainnet entry in `checkpointData`
/// (ycash 4.5.0 `src/chainparams.cpp`). Like ycashd with checkpoints enabled
/// (its default), blocks at or below it skip transparent script checks and
/// Sprout Groth16 proofs; PoW, merkle, coinbase, UTXO/value accounting,
/// anchors, nullifiers, joinSplitSig and Sapling proofs are still verified.
/// It only activates when our PoW-verified header at that height matches.
/// Set YCASH_FULL_VERIFY=1 to verify every script from genesis.
pub const ASSUME_VALID_HEIGHT: u64 = 2_250_000;
pub const ASSUME_VALID_HASH_DISPLAY: &str = "000003f98b7497fdcd8a6b6d10a93a887c5d47127e24a9dc3a40cb65754d21e7";

/// Heights planned per `ensure_planned` call (split into ≤16-block ranges).
const PLAN_WINDOW: usize = 256;

fn env_usize(name: &str) -> Option<usize> {
    std::env::var(name).ok().and_then(|v| v.trim().parse::<usize>().ok())
}

/// Verifier thread count: all cores but one (leave one for networking/SQLite),
/// capped at 8 so a phone doesn't cook itself.
pub fn verify_threads() -> usize {
    if let Some(n) = env_usize("YORTAL_VERIFY_THREADS") {
        return n.clamp(1, 32);
    }
    let cores = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(2);
    cores.saturating_sub(1).clamp(1, 8)
}

/// How far ahead of the last committed height blocks may be fetched/verified.
/// Bounds memory: validated-but-uncommitted blocks live in RAM.
fn lookahead() -> u64 {
    env_usize("YORTAL_LOOKAHEAD").unwrap_or(2048).clamp(64, 50_000) as u64
}

/// Max blocks folded into one SQLite transaction by the committer.
fn commit_batch_blocks() -> usize {
    env_usize("YORTAL_COMMIT_BATCH").unwrap_or(256).clamp(16, 4096)
}

fn assume_valid_active(state: &State) -> bool {
    if std::env::var("YCASH_FULL_VERIFY").ok().as_deref() == Some("1") { return false; }
    if ASSUME_VALID_HEIGHT == 0 || ASSUME_VALID_HASH_DISPLAY.len() != 64 { return false; }
    let Ok(bytes) = hex::decode(ASSUME_VALID_HASH_DISPLAY) else { return false };
    let mut internal = [0u8; 32];
    for i in 0..32 { internal[i] = bytes[31 - i]; }
    matches!(state.header_hash_by_height(ASSUME_VALID_HEIGHT), Ok(Some(v)) if v.as_slice() == internal)
}

/// Error kind used for "this node can't validate this block yet". Not the
/// peer's fault: don't release/retry the range and don't drop the connection.
pub fn is_node_unsupported(e: &std::io::Error) -> bool {
    e.kind() == ErrorKind::Unsupported
}

fn pipeline_log(stage: &str, detail: impl std::fmt::Display) {
    eprintln!("[PIPELINE] stage={} {}", stage, detail);
}

/// A downloaded, hash-matched range plus every piece of context the verifier
/// needs, so verifier threads are pure CPU.
struct VerifyJob {
    lease: RangeLease,
    peer: String,
    /// (height, expected hash, median-time-past, chain work, raw block), ascending.
    blocks: Vec<(u64, [u8; 32], u32, [u8; 32], Vec<u8>)>,
    prev_of_start: [u8; 32],
    assume_valid_ok: bool,
    bytes: u64,
}

type Buffered = (RangeLease, Vec<BlockCommit>, u64);

struct Inner {
    engine: PipelineEngine,
    next_commit: u64,
    buffered: BTreeMap<u64, Buffered>,
    planned_up_to: u64,
    halted: Option<String>,
    /// Peers that served a block failing contextless validation. Their session
    /// is closed on the next claim attempt (previously the error dropped the
    /// connection directly; the verifier runs off the peer thread now).
    misbehaving: HashSet<String>,
    /// Ranges sitting in the verify channel or being verified.
    verifying: u64,
}

#[derive(Clone)]
pub struct BlockPipeline {
    inner: Arc<Mutex<Inner>>,
    commit_cv: Arc<Condvar>,
    jobs: Arc<Mutex<Option<SyncSender<VerifyJob>>>>,
    started: Arc<AtomicBool>,
    verified_blocks: Arc<AtomicU64>,
}

impl BlockPipeline {
    /// `next_commit` should be the current validated block tip + 1.
    pub fn new(next_commit: u64) -> Self {
        pipeline_log("INIT", format_args!(
            "mode=PARALLEL next_commit={} verify_threads={} lookahead={} commit_batch={} assume_valid_height={} full_verify={}",
            next_commit, verify_threads(), lookahead(), commit_batch_blocks(), ASSUME_VALID_HEIGHT,
            std::env::var("YCASH_FULL_VERIFY").ok().as_deref() == Some("1")
        ));
        Self {
            inner: Arc::new(Mutex::new(Inner {
                engine: PipelineEngine::new(AdaptiveConfig {
                    min_window: PLAN_WINDOW,
                    initial_window: PLAN_WINDOW,
                    max_window: PLAN_WINDOW,
                    step: 1,
                    high_watermark: 0.90,
                    low_watermark: 0.55,
                }),
                next_commit,
                buffered: BTreeMap::new(),
                planned_up_to: next_commit.saturating_sub(1),
                halted: None,
                misbehaving: HashSet::new(),
                verifying: 0,
            })),
            commit_cv: Arc::new(Condvar::new()),
            jobs: Arc::new(Mutex::new(None)),
            started: Arc::new(AtomicBool::new(false)),
            verified_blocks: Arc::new(AtomicU64::new(0)),
        }
    }

    /// Spawn the verifier pool and the ordered committer. Idempotent.
    pub fn start(&self, state: Arc<State>, live: SharedState) {
        if self.started.swap(true, Ordering::SeqCst) { return; }
        let n = verify_threads();
        // Bounded: when verifiers fall behind, peer threads block on send
        // instead of piling raw blocks into RAM.
        let (tx, rx) = sync_channel::<VerifyJob>(n * 2);
        *self.jobs.lock().unwrap() = Some(tx);
        let rx = Arc::new(Mutex::new(rx));
        for i in 0..n {
            let me = self.clone();
            let rx = rx.clone();
            let live = live.clone();
            std::thread::Builder::new()
                .name(format!("yortal-verify-{i}"))
                .spawn(move || me.verifier_loop(rx, live))
                .expect("spawn verifier");
        }
        let me = self.clone();
        std::thread::Builder::new()
            .name("yortal-commit".into())
            .spawn(move || me.committer_loop(state, live))
            .expect("spawn committer");
        pipeline_log("START", format_args!("verifier_threads={} committer=1", n));
    }

    /// Make sure claimable ranges exist up to `chain_tip`. Cheap to call often.
    pub fn ensure_planned(&self, chain_tip: u64, workers: usize) {
        let mut g = self.inner.lock().unwrap();
        let next_commit = g.next_commit;
        g.engine.requeue_if_quarantined_at(next_commit);
        if chain_tip <= g.planned_up_to { return; }
        // Backpressure: never plan further than `lookahead` past the commit tip.
        if g.planned_up_to.saturating_sub(g.next_commit).saturating_add(1) >= lookahead() {
            return;
        }
        let next = g.next_commit.max(g.planned_up_to.saturating_add(1));
        if next > chain_tip { return; }
        let ids = g.engine.plan_parallel_ranges(next, chain_tip, workers.max(1));
        let window = g.engine.window();
        g.planned_up_to = next.saturating_add(window.saturating_sub(1)).min(chain_tip);
        pipeline_log("PLAN", format_args!(
            "next={} planned_up_to={} ranges={} chain_tip={} next_commit={} in_flight={}",
            next, g.planned_up_to, ids.len(), chain_tip, g.next_commit, g.engine.outstanding_heights()
        ));
    }

    /// Claim one range for this peer, download it, and hand it to the verifier
    /// pool. Returns `Ok(true)` if a range was fetched, `Ok(false)` if nothing
    /// was claimable. An `Err` means the session should close.
    pub fn run_once(
        &self,
        stream: &mut TcpStream,
        state: &Arc<State>,
        live: &SharedState,
        peer_label: &str,
        peer_height: Option<u64>,
    ) -> std::io::Result<bool> {
        let max_end = peer_height.unwrap_or(u64::MAX);
        let lease = {
            let mut g = self.inner.lock().unwrap();
            if g.misbehaving.remove(peer_label) {
                return Err(ioe("peer served a block that failed validation; disconnecting"));
            }
            if let Some(reason) = g.halted.clone() {
                drop(g);
                live.write().unwrap().message = reason;
                return Ok(false);
            }
            g.engine.claim_upto(peer_label, max_end)
        };
        let Some(lease) = lease else { return Ok(false) };

        match fetch_range(stream, state, &lease) {
            Ok(mut job) => {
                job.peer = peer_label.to_string();
                let sender = self.jobs.lock().unwrap().clone();
                let Some(sender) = sender else {
                    // Pool not started: give the range back rather than lose it.
                    self.inner.lock().unwrap().engine.requeue_lease(lease.id);
                    return Ok(false);
                };
                self.inner.lock().unwrap().verifying += 1;
                if sender.send(job).is_err() {
                    let mut g = self.inner.lock().unwrap();
                    g.verifying = g.verifying.saturating_sub(1);
                    g.engine.requeue_lease(lease.id);
                    return Ok(false);
                }
                self.publish(live, None);
                Ok(true)
            }
            Err(e) => {
                pipeline_log("RANGE_ERROR", format_args!(
                    "peer={} range={}..{} kind={:?} error={}",
                    peer_label, lease.range.start, lease.range.end, e.kind(), e
                ));
                {
                    let mut g = self.inner.lock().unwrap();
                    g.engine.release(lease.id);
                    let nc = g.next_commit;
                    g.engine.requeue_if_quarantined_at(nc);
                }
                self.publish(live, None);
                Err(e)
            }
        }
    }

    fn verifier_loop(&self, rx: Arc<Mutex<Receiver<VerifyJob>>>, live: SharedState) {
        loop {
            let job = { let r = rx.lock().unwrap(); r.recv() };
            let Ok(job) = job else { return };
            let (start, end) = (job.lease.range.start, job.lease.range.end);
            let peer = job.peer.clone();
            let started = Instant::now();
            let result = verify_job(job);
            let mut g = self.inner.lock().unwrap();
            g.verifying = g.verifying.saturating_sub(1);
            match result {
                Ok((lease, commits, bytes)) => {
                    self.verified_blocks.fetch_add(commits.len() as u64, Ordering::Relaxed);
                    pipeline_log("VERIFIED", format_args!(
                        "range={}..{} blocks={} ms={} buffered={}",
                        start, end, commits.len(), started.elapsed().as_millis(), g.buffered.len() + 1
                    ));
                    g.buffered.insert(lease.range.start, (lease, commits, bytes));
                    drop(g);
                    self.commit_cv.notify_one();
                }
                Err((lease, e)) if is_node_unsupported(&e) => {
                    let reason = format!("block sync halted: {}", e);
                    pipeline_log("UNSUPPORTED", format_args!("range={}..{} error={}", start, end, e));
                    g.engine.requeue_lease(lease.id);
                    g.halted = Some(reason.clone());
                    drop(g);
                    let mut st = live.write().unwrap();
                    st.last_error = reason.clone();
                    st.message = reason;
                }
                Err((lease, e)) => {
                    pipeline_log("VALIDATION_ERROR", format_args!(
                        "peer={} range={}..{} error={}", peer, start, end, e
                    ));
                    g.engine.release(lease.id);
                    let nc = g.next_commit;
                    g.engine.requeue_if_quarantined_at(nc);
                    g.misbehaving.insert(peer.clone());
                    drop(g);
                    live.write().unwrap().last_error = format!("{} block validation: {}", peer, e);
                }
            }
        }
    }

    fn committer_loop(&self, state: Arc<State>, live: SharedState) {
        let max_blocks = commit_batch_blocks();
        loop {
            // Take the longest run of contiguous validated ranges at next_commit.
            let batch: Vec<Buffered> = {
                let mut g = self.inner.lock().unwrap();
                loop {
                    let mut out = Vec::new();
                    if g.halted.is_none() {
                        let mut expected = g.next_commit;
                        let mut count = 0usize;
                        while count < max_blocks {
                            let Some(item) = g.buffered.remove(&expected) else { break };
                            expected = item.0.range.end + 1;
                            count += item.1.len();
                            out.push(item);
                        }
                    }
                    if !out.is_empty() { break out; }
                    g = self.commit_cv.wait_timeout(g, Duration::from_secs(1)).unwrap().0;
                }
            };

            let first = batch[0].0.range.start;
            let last = batch[batch.len() - 1].0.range.end;
            // Move (not clone) the raw blocks into one commit vector.
            let mut leases: Vec<(RangeLease, u64)> = Vec::with_capacity(batch.len());
            let mut blocks: Vec<BlockCommit> = Vec::new();
            let mut bytes = 0u64;
            for (lease, b, n) in batch {
                leases.push((lease, b.len() as u64));
                blocks.extend(b);
                bytes += n;
            }
            let started = Instant::now();
            if let Err(e) = state.commit_blocks_batch(&blocks) {
                // Blocks matched PoW-verified headers and passed contextless
                // checks, so a stateful failure is deterministic. Halt.
                let reason = format!("block sync halted: commit {}..{} failed: {}", first, last, e);
                pipeline_log("COMMIT_ERROR", &reason);
                {
                    let mut g = self.inner.lock().unwrap();
                    for (lease, _) in &leases { g.engine.requeue_lease(lease.id); }
                    g.halted = Some(reason.clone());
                }
                let mut st = live.write().unwrap();
                st.last_error = reason.clone();
                st.message = reason;
                continue;
            }
            let commit_ms = started.elapsed().as_millis() as u64;
            {
                let mut g = self.inner.lock().unwrap();
                for (lease, n) in &leases { g.engine.complete(lease.id, *n, 0); }
                g.next_commit = last + 1;
            }
            // Wake any committer wait immediately if more is already buffered.
            self.commit_cv.notify_one();
            let rate = blocks.len() as u64 * 1000 / commit_ms.max(1);
            pipeline_log("COMMIT_OK", format_args!(
                "range={}..{} blocks={} ranges={} commit_ms={} blocks_per_sec={}",
                first, last, blocks.len(), leases.len(), commit_ms, rate
            ));
            let tip_time = state.header_time(last).ok().flatten().unwrap_or(0);
            {
                let mut st = live.write().unwrap();
                st.local_height = last;
                st.tip_time = tip_time;
                st.blocks_received = st.blocks_received.saturating_add(blocks.len() as u64);
                st.blocks_validated = st.blocks_validated.saturating_add(blocks.len() as u64);
                st.block_bytes_received = st.block_bytes_received.saturating_add(bytes);
                st.db_commits = st.db_commits.saturating_add(1);
                st.db_commit_ms_total = st.db_commit_ms_total.saturating_add(commit_ms);
                st.txs_indexed = st.txs_indexed.saturating_add(blocks.iter().map(|b| b.txs.len() as u64).sum());
                st.batch_size = blocks.len() as u64;
                st.last_commit_unix = unix_time();
            }
            self.publish(&live, Some(format!(
                "committed {}..{} ({} blocks in 1 tx, {} verifier threads)",
                first, last, blocks.len(), verify_threads()
            )));
        }
    }

    /// Mirror pipeline counters to the dashboard.
    fn publish(&self, live: &SharedState, message: Option<String>) {
        let (snap, outstanding, queue) = {
            let g = self.inner.lock().unwrap();
            (g.engine.snapshot(), g.engine.outstanding_heights(), g.verifying + g.buffered.len() as u64)
        };
        let mut st = live.write().unwrap();
        st.blocks_in_flight = outstanding;
        st.validation_queue = queue;
        st.active_block_workers = verify_threads() as u64;
        st.current_window = snap.window;
        st.completed_ranges = snap.completed_ranges;
        st.retried_ranges = snap.retried_ranges;
        st.quarantined_ranges = snap.quarantined_ranges;
        if let Some(m) = message { st.message = m; }
    }
}

/// Block hash straight from the raw block bytes (sha256d of the header incl.
/// Equihash solution).
fn raw_block_hash(raw: &[u8]) -> Option<[u8; 32]> {
    use sha2::{Digest, Sha256};
    let mut i = 140usize;
    let sol_len = ycash_network::runtime::read_compact_size(raw, &mut i).ok()? as usize;
    let end = i.checked_add(sol_len)?;
    let header = raw.get(..end)?;
    let a = Sha256::digest(header);
    let b = Sha256::digest(a);
    let mut out = [0u8; 32];
    out.copy_from_slice(&b);
    Some(out)
}

/// Median-time-past for every height in `start..=end`, computed exactly like
/// `crate::mtp` (median of the 11 preceding header times, with the genesis time
/// standing in below height 12) but from a single range query.
fn mtp_range(state: &State, start: u64, end: u64) -> std::io::Result<HashMap<u64, u32>> {
    let from = start.saturating_sub(11).max(1);
    let rows = state.header_times_range(from, end).map_err(|e| ioe(&e.to_string()))?;
    let times: HashMap<u64, u32> = rows.into_iter().collect();
    let mut out = HashMap::new();
    for h in start..=end {
        let s = h.saturating_sub(11);
        let mut v = Vec::with_capacity(11);
        if s == 0 && h > 0 { v.push(GENESIS_TIME); }
        for x in s.max(1)..h {
            if let Some(t) = times.get(&x) { v.push(*t); }
        }
        let m = if v.is_empty() { 0 } else { v.sort_unstable(); v[v.len() / 2] };
        out.insert(h, m);
    }
    Ok(out)
}

/// Stage 1: download a leased range and attach verifier context. No validation.
fn fetch_range(stream: &mut TcpStream, state: &Arc<State>, lease: &RangeLease) -> std::io::Result<VerifyJob> {
    let (start, end) = (lease.range.start, lease.range.end);
    let hashes = state.header_hashes_range(start, end).map_err(|e| ioe(&e.to_string()))?;
    let works = state.header_works_range(start, end).map_err(|e| ioe(&e.to_string()))?;
    let mtps = mtp_range(state, start, end)?;
    let mut requests = Vec::with_capacity((end - start + 1) as usize);
    for h in start..=end {
        let hash = hashes.get(&h).copied().ok_or_else(|| ioe("missing header for claimed range"))?;
        requests.push((h, hash));
    }
    let prev_of_start: [u8; 32] = if start == 1 {
        genesis_hash_internal()
    } else {
        state.header_hash_by_height(start - 1)
            .map_err(|e| ioe(&e.to_string()))?
            .and_then(|v| <[u8; 32]>::try_from(v.as_slice()).ok())
            .ok_or_else(|| ioe("missing previous header"))?
    };
    let assume_valid_ok = start <= ASSUME_VALID_HEIGHT && assume_valid_active(state);
    if assume_valid_ok { state.set_assume_valid_height(ASSUME_VALID_HEIGHT); }

    let by_hash: HashMap<[u8; 32], u64> = requests.iter().map(|(h, hash)| (*hash, *h)).collect();
    let want: Vec<[u8; 32]> = requests.iter().map(|(_, h)| *h).collect();
    send(stream, "getdata", &getdata_payload(&want)).map_err(|e| phase_error("getdata send", e))?;

    let mut got: BTreeMap<u64, Vec<u8>> = BTreeMap::new();
    let mut bytes = 0u64;
    let mut idle = 0u32;
    // Progress deadline: at least one requested block every 180s
    // (ycashd's post-Blossom minimum block timeout is 150s).
    const PROGRESS_TIMEOUT: Duration = Duration::from_secs(180);
    let mut deadline = Instant::now() + PROGRESS_TIMEOUT;
    while got.len() < requests.len() {
        if Instant::now() >= deadline {
            return Err(ioe(&format!(
                "peer made no progress on range {}..{} for 180s (received {}/{} blocks)",
                start, end, got.len(), requests.len()
            )));
        }
        let (cmd, payload) = match read_message(stream) {
            Ok(v) => v,
            Err(e) if is_timeout(&e) => {
                idle += 1;
                if idle >= 8 { return Err(ioe("peer stopped sending blocks for claimed range")); }
                continue;
            }
            Err(e) => return Err(phase_error("block stream read", e)),
        };
        idle = 0;
        if cmd == "ping" {
            send(stream, "pong", &payload).map_err(|e| phase_error("block-stream pong send", e))?;
            continue;
        }
        if cmd == "notfound" {
            return Err(ioe(&format!("peer sent notfound for range {}..{}", start, end)));
        }
        if cmd != "block" { continue; }
        let Some(height) = raw_block_hash(&payload).and_then(|h| by_hash.get(&h).copied()) else { continue };
        if got.contains_key(&height) { continue; }
        deadline = Instant::now() + PROGRESS_TIMEOUT;
        bytes += payload.len() as u64;
        got.insert(height, payload);
    }

    let mut blocks = Vec::with_capacity(requests.len());
    for (h, hash) in requests {
        let raw = got.remove(&h).ok_or_else(|| ioe("range assembly lost a block"))?;
        let m = *mtps.get(&h).unwrap_or(&0);
        let w = works.get(&h).copied().ok_or_else(|| ioe("missing header chain work"))?;
        blocks.push((h, hash, m, w, raw));
    }
    Ok(VerifyJob { lease: lease.clone(), peer: String::new(), blocks, prev_of_start, assume_valid_ok, bytes })
}

/// Stage 2: contextless validation of one range. Pure CPU, no DB.
fn verify_job(job: VerifyJob) -> Result<Buffered, (RangeLease, std::io::Error)> {
    let VerifyJob { lease, blocks, prev_of_start, assume_valid_ok, bytes, .. } = job;
    let mut out = Vec::with_capacity(blocks.len());
    let mut prev = prev_of_start;
    for (height, hash, mtp_time, work, raw) in blocks {
        let ctx = Context { height, prev_height: height.saturating_sub(1), median_time_past: mtp_time };
        let assume_valid = height <= ASSUME_VALID_HEIGHT && assume_valid_ok;
        let validated = match validate_for_commit_opts(&raw, ctx, assume_valid) {
            Ok(v) => v,
            Err(e) => {
                let msg = format!("{e:?}");
                let kind = if msg.contains(UNSUPPORTED_PREFIX) { ErrorKind::Unsupported } else { ErrorKind::InvalidData };
                return Err((lease, std::io::Error::new(kind, format!("block {height}: {msg}"))));
            }
        };
        if validated.txs.is_empty() {
            return Err((lease, ioe("consensus decoder returned zero transactions")));
        }
        let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
        out.push(BlockCommit { height, hash, prev, work, raw, txs });
        prev = hash;
    }
    Ok((lease, out, bytes))
}

fn ioe(s: &str) -> std::io::Error {
    std::io::Error::new(ErrorKind::InvalidData, s.to_string())
}

fn phase_error(phase: &str, e: std::io::Error) -> std::io::Error {
    std::io::Error::new(e.kind(), format!("{}: {}", phase, e))
}
