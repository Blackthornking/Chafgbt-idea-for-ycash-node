plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "org.ycash.node"
    compileSdk = 35

    defaultConfig {
        applicationId = "org.ycash.node"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-node"

        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildFeatures { buildConfig = true }

    sourceSets {
        getByName("main") {
            assets.srcDir("src/main/node-assets")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
