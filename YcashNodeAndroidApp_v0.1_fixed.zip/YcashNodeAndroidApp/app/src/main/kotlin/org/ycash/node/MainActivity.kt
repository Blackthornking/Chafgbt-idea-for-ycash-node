package org.ycash.node

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private var daemon: Process? = null
    private lateinit var dataDir: File

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dataDir = File(filesDir, "ycash")
        dataDir.mkdirs()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        val title = TextView(this).apply {
            text = "Ycash Node"
            textSize = 28f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.BLACK)
            setPadding(16, 16, 16, 16)
        }
        status = TextView(this).apply {
            text = "Stopped\nData: ${dataDir.absolutePath}"
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }
        val start = Button(this).apply {
            text = "Start node"
            setOnClickListener { startNode() }
        }
        val stop = Button(this).apply {
            text = "Stop node"
            setOnClickListener { stopNode() }
        }
        val logs = TextView(this).apply {
            textSize = 13f
            setPadding(0, 24, 0, 0)
        }
        root.addView(title)
        root.addView(status)
        root.addView(start)
        root.addView(stop)
        root.addView(logs)
        setContentView(root)

        lifecycleScope.launch(Dispatchers.IO) {
            val bin = installDaemon()
            runOnUiThread {
                status.text = if (bin != null)
                    "Ready\n${bin.absolutePath}\nData: ${dataDir.absolutePath}"
                else
                    "Daemon binary not packaged. Build/copy ycashd first."
            }
        }
    }

    private fun installDaemon(): File? {
        val asset = "ycashd"
        return try {
            assets.open(asset).use { input ->
                val out = File(filesDir, "ycashd")
                FileOutputStream(out).use { output -> input.copyTo(output) }
                out.setExecutable(true, false)
                out
            }
        } catch (_: Exception) { null }
    }

    private fun startNode() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val bin = File(filesDir, "ycashd")
                if (!bin.exists()) throw IllegalStateException("ycashd is not installed")
                if (daemon?.isAlive == true) return@launch
                val proc = ProcessBuilder(
                    bin.absolutePath,
                    "-datadir=${dataDir.absolutePath}",
                    "-daemon=0",
                    "-listen=1",
                    "-discover=1",
                    "-rpcbind=127.0.0.1",
                    "-rpcallowip=127.0.0.1"
                ).redirectErrorStream(true).start()
                daemon = proc
                runOnUiThread { status.text = "Running — syncing P2P chain…" }
                proc.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { line -> runOnUiThread { status.text = "Running\n$line" } }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Start failed: ${e.message}" }
            }
        }
    }

    private fun stopNode() {
        daemon?.destroy()
        daemon = null
        status.text = "Stopped"
    }

    override fun onDestroy() {
        daemon?.destroy()
        super.onDestroy()
    }
}
