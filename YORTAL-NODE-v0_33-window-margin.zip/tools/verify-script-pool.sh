#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

state="$ROOT/crates/state/src/chainstate.rs"
config="$ROOT/config/pipeline.toml"
[[ -f "$state" ]] || { echo "ERROR: missing $state" >&2; exit 1; }

grep -q 'rayon.workspace = true' "$ROOT/crates/state/Cargo.toml" || { echo "ERROR: rayon dependency missing" >&2; exit 1; }
grep -q 'OnceLock<rayon::ThreadPool>' "$state" || { echo "ERROR: persistent script pool missing" >&2; exit 1; }
grep -q 'par_iter().enumerate()' "$state" || { echo "ERROR: per-input dynamic scheduling missing" >&2; exit 1; }
if grep -q 'std::thread::scope' "$state"; then
  echo "ERROR: per-transaction thread spawning remains in script verifier" >&2
  exit 1
fi
grep -q 'available_parallelism' "$state" || { echo "ERROR: adaptive CPU sizing missing" >&2; exit 1; }
grep -q 'YORTAL_SCRIPT_WORKERS' "$state" || { echo "ERROR: verifier worker override missing" >&2; exit 1; }
grep -q 'YORTAL_SCRIPT_PARALLEL_THRESHOLD' "$state" || { echo "ERROR: verifier threshold override missing" >&2; exit 1; }
# v0.33 removed the process-wide ScriptPermit mutex on purpose: every input in
# the parallel loop took it twice (acquire + telemetry read), which serialised
# the inside of the parallel section against itself. The ordered state gate
# now guarantees exactly one thread ever drives this pool, and the pool's own
# thread count already bounds concurrency, so no separate gate is needed.
# See YORTAL_V0_33_PIPELINE_DESIGN.md, "Fixed now: the permit gate".
if grep -q 'ScriptPermit' "$state"; then
  echo "ERROR: ScriptPermit gate was reintroduced; v0.33 removed it because it self-serialised the pool" >&2
  exit 1
fi
grep -q 'current_num_threads' "$state" || { echo "ERROR: script pool telemetry missing" >&2; exit 1; }

# v0.33 deleted the range scheduler entirely (crates/state/src/pipeline/ and
# pipeline_sync.rs are gone, not renamed): no AdaptiveController, RangeScheduler,
# RangeLease or plan_parallel_ranges remain, and no config key re-enables them.
if grep -RInE 'AdaptiveController|RangeScheduler|RangeLease|RangeId|ValidatedRange|plan_parallel_ranges' \
    "$ROOT/crates" "$ROOT/config" "$ROOT/android-app/app/src/main/java" 2>/dev/null; then
  echo "ERROR: range-scheduler identifiers found; v0.33 removed the range scheduler" >&2
  exit 1
fi

# Fixed 48-block transport window and the new (non-adaptive-range) transport
# settings, replacing the old max_validation_workers/max_inflight_ranges/
# max_range_len keys that no longer exist in config/pipeline.toml.
grep -Eq '^max_blocks_in_transit_per_peer[[:space:]]*=[[:space:]]*48([[:space:]]*(#.*)?)?$' "$config" || {
  echo "ERROR: fixed 48-block transport window setting missing or changed" >&2
  exit 1
}
grep -q 'max_blocks_in_flight' "$config" || { echo "ERROR: global in-flight block ceiling missing" >&2; exit 1; }
grep -q 'max_prospective_blocks' "$config" || { echo "ERROR: prospective block ceiling missing" >&2; exit 1; }
grep -q 'verifier_workers' "$config" || { echo "ERROR: semantic verification worker setting missing" >&2; exit 1; }
grep -q 'script_workers' "$config" || { echo "ERROR: script verification worker setting missing" >&2; exit 1; }

echo "PASS: consensus-safe script pool and ordered pipeline checks present"
