//! Peer connections and their health.
//!
//! The peer manager knows who is connected and how much work each peer owes.
//! It has no opinion about the canonical chain: a peer cannot make a block
//! valid, and no peer's response is treated as the chain.

use std::collections::HashMap;
use std::sync::Mutex;

#[derive(Clone, Debug, Default)]
pub struct PeerStats {
    pub in_flight: usize,
    pub requested: u64,
    pub received: u64,
    pub timeouts: u64,
}

/// Peer connections and their health. Owns no consensus decision.
#[derive(Default)]
pub struct PeerManager {
    peers: Mutex<HashMap<String, PeerStats>>,
}

impl PeerManager {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn connected(&self, peer: &str) {
        if let Ok(mut peers) = self.peers.lock() {
            peers.entry(peer.to_string()).or_default();
        }
    }

    pub fn disconnected(&self, peer: &str) {
        if let Ok(mut peers) = self.peers.lock() {
            peers.remove(peer);
        }
    }

    pub fn peer_count(&self) -> usize {
        self.peers.lock().map(|p| p.len()).unwrap_or(0)
    }

    pub fn total_in_flight(&self) -> usize {
        self.peers.lock().map(|p| p.values().map(|s| s.in_flight).sum()).unwrap_or(0)
    }

    pub fn snapshot(&self) -> Vec<(String, PeerStats)> {
        self.peers
            .lock()
            .map(|p| p.iter().map(|(k, v)| (k.clone(), v.clone())).collect())
            .unwrap_or_default()
    }

    pub(crate) fn update(&self, peer: &str, f: impl FnOnce(&mut PeerStats)) {
        if let Ok(mut peers) = self.peers.lock() {
            f(peers.entry(peer.to_string()).or_default());
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn peer_in_flight_counts_track_requests_and_completions() {
        let peers = PeerManager::new();
        peers.connected("peer-a");
        peers.update("peer-a", |s| s.in_flight = 48);
        assert_eq!(peers.total_in_flight(), 48);
        peers.update("peer-a", |s| s.in_flight -= 1);
        assert_eq!(peers.total_in_flight(), 47);
        peers.disconnected("peer-a");
        assert_eq!(peers.peer_count(), 0);
        assert_eq!(peers.total_in_flight(), 0);
    }
}
