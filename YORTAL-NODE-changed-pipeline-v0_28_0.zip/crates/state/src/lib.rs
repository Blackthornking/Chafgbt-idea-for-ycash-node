use anyhow::{bail, Result};
use rusqlite::{params, Connection};
use std::collections::{HashMap, HashSet};
use std::io::Cursor;
use std::path::Path;
use std::sync::Mutex;
use std::sync::atomic::{AtomicU64, Ordering};
use ycash_consensus::{validate_sapling_transaction_state, SaplingConsensusState};

pub mod chainstate;
use chainstate::{BlockConnector, CoinsView, SproutView, SPENT_OUTPUT_RETENTION};

/// v3: transparent UTXO set (value/script/height/coinbase/spent_height),
/// Sprout nullifiers and per-block Sprout treestate + value pools.
const SCHEMA_VERSION: i64 = 3;

#[derive(Debug, Clone)]
pub struct Tip {
    pub hash: Vec<u8>,
    pub height: u64,
    pub work: [u8; 32],
}

pub struct State {
    db: Mutex<Connection>,
    sapling: Mutex<SaplingConsensusState>,
    /// Blocks at or below this height skip script verification, like ycashd
    /// under its last checkpoint (`fExpensiveChecks = false`). 0 = verify all.
    assume_valid_height: AtomicU64,
}

#[derive(Debug, Clone)]
pub struct BlockCommit {
    pub height: u64,
    pub hash: [u8; 32],
    pub prev: [u8; 32],
    pub work: [u8; 32],
    pub raw: Vec<u8>,
    pub txs: Vec<([u8; 32], Vec<u8>)>,
}

impl State {
    pub fn open(p: impl AsRef<Path>) -> Result<Self> {
        let db = Connection::open(p)?;
        db.execute_batch(
            "PRAGMA journal_mode=WAL;
             PRAGMA synchronous=NORMAL;
             PRAGMA cache_size=-32768;
             PRAGMA temp_store=MEMORY;
             PRAGMA foreign_keys=ON;",
        )?;

        let version: i64 = db.pragma_query_value(None, "user_version", |row| row.get(0))?;
        if version > SCHEMA_VERSION {
            bail!("database schema version {version} is newer than supported version {SCHEMA_VERSION}");
        }

        // v0.27.1 deliberately starts a clean state schema. An unversioned DB can
        // be the partially-created database produced by the old txs-index ordering
        // bug. It contains no trustworthy Sapling/UTXO state, so discard only the
        // old node tables and rebuild them. A fresh install therefore self-heals
        // without requiring the user to manually clear application data.
        let has_old_schema = ["meta", "blocks", "headers", "txs", "sapling_roots"]
            .iter()
            .try_fold(false, |found, name| Ok::<bool, anyhow::Error>(found || table_exists(&db, name)?))?;
        if version == 2 {
            // v2 block state was committed without a UTXO set or Sprout state,
            // so it can't be trusted for validation. Rebuild block-derived
            // tables; keep the (independently validated) header chain.
            db.execute_batch(
                "DROP TABLE IF EXISTS utxos;
                 DROP TABLE IF EXISTS sapling_roots;
                 DROP TABLE IF EXISTS nullifiers;
                 DROP TABLE IF EXISTS txs;
                 DROP TABLE IF EXISTS undo;
                 DROP TABLE IF EXISTS blocks;
                 DELETE FROM meta WHERE k IN ('tip_hash','tip_height','sapling_frontier');",
            )?;
        } else if version < SCHEMA_VERSION && has_old_schema {
            db.execute_batch(
                "DROP TABLE IF EXISTS utxos;
                 DROP TABLE IF EXISTS sapling_roots;
                 DROP TABLE IF EXISTS nullifiers;
                 DROP TABLE IF EXISTS txs;
                 DROP TABLE IF EXISTS undo;
                 DROP TABLE IF EXISTS headers;
                 DROP TABLE IF EXISTS blocks;
                 DROP TABLE IF EXISTS meta;",
            )?;
        }

        create_schema(&db)?;
        db.pragma_update(None, "user_version", SCHEMA_VERSION)?;

        let sapling = match db.query_row(
            "SELECT v FROM meta WHERE k='sapling_frontier'",
            [],
            |r| r.get::<_, Vec<u8>>(0),
        ) {
            Ok(v) => SaplingConsensusState::decode(&v)
                .map_err(|e| anyhow::anyhow!("invalid persisted Sapling state: {e:?}"))?,
            Err(rusqlite::Error::QueryReturnedNoRows) => SaplingConsensusState::new(),
            Err(e) => return Err(e.into()),
        };

        Ok(Self {
            db: Mutex::new(db),
            sapling: Mutex::new(sapling),
            assume_valid_height: AtomicU64::new(0),
        })
    }

    /// Skip transparent script verification for blocks at or below `height`
    /// (callers must only set this once the header at a hard-coded checkpoint
    /// has been verified to match). Everything else is still validated.
    pub fn set_assume_valid_height(&self, height: u64) {
        self.assume_valid_height.store(height, Ordering::Relaxed);
    }

    pub fn put_block(
        &self,
        height: u64,
        hash: &[u8],
        prev: &[u8],
        work: &[u8],
        raw: &[u8],
    ) -> Result<()> {
        if hash.len() != 32 || prev.len() != 32 || work.len() != 32 {
            bail!("invalid hash/work length");
        }
        let db = self.db.lock().unwrap();
        db.execute(
            "INSERT OR REPLACE INTO blocks(hash,height,prev,work,raw,main_chain) VALUES(?1,?2,?3,?4,?5,0)",
            params![hash, height, prev, work, raw],
        )?;
        Ok(())
    }

    pub fn commit_block(
        &self,
        height: u64,
        hash: &[u8],
        prev: &[u8],
        work: &[u8],
        raw: &[u8],
        txs: &[([u8; 32], Vec<u8>)],
    ) -> Result<()> {
        let b = BlockCommit {
            height,
            hash: hash.try_into().map_err(|_| anyhow::anyhow!("invalid hash length"))?,
            prev: prev.try_into().map_err(|_| anyhow::anyhow!("invalid prev length"))?,
            work: work.try_into().map_err(|_| anyhow::anyhow!("invalid work length"))?,
            raw: raw.to_vec(),
            txs: txs.to_vec(),
        };
        self.commit_blocks_batch(&[b])
    }

    pub fn commit_blocks_batch(&self, blocks: &[BlockCommit]) -> Result<()> {
        if blocks.is_empty() {
            return Ok(());
        }
        validate_batch_shape(blocks)?;
        let assume_valid_height = self.assume_valid_height.load(Ordering::Relaxed);

        let db = self.db.lock().unwrap();
        let tx = db.unchecked_transaction()?;

        let first = &blocks[0];
        let first_height = first.height;
        let parent_frontier = load_parent_frontier(&tx, first.height, &first.prev)?;
        let mut working = parent_frontier;
        let mut valid_batch_roots = HashSet::new();
        valid_batch_roots.insert(working.root());

        let mut coins = CoinsView::new(first_height);
        let mut sprout = SproutView::load(&tx, first_height, &first.prev)?;

        // Validate the complete batch against the canonical ancestor state before
        // changing any canonical flags. This makes a failed batch atomic both
        // logically and physically: no half-reorged anchor set is visible.
        let mut batch_nullifiers = HashSet::new();
        for b in blocks {
            let block = ycash_chain::read_block_at_height(&b.raw, b.height)?;
            let expected_prev = if b.height == first.height {
                b.prev
            } else {
                blocks
                    .iter()
                    .find(|x| x.height + 1 == b.height)
                    .map(|x| x.hash)
                    .ok_or_else(|| anyhow::anyhow!("batch is not contiguous"))?
            };
            if block.header.hash() != b.hash || block.header.prev != expected_prev {
                bail!("block commit does not match its supplied hash/previous hash");
            }

            let mut connector = BlockConnector::new(b.height, b.height > assume_valid_height);
            for rawtx in &block.txs {
                let mut c = Cursor::new(rawtx.as_slice());
                let parsed = ycash_chain::parse_transaction(&mut c)?;
                let txid = ycash_chain::txid(rawtx);

                // Transparent inputs/scripts/fees and Sprout requirements, then
                // connect the transaction's coins and Sprout effects.
                connector.connect_tx(&tx, &mut coins, &mut sprout, &parsed, &txid)?;

                let anchor_exists = |a: &[u8; 32]| -> bool {
                    valid_batch_roots.contains(a)
                        || tx.query_row(
                            "SELECT 1 FROM sapling_roots WHERE root=?1 AND main_chain=1 AND height < ?2 LIMIT 1",
                            params![a.as_slice(), first_height as i64],
                            |r| r.get::<_, i64>(0),
                        ).is_ok()
                };
                let nullifier_exists = |n: &[u8; 32]| -> bool {
                    batch_nullifiers.contains(n)
                        || tx.query_row(
                            "SELECT 1 FROM nullifiers n
                             JOIN blocks oldb ON oldb.hash=n.block_hash
                             WHERE n.n=?1 AND n.main_chain=1 AND oldb.main_chain=1 AND oldb.height < ?2 LIMIT 1",
                            params![n.as_slice(), first_height as i64],
                            |r| r.get::<_, i64>(0),
                        ).is_ok()
                };
                validate_sapling_transaction_state(
                    &parsed,
                    b.height,
                    &mut working,
                    anchor_exists,
                    nullifier_exists,
                )
                .map_err(|e| anyhow::anyhow!("sapling consensus failure at height {}: {e:?}", b.height))?;

                for spend in &parsed.sapling_spends {
                    if !batch_nullifiers.insert(spend.nullifier) {
                        bail!("Sapling nullifier is duplicated within the commit batch");
                    }
                }
            }
            connector.finish()?;
            sprout.finish_block(b.hash, b.height)?;
            valid_batch_roots.insert(working.root());
        }

        let first_height = first.height as i64;
        tx.execute(
            "UPDATE blocks SET main_chain=0 WHERE main_chain=1 AND height>=?1",
            params![first_height],
        )?;
        tx.execute(
            "UPDATE sapling_roots SET main_chain=0 WHERE main_chain=1 AND height>=?1",
            params![first_height],
        )?;
        tx.execute(
            "UPDATE nullifiers SET main_chain=0 WHERE main_chain=1 AND block_hash IN
             (SELECT hash FROM blocks WHERE main_chain=0 AND height>=?1)",
            params![first_height],
        )?;
        // The nullifier table uses the nullifier itself as its primary key. Once
        // an old branch is orphaned, remove its rows so a valid replacement branch
        // can reuse a nullifier without colliding with stale historical state.
        tx.execute(
            "DELETE FROM nullifiers WHERE main_chain=0 AND block_hash IN
             (SELECT hash FROM blocks WHERE main_chain=0 AND height>=?1)",
            params![first_height],
        )?;
        // Transactions are an index of the canonical chain, so orphaned rows must
        // disappear as a unit rather than being left to inflate transaction_count.
        tx.execute(
            "DELETE FROM txs WHERE block_hash IN
             (SELECT hash FROM blocks WHERE main_chain=0 AND height>=?1)",
            params![first_height],
        )?;
        // Roll back transparent and Sprout state of any replaced branch.
        tx.execute("DELETE FROM utxos WHERE height>=?1", params![first_height])?;
        tx.execute("UPDATE utxos SET spent_height=NULL WHERE spent_height>=?1", params![first_height])?;
        tx.execute("DELETE FROM sprout_nullifiers WHERE height>=?1", params![first_height])?;
        tx.execute("DELETE FROM block_state WHERE height>=?1", params![first_height])?;

        for b in blocks {
            tx.execute(
                "INSERT OR REPLACE INTO blocks(hash,height,prev,work,raw,main_chain)
                 VALUES(?1,?2,?3,?4,?5,1)",
                params![b.hash.as_slice(), b.height, b.prev.as_slice(), b.work.as_slice(), &b.raw],
            )?;

            for (txid, txraw) in &b.txs {
                tx.execute(
                    "INSERT OR REPLACE INTO txs(txid,block_hash,raw) VALUES(?1,?2,?3)",
                    params![txid.as_slice(), b.hash.as_slice(), txraw],
                )?;
            }
            let committed_block = ycash_chain::read_block_at_height(&b.raw, b.height)?;
            for rawtx in &committed_block.txs {
                let mut c = Cursor::new(rawtx.as_slice());
                let parsed = ycash_chain::parse_transaction(&mut c)?;
                for spend in &parsed.sapling_spends {
                    tx.execute(
                        "INSERT INTO nullifiers(n,block_hash,main_chain) VALUES(?1,?2,1)",
                        params![spend.nullifier.as_slice(), b.hash.as_slice()],
                    )?;
                }
            }

            let frontier_blob = working.encode();
            tx.execute(
                "INSERT OR REPLACE INTO sapling_roots(block_hash,root,height,frontier,main_chain)
                 VALUES(?1,?2,?3,?4,1)",
                params![b.hash.as_slice(), working.root().as_slice(), b.height as i64, frontier_blob],
            )?;
            tx.execute(
                "INSERT OR REPLACE INTO meta(k,v) VALUES('tip_hash',?1)",
                params![b.hash.as_slice()],
            )?;
            tx.execute(
                "INSERT OR REPLACE INTO meta(k,v) VALUES('tip_height',?1)",
                params![b.height.to_le_bytes().to_vec()],
            )?;
        }

        coins.flush(&tx)?;
        sprout.flush(&tx)?;
        let tip = blocks[blocks.len() - 1].height;
        if tip > SPENT_OUTPUT_RETENTION {
            tx.execute(
                "DELETE FROM utxos WHERE spent_height IS NOT NULL AND spent_height<?1",
                params![(tip - SPENT_OUTPUT_RETENTION) as i64],
            )?;
        }

        tx.execute(
            "INSERT OR REPLACE INTO meta(k,v) VALUES('sapling_frontier',?1)",
            params![working.encode()],
        )?;
        tx.commit()?;

        let mut sap = self.sapling.lock().unwrap();
        *sap = working;
        Ok(())
    }

    pub fn transaction_count(&self) -> Result<u64> {
        let db = self.db.lock().unwrap();
        Ok(db.query_row("SELECT COUNT(*) FROM txs", [], |r| r.get::<_, i64>(0))? as u64)
    }

    pub fn set_tip(&self, tip: &Tip) -> Result<()> {
        let db = self.db.lock().unwrap();
        let tx = db.unchecked_transaction()?;
        tx.execute("UPDATE blocks SET main_chain=0 WHERE main_chain=1", [])?;
        tx.execute(
            "UPDATE blocks SET main_chain=1 WHERE hash=?1",
            params![&tip.hash],
        )?;
        tx.execute(
            "INSERT OR REPLACE INTO meta(k,v) VALUES('tip_hash',?1)",
            params![&tip.hash],
        )?;
        tx.execute(
            "INSERT OR REPLACE INTO meta(k,v) VALUES('tip_height',?1)",
            params![tip.height.to_le_bytes().to_vec()],
        )?;
        tx.commit()?;
        Ok(())
    }

    pub fn tip_height(&self) -> Result<Option<u64>> {
        let db = self.db.lock().unwrap();
        let r = db.query_row(
            "SELECT MAX(height) FROM blocks WHERE main_chain=1",
            [],
            |r| r.get::<_, Option<i64>>(0),
        )?;
        Ok(r.map(|x| x as u64))
    }

    pub fn has_block(&self, hash: &[u8]) -> Result<bool> {
        let db = self.db.lock().unwrap();
        Ok(db.query_row(
            "SELECT EXISTS(SELECT 1 FROM blocks WHERE hash=?1)",
            params![hash],
            |r| r.get(0),
        )?)
    }

    pub fn put_header(&self, height: u64, hash: &[u8], prev: &[u8], time: u32, bits: u32, work: &[u8], raw: &[u8]) -> Result<()> {
        if hash.len() != 32 || prev.len() != 32 || work.len() != 32 {
            bail!("invalid header hash/work length");
        }
        let db = self.db.lock().unwrap();
        db.execute(
            "UPDATE headers SET main_chain=0 WHERE height>=?1 AND hash<>?2 AND main_chain=1",
            params![height, hash],
        )?;
        db.execute(
            "INSERT OR REPLACE INTO headers(hash,height,prev,time,bits,work,raw,main_chain) VALUES(?1,?2,?3,?4,?5,?6,?7,1)",
            params![hash, height, prev, time, bits, work, raw],
        )?;
        Ok(())
    }

    pub fn header_by_height(&self, height: u64) -> Result<Option<Vec<u8>>> {
        let db = self.db.lock().unwrap();
        let r = db.query_row(
            "SELECT raw FROM headers WHERE height=?1 AND main_chain=1",
            params![height],
            |r| r.get(0),
        );
        match r {
            Ok(v) => Ok(Some(v)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    pub fn tip_hash(&self) -> Result<Option<Vec<u8>>> {
        let db = self.db.lock().unwrap();
        let r = db.query_row(
            "SELECT hash FROM blocks WHERE main_chain=1 ORDER BY height DESC LIMIT 1",
            [],
            |r| r.get(0),
        );
        match r {
            Ok(v) => Ok(Some(v)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    pub fn header_height_by_hash(&self, hash: &[u8]) -> Result<Option<u64>> {
        let db = self.db.lock().unwrap();
        let r = db.query_row("SELECT height FROM headers WHERE hash=?1", params![hash], |r| r.get::<_, i64>(0));
        match r {
            Ok(v) => Ok(Some(v as u64)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    pub fn header_height(&self) -> Result<Option<u64>> {
        let db = self.db.lock().unwrap();
        let r = db.query_row("SELECT MAX(height) FROM headers WHERE main_chain=1", [], |r| r.get::<_, Option<i64>>(0))?;
        Ok(r.map(|x| x as u64))
    }

    pub fn header_hash_by_height(&self, height: u64) -> Result<Option<Vec<u8>>> {
        let db = self.db.lock().unwrap();
        let r = db.query_row("SELECT hash FROM headers WHERE height=?1 AND main_chain=1", params![height], |r| r.get(0));
        match r {
            Ok(v) => Ok(Some(v)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    pub fn header_work_by_height(&self, height: u64) -> Result<Option<Vec<u8>>> {
        let db = self.db.lock().unwrap();
        let r = db.query_row("SELECT work FROM headers WHERE height=?1 AND main_chain=1", params![height], |r| r.get(0));
        match r {
            Ok(v) => Ok(Some(v)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    pub fn header_hashes_range(&self, start: u64, end: u64) -> Result<HashMap<u64, [u8; 32]>> {
        let db = self.db.lock().unwrap();
        let mut q = db.prepare_cached("SELECT height,hash FROM headers WHERE height>=?1 AND height<=?2 AND main_chain=1")?;
        let mut rows = q.query(params![start as i64, end as i64])?;
        let mut out = HashMap::new();
        while let Some(r) = rows.next()? {
            let h: i64 = r.get(0)?;
            let v: Vec<u8> = r.get(1)?;
            if let Ok(a) = <[u8; 32]>::try_from(v.as_slice()) {
                out.insert(h as u64, a);
            }
        }
        Ok(out)
    }

    pub fn header_times_range(&self, start: u64, end: u64) -> Result<Vec<(u64, u32)>> {
        let db = self.db.lock().unwrap();
        let mut q = db.prepare_cached("SELECT height,time FROM headers WHERE height>=?1 AND height<?2 AND main_chain=1 ORDER BY height")?;
        let mut rows = q.query(params![start as i64, end as i64])?;
        let mut out = Vec::new();
        while let Some(r) = rows.next()? {
            let h: i64 = r.get(0)?;
            let t: i64 = r.get(1)?;
            out.push((h as u64, t as u32));
        }
        Ok(out)
    }

    pub fn header_time(&self, height: u64) -> Result<Option<u32>> {
        let db = self.db.lock().unwrap();
        let r = db.query_row("SELECT time FROM headers WHERE height=?1 AND main_chain=1", params![height as i64], |r| r.get::<_, i64>(0));
        match r {
            Ok(v) => Ok(Some(v as u32)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    pub fn locator_hashes(&self) -> Result<Vec<[u8; 32]>> {
        let tip = self.header_height()?.unwrap_or(0);
        let mut heights = Vec::new();
        let mut h = tip;
        while h > 0 && heights.len() < 10 {
            heights.push(h);
            h = h.saturating_sub(1);
        }
        let mut step = 2u64;
        while h > 0 && heights.len() < 32 {
            heights.push(h);
            h = h.saturating_sub(step);
            step = step.saturating_mul(2);
        }
        heights.push(0);
        heights.sort_unstable();
        heights.dedup();
        heights.reverse();
        let mut out = Vec::new();
        for h in heights {
            if let Some(v) = self.header_hash_by_height(h)? {
                if v.len() == 32 {
                    let mut a = [0u8; 32];
                    a.copy_from_slice(&v);
                    out.push(a);
                }
            } else if h == 0 {
                out.push(ycash_chain::genesis_hash_internal());
            }
        }
        Ok(out)
    }

    pub fn export_snapshot(&self, dest: &Path) -> Result<()> {
        let path = match dest.to_str() {
            Some(s) => s,
            None => bail!("destination path is not valid UTF-8"),
        };
        let db = self.db.lock().unwrap();
        db.execute("VACUUM INTO ?1", params![path])?;
        Ok(())
    }
}

fn table_exists(db: &Connection, name: &str) -> Result<bool> {
    Ok(db.query_row(
        "SELECT EXISTS(SELECT 1 FROM sqlite_master WHERE type='table' AND name=?1)",
        params![name],
        |r| r.get(0),
    )?)
}

fn create_schema(db: &Connection) -> Result<()> {
    db.execute_batch(
        "BEGIN;
         CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY,v BLOB NOT NULL);
         CREATE TABLE IF NOT EXISTS blocks(hash BLOB PRIMARY KEY,height INTEGER NOT NULL,prev BLOB NOT NULL,work BLOB NOT NULL,raw BLOB NOT NULL,main_chain INTEGER NOT NULL DEFAULT 0);
         CREATE TABLE IF NOT EXISTS headers(hash BLOB PRIMARY KEY,height INTEGER NOT NULL,prev BLOB NOT NULL,time INTEGER NOT NULL,bits INTEGER NOT NULL,work BLOB NOT NULL,raw BLOB NOT NULL,main_chain INTEGER NOT NULL DEFAULT 0);
         CREATE INDEX IF NOT EXISTS headers_height ON headers(height);
         CREATE INDEX IF NOT EXISTS blocks_height ON blocks(height);
         CREATE INDEX IF NOT EXISTS blocks_prev ON blocks(prev);
         CREATE TABLE IF NOT EXISTS undo(block_hash BLOB PRIMARY KEY,height INTEGER NOT NULL,undo BLOB NOT NULL);
         CREATE TABLE IF NOT EXISTS txs(txid BLOB PRIMARY KEY,block_hash BLOB NOT NULL,raw BLOB NOT NULL);
         CREATE INDEX IF NOT EXISTS txs_block_hash ON txs(block_hash);
         CREATE TABLE IF NOT EXISTS nullifiers(n BLOB PRIMARY KEY,block_hash BLOB NOT NULL,main_chain INTEGER NOT NULL DEFAULT 1);
         CREATE INDEX IF NOT EXISTS nullifiers_block_hash ON nullifiers(block_hash);
         CREATE TABLE IF NOT EXISTS sapling_roots(
             block_hash BLOB PRIMARY KEY,
             root BLOB NOT NULL,
             height INTEGER NOT NULL,
             frontier BLOB NOT NULL,
             main_chain INTEGER NOT NULL DEFAULT 1
         );
         CREATE INDEX IF NOT EXISTS sapling_roots_root_main ON sapling_roots(root,main_chain);
         CREATE INDEX IF NOT EXISTS sapling_roots_height ON sapling_roots(height);
         CREATE TABLE IF NOT EXISTS utxos(
             txid BLOB NOT NULL,
             vout INTEGER NOT NULL,
             value INTEGER NOT NULL,
             script BLOB NOT NULL,
             height INTEGER NOT NULL,
             coinbase INTEGER NOT NULL,
             spent_height INTEGER,
             PRIMARY KEY(txid,vout)
         );
         CREATE INDEX IF NOT EXISTS utxos_height ON utxos(height);
         CREATE INDEX IF NOT EXISTS utxos_spent_height ON utxos(spent_height);
         CREATE TABLE IF NOT EXISTS sprout_nullifiers(n BLOB PRIMARY KEY,height INTEGER NOT NULL);
         CREATE INDEX IF NOT EXISTS sprout_nullifiers_height ON sprout_nullifiers(height);
         CREATE TABLE IF NOT EXISTS block_state(
             block_hash BLOB PRIMARY KEY,
             height INTEGER NOT NULL,
             sprout_root BLOB NOT NULL,
             sprout_frontier BLOB NOT NULL,
             chain_sprout_value INTEGER NOT NULL,
             chain_sapling_value INTEGER NOT NULL
         );
         CREATE INDEX IF NOT EXISTS block_state_height ON block_state(height);
         CREATE INDEX IF NOT EXISTS block_state_sprout_root ON block_state(sprout_root);
         COMMIT;",
    )?;
    Ok(())
}

fn validate_batch_shape(blocks: &[BlockCommit]) -> Result<()> {
    for i in 1..blocks.len() {
        if blocks[i].height != blocks[i - 1].height + 1 || blocks[i].prev != blocks[i - 1].hash {
            bail!("block batch is not contiguous");
        }
    }
    Ok(())
}

fn load_parent_frontier(
    tx: &rusqlite::Transaction<'_>,
    height: u64,
    prev: &[u8; 32],
) -> Result<SaplingConsensusState> {
    if height == 1 && *prev == ycash_chain::genesis_hash_internal() {
        return Ok(SaplingConsensusState::new());
    }
    if height == 0 {
        return Ok(SaplingConsensusState::new());
    }
    let frontier = tx
        .query_row(
            "SELECT frontier FROM sapling_roots WHERE block_hash=?1 AND main_chain=1 AND height=?2",
            params![prev.as_slice(), (height - 1) as i64],
            |r| r.get::<_, Vec<u8>>(0),
        )
        .map_err(|e| anyhow::anyhow!("missing canonical Sapling state for parent: {e}"))?;
    SaplingConsensusState::decode(&frontier)
        .map_err(|e| anyhow::anyhow!("invalid canonical Sapling state for parent: {e:?}"))
}

// v0.22 adaptive sync pipeline
pub mod pipeline;

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp_db() -> std::path::PathBuf {
        std::env::temp_dir().join(format!(
            "ycash-state-test-{}-{}.sqlite",
            std::process::id(),
            SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos()
        ))
    }

    #[test]
    fn fresh_database_creates_txs_before_index() {
        let p = temp_db();
        let s = State::open(&p).unwrap();
        assert_eq!(s.transaction_count().unwrap(), 0);
        let db = Connection::open(&p).unwrap();
        let tables: Vec<String> = {
            let mut q = db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").unwrap();
            q.query_map([], |r| r.get(0)).unwrap().map(|r| r.unwrap()).collect()
        };
        assert!(tables.iter().any(|x| x == "txs"));
        assert!(tables.iter().any(|x| x == "sapling_roots"));
        let index_target: String = db.query_row(
            "SELECT tbl_name FROM sqlite_master WHERE type='index' AND name='txs_block_hash'",
            [], |r| r.get(0)
        ).unwrap();
        assert_eq!(index_target, "txs");
        drop(s);
        let _ = fs::remove_file(&p);
        let _ = fs::remove_file(format!("{}-wal", p.display()));
        let _ = fs::remove_file(format!("{}-shm", p.display()));
    }

    #[test]
    fn failed_old_unversioned_database_is_rebuilt() {
        let p = temp_db();
        {
            let db = Connection::open(&p).unwrap();
            db.execute_batch("CREATE TABLE blocks(hash BLOB PRIMARY KEY,height INTEGER,prev BLOB,work BLOB,raw BLOB,main_chain INTEGER); CREATE TABLE headers(hash BLOB PRIMARY KEY,height INTEGER,prev BLOB,time INTEGER,bits INTEGER,work BLOB,raw BLOB,main_chain INTEGER);").unwrap();
        }
        let s = State::open(&p).unwrap();
        assert_eq!(s.transaction_count().unwrap(), 0);
        let db = Connection::open(&p).unwrap();
        let v: i64 = db.pragma_query_value(None, "user_version", |r| r.get(0)).unwrap();
        assert_eq!(v, SCHEMA_VERSION);
        drop(s);
        let _ = fs::remove_file(&p);
        let _ = fs::remove_file(format!("{}-wal", p.display()));
        let _ = fs::remove_file(format!("{}-shm", p.display()));
    }
}
