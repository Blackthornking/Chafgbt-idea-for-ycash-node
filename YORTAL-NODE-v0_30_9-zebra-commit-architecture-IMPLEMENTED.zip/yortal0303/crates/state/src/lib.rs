use anyhow::{bail, Result};
use rusqlite::{params, Connection, OpenFlags};
use std::collections::{HashMap, HashSet};
use std::io::Cursor;
use std::path::Path;
use std::sync::{Arc, Mutex, MutexGuard};
use std::time::Instant;
use std::cell::Cell;
use std::sync::atomic::{AtomicU64, Ordering};
use ycash_consensus::{validate_sapling_transaction_state_opts, SaplingConsensusState, SproutTree};

pub mod chainstate;
use chainstate::{BlockConnector, CoinsView, SproutView, SPENT_OUTPUT_RETENTION};

/// v3: transparent UTXO set (value/script/height/coinbase/spent_height),
/// Sprout nullifiers and per-block Sprout treestate + value pools.
const SCHEMA_VERSION: i64 = 4;

#[derive(Debug, Clone)]
pub struct Tip {
    pub hash: Vec<u8>,
    pub height: u64,
    pub work: [u8; 32],
}

#[derive(Debug, Clone, Default)]
pub struct CommitTiming {
    pub total_ms: u64,
    /// Time spent after a batch became commit-ready before state preparation began.
    /// Populated by the pipeline layer; zero for direct State callers.
    pub queue_wait_ms: u64,
    /// Head-of-line wait before the commit worker could obtain a contiguous batch.
    /// Populated by the pipeline layer; zero for direct State callers.
    pub head_of_line_wait_ms: u64,
    /// Full ordered commit wall time, including state preparation, SQL writes, and SQLite COMMIT.
    pub state_validation_us: u64,
    pub state_unattributed_us: u64,
    /// Fine-grained residuals used to locate time that is not covered by the named consensus calls.
    pub header_hash_us: u64,
    pub connector_new_us: u64,
    pub connector_other_us: u64,
    pub block_root_us: u64,
    /// Deep Sapling root telemetry: per-root-level time/hash counts plus
    /// the repeated empty-subtree work that can dominate root construction.
    pub block_root_level_us: [u64; 32],
    pub block_root_level_hashes: [u64; 32],
    pub block_root_empty_us: [u64; 32],
    pub block_root_empty_hashes: [u64; 32],
    pub block_root_hash_us: [u64; 32],
    pub block_root_hashes: [u64; 32],
    pub block_loop_other_us: u64,
    pub slowest_block_height: u64,
    pub slowest_block_us: u64,
    pub slowest_block_other_us: u64,
    pub slowest_tx_height: u64,
    pub slowest_tx_index: u64,
    pub slowest_tx_us: u64,
    pub slowest_tx_other_us: u64,
    pub total_us: u64,
    pub state_validation_ms: u64,
    pub rollback_ms: u64,
    pub db_write_ms: u64,
    pub db_write_us: u64,
    /// Time to open the SQLite write transaction (BEGIN).
    pub begin_ms: u64,
    /// Time spent advancing Sapling/tree state during state validation.
    pub tree_ms: u64,
    /// Time spent executing block/transaction/tree/nullifier SQL statements.
    pub sql_write_ms: u64,
    /// Time spent on indexed state writes (tx/root/nullifier indexes).
    pub index_write_ms: u64,
    pub sqlite_commit_ms: u64,
    pub sqlite_commit_us: u64,
    pub blocks: u64,
    pub txs: u64,
    /// Number of transparent UTXO lookups performed during state validation.
    pub utxo_lookups: u64,
    /// Number of BIP30 existing-tx checks performed during state validation.
    pub bip30_checks: u64,
    /// Number of transaction inputs whose scripts were actually executed.
    pub script_checks: u64,
    /// Script verification telemetry: checks remain consensus-identical, but
    /// independent transparent inputs are verified in parallel before ordered state mutation.
    pub script_parallel_workers: u64,
    pub script_parallel_us: u64,
    pub script_input_work_us: u64,
    pub script_slowest_input_index: u64,
    pub script_slowest_input_us: u64,
    pub script_slowest_input_tx_height: u64,
    pub script_slowest_input_tx_index: u64,
    pub script_transaction_input_extraction_us: u64,
    pub script_sig_construction_us: u64,
    pub script_pubkey_retrieval_us: u64,
    pub script_parsing_us: u64,
    pub signature_hash_preparation_us: u64,
    pub ecdsa_verification_us: u64,
    pub script_interpreter_us: u64,
    pub script_cache_lookup_us: u64,
    pub script_synchronization_us: u64,
    pub script_worker_wall_us: [u64; 32],
    pub script_worker_input_work_us: [u64; 32],
    pub script_worker_inputs: [u64; 32],
    pub script_spawn_us: u64,
    pub script_join_us: u64,
    pub script_pool_overhead_us: u64,
    pub script_pool_threads: u64,
    pub script_worker_max_us: u64,
    pub script_worker_min_us: u64,
    pub utxo_cache_hits: u64,
    pub utxo_cache_misses: u64,
    pub parent_state_cache_hit: bool,
    pub sprout_state_cache_hit: bool,
    /// Fine-grained ordered state-validation timings.
    pub parent_state_load_ms: u64,
    pub parent_state_load_us: u64,
    pub block_parse_ms: u64,
    pub block_parse_us: u64,
    pub txid_us: u64,
    pub tx_connect_ms: u64,
    pub tx_connect_us: u64,
    pub bip30_ms: u64,
    pub bip30_us: u64,
    pub sigops_ms: u64,
    pub sigops_us: u64,
    pub tx_parse_us: u64,
    pub utxo_lookup_ms: u64,
    pub utxo_lookup_us: u64,
    pub sprout_requirements_ms: u64,
    pub sprout_requirements_us: u64,
    pub value_checks_ms: u64,
    pub value_checks_us: u64,
    pub script_ms: u64,
    pub script_us: u64,
    pub coin_state_update_ms: u64,
    pub coin_state_update_us: u64,
    pub sprout_apply_ms: u64,
    pub sprout_apply_us: u64,
    pub sapling_validate_ms: u64,
    pub sapling_validate_us: u64,
    pub sapling_anchor_lookup_ms: u64,
    pub sapling_anchor_lookup_us: u64,
    pub sapling_nullifier_lookup_ms: u64,
    pub sapling_nullifier_lookup_us: u64,
    pub sapling_tree_update_ms: u64,
    pub sapling_tree_update_us: u64,
    pub block_finalize_ms: u64,
    pub block_finalize_us: u64,
    pub tree_encode_us: u64,
    pub read_transaction_us: u64,
    pub read_transaction_commit_us: u64,
    pub parent_frontier_load_us: u64,
    pub sprout_state_load_us: u64,
    pub sapling_anchor_queries: u64,
    pub sapling_nullifier_queries: u64,
    pub sapling_empty_hashes_avoided: u64,
    pub sapling_root_cache_hits: u64,
}

/// Bounded process-local cache of the exact canonical state at the last
/// successfully committed tip. It is an acceleration layer only: a miss always
/// falls back to SQLite, and the cache is discarded on reorgs.
struct ConsensusCache {
    tip_hash: [u8; 32],
    tip_height: u64,
    sapling: SaplingConsensusState,
    sprout: SproutTree,
    chain_sprout_value: i64,
    chain_sapling_value: i64,
    utxos: Arc<HashMap<chainstate::OutPoint, chainstate::Coin>>,
}

impl ConsensusCache {
    fn new(
        tip_hash: [u8; 32],
        tip_height: u64,
        sapling: SaplingConsensusState,
        sprout: SproutTree,
        chain_sprout_value: i64,
        chain_sapling_value: i64,
    ) -> Self {
        Self { tip_hash, tip_height, sapling, sprout, chain_sprout_value, chain_sapling_value, utxos: Arc::new(HashMap::new()) }
    }
}

pub struct State {
    db: Mutex<Connection>,
    /// v0.29.2: separate read-only WAL connection for `headers` lookups, so
    /// block fetchers never wait on the committer's write transaction.
    /// `None` (e.g. the read-only open failed) falls back to `db`.
    reader: Option<Mutex<Connection>>,
    sapling: Mutex<SaplingConsensusState>,
    /// Blocks at or below this height skip script verification, like ycashd
    /// under its last checkpoint (`fExpensiveChecks = false`). 0 = verify all.
    assume_valid_height: AtomicU64,
    last_commit_timing: Mutex<CommitTiming>,
    /// Canonical state/UTXO cache. This never replaces the DB as authority.
    consensus_cache: Mutex<Option<ConsensusCache>>,
}

/// One validated header, ready for `State::put_headers_batch`.
#[derive(Debug, Clone)]
pub struct HeaderRow {
    pub height: u64,
    pub hash: [u8; 32],
    pub prev: [u8; 32],
    pub time: u32,
    pub bits: u32,
    pub work: [u8; 32],
    pub raw: Vec<u8>,
}

#[derive(Debug, Clone)]
pub struct BlockCommit {
    pub height: u64,
    pub hash: [u8; 32],
    pub prev: [u8; 32],
    pub work: [u8; 32],
    pub raw: Vec<u8>,
    pub txs: Vec<([u8; 32], Vec<u8>)>,
    /// Already-parsed transactions from the stateless validation stage. Empty
    /// for legacy callers; commit falls back to parsing `raw` when absent.
    pub parsed_txs: Vec<ycash_chain::ParsedTransaction>,
    /// Transaction-wide ZIP143/243 signature-hash precomputation produced by
    /// the stateless verifier and carried into commit, so the ordered state
    /// phase does not rebuild it. Empty for legacy callers.
    pub precomputed_txs: Vec<ycash_script::PrecomputedTxData>,
    /// True when Sapling proofs/signatures already passed the verify stage
    /// (`validate_for_commit_opts` or `validate_for_commit_batched` + finish).
    /// The commit then checks anchors/nullifiers/tree without re-verifying proofs.
    pub proofs_verified: bool,
}

/// Zebra-style prepared commit envelope. The canonical state transition is
/// prepared once from the validated blocks and then applied by the single
/// ordered commit owner. Keeping the envelope explicit prevents future write
/// paths from silently reparsing or rebuilding validation inputs.
#[derive(Debug, Clone, Copy)]
pub struct PreparedCommit<'a> {
    pub blocks: &'a [BlockCommit],
}

impl<'a> PreparedCommit<'a> {
    pub fn len(&self) -> usize { self.blocks.len() }
    pub fn is_empty(&self) -> bool { self.blocks.is_empty() }
}

impl State {
    pub fn open(p: impl AsRef<Path>) -> Result<Self> {
        let db = Connection::open(p.as_ref())?;
        db.busy_timeout(std::time::Duration::from_secs(10))?;
        db.execute_batch(
            "PRAGMA journal_mode=WAL;
             PRAGMA synchronous=NORMAL;
             PRAGMA cache_size=-32768;
             PRAGMA temp_store=MEMORY;
             PRAGMA foreign_keys=ON;",
        )?;

        let version: i64 = db.pragma_query_value(None, "user_version", |row| row.get(0))?;
        if version > SCHEMA_VERSION {
            bail!("database schema version {version} is newer than supported version {SCHEMA_VERSION}");
        }

        // v0.27.1 deliberately starts a clean state schema. An unversioned DB can
        // be the partially-created database produced by the old txs-index ordering
        // bug. It contains no trustworthy Sapling/UTXO state, so discard only the
        // old node tables and rebuild them. A fresh install therefore self-heals
        // without requiring the user to manually clear application data.
        let has_old_schema = ["meta", "blocks", "headers", "txs", "sapling_roots"]
            .iter()
            .try_fold(false, |found, name| Ok::<bool, anyhow::Error>(found || table_exists(&db, name)?))?;
        if version == 2 {
            // v2 state predates the genesis-first diagnostic invariant. Reset the
            // complete chain state rather than carrying any header mapping forward.
            db.execute_batch(
                "DROP TABLE IF EXISTS utxos;
                 DROP TABLE IF EXISTS sapling_roots;
                 DROP TABLE IF EXISTS nullifiers;
                 DROP TABLE IF EXISTS txs;
                 DROP TABLE IF EXISTS undo;
                 DROP TABLE IF EXISTS headers;
                 DROP TABLE IF EXISTS blocks;
                 DROP TABLE IF EXISTS meta;",
            )?;
        } else if version < SCHEMA_VERSION && has_old_schema {
            // v0.28.1 is a genesis-first diagnostic reset. Do not reuse the
            // v0.28.0 header mapping: the first accepted network header must
            // always be height 1 with the hard-coded Ycash genesis as parent.
            db.execute_batch(
                "DROP TABLE IF EXISTS utxos;
                 DROP TABLE IF EXISTS sapling_roots;
                 DROP TABLE IF EXISTS nullifiers;
                 DROP TABLE IF EXISTS txs;
                 DROP TABLE IF EXISTS undo;
                 DROP TABLE IF EXISTS headers;
                 DROP TABLE IF EXISTS blocks;
                 DROP TABLE IF EXISTS meta;",
            )?;
        }

        create_schema(&db)?;
        db.pragma_update(None, "user_version", SCHEMA_VERSION)?;

        let sapling = match db.query_row(
            "SELECT v FROM meta WHERE k='sapling_frontier'",
            [],
            |r| r.get::<_, Vec<u8>>(0),
        ) {
            Ok(v) => SaplingConsensusState::decode(&v)
                .map_err(|e| anyhow::anyhow!("invalid persisted Sapling state: {e:?}"))?,
            Err(rusqlite::Error::QueryReturnedNoRows) => SaplingConsensusState::new(),
            Err(e) => return Err(e.into()),
        };

        let reader = open_reader(p.as_ref());
        Ok(Self {
            db: Mutex::new(db),
            reader,
            sapling: Mutex::new(sapling),
            assume_valid_height: AtomicU64::new(0),
            last_commit_timing: Mutex::new(CommitTiming::default()),
            consensus_cache: Mutex::new(None),
        })
    }

    /// Connection for read-only `headers` queries.
    fn rd(&self) -> MutexGuard<'_, Connection> {
        match &self.reader {
            Some(r) => r.lock().unwrap(),
            None => self.db.lock().unwrap(),
        }
    }

    /// Skip transparent script verification for blocks at or below `height`
    /// (callers must only set this once the header at a hard-coded checkpoint
    /// has been verified to match). Everything else is still validated.
    pub fn set_assume_valid_height(&self, height: u64) {
        self.assume_valid_height.store(height, Ordering::Relaxed);
    }

    pub fn put_block(
        &self,
        height: u64,
        hash: &[u8],
        prev: &[u8],
        work: &[u8],
        raw: &[u8],
    ) -> Result<()> {
        if hash.len() != 32 || prev.len() != 32 || work.len() != 32 {
            bail!("invalid hash/work length");
        }
        let db = self.db.lock().unwrap();
        db.execute(
            "INSERT INTO blocks(hash,height,prev,work,raw,main_chain) VALUES(?1,?2,?3,?4,?5,0)
             ON CONFLICT(hash) DO UPDATE SET height=excluded.height,prev=excluded.prev,work=excluded.work,raw=excluded.raw,main_chain=0",
            params![hash, height, prev, work, raw],
        )?;
        Ok(())
    }

    pub fn commit_block(
        &self,
        height: u64,
        hash: &[u8],
        prev: &[u8],
        work: &[u8],
        raw: &[u8],
        txs: &[([u8; 32], Vec<u8>)],
    ) -> Result<()> {
        let b = BlockCommit {
            height,
            hash: hash.try_into().map_err(|_| anyhow::anyhow!("invalid hash length"))?,
            prev: prev.try_into().map_err(|_| anyhow::anyhow!("invalid prev length"))?,
            work: work.try_into().map_err(|_| anyhow::anyhow!("invalid work length"))?,
            raw: raw.to_vec(),
            txs: txs.to_vec(),
            parsed_txs: Vec::new(),
            precomputed_txs: Vec::new(),
            proofs_verified: false,
        };
        self.commit_blocks_batch(&[b])
    }

    /// Prepare an ordered commit without mutating canonical database state.
    /// The envelope owns the already parsed/precomputed validation inputs.
    pub fn prepare_commit_batch<'a>(&self, blocks: &'a [BlockCommit]) -> Result<PreparedCommit<'a>> {
        if blocks.is_empty() {
            return Ok(PreparedCommit { blocks });
        }
        validate_batch_shape(blocks)?;
        Ok(PreparedCommit { blocks })
    }

    /// Apply one prepared commit. This remains the sole canonical mutation
    /// boundary and executes one atomic SQLite transaction.
    pub fn apply_prepared_commit(&self, prepared: PreparedCommit) -> Result<()> {
        self.commit_blocks_batch_inner(&prepared.blocks)
    }

    pub fn commit_blocks_batch(&self, blocks: &[BlockCommit]) -> Result<()> {
        let prepared = self.prepare_commit_batch(blocks)?;
        self.apply_prepared_commit(prepared)
    }

    fn commit_blocks_batch_inner(&self, blocks: &[BlockCommit]) -> Result<()> {
        if blocks.is_empty() {
            return Ok(());
        }
        validate_batch_shape(blocks)?;
        let assume_valid_height = self.assume_valid_height.load(Ordering::Relaxed);
        let total_started = Instant::now();
        let mut timing = CommitTiming { blocks: blocks.len() as u64, txs: blocks.iter().map(|b| b.txs.len() as u64).sum(), ..Default::default() };
        // Fine-grained counters make the existing four-stage timing useful for
        // identifying whether the commit bottleneck is transaction/UTXO work,
        // script execution, database writes, or the final SQLite COMMIT.
        timing.bip30_checks = 0;

        // Zcash-style commit separation: perform the expensive consensus/state
        // preparation against a read transaction first.  Do not hold SQLite's
        // WRITE transaction open while parsing, connecting UTXOs, or advancing
        // the Sapling frontier.  The committer owns `self.db`, so no competing
        // canonical writer can change the state between these two transactions.
        let db = self.db.lock().unwrap();
        let validation_started = Instant::now();
        let read_tx_started = Instant::now();
        let read_tx = db.unchecked_transaction()?;
        timing.read_transaction_us = read_tx_started.elapsed().as_micros() as u64;

        let first = &blocks[0];
        let first_height = first.height;
        const UTXO_CACHE_ENTRIES: usize = 50_000;
        let parent_started = Instant::now();

        // Cache hits are accepted only when the cached state is exactly the
        // canonical parent identified by the first block. This makes the cache
        // incapable of crossing a reorg boundary or being used for the wrong
        // branch.
        let mut cache_guard = self.consensus_cache.lock().unwrap();
        let cache_parent_hit = cache_guard.as_ref().map(|c| {
            c.tip_height.saturating_add(1) == first.height && c.tip_hash == first.prev
        }).unwrap_or(false);
        timing.parent_state_cache_hit = cache_parent_hit;
        let (parent_frontier, cached_utxo_map, cached_sprout, cached_sprout_value, cached_sapling_value) = if cache_parent_hit {
            let c = cache_guard.as_ref().unwrap();
            (c.sapling.clone(), Some(Arc::clone(&c.utxos)), Some(c.sprout.clone()), Some(c.chain_sprout_value), Some(c.chain_sapling_value))
        } else {
            let parent_frontier_started = Instant::now();
            let pf = load_parent_frontier(&read_tx, first.height, &first.prev)?;
            timing.parent_frontier_load_us = parent_frontier_started.elapsed().as_micros() as u64;
            (pf, None, None, None, None)
        };
        let mut working = parent_frontier;
        let mut valid_batch_roots = HashSet::new();
        valid_batch_roots.insert(working.root());

        let mut coins = CoinsView::new(first_height, cached_utxo_map.as_deref());
        let sprout_started = Instant::now();
        let mut sprout = if let Some(tree) = cached_sprout {
            timing.sprout_state_cache_hit = true;
            SproutView::from_cached(first_height, tree, cached_sprout_value.unwrap_or(0), cached_sapling_value.unwrap_or(0))
        } else {
            timing.sprout_state_cache_hit = false;
            SproutView::load(&read_tx, first_height, &first.prev)?
        };
        timing.sprout_state_load_us = sprout_started.elapsed().as_micros() as u64;
        timing.parent_state_load_us = parent_started.elapsed().as_micros() as u64;
        timing.parent_state_load_ms = timing.parent_state_load_us / 1000;

        // Validate the complete batch against the canonical ancestor state before
        // changing any canonical flags. This makes a failed batch atomic both
        // logically and physically: no half-reorged anchor set is visible.
        let mut batch_nullifiers = HashSet::new();
        // v0.29.2: everything the write phase needs is collected here, so the
        // write phase never re-parses a block or transaction.
        let mut pending_nullifiers: Vec<([u8; 32], [u8; 32])> = Vec::new();
        // Per-block Sapling root + frontier. v0.29.1 wrote the batch's FINAL
        // tree to every block's sapling_roots row; each row now gets its own.
        let mut block_trees: Vec<([u8; 32], Vec<u8>)> = Vec::with_capacity(blocks.len());
        for (i, b) in blocks.iter().enumerate() {
            let block_started = Instant::now();
            let block_parse_before = timing.block_parse_us;
            let tx_parse_before = timing.tx_parse_us;
            let txid_before = timing.txid_us;
            let tx_connect_before = timing.tx_connect_us;
            let sapling_before = timing.sapling_validate_us;
            let finalize_before = timing.block_finalize_us;
            let encode_before = timing.tree_encode_us;
            let header_hash_before = timing.header_hash_us;
            let connector_new_before = timing.connector_new_us;
            let block_root_before = timing.block_root_us;
            let parse_started = Instant::now();
            let block = ycash_chain::read_block_at_height(&b.raw, b.height)?;
            let parse_us = parse_started.elapsed().as_micros() as u64;
            timing.block_parse_us = timing.block_parse_us.saturating_add(parse_us);
            timing.block_parse_ms = timing.block_parse_us / 1000;
            let expected_prev = if i == 0 { b.prev } else { blocks[i - 1].hash };
            let header_hash_started = Instant::now();
            let computed_hash = block.header.hash();
            timing.header_hash_us = timing.header_hash_us.saturating_add(header_hash_started.elapsed().as_micros() as u64);
            if computed_hash != b.hash || block.header.prev != expected_prev {
                bail!("block commit does not match its supplied hash/previous hash");
            }

            if !b.parsed_txs.is_empty() && b.parsed_txs.len() != block.txs.len() {
                bail!("parsed transaction count does not match raw block at height {}", b.height);
            }
            let connector_started = Instant::now();
            let mut connector = BlockConnector::new(b.height, b.height > assume_valid_height);
            timing.connector_new_us = timing.connector_new_us.saturating_add(connector_started.elapsed().as_micros() as u64);
            let mut connect_timing = chainstate::ConnectTiming::default();
            let mut block_slowest_script_input_tx_index: u64 = 0;
            for (tx_index, rawtx) in block.txs.iter().enumerate() {
                let tx_started = Instant::now();
                let tx_parse_before = timing.tx_parse_us;
                let txid_before = timing.txid_us;
                let tx_connect_before = timing.tx_connect_us;
                let sapling_before = timing.sapling_validate_us;
                let tx_parse_started = Instant::now();
                // Reuse the parsed transaction handed over by stateless
                // validation. Legacy callers without parsed data still parse
                // here, but the normal Android/node pipeline no longer clones
                // every ParsedTransaction during ordered commit.
                let parsed_owned = if b.parsed_txs.is_empty() {
                    let mut c = Cursor::new(rawtx.as_slice());
                    Some(ycash_chain::parse_transaction(&mut c)?)
                } else {
                    None
                };
                let parsed = parsed_owned.as_ref().unwrap_or_else(|| &b.parsed_txs[tx_index]);
                timing.tx_parse_us = timing.tx_parse_us.saturating_add(tx_parse_started.elapsed().as_micros() as u64);
                let txid_started = Instant::now();
                let txid = ycash_chain::txid(rawtx);
                timing.txid_us = timing.txid_us.saturating_add(txid_started.elapsed().as_micros() as u64);

                // Build transaction-wide signature-hash data exactly once; the
                // parallel script workers share this immutable structure.
                let precomputed_generated = if b.precomputed_txs.is_empty() && parsed.overwintered {
                    Some(ycash_script::PrecomputedTxData::new(parsed))
                } else {
                    None
                };
                let precomputed = if !b.precomputed_txs.is_empty() {
                    if b.precomputed_txs.len() != block.txs.len() {
                        bail!("precomputed transaction count does not match raw block at height {}", b.height);
                    }
                    if parsed.overwintered { Some(&b.precomputed_txs[tx_index]) } else { None }
                } else {
                    precomputed_generated.as_ref()
                };
                // Transparent inputs/scripts/fees and Sprout requirements, then
                // connect the transaction's coins and Sprout effects. State
                // mutation remains strictly ordered even when script checks run in parallel.
                let script_slowest_input_before = connect_timing.script_slowest_input_us;
                connector.connect_tx(&read_tx, &mut coins, &mut sprout, parsed, &txid, precomputed, &mut connect_timing)?;
                if connect_timing.script_slowest_input_us > script_slowest_input_before {
                    block_slowest_script_input_tx_index = tx_index as u64;
                }

                let anchor_lookup_ms = Cell::new(0u64);
                let nullifier_lookup_ms = Cell::new(0u64);
                let anchor_queries = Cell::new(0u64);
                let nullifier_queries = Cell::new(0u64);
                let anchor_exists = |a: &[u8; 32]| -> bool {
                    if valid_batch_roots.contains(a) {
                        return true;
                    }
                    anchor_queries.set(anchor_queries.get().saturating_add(1));
                    let started = Instant::now();
                    let result = read_tx.prepare_cached(
                        "SELECT 1 FROM sapling_roots WHERE root=?1 AND main_chain=1 AND height < ?2 LIMIT 1",
                    ).and_then(|mut q| q.query_row(
                        params![a.as_slice(), first_height as i64],
                        |r| r.get::<_, i64>(0),
                    )).is_ok();
                    anchor_lookup_ms.set(anchor_lookup_ms.get().saturating_add(started.elapsed().as_micros() as u64));
                    result
                };
                let nullifier_exists = |n: &[u8; 32]| -> bool {
                    if batch_nullifiers.contains(n) {
                        return true;
                    }
                    nullifier_queries.set(nullifier_queries.get().saturating_add(1));
                    let started = Instant::now();
                    let result = read_tx.prepare_cached(
                        "SELECT 1 FROM nullifiers n
                         JOIN blocks oldb ON oldb.hash=n.block_hash
                         WHERE n.n=?1 AND n.main_chain=1 AND oldb.main_chain=1 AND oldb.height < ?2 LIMIT 1",
                    ).and_then(|mut q| q.query_row(
                        params![n.as_slice(), first_height as i64],
                        |r| r.get::<_, i64>(0),
                    )).is_ok();
                    nullifier_lookup_ms.set(nullifier_lookup_ms.get().saturating_add(started.elapsed().as_micros() as u64));
                    result
                };
                let tree_started = Instant::now();
                validate_sapling_transaction_state_opts(
                    &parsed,
                    b.height,
                    &mut working,
                    anchor_exists,
                    nullifier_exists,
                    !b.proofs_verified,
                )
                .map_err(|e| anyhow::anyhow!("sapling consensus failure at height {}: {e:?}", b.height))?;
                let sapling_elapsed_us = tree_started.elapsed().as_micros() as u64;
                let sapling_elapsed = sapling_elapsed_us / 1000;
                let anchor_us = anchor_lookup_ms.get();
                let nullifier_us = nullifier_lookup_ms.get();
                let anchor_ms = anchor_us / 1000;
                let nullifier_ms = nullifier_us / 1000;
                timing.tree_ms = timing.tree_ms.saturating_add(sapling_elapsed);
                timing.sapling_validate_us = timing.sapling_validate_us.saturating_add(sapling_elapsed_us);
                timing.sapling_validate_ms = timing.sapling_validate_us / 1000;
                timing.sapling_anchor_lookup_us = timing.sapling_anchor_lookup_us.saturating_add(anchor_us);
                timing.sapling_nullifier_lookup_us = timing.sapling_nullifier_lookup_us.saturating_add(nullifier_us);
                timing.sapling_anchor_lookup_ms = timing.sapling_anchor_lookup_us / 1000;
                timing.sapling_nullifier_lookup_ms = timing.sapling_nullifier_lookup_us / 1000;
                timing.sapling_tree_update_us = timing.sapling_tree_update_us.saturating_add(sapling_elapsed_us.saturating_sub(anchor_us).saturating_sub(nullifier_us));
                timing.sapling_tree_update_ms = timing.sapling_tree_update_us / 1000;
                timing.sapling_anchor_queries = timing.sapling_anchor_queries.saturating_add(anchor_queries.get());
                timing.sapling_nullifier_queries = timing.sapling_nullifier_queries.saturating_add(nullifier_queries.get());

                for spend in &parsed.sapling_spends {
                    if !batch_nullifiers.insert(spend.nullifier) {
                        bail!("Sapling nullifier is duplicated within the commit batch");
                    }
                    pending_nullifiers.push((spend.nullifier, b.hash));
                }
                let tx_elapsed_us = tx_started.elapsed().as_micros() as u64;
                let tx_named_us = timing.tx_parse_us.saturating_sub(tx_parse_before)
                    .saturating_add(timing.txid_us.saturating_sub(txid_before))
                    .saturating_add(timing.tx_connect_us.saturating_sub(tx_connect_before))
                    .saturating_add(timing.sapling_validate_us.saturating_sub(sapling_before));
                let tx_other_us = tx_elapsed_us.saturating_sub(tx_named_us);
                if tx_elapsed_us > timing.slowest_tx_us {
                    timing.slowest_tx_us = tx_elapsed_us;
                    timing.slowest_tx_height = b.height;
                    timing.slowest_tx_index = tx_index as u64;
                    timing.slowest_tx_other_us = tx_other_us;
                }
            }
            let finalize_started = Instant::now();
            connector.finish()?;
            sprout.finish_block(b.hash, b.height)?;
            let finalize_us = finalize_started.elapsed().as_micros() as u64;
            timing.block_finalize_us = timing.block_finalize_us.saturating_add(finalize_us);
            timing.block_finalize_ms = timing.block_finalize_us / 1000;
            timing.tx_connect_us = timing.tx_connect_us.saturating_add(connect_timing.tx_total_us);
            timing.tx_connect_ms = timing.tx_connect_us / 1000;
            timing.bip30_us = timing.bip30_us.saturating_add(connect_timing.bip30_us);
            timing.bip30_ms = timing.bip30_us / 1000;
            timing.sigops_us = timing.sigops_us.saturating_add(connect_timing.sigops_us);
            timing.sigops_ms = timing.sigops_us / 1000;
            timing.utxo_lookup_us = timing.utxo_lookup_us.saturating_add(connect_timing.utxo_lookup_us);
            timing.utxo_lookup_ms = timing.utxo_lookup_us / 1000;
            timing.sprout_requirements_us = timing.sprout_requirements_us.saturating_add(connect_timing.sprout_requirements_us);
            timing.sprout_requirements_ms = timing.sprout_requirements_us / 1000;
            timing.value_checks_us = timing.value_checks_us.saturating_add(connect_timing.value_checks_us);
            timing.value_checks_ms = timing.value_checks_us / 1000;
            timing.script_us = timing.script_us.saturating_add(connect_timing.script_us);
            timing.script_ms = timing.script_us / 1000;
            timing.coin_state_update_us = timing.coin_state_update_us.saturating_add(connect_timing.coin_state_update_us);
            timing.coin_state_update_ms = timing.coin_state_update_us / 1000;
            timing.sprout_apply_us = timing.sprout_apply_us.saturating_add(connect_timing.sprout_apply_us);
            timing.sprout_apply_ms = timing.sprout_apply_us / 1000;
            let connector_named_us = connect_timing.sigops_us
                .saturating_add(connect_timing.bip30_us)
                .saturating_add(connect_timing.utxo_lookup_us)
                .saturating_add(connect_timing.sprout_requirements_us)
                .saturating_add(connect_timing.value_checks_us)
                .saturating_add(connect_timing.script_us)
                .saturating_add(connect_timing.coin_state_update_us)
                .saturating_add(connect_timing.sprout_apply_us);
            timing.connector_other_us = timing.connector_other_us.saturating_add(
                connect_timing.tx_total_us.saturating_sub(connector_named_us));
            timing.utxo_lookups = timing.utxo_lookups.saturating_add(connect_timing.utxo_lookups);
            timing.script_checks = timing.script_checks.saturating_add(connect_timing.script_checks);
            timing.script_parallel_workers = timing.script_parallel_workers.max(connect_timing.script_parallel_workers);
            timing.script_parallel_us = timing.script_parallel_us.saturating_add(connect_timing.script_parallel_us);
            timing.script_input_work_us = timing.script_input_work_us.saturating_add(connect_timing.script_input_work_us);
            timing.script_transaction_input_extraction_us = timing.script_transaction_input_extraction_us.saturating_add(connect_timing.script_transaction_input_extraction_us);
            timing.script_sig_construction_us = timing.script_sig_construction_us.saturating_add(connect_timing.script_sig_construction_us);
            timing.script_pubkey_retrieval_us = timing.script_pubkey_retrieval_us.saturating_add(connect_timing.script_pubkey_retrieval_us);
            timing.script_parsing_us = timing.script_parsing_us.saturating_add(connect_timing.script_parsing_us);
            timing.signature_hash_preparation_us = timing.signature_hash_preparation_us.saturating_add(connect_timing.signature_hash_preparation_us);
            timing.ecdsa_verification_us = timing.ecdsa_verification_us.saturating_add(connect_timing.ecdsa_verification_us);
            timing.script_interpreter_us = timing.script_interpreter_us.saturating_add(connect_timing.script_interpreter_us);
            timing.script_cache_lookup_us = timing.script_cache_lookup_us.saturating_add(connect_timing.script_cache_lookup_us);
            timing.script_synchronization_us = timing.script_synchronization_us.saturating_add(connect_timing.script_synchronization_us);
            for i in 0..4 {
                timing.script_worker_wall_us[i] = timing.script_worker_wall_us[i].saturating_add(connect_timing.script_worker_wall_us[i]);
                timing.script_worker_input_work_us[i] = timing.script_worker_input_work_us[i].saturating_add(connect_timing.script_worker_input_work_us[i]);
                timing.script_worker_inputs[i] = timing.script_worker_inputs[i].saturating_add(connect_timing.script_worker_inputs[i]);
            }
            timing.script_spawn_us = timing.script_spawn_us.saturating_add(connect_timing.script_spawn_us);
            timing.script_join_us = timing.script_join_us.saturating_add(connect_timing.script_join_us);
            timing.script_pool_overhead_us = timing.script_pool_overhead_us.saturating_add(connect_timing.script_pool_overhead_us);
            timing.script_pool_threads = timing.script_pool_threads.max(connect_timing.script_pool_threads);
            timing.script_worker_max_us = timing.script_worker_max_us.max(connect_timing.script_worker_max_us);
            if timing.script_worker_min_us == 0 { timing.script_worker_min_us = connect_timing.script_worker_min_us; } else if connect_timing.script_worker_min_us != 0 { timing.script_worker_min_us = timing.script_worker_min_us.min(connect_timing.script_worker_min_us); }
            if connect_timing.script_slowest_input_us > timing.script_slowest_input_us {
                timing.script_slowest_input_us = connect_timing.script_slowest_input_us;
                timing.script_slowest_input_index = connect_timing.script_slowest_input_index;
                timing.script_slowest_input_tx_height = b.height;
                timing.script_slowest_input_tx_index = block_slowest_script_input_tx_index;
            }
            timing.bip30_checks = timing.bip30_checks.saturating_add(connect_timing.bip30_checks);
            let root_started = Instant::now();
            let (root, root_timing) = working.root_with_timing();
            let measured_root_us = root_started.elapsed().as_micros() as u64;
            timing.block_root_us = timing.block_root_us.saturating_add(measured_root_us);
            if root_timing.root_cache_hit {
                timing.sapling_root_cache_hits = timing.sapling_root_cache_hits.saturating_add(1);
            }
            timing.sapling_empty_hashes_avoided = timing.sapling_empty_hashes_avoided.saturating_add(root_timing.empty_hashes_avoided);
            for level in 0..32 {
                timing.block_root_level_us[level] =
                    timing.block_root_level_us[level].saturating_add(root_timing.level_us[level]);
                timing.block_root_level_hashes[level] =
                    timing.block_root_level_hashes[level].saturating_add(root_timing.level_hashes[level]);
                timing.block_root_empty_us[level] =
                    timing.block_root_empty_us[level].saturating_add(root_timing.empty_us[level]);
                timing.block_root_empty_hashes[level] =
                    timing.block_root_empty_hashes[level].saturating_add(root_timing.empty_hashes[level]);
                timing.block_root_hash_us[level] =
                    timing.block_root_hash_us[level].saturating_add(root_timing.root_hash_us[level]);
                timing.block_root_hashes[level] =
                    timing.block_root_hashes[level].saturating_add(root_timing.root_hashes[level]);
            }
            valid_batch_roots.insert(root);
            let encode_started = Instant::now();
            let encoded_frontier = working.encode();
            timing.tree_encode_us = timing.tree_encode_us.saturating_add(encode_started.elapsed().as_micros() as u64);
block_trees.push((root, encoded_frontier));
        }
        timing.utxo_cache_hits = coins.cache_hits;
        timing.utxo_cache_misses = coins.cache_misses;

        // All consensus/state preparation above is deterministic from the
        // canonical ancestor and the ordered batch; the database mutex prevents
        // another YORTAL writer from intervening.
        let read_commit_started = Instant::now();
        read_tx.commit()?;
        timing.read_transaction_commit_us = read_commit_started.elapsed().as_micros() as u64;
        timing.state_validation_us = validation_started.elapsed().as_micros() as u64;
        timing.state_validation_ms = timing.state_validation_us / 1000;
        let named_state_us = timing.read_transaction_us
            .saturating_add(timing.parent_state_load_us)
            .saturating_add(timing.block_parse_us)
            .saturating_add(timing.tx_parse_us)
            .saturating_add(timing.txid_us)
            .saturating_add(timing.tx_connect_us)
            .saturating_add(timing.sapling_validate_us)
            .saturating_add(timing.block_finalize_us)
            .saturating_add(timing.tree_encode_us)
            .saturating_add(timing.header_hash_us)
            .saturating_add(timing.connector_new_us)
            .saturating_add(timing.block_root_us)
            .saturating_add(timing.read_transaction_commit_us);
        timing.block_loop_other_us = timing.state_validation_us.saturating_sub(named_state_us);
        let top_level_accounted_us = timing.read_transaction_us
            .saturating_add(timing.parent_state_load_us)
            .saturating_add(timing.block_parse_us)
            .saturating_add(timing.tx_parse_us)
            .saturating_add(timing.txid_us)
            .saturating_add(timing.tx_connect_us)
            .saturating_add(timing.sapling_validate_us)
            .saturating_add(timing.block_finalize_us)
            .saturating_add(timing.tree_encode_us)
            .saturating_add(timing.read_transaction_commit_us);
        timing.state_unattributed_us = timing.state_validation_us.saturating_sub(top_level_accounted_us);

        let begin_started = Instant::now();
        let tx = db.unchecked_transaction()?;
        timing.begin_ms = begin_started.elapsed().as_millis() as u64;
        pipeline_commit_log("STATE_VALIDATED", first.height, blocks.last().map(|b| b.height).unwrap_or(first.height), &timing);

        let first_height = first.height as i64;
        let normal_extension = if first.height == 0 {
            true
        } else {
            tx.query_row(
                "SELECT EXISTS(SELECT 1 FROM blocks WHERE hash=?1 AND height=?2 AND main_chain=1)",
                params![first.prev.as_slice(), (first.height - 1) as i64],
                |r| r.get::<_, i64>(0),
            )? != 0
        };
        let rollback_started = Instant::now();
        if !normal_extension {
            pipeline_commit_log("REORG", first.height, blocks.last().map(|b| b.height).unwrap_or(first.height), &timing);
            let stmt = |sql: &str| -> Result<()> {
                tx.prepare_cached(sql)?.execute(params![first_height])?;
                Ok(())
            };
            stmt("UPDATE blocks SET main_chain=0 WHERE main_chain=1 AND height>=?1")?;
            stmt("UPDATE sapling_roots SET main_chain=0 WHERE main_chain=1 AND height>=?1")?;
            stmt("UPDATE nullifiers SET main_chain=0 WHERE main_chain=1 AND block_hash IN
                  (SELECT hash FROM blocks WHERE main_chain=0 AND height>=?1)")?;
            stmt("DELETE FROM nullifiers WHERE main_chain=0 AND block_hash IN
                  (SELECT hash FROM blocks WHERE main_chain=0 AND height>=?1)")?;
            stmt("DELETE FROM txs WHERE block_hash IN
                  (SELECT hash FROM blocks WHERE main_chain=0 AND height>=?1)")?;
            stmt("DELETE FROM utxos WHERE height>=?1")?;
            stmt("UPDATE utxos SET spent_height=NULL WHERE spent_height>=?1")?;
            stmt("DELETE FROM sprout_nullifiers WHERE height>=?1")?;
            stmt("DELETE FROM block_state WHERE height>=?1")?;
        }
        timing.rollback_ms = rollback_started.elapsed().as_millis() as u64;

        let db_write_started = Instant::now();
        {
            // Use UPSERT instead of INSERT OR REPLACE. REPLACE is implemented by
            // deleting the conflicting row and inserting a new one, which creates
            // extra B-tree/index work on reorgs and needlessly dirties pages.
            // UPSERT updates only the fields that change while preserving the
            // existing primary-key row. Normal extension remains a single insert.
            let mut ins_block = tx.prepare_cached(
                "INSERT INTO blocks(hash,height,prev,work,raw,main_chain)
                 VALUES(?1,?2,?3,?4,?5,1)
                 ON CONFLICT(hash) DO UPDATE SET
                   height=excluded.height, prev=excluded.prev, work=excluded.work,
                   raw=excluded.raw, main_chain=1",
            )?;
            let mut ins_tx = tx.prepare_cached(
                "INSERT INTO txs(txid,block_hash,raw) VALUES(?1,?2,?3)
                 ON CONFLICT(txid) DO UPDATE SET block_hash=excluded.block_hash, raw=excluded.raw",
            )?;
            let mut ins_root = tx.prepare_cached(
                "INSERT INTO sapling_roots(block_hash,root,height,frontier,main_chain)
                 VALUES(?1,?2,?3,?4,1)
                 ON CONFLICT(block_hash) DO UPDATE SET
                   root=excluded.root, height=excluded.height, frontier=excluded.frontier, main_chain=1",
            )?;
            let sql_started = Instant::now();
            for (b, (root, frontier)) in blocks.iter().zip(block_trees.iter()) {
                ins_block.execute(params![b.hash.as_slice(), b.height, b.prev.as_slice(), b.work.as_slice(), &b.raw])?;
                for (txid, txraw) in &b.txs {
                    ins_tx.execute(params![txid.as_slice(), b.hash.as_slice(), txraw])?;
                }
                ins_root.execute(params![b.hash.as_slice(), root.as_slice(), b.height as i64, frontier])?;
            }
            timing.sql_write_ms = timing.sql_write_ms.saturating_add(sql_started.elapsed().as_millis() as u64);
            let index_started = Instant::now();
            let mut ins_nf = tx.prepare_cached("INSERT INTO nullifiers(n,block_hash,main_chain) VALUES(?1,?2,1)")?;
            for (nf, bh) in &pending_nullifiers {
                ins_nf.execute(params![nf.as_slice(), bh.as_slice()])?;
            }
            timing.index_write_ms = timing.index_write_ms.saturating_add(index_started.elapsed().as_millis() as u64);
            // Tip meta once per batch (same final values the per-block writes left).
            let last = &blocks[blocks.len() - 1];
            let mut meta = tx.prepare_cached("INSERT INTO meta(k,v) VALUES(?1,?2) ON CONFLICT(k) DO UPDATE SET v=excluded.v")?;
            meta.execute(params!["tip_hash", last.hash.as_slice()])?;
            meta.execute(params!["tip_height", last.height.to_le_bytes().to_vec()])?;
            // First height whose per-block sapling_roots rows were written by
            // v0.29.2+ (earlier batches stored the batch-final tree on every row).
            tx.prepare_cached("INSERT OR IGNORE INTO meta(k,v) VALUES('sapling_roots_per_block_from',?1)")?
                .execute(params![blocks[0].height.to_le_bytes().to_vec()])?;
        }

        coins.flush(&tx)?;
        sprout.flush(&tx)?;
        let tip = blocks[blocks.len() - 1].height;
        if tip > SPENT_OUTPUT_RETENTION {
            tx.execute(
                "DELETE FROM utxos WHERE spent_height IS NOT NULL AND spent_height<?1",
                params![(tip - SPENT_OUTPUT_RETENTION) as i64],
            )?;
        }

        let final_frontier_encode_started = Instant::now();
        let final_frontier = working.encode();
        timing.tree_encode_us = timing.tree_encode_us.saturating_add(final_frontier_encode_started.elapsed().as_micros() as u64);
        tx.execute(
            "INSERT INTO meta(k,v) VALUES('sapling_frontier',?1) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
            params![final_frontier],
        )?;
        timing.db_write_us = db_write_started.elapsed().as_micros() as u64;
        timing.db_write_ms = timing.db_write_us / 1000;
        let sqlite_commit_started = Instant::now();
        tx.commit()?;
        timing.sqlite_commit_us = sqlite_commit_started.elapsed().as_micros() as u64;
        timing.sqlite_commit_ms = timing.sqlite_commit_us / 1000;
        timing.total_us = total_started.elapsed().as_micros() as u64;
        timing.total_ms = timing.total_us / 1000;

        // Only publish RAM-cache state after SQLite has committed successfully.
        // A failed validation/commit therefore cannot poison the acceleration layer.
        let final_hash = blocks[blocks.len() - 1].hash;
        let final_height = blocks[blocks.len() - 1].height;
        let mut new_cache = ConsensusCache::new(
            final_hash,
            final_height,
            working.clone(),
            sprout.tree.clone(),
            sprout.chain_sprout_value,
            sprout.chain_sapling_value,
        );
        let mut new_utxos = HashMap::new();
        // Preserve the previous cache's untouched entries on normal extension.
        // On reorg, start from an empty cache because cached coins may belong to
        // the detached branch.
        if cache_parent_hit {
            if let Some(old) = cache_guard.as_ref() {
                new_utxos.extend(old.utxos.iter().map(|(k,v)| (*k, v.clone())));
            }
        }
        coins.update_cache(&mut new_utxos, UTXO_CACHE_ENTRIES);
        new_cache.utxos = Arc::new(new_utxos);
        *cache_guard = Some(new_cache);
        drop(cache_guard);

        pipeline_commit_log("COMMIT", first.height, blocks.last().map(|b| b.height).unwrap_or(first.height), &timing);
        *self.last_commit_timing.lock().unwrap() = timing;

        let mut sap = self.sapling.lock().unwrap();
        *sap = working;
        Ok(())
    }

    pub fn last_commit_timing(&self) -> CommitTiming {
        self.last_commit_timing.lock().unwrap().clone()
    }

    pub fn transaction_count(&self) -> Result<u64> {
        let db = self.db.lock().unwrap();
        Ok(db.query_row("SELECT COUNT(*) FROM txs", [], |r| r.get::<_, i64>(0))? as u64)
    }

    pub fn set_tip(&self, tip: &Tip) -> Result<()> {
        let db = self.db.lock().unwrap();
        let tx = db.unchecked_transaction()?;
        tx.execute("UPDATE blocks SET main_chain=0 WHERE main_chain=1", [])?;
        tx.execute(
            "UPDATE blocks SET main_chain=1 WHERE hash=?1",
            params![&tip.hash],
        )?;
        tx.execute(
            "INSERT INTO meta(k,v) VALUES('tip_hash',?1) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
            params![&tip.hash],
        )?;
        tx.execute(
            "INSERT INTO meta(k,v) VALUES('tip_height',?1) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
            params![tip.height.to_le_bytes().to_vec()],
        )?;
        tx.commit()?;
        *self.consensus_cache.lock().unwrap() = None;
        Ok(())
    }

    pub fn tip_height(&self) -> Result<Option<u64>> {
        let db = self.db.lock().unwrap();
        let r = db.query_row(
            "SELECT MAX(height) FROM blocks WHERE main_chain=1",
            [],
            |r| r.get::<_, Option<i64>>(0),
        )?;
        Ok(r.map(|x| x as u64))
    }

    pub fn has_block(&self, hash: &[u8]) -> Result<bool> {
        let db = self.db.lock().unwrap();
        Ok(db.query_row(
            "SELECT EXISTS(SELECT 1 FROM blocks WHERE hash=?1)",
            params![hash],
            |r| r.get(0),
        )?)
    }

    pub fn put_header(&self, height: u64, hash: &[u8], prev: &[u8], time: u32, bits: u32, work: &[u8], raw: &[u8]) -> Result<()> {
        if hash.len() != 32 || prev.len() != 32 || work.len() != 32 {
            bail!("invalid header hash/work length");
        }
        let db = self.db.lock().unwrap();
        db.execute(
            "UPDATE headers SET main_chain=0 WHERE height>=?1 AND hash<>?2 AND main_chain=1",
            params![height, hash],
        )?;
        db.execute(
            "INSERT INTO headers(hash,height,prev,time,bits,work,raw,main_chain) VALUES(?1,?2,?3,?4,?5,?6,?7,1)
                 ON CONFLICT(hash) DO UPDATE SET height=excluded.height,prev=excluded.prev,time=excluded.time,bits=excluded.bits,work=excluded.work,raw=excluded.raw,main_chain=1",
            params![hash, height, prev, time, bits, work, raw],
        )?;
        Ok(())
    }

    /// Write a whole validated header batch in ONE SQLite transaction.
    /// Each row runs exactly the two statements `put_header` runs, in order,
    /// so the resulting table is identical -- only the commit count changes
    /// (1 per 160-header batch instead of 2 autocommits per header).
    pub fn put_headers_batch(&self, rows: &[HeaderRow]) -> Result<()> {
        if rows.is_empty() {
            return Ok(());
        }
        let db = self.db.lock().unwrap();
        let tx = db.unchecked_transaction()?;
        {
            let mut demote = tx.prepare_cached(
                "UPDATE headers SET main_chain=0 WHERE height>=?1 AND hash<>?2 AND main_chain=1",
            )?;
            let mut insert = tx.prepare_cached(
                "INSERT INTO headers(hash,height,prev,time,bits,work,raw,main_chain) VALUES(?1,?2,?3,?4,?5,?6,?7,1)
                 ON CONFLICT(hash) DO UPDATE SET height=excluded.height,prev=excluded.prev,time=excluded.time,bits=excluded.bits,work=excluded.work,raw=excluded.raw,main_chain=1",
            )?;
            for r in rows {
                demote.execute(params![r.height, &r.hash[..]])?;
                insert.execute(params![&r.hash[..], r.height, &r.prev[..], r.time, r.bits, &r.work[..], &r.raw])?;
            }
        }
        tx.commit()?;
        Ok(())
    }

    /// Canonical headers `start..=end` as (height, hash, work, raw) in one
    /// query. Seeds the in-memory header window for batched header sync.
    pub fn header_rows_range(&self, start: u64, end: u64) -> Result<Vec<(u64, [u8; 32], [u8; 32], Vec<u8>)>> {
        let db = self.rd();
        let mut q = db.prepare_cached(
            "SELECT height,hash,work,raw FROM headers WHERE height>=?1 AND height<=?2 AND main_chain=1 ORDER BY height",
        )?;
        let mut rows = q.query(params![start as i64, end as i64])?;
        let mut out = Vec::new();
        while let Some(r) = rows.next()? {
            let h: i64 = r.get(0)?;
            let hash: Vec<u8> = r.get(1)?;
            let work: Vec<u8> = r.get(2)?;
            let raw: Vec<u8> = r.get(3)?;
            let (Ok(hash), Ok(work)) = (<[u8; 32]>::try_from(hash.as_slice()), <[u8; 32]>::try_from(work.as_slice())) else {
                continue;
            };
            out.push((h as u64, hash, work, raw));
        }
        Ok(out)
    }

    pub fn header_by_height(&self, height: u64) -> Result<Option<Vec<u8>>> {
        let db = self.rd();
        let r = db.query_row(
            "SELECT raw FROM headers WHERE height=?1 AND main_chain=1",
            params![height],
            |r| r.get(0),
        );
        match r {
            Ok(v) => Ok(Some(v)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    pub fn tip_hash(&self) -> Result<Option<Vec<u8>>> {
        let db = self.db.lock().unwrap();
        let r = db.query_row(
            "SELECT hash FROM blocks WHERE main_chain=1 ORDER BY height DESC LIMIT 1",
            [],
            |r| r.get(0),
        );
        match r {
            Ok(v) => Ok(Some(v)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    pub fn header_height_by_hash(&self, hash: &[u8]) -> Result<Option<u64>> {
        let db = self.rd();
        let r = db.query_row("SELECT height FROM headers WHERE hash=?1 AND main_chain=1", params![hash], |r| r.get::<_, i64>(0));
        match r {
            Ok(v) => Ok(Some(v as u64)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    pub fn header_height(&self) -> Result<Option<u64>> {
        let db = self.rd();
        let r = db.query_row("SELECT MAX(height) FROM headers WHERE main_chain=1", [], |r| r.get::<_, Option<i64>>(0))?;
        Ok(r.map(|x| x as u64))
    }

    pub fn header_hash_by_height(&self, height: u64) -> Result<Option<Vec<u8>>> {
        let db = self.rd();
        let r = db.query_row("SELECT hash FROM headers WHERE height=?1 AND main_chain=1", params![height], |r| r.get(0));
        match r {
            Ok(v) => Ok(Some(v)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    pub fn header_work_by_height(&self, height: u64) -> Result<Option<Vec<u8>>> {
        let db = self.rd();
        let r = db.query_row("SELECT work FROM headers WHERE height=?1 AND main_chain=1", params![height], |r| r.get(0));
        match r {
            Ok(v) => Ok(Some(v)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    pub fn header_hashes_range(&self, start: u64, end: u64) -> Result<HashMap<u64, [u8; 32]>> {
        let db = self.rd();
        let mut q = db.prepare_cached("SELECT height,hash FROM headers WHERE height>=?1 AND height<=?2 AND main_chain=1")?;
        let mut rows = q.query(params![start as i64, end as i64])?;
        let mut out = HashMap::new();
        while let Some(r) = rows.next()? {
            let h: i64 = r.get(0)?;
            let v: Vec<u8> = r.get(1)?;
            if let Ok(a) = <[u8; 32]>::try_from(v.as_slice()) {
                out.insert(h as u64, a);
            }
        }
        Ok(out)
    }

    /// Chain work for every canonical header in `start..=end` (inclusive), in
    /// one query. Used by the parallel pipeline's fetch stage so verifier
    /// threads never touch the database.
    pub fn header_works_range(&self, start: u64, end: u64) -> Result<HashMap<u64, [u8; 32]>> {
        let db = self.rd();
        let mut q = db.prepare_cached("SELECT height,work FROM headers WHERE height>=?1 AND height<=?2 AND main_chain=1")?;
        let mut rows = q.query(params![start as i64, end as i64])?;
        let mut out = HashMap::new();
        while let Some(r) = rows.next()? {
            let h: i64 = r.get(0)?;
            let v: Vec<u8> = r.get(1)?;
            if let Ok(a) = <[u8; 32]>::try_from(v.as_slice()) {
                out.insert(h as u64, a);
            }
        }
        Ok(out)
    }

    pub fn header_times_range(&self, start: u64, end: u64) -> Result<Vec<(u64, u32)>> {
        let db = self.rd();
        let mut q = db.prepare_cached("SELECT height,time FROM headers WHERE height>=?1 AND height<?2 AND main_chain=1 ORDER BY height")?;
        let mut rows = q.query(params![start as i64, end as i64])?;
        let mut out = Vec::new();
        while let Some(r) = rows.next()? {
            let h: i64 = r.get(0)?;
            let t: i64 = r.get(1)?;
            out.push((h as u64, t as u32));
        }
        Ok(out)
    }

    pub fn header_time(&self, height: u64) -> Result<Option<u32>> {
        let db = self.rd();
        let r = db.query_row("SELECT time FROM headers WHERE height=?1 AND main_chain=1", params![height as i64], |r| r.get::<_, i64>(0));
        match r {
            Ok(v) => Ok(Some(v as u32)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    pub fn locator_hashes(&self) -> Result<Vec<[u8; 32]>> {
        let tip = self.header_height()?.unwrap_or(0);
        let mut heights = Vec::new();
        let mut h = tip;
        while h > 0 && heights.len() < 10 {
            heights.push(h);
            h = h.saturating_sub(1);
        }
        let mut step = 2u64;
        while h > 0 && heights.len() < 32 {
            heights.push(h);
            h = h.saturating_sub(step);
            step = step.saturating_mul(2);
        }
        heights.push(0);
        heights.sort_unstable();
        heights.dedup();
        heights.reverse();
        let mut out = Vec::new();
        for h in heights {
            if let Some(v) = self.header_hash_by_height(h)? {
                if v.len() == 32 {
                    let mut a = [0u8; 32];
                    a.copy_from_slice(&v);
                    out.push(a);
                }
            } else if h == 0 {
                out.push(ycash_chain::genesis_hash_internal());
            }
        }
        Ok(out)
    }

    pub fn export_snapshot(&self, dest: &Path) -> Result<()> {
        let path = match dest.to_str() {
            Some(s) => s,
            None => bail!("destination path is not valid UTF-8"),
        };
        let db = self.db.lock().unwrap();
        db.execute("VACUUM INTO ?1", params![path])?;
        Ok(())
    }
}

/// Read-only companion connection. WAL lets it read committed rows while the
/// writer holds an open transaction. In-memory/temp paths get no reader.
fn open_reader(path: &Path) -> Option<Mutex<Connection>> {
    let s = path.to_str()?;
    if s.is_empty() || s == ":memory:" { return None; }
    let flags = OpenFlags::SQLITE_OPEN_READ_ONLY | OpenFlags::SQLITE_OPEN_NO_MUTEX | OpenFlags::SQLITE_OPEN_URI;
    let c = Connection::open_with_flags(path, flags).ok()?;
    let _ = c.busy_timeout(std::time::Duration::from_secs(10));
    c.execute_batch("PRAGMA query_only=1; PRAGMA cache_size=-16384; PRAGMA temp_store=MEMORY;").ok()?;
    Some(Mutex::new(c))
}

fn table_exists(db: &Connection, name: &str) -> Result<bool> {
    Ok(db.query_row(
        "SELECT EXISTS(SELECT 1 FROM sqlite_master WHERE type='table' AND name=?1)",
        params![name],
        |r| r.get(0),
    )?)
}

fn create_schema(db: &Connection) -> Result<()> {
    db.execute_batch(
        "BEGIN;
         CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY,v BLOB NOT NULL);
         CREATE TABLE IF NOT EXISTS blocks(hash BLOB PRIMARY KEY,height INTEGER NOT NULL,prev BLOB NOT NULL,work BLOB NOT NULL,raw BLOB NOT NULL,main_chain INTEGER NOT NULL DEFAULT 0);
         CREATE TABLE IF NOT EXISTS headers(hash BLOB PRIMARY KEY,height INTEGER NOT NULL,prev BLOB NOT NULL,time INTEGER NOT NULL,bits INTEGER NOT NULL,work BLOB NOT NULL,raw BLOB NOT NULL,main_chain INTEGER NOT NULL DEFAULT 0);
         CREATE INDEX IF NOT EXISTS headers_height ON headers(height);
         CREATE INDEX IF NOT EXISTS blocks_height ON blocks(height);
         CREATE INDEX IF NOT EXISTS blocks_prev ON blocks(prev);
         CREATE TABLE IF NOT EXISTS undo(block_hash BLOB PRIMARY KEY,height INTEGER NOT NULL,undo BLOB NOT NULL);
         CREATE TABLE IF NOT EXISTS txs(txid BLOB PRIMARY KEY,block_hash BLOB NOT NULL,raw BLOB NOT NULL);
         CREATE INDEX IF NOT EXISTS txs_block_hash ON txs(block_hash);
         CREATE TABLE IF NOT EXISTS nullifiers(n BLOB PRIMARY KEY,block_hash BLOB NOT NULL,main_chain INTEGER NOT NULL DEFAULT 1);
         CREATE INDEX IF NOT EXISTS nullifiers_block_hash ON nullifiers(block_hash);
         CREATE TABLE IF NOT EXISTS sapling_roots(
             block_hash BLOB PRIMARY KEY,
             root BLOB NOT NULL,
             height INTEGER NOT NULL,
             frontier BLOB NOT NULL,
             main_chain INTEGER NOT NULL DEFAULT 1
         );
         CREATE INDEX IF NOT EXISTS sapling_roots_root_main ON sapling_roots(root,main_chain);
         CREATE INDEX IF NOT EXISTS sapling_roots_root_main_height ON sapling_roots(root,main_chain,height);
         CREATE INDEX IF NOT EXISTS sapling_roots_height ON sapling_roots(height);
         CREATE TABLE IF NOT EXISTS utxos(
             txid BLOB NOT NULL,
             vout INTEGER NOT NULL,
             value INTEGER NOT NULL,
             script BLOB NOT NULL,
             height INTEGER NOT NULL,
             coinbase INTEGER NOT NULL,
             spent_height INTEGER,
             PRIMARY KEY(txid,vout)
         );
         CREATE INDEX IF NOT EXISTS utxos_height ON utxos(height);
         CREATE INDEX IF NOT EXISTS utxos_spent_height ON utxos(spent_height);
         CREATE TABLE IF NOT EXISTS sprout_nullifiers(n BLOB PRIMARY KEY,height INTEGER NOT NULL);
         CREATE INDEX IF NOT EXISTS sprout_nullifiers_height ON sprout_nullifiers(height);
         CREATE TABLE IF NOT EXISTS block_state(
             block_hash BLOB PRIMARY KEY,
             height INTEGER NOT NULL,
             sprout_root BLOB NOT NULL,
             sprout_frontier BLOB NOT NULL,
             chain_sprout_value INTEGER NOT NULL,
             chain_sapling_value INTEGER NOT NULL
         );
         CREATE INDEX IF NOT EXISTS block_state_height ON block_state(height);
         CREATE INDEX IF NOT EXISTS block_state_sprout_root ON block_state(sprout_root);
         CREATE INDEX IF NOT EXISTS block_state_sprout_root_height ON block_state(sprout_root,height);
         COMMIT;",
    )?;
    Ok(())
}

fn telemetry_array_json(values: &[u64; 32]) -> String {
    let mut out = String::from("[");
    for (i, v) in values.iter().enumerate() {
        if i != 0 { out.push(','); }
        out.push_str(&v.to_string());
    }
    out.push(']');
    out
}

fn telemetry_array_json_32(values: &[u64; 32]) -> String {
    let mut out = String::from("[");
    for (i, v) in values.iter().enumerate() {
        if i != 0 { out.push(','); }
        out.push_str(&v.to_string());
    }
    out.push(']');
    out
}

fn pipeline_commit_log(stage: &str, first: u64, last: u64, t: &CommitTiming) {
    eprintln!(
        "[DBPIPE] stage={} range={}..{} total_ms={} begin_ms={} state_validate_ms={} state_validate_us={} state_unattributed_us={} header_hash_us={} connector_new_us={} connector_other_us={} block_root_us={} block_loop_other_us={} slowest_block_height={} slowest_block_us={} slowest_block_other_us={} slowest_tx_height={} slowest_tx_index={} slowest_tx_us={} slowest_tx_other_us={} parent_state_ms={} parent_state_us={} parent_frontier_us={} sprout_state_load_us={} block_parse_ms={} block_parse_us={} txid_us={} tx_parse_us={} tx_connect_ms={} tx_connect_us={} sigops_ms={} sigops_us={} bip30_ms={} bip30_us={} utxo_lookup_ms={} sprout_req_ms={} value_ms={} script_ms={} coin_state_ms={} sprout_apply_ms={} sapling_validate_ms={} sapling_anchor_ms={} sapling_nullifier_ms={} sapling_tree_ms={} block_finalize_ms={} tree_ms={} rollback_ms={} db_write_ms={} sql_write_ms={} index_write_ms={} sqlite_commit_ms={} blocks={} txs={} utxo_lookups={} bip30_checks={} script_checks={} script_parallel_workers={} script_parallel_us={} script_spawn_us={} script_join_us={} script_pool_overhead_us={} script_pool_threads={} script_worker_max_us={} script_worker_min_us={} script_worker_wall_us={} script_worker_input_work_us={} script_worker_inputs={} utxo_cache_hits={} utxo_cache_misses={} parent_state_cache_hit={} sprout_state_cache_hit={} sapling_anchor_queries={} sapling_nullifier_queries={} sapling_empty_hashes_avoided={} sapling_root_cache_hits={} root_levels_us={} root_level_hashes={} root_empty_us={} root_empty_hashes={} root_hash_us={} root_hashes={}",
        stage, first, last, t.total_ms, t.begin_ms, t.state_validation_ms, t.state_validation_us, t.state_unattributed_us, t.header_hash_us, t.connector_new_us, t.connector_other_us, t.block_root_us, t.block_loop_other_us, t.slowest_block_height, t.slowest_block_us, t.slowest_block_other_us, t.slowest_tx_height, t.slowest_tx_index, t.slowest_tx_us, t.slowest_tx_other_us, t.parent_state_load_ms, t.parent_state_load_us, t.parent_frontier_load_us, t.sprout_state_load_us, t.block_parse_ms, t.block_parse_us, t.txid_us, t.tx_parse_us, t.tx_connect_ms, t.tx_connect_us, t.sigops_ms, t.sigops_us, t.bip30_ms, t.bip30_us, t.utxo_lookup_ms, t.sprout_requirements_ms, t.value_checks_ms, t.script_ms, t.coin_state_update_ms, t.sprout_apply_ms, t.sapling_validate_ms, t.sapling_anchor_lookup_ms, t.sapling_nullifier_lookup_ms, t.sapling_tree_update_ms, t.block_finalize_ms, t.tree_ms, t.rollback_ms, t.db_write_ms, t.sql_write_ms, t.index_write_ms, t.sqlite_commit_ms, t.blocks, t.txs, t.utxo_lookups, t.bip30_checks, t.script_checks, t.script_parallel_workers, t.script_parallel_us, t.script_spawn_us, t.script_join_us, t.script_pool_overhead_us, t.script_pool_threads, t.script_worker_max_us, t.script_worker_min_us, telemetry_array_json_32(&t.script_worker_wall_us), telemetry_array_json_32(&t.script_worker_input_work_us), telemetry_array_json_32(&t.script_worker_inputs), t.utxo_cache_hits, t.utxo_cache_misses, t.parent_state_cache_hit, t.sprout_state_cache_hit, t.sapling_anchor_queries, t.sapling_nullifier_queries, t.sapling_empty_hashes_avoided, t.sapling_root_cache_hits, telemetry_array_json(&t.block_root_level_us), telemetry_array_json(&t.block_root_level_hashes), telemetry_array_json(&t.block_root_empty_us), telemetry_array_json(&t.block_root_empty_hashes), telemetry_array_json(&t.block_root_hash_us), telemetry_array_json(&t.block_root_hashes)
    );
}

fn validate_batch_shape(blocks: &[BlockCommit]) -> Result<()> {
    for i in 1..blocks.len() {
        if blocks[i].height != blocks[i - 1].height + 1 || blocks[i].prev != blocks[i - 1].hash {
            bail!("block batch is not contiguous");
        }
    }
    Ok(())
}

fn load_parent_frontier(
    tx: &rusqlite::Transaction<'_>,
    height: u64,
    prev: &[u8; 32],
) -> Result<SaplingConsensusState> {
    if height == 1 && *prev == ycash_chain::genesis_hash_internal() {
        return Ok(SaplingConsensusState::new());
    }
    if height == 0 {
        return Ok(SaplingConsensusState::new());
    }
    let frontier = tx
        .query_row(
            "SELECT frontier FROM sapling_roots WHERE block_hash=?1 AND main_chain=1 AND height=?2",
            params![prev.as_slice(), (height - 1) as i64],
            |r| r.get::<_, Vec<u8>>(0),
        )
        .map_err(|e| anyhow::anyhow!("missing canonical Sapling state for parent: {e}"))?;
    SaplingConsensusState::decode(&frontier)
        .map_err(|e| anyhow::anyhow!("invalid canonical Sapling state for parent: {e:?}"))
}

// v0.22 adaptive sync pipeline
pub mod pipeline;

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp_db() -> std::path::PathBuf {
        std::env::temp_dir().join(format!(
            "ycash-state-test-{}-{}.sqlite",
            std::process::id(),
            SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos()
        ))
    }

    #[test]
    fn fresh_database_creates_txs_before_index() {
        let p = temp_db();
        let s = State::open(&p).unwrap();
        assert_eq!(s.transaction_count().unwrap(), 0);
        let db = Connection::open(&p).unwrap();
        let tables: Vec<String> = {
            let mut q = db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").unwrap();
            q.query_map([], |r| r.get(0)).unwrap().map(|r| r.unwrap()).collect()
        };
        assert!(tables.iter().any(|x| x == "txs"));
        assert!(tables.iter().any(|x| x == "sapling_roots"));
        let index_target: String = db.query_row(
            "SELECT tbl_name FROM sqlite_master WHERE type='index' AND name='txs_block_hash'",
            [], |r| r.get(0)
        ).unwrap();
        assert_eq!(index_target, "txs");
        drop(s);
        let _ = fs::remove_file(&p);
        let _ = fs::remove_file(format!("{}-wal", p.display()));
        let _ = fs::remove_file(format!("{}-shm", p.display()));
    }

    #[test]
    fn consensus_state_indexes_are_present_and_wal_is_enabled() {
        let p = temp_db();
        let s = State::open(&p).unwrap();
        let db = Connection::open(&p).unwrap();
        let journal: String = db.pragma_query_value(None, "journal_mode", |r| r.get(0)).unwrap();
        assert_eq!(journal.to_ascii_lowercase(), "wal");
        for name in ["sapling_roots_root_main_height", "block_state_sprout_root_height", "utxos_height", "utxos_spent_height"] {
            let exists: i64 = db.query_row(
                "SELECT EXISTS(SELECT 1 FROM sqlite_master WHERE type='index' AND name=?1)",
                params![name], |r| r.get(0)
            ).unwrap();
            assert_eq!(exists, 1, "missing index {name}");
        }
        drop(s);
        let _ = fs::remove_file(&p);
        let _ = fs::remove_file(format!("{}-wal", p.display()));
        let _ = fs::remove_file(format!("{}-shm", p.display()));
    }

    #[test]
    fn failed_old_unversioned_database_is_rebuilt() {
        let p = temp_db();
        {
            let db = Connection::open(&p).unwrap();
            db.execute_batch("CREATE TABLE blocks(hash BLOB PRIMARY KEY,height INTEGER,prev BLOB,work BLOB,raw BLOB,main_chain INTEGER); CREATE TABLE headers(hash BLOB PRIMARY KEY,height INTEGER,prev BLOB,time INTEGER,bits INTEGER,work BLOB,raw BLOB,main_chain INTEGER);").unwrap();
        }
        let s = State::open(&p).unwrap();
        assert_eq!(s.transaction_count().unwrap(), 0);
        let db = Connection::open(&p).unwrap();
        let v: i64 = db.pragma_query_value(None, "user_version", |r| r.get(0)).unwrap();
        assert_eq!(v, SCHEMA_VERSION);
        drop(s);
        let _ = fs::remove_file(&p);
        let _ = fs::remove_file(format!("{}-wal", p.display()));
        let _ = fs::remove_file(format!("{}-shm", p.display()));
    }
}
