//! Wires the v0.23 concurrent multi-peer block pipeline (`ycash_state::pipeline`,
//! the same engine `crates/node` already uses) into the Android node's
//! outbound peer connections.
//!
//! Header sync stays owned by a single peer at a time (`sync_owner` in
//! `main.rs`) -- the header chain is one canonical, strictly ordered stream,
//! and that part of the design was already correct. The gap was on the block
//! side: `download_blocks()` only ran after `sync_headers()` fully returned,
//! on the *same* single connection, even though `peer_supervisor` already
//! keeps up to 12 other peers connected and idle in their ping/keepalive
//! loop the whole time.
//!
//! This module lets every connected peer -- not just the header owner --
//! claim and validate a disjoint height range the moment headers exist ahead
//! of the local block tip, in parallel with the header owner's ongoing
//! header sync. A single coordinator (guarded by the same mutex as the
//! scheduler) still applies commits to `State` strictly in height order, so
//! out-of-order validation across peers can never produce an out-of-order
//! canonical chain -- matching the safety invariant in
//! `V0.23_CONCURRENT_PIPELINE.md`.

use std::collections::BTreeMap;
use std::io::ErrorKind;
use std::net::TcpStream;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use ycash_chain::{genesis_hash_internal, read_block_at_height, txid};
use ycash_consensus::{validate_for_commit, Context};
use ycash_network::runtime::{getdata_payload, unix_time};
use ycash_state::pipeline::{range_scheduler::RangeLease, AdaptiveConfig, PipelineEngine};
use ycash_state::{BlockCommit, State};

use crate::runtime::SharedState;
use crate::{header_from_raw, is_timeout, mtp, read_message, send};

/// Cloneable handle shared across every peer connection so height ranges are
/// claimed exactly once and committed exactly once, in order.
#[derive(Clone)]
pub struct BlockPipeline {
    inner: Arc<Mutex<Inner>>,
}

struct Inner {
    engine: PipelineEngine,
    /// Next height the coordinator is waiting to commit, in strict order.
    next_commit: u64,
    /// Validated-but-not-yet-committed ranges, keyed by their start height,
    /// so a later range that finishes first can wait for an earlier one.
    buffered: BTreeMap<u64, (RangeLease, Vec<BlockCommit>, u64)>,
    /// High-water mark already handed to the scheduler, so we don't
    /// re-enqueue the same heights every time a peer calls `ensure_planned`.
    planned_up_to: u64,
}

impl BlockPipeline {
    /// `next_commit` should be the current validated block tip + 1.
    pub fn new(next_commit: u64) -> Self {
        Self {
            inner: Arc::new(Mutex::new(Inner {
                engine: PipelineEngine::new(AdaptiveConfig::default()),
                next_commit,
                buffered: BTreeMap::new(),
                planned_up_to: next_commit.saturating_sub(1),
            })),
        }
    }

    /// Make sure claimable ranges exist up to `chain_tip` (normally
    /// `headers_height`). Cheap to call repeatedly -- it only enqueues new
    /// ranges past whatever was already planned.
    pub fn ensure_planned(&self, chain_tip: u64, workers: usize) {
        let mut g = self.inner.lock().unwrap();
        if chain_tip <= g.planned_up_to {
            return;
        }
        let next = g.next_commit.max(g.planned_up_to.saturating_add(1));
        if next <= chain_tip {
            let _ = g.engine.plan_parallel_ranges(next, chain_tip, workers.max(1));
            // `plan_parallel_ranges` only plans one adaptive window.  The old
            // code advanced `planned_up_to` all the way to `chain_tip`, even
            // when only the first window was actually enqueued. That made a
            // header tip look fully planned after scheduling only the first
            // window, so subsequent calls skipped the remaining heights.
            // Track the end of the window that was really enqueued instead.
            let snap = g.engine.snapshot();
            g.planned_up_to = next
                .saturating_add(snap.window.saturating_sub(1))
                .min(chain_tip);
        }
    }

    /// Try to claim one pending range for `peer_label` and, if one is
    /// available, fetch + validate it over `stream` and fold it into the
    /// commit path. Returns `Ok(true)` if a range was processed, `Ok(false)`
    /// if nothing was available to claim right now.
    pub fn run_once(
        &self,
        stream: &mut TcpStream,
        state: &Arc<State>,
        live: &SharedState,
        peer_label: &str,
    ) -> std::io::Result<bool> {
        let lease = {
            let mut g = self.inner.lock().unwrap();
            g.engine.claim(peer_label)
        };
        let Some(lease) = lease else { return Ok(false) };

        {
            // blocks_in_flight/current_window are already tracked by the
            // engine itself (set in plan_parallel_ranges, decremented in
            // complete()) -- just mirror its snapshot rather than keeping a
            // second counter here.
            let snap = { let g = self.inner.lock().unwrap(); g.engine.snapshot() };
            let mut st = live.write().unwrap();
            st.blocks_in_flight = snap.blocks_in_flight;
            st.active_block_workers = snap.workers;
            st.completed_ranges = snap.completed_ranges;
            st.retried_ranges = snap.retried_ranges;
            st.quarantined_ranges = snap.quarantined_ranges;
            st.message = format!(
                "{} claimed heights {}..{}",
                peer_label, lease.range.start, lease.range.end
            );
        }

        match fetch_and_validate(stream, state, &lease) {
            Ok((blocks, bytes)) => {
                self.complete(lease, blocks, bytes, state, live);
                Ok(true)
            }
            Err(e) => {
                let snap = {
                    let mut g = self.inner.lock().unwrap();
                    g.engine.release(lease.id);
                    g.engine.snapshot()
                };
                // Mirror immediately: a range going to retry/quarantine here
                // (peer timed out or sent bad data) is exactly the signal
                // that should show up on the dashboard even if no range
                // completes again for a while.
                let mut st = live.write().unwrap();
                st.active_block_workers = snap.workers;
                st.completed_ranges = snap.completed_ranges;
                st.retried_ranges = snap.retried_ranges;
                st.quarantined_ranges = snap.quarantined_ranges;
                Err(e)
            }
        }
    }

    fn complete(
        &self,
        lease: RangeLease,
        blocks: Vec<BlockCommit>,
        bytes: u64,
        state: &Arc<State>,
        live: &SharedState,
    ) {
        let mut g = self.inner.lock().unwrap();
        g.buffered.insert(lease.range.start, (lease, blocks, bytes));
        // Commit every buffered range that is now contiguous with
        // next_commit, strictly in height order, regardless of which peer
        // validated it or the order ranges finished in.
        loop {
            let key = match g.buffered.keys().next().copied() {
                Some(k) => k,
                None => break,
            };
            if key != g.next_commit {
                break;
            }
            let (lease, blocks, bytes) = g.buffered.remove(&key).unwrap();
            let started = Instant::now();
            if let Err(e) = state.commit_blocks_batch(&blocks) {
                let mut st = live.write().unwrap();
                st.last_error = format!(
                    "batch commit {}..{} failed: {}",
                    lease.range.start, lease.range.end, e
                );
                g.engine.release(lease.id);
                break;
            }
            let commit_ms = started.elapsed().as_millis() as u64;
            g.engine.complete(lease.id, blocks.len() as u64, bytes);
            g.next_commit = lease.range.end + 1;
            if let Some(last) = blocks.last() {
                let snap = g.engine.snapshot();
                let tip_time = state
                    .header_by_height(last.height)
                    .ok()
                    .flatten()
                    .and_then(|raw| header_from_raw(&raw, last.height).ok())
                    .map(|h| h.time)
                    .unwrap_or(0);
                let mut st = live.write().unwrap();
                st.local_height = last.height;
                st.tip_time = tip_time;
                st.blocks_received = st.blocks_received.saturating_add(blocks.len() as u64);
                st.blocks_validated = st.blocks_validated.saturating_add(blocks.len() as u64);
                st.block_bytes_received = st.block_bytes_received.saturating_add(bytes);
                st.db_commits = st.db_commits.saturating_add(1);
                st.db_commit_ms_total = st.db_commit_ms_total.saturating_add(commit_ms);
                st.txs_indexed = st
                    .txs_indexed
                    .saturating_add(blocks.iter().map(|b| b.txs.len() as u64).sum());
                st.blocks_in_flight = snap.blocks_in_flight;
                st.batch_size = blocks.len() as u64;
                st.validation_queue = g.buffered.len() as u64;
                st.active_block_workers = snap.workers;
                st.completed_ranges = snap.completed_ranges;
                st.retried_ranges = snap.retried_ranges;
                st.quarantined_ranges = snap.quarantined_ranges;
                st.last_commit_unix = unix_time();
                st.message = format!(
                    "committed heights {}..{} ({} concurrent workers)",
                    lease.range.start, lease.range.end, snap.workers
                );
            }
        }
    }
}

fn fetch_and_validate(
    stream: &mut TcpStream,
    state: &Arc<State>,
    lease: &RangeLease,
) -> std::io::Result<(Vec<BlockCommit>, u64)> {
    let mut requests = Vec::new();
    for h in lease.range.start..=lease.range.end {
        let raw = state
            .header_by_height(h)
            .map_err(|e| ioe(&e.to_string()))?
            .ok_or_else(|| ioe("missing header for claimed range"))?;
        requests.push((h, header_from_raw(&raw, h)?.hash()));
    }
    let hashes: Vec<[u8; 32]> = requests.iter().map(|(_, h)| *h).collect();
    send(stream, "getdata", &getdata_payload(&hashes))?;

    let mut done = std::collections::HashSet::new();
    let mut blocks = Vec::with_capacity(requests.len());
    let mut bytes = 0u64;
    let mut idle = 0u32;
    // `idle` only counts consecutive *silence* (read timeouts) and resets on
    // any message at all, including ones that don't advance `done` (ping,
    // addr, inv). A peer that accepts our getdata but never actually sends
    // the requested blocks -- while still being "alive" enough to ping --
    // can hold this claim hostage forever: idle keeps resetting, the range
    // never times out, never gets released, and never shows up as retried
    // or quarantined. This wall-clock deadline is a backstop that fires
    // regardless of what the peer sends in the meantime.
    let deadline = Instant::now() + Duration::from_secs(90);
    while done.len() < requests.len() {
        if Instant::now() >= deadline {
            return Err(ioe(&format!(
                "peer did not deliver claimed range {}..{} within 90s (received {}/{} blocks; other traffic may have kept the connection looking alive)",
                lease.range.start, lease.range.end, done.len(), requests.len()
            )));
        }
        let (cmd, payload) = match read_message(stream) {
            Ok(v) => v,
            Err(e) if is_timeout(&e) => {
                idle += 1;
                if idle >= 8 {
                    return Err(ioe("peer stopped sending blocks for claimed range"));
                }
                continue;
            }
            Err(e) => return Err(e),
        };
        idle = 0;
        // ping/addr/etc arriving on a worker connection mid-range are simply
        // skipped here; this peer's own session loop still handles those
        // between claims, and a range is small enough (adaptive window,
        // partitioned across active peers) that this is a brief gap.
        if cmd != "block" {
            continue;
        }
        let mut matched = None;
        for (height, expected) in &requests {
            if done.contains(height) {
                continue;
            }
            if let Ok(candidate) = read_block_at_height(&payload, *height) {
                if candidate.header.hash() == *expected {
                    matched = Some(*height);
                    break;
                }
            }
        }
        let height = matched.ok_or_else(|| ioe("received block not in claimed range"))?;
        let expected_hash = requests.iter().find(|(h, _)| *h == height).map(|(_, h)| *h).unwrap();
        let prev_header = if height == 1 {
            None
        } else {
            state
                .header_by_height(height - 1)
                .map_err(|e| ioe(&e.to_string()))?
                .map(|r| header_from_raw(&r, height - 1))
                .transpose()?
        };
        let mtp_time = mtp(state, height);
        let ctx = Context {
            height,
            prev_height: height.saturating_sub(1),
            median_time_past: mtp_time,
        };
        let validated = validate_for_commit(&payload, ctx)
            .map_err(|e| ioe(&format!("block validation failed at {height}: {e:?}")))?;
        if validated.txs.is_empty() {
            return Err(ioe("consensus decoder returned zero transactions"));
        }
        let work = state
            .header_work_by_height(height)
            .map_err(|e| ioe(&e.to_string()))?
            .ok_or_else(|| ioe("missing header chain work"))?;
        let work: [u8; 32] = work.try_into().map_err(|_| ioe("invalid chain work"))?;
        let prev_hash: [u8; 32] = prev_header
            .as_ref()
            .map(|p| p.hash())
            .unwrap_or_else(genesis_hash_internal);
        let txs: Vec<([u8; 32], Vec<u8>)> = validated
            .txs
            .iter()
            .map(|t| (txid(t), t.clone()))
            .collect();
        bytes += payload.len() as u64;
        blocks.push(BlockCommit {
            height,
            hash: expected_hash,
            prev: prev_hash,
            work,
            raw: payload.clone(),
            txs,
        });
        done.insert(height);
    }
    blocks.sort_by_key(|b| b.height);
    Ok((blocks, bytes))
}

fn ioe(s: &str) -> std::io::Error {
    std::io::Error::new(ErrorKind::InvalidData, s.to_string())
}
