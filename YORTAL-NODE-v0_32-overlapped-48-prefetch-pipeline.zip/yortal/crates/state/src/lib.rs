use anyhow::{bail, Result};
use std::collections::{HashMap, HashSet};
use std::io::Cursor;
use std::path::Path;
use std::sync::{Arc, Mutex};
use std::time::Instant;
use std::cell::Cell;
use std::sync::atomic::{AtomicU64, Ordering};
use ycash_consensus::{validate_sapling_transaction_state_opts, SaplingConsensusState, SproutTree};

pub mod db;
pub use db::Db;

pub mod chainstate;
use chainstate::{
    BlockConnector, CoinsView, PreparedSproutChanges, PreparedUtxoChanges, SproutView,
    SPENT_OUTPUT_RETENTION, UtxoCache,
};

/// v5: RocksDB column families (Zebra-style). The logical state model is
/// unchanged from schema v4: transparent UTXO set
/// (value/script/height/coinbase/spent_height), Sprout nullifiers and
/// per-block Sprout treestate + value pools, Sapling per-block roots and
/// nullifiers. Only the physical representation differs.
const SCHEMA_VERSION: u64 = 5;

#[derive(Debug, Clone)]
pub struct Tip {
    pub hash: Vec<u8>,
    pub height: u64,
    pub work: [u8; 32],
}

#[derive(Debug, Clone, Default)]
pub struct CommitTiming {
    pub total_ms: u64,
    /// Time spent after a batch became commit-ready before state preparation began.
    /// Populated by the pipeline layer; zero for direct State callers.
    pub queue_wait_ms: u64,
    /// Head-of-line wait before the commit worker could obtain a contiguous batch.
    /// Populated by the pipeline layer; zero for direct State callers.
    pub head_of_line_wait_ms: u64,
    /// Full ordered commit wall time, including state preparation, batch construction and the atomic write.
    /// Field names ending in `sqlite_*`/`sql_*` are kept for the dashboard JSON
    /// contract; they now measure the RocksDB WriteBatch stages.
    pub state_validation_us: u64,
    pub state_unattributed_us: u64,
    /// Fine-grained residuals used to locate time that is not covered by the named consensus calls.
    pub header_hash_us: u64,
    pub connector_new_us: u64,
    pub connector_other_us: u64,
    pub block_root_us: u64,
    /// Deep Sapling root telemetry: per-root-level time/hash counts plus
    /// the repeated empty-subtree work that can dominate root construction.
    pub block_root_level_us: [u64; 32],
    pub block_root_level_hashes: [u64; 32],
    pub block_root_empty_us: [u64; 32],
    pub block_root_empty_hashes: [u64; 32],
    pub block_root_hash_us: [u64; 32],
    pub block_root_hashes: [u64; 32],
    pub block_loop_other_us: u64,
    pub slowest_block_height: u64,
    pub slowest_block_us: u64,
    pub slowest_block_other_us: u64,
    pub slowest_tx_height: u64,
    pub slowest_tx_index: u64,
    pub slowest_tx_us: u64,
    pub slowest_tx_other_us: u64,
    pub total_us: u64,
    pub state_validation_ms: u64,
    pub rollback_ms: u64,
    pub db_write_ms: u64,
    pub db_write_us: u64,
    /// Time to construct the write batch (column-family handle setup).
    pub begin_ms: u64,
    /// Time spent advancing Sapling/tree state during state validation.
    pub tree_ms: u64,
    /// Time spent staging block/transaction/tree writes into the batch.
    pub sql_write_ms: u64,
    /// Time spent on indexed state writes (tx/root/nullifier indexes).
    pub index_write_ms: u64,
    pub sqlite_commit_ms: u64,
    pub sqlite_commit_us: u64,
    pub blocks: u64,
    pub txs: u64,
    /// Number of transparent UTXO lookups performed during state validation.
    pub utxo_lookups: u64,
    /// Number of BIP30 existing-tx checks performed during state validation.
    pub bip30_checks: u64,
    /// Number of transaction inputs whose scripts were actually executed.
    pub script_checks: u64,
    /// Script verification telemetry: checks remain consensus-identical, but
    /// independent transparent inputs are verified in parallel before ordered state mutation.
    pub script_parallel_workers: u64,
    pub script_parallel_us: u64,
    pub script_input_work_us: u64,
    pub script_slowest_input_index: u64,
    pub script_slowest_input_us: u64,
    pub script_slowest_input_tx_height: u64,
    pub script_slowest_input_tx_index: u64,
    pub script_transaction_input_extraction_us: u64,
    pub script_sig_construction_us: u64,
    pub script_pubkey_retrieval_us: u64,
    pub script_parsing_us: u64,
    pub signature_hash_preparation_us: u64,
    pub ecdsa_verification_us: u64,
    pub script_interpreter_us: u64,
    pub script_cache_lookup_us: u64,
    pub script_synchronization_us: u64,
    /// Time script jobs spent waiting for the shared CPU permit.
    pub script_permit_wait_us: u64,
    /// Maximum simultaneous script jobs observed during this call.
    pub script_active_peak: u64,
    /// Wall time not covered by the longest observed worker span. Diagnostic only.
    pub script_scheduler_gap_us: u64,
    pub script_worker_wall_us: [u64; 32],
    pub script_worker_input_work_us: [u64; 32],
    pub script_worker_inputs: [u64; 32],
    pub script_spawn_us: u64,
    pub script_join_us: u64,
    pub script_pool_overhead_us: u64,
    pub script_pool_threads: u64,
    pub script_worker_max_us: u64,
    pub script_worker_min_us: u64,
    pub utxo_cache_hits: u64,
    pub utxo_cache_misses: u64,
    pub parent_state_cache_hit: bool,
    pub sprout_state_cache_hit: bool,
    /// Fine-grained ordered state-validation timings.
    pub parent_state_load_ms: u64,
    pub parent_state_load_us: u64,
    pub block_parse_ms: u64,
    pub block_parse_us: u64,
    pub txid_us: u64,
    pub tx_connect_ms: u64,
    pub tx_connect_us: u64,
    pub bip30_ms: u64,
    pub bip30_us: u64,
    pub sigops_ms: u64,
    pub sigops_us: u64,
    pub tx_parse_us: u64,
    pub utxo_lookup_ms: u64,
    pub utxo_lookup_us: u64,
    pub sprout_requirements_ms: u64,
    pub sprout_requirements_us: u64,
    pub value_checks_ms: u64,
    pub value_checks_us: u64,
    pub script_ms: u64,
    pub script_us: u64,
    pub coin_state_update_ms: u64,
    pub coin_state_update_us: u64,
    pub sprout_apply_ms: u64,
    pub sprout_apply_us: u64,
    pub sapling_validate_ms: u64,
    pub sapling_validate_us: u64,
    pub sapling_anchor_lookup_ms: u64,
    pub sapling_anchor_lookup_us: u64,
    pub sapling_nullifier_lookup_ms: u64,
    pub sapling_nullifier_lookup_us: u64,
    pub sapling_tree_update_ms: u64,
    pub sapling_tree_update_us: u64,
    pub block_finalize_ms: u64,
    pub block_finalize_us: u64,
    pub tree_encode_us: u64,
    pub read_transaction_us: u64,
    pub read_transaction_commit_us: u64,
    pub parent_frontier_load_us: u64,
    pub sprout_state_load_us: u64,
    pub sapling_anchor_queries: u64,
    pub sapling_nullifier_queries: u64,
    pub sapling_empty_hashes_avoided: u64,
    pub sapling_root_cache_hits: u64,
}

/// Bounded process-local cache of the exact canonical state at the last
/// successfully committed tip. It is an acceleration layer only: a miss always
/// falls back to RocksDB, and the cache is discarded on reorgs.
struct ConsensusCache {
    tip_hash: [u8; 32],
    tip_height: u64,
    sapling: SaplingConsensusState,
    sprout: SproutTree,
    chain_sprout_value: i64,
    chain_sapling_value: i64,
    utxos: Arc<UtxoCache>,
}


impl ConsensusCache {
    fn new(
        tip_hash: [u8; 32],
        tip_height: u64,
        sapling: SaplingConsensusState,
        sprout: SproutTree,
        chain_sprout_value: i64,
        chain_sapling_value: i64,
    ) -> Self {
        Self { tip_hash, tip_height, sapling, sprout, chain_sprout_value, chain_sapling_value, utxos: Arc::new(UtxoCache::empty()) }
    }
}

pub struct State {
    db: Arc<Db>,
    /// The ordered canonical committer is the only component allowed to mutate
    /// canonical state. RocksDB itself permits concurrent writers, so this lock
    /// makes the single-writer rule explicit rather than incidental.
    write_lock: Mutex<()>,
    sapling: Mutex<SaplingConsensusState>,
    /// Blocks at or below this height skip script verification, like ycashd
    /// under its last checkpoint (`fExpensiveChecks = false`). 0 = verify all.
    assume_valid_height: AtomicU64,
    last_commit_timing: Mutex<CommitTiming>,
    /// Canonical state/UTXO cache. This never replaces the DB as authority.
    consensus_cache: Mutex<Option<ConsensusCache>>,
}

/// Borrow the underlying database (diagnostics, checkpoints).
impl State {
    pub fn database(&self) -> Arc<Db> {
        Arc::clone(&self.db)
    }
}

/// One validated header, ready for `State::put_headers_batch`.
#[derive(Debug, Clone)]
pub struct HeaderRow {
    pub height: u64,
    pub hash: [u8; 32],
    pub prev: [u8; 32],
    pub time: u32,
    pub bits: u32,
    pub work: [u8; 32],
    pub raw: Vec<u8>,
}

#[derive(Debug, Clone)]
pub struct BlockCommit {
    pub height: u64,
    pub hash: [u8; 32],
    pub prev: [u8; 32],
    pub work: [u8; 32],
    pub raw: Vec<u8>,
    pub txs: Vec<([u8; 32], Vec<u8>)>,
    /// Already-parsed transactions from the stateless validation stage. Empty
    /// for legacy callers; commit falls back to parsing `raw` when absent.
    pub parsed_txs: Vec<ycash_chain::ParsedTransaction>,
    /// Transaction-wide ZIP143/243 signature-hash precomputation produced by
    /// the stateless verifier and carried into commit, so the ordered state
    /// phase does not rebuild it. Empty for legacy callers.
    pub precomputed_txs: Vec<ycash_script::PrecomputedTxData>,
    /// True when Sapling proofs/signatures already passed the verify stage
    /// (`validate_for_commit_opts` or `validate_for_commit_batched` + finish).
    /// The commit then checks anchors/nullifiers/tree without re-verifying proofs.
    pub proofs_verified: bool,
}

/// Zebra-style prepared commit envelope.
///
/// `prepare_commit_batch()` performs all consensus/state work against a
/// read-only RocksDB snapshot and produces the complete mutation plan.  The
/// returned envelope contains only immutable data needed by the canonical
/// writer.  `apply_prepared_commit()` turns that plan into one atomic RocksDB
/// WriteBatch and publishes the in-memory state only after the write succeeds.
///
/// The original block slice is borrowed to avoid another copy of raw blocks;
/// all database/state mutations are owned by this envelope, so the expensive
/// state preparation never has to be repeated during application.
pub struct PreparedCommit<'a> {
    pub blocks: &'a [BlockCommit],
    pub(crate) block_trees: Vec<([u8; 32], Vec<u8>)>,
    pub(crate) pending_nullifiers: Vec<([u8; 32], [u8; 32], u64)>,
    pub(crate) utxo_changes: PreparedUtxoChanges,
    pub(crate) sprout_changes: PreparedSproutChanges,
    pub(crate) working_sapling: SaplingConsensusState,
    pub(crate) sprout_tree: SproutTree,
    pub(crate) chain_sprout_value: i64,
    pub(crate) chain_sapling_value: i64,
    pub(crate) cache_parent_hit: bool,
    pub(crate) normal_extension: bool,
    pub(crate) expected_tip: Option<([u8; 32], u64)>,
    pub(crate) prepare_us: u64,
    pub(crate) timing: CommitTiming,
}

impl<'a> PreparedCommit<'a> {
    pub fn len(&self) -> usize { self.blocks.len() }
    pub fn is_empty(&self) -> bool { self.blocks.is_empty() }
}

impl State {
    pub fn open(p: impl AsRef<Path>) -> Result<Self> {
        let db = Db::open(p.as_ref())?;

        let version = db.meta_u64(db::META_SCHEMA_VERSION)?.unwrap_or(0);
        if version > SCHEMA_VERSION {
            bail!("database schema version {version} is newer than supported version {SCHEMA_VERSION}");
        }
        if version != SCHEMA_VERSION {
            // A directory with no version marker is either brand new or a
            // partially created state directory from an interrupted first run.
            // Neither contains trustworthy canonical state, so stamp the
            // current version and let the node synchronize from genesis.
            let mut w = db.writer()?;
            w.put_meta_u64(db::META_SCHEMA_VERSION, SCHEMA_VERSION);
            w.commit()?;
        }

        let sapling = match db.meta(db::META_SAPLING_FRONTIER)? {
            Some(v) => SaplingConsensusState::decode(&v)
                .map_err(|e| anyhow::anyhow!("invalid persisted Sapling state: {e:?}"))?,
            None => SaplingConsensusState::new(),
        };

        Ok(Self {
            db: Arc::new(db),
            write_lock: Mutex::new(()),
            sapling: Mutex::new(sapling),
            assume_valid_height: AtomicU64::new(0),
            last_commit_timing: Mutex::new(CommitTiming::default()),
            consensus_cache: Mutex::new(None),
        })
    }

    /// Skip transparent script verification for blocks at or below `height`
    /// (callers must only set this once the header at a hard-coded checkpoint
    /// has been verified to match). Everything else is still validated.
    pub fn set_assume_valid_height(&self, height: u64) {
        self.assume_valid_height.store(height, Ordering::Relaxed);
    }

    pub fn put_block(
        &self,
        height: u64,
        hash: &[u8],
        prev: &[u8],
        work: &[u8],
        raw: &[u8],
    ) -> Result<()> {
        let hash = hash32(hash, "block hash")?;
        let prev = hash32(prev, "previous block hash")?;
        let work = hash32(work, "chain work")?;
        let _guard = self.write_lock.lock().unwrap();
        // Stashing a block never changes the canonical chain: the canonical
        // marker stays exactly where the ordered committer left it.
        let canonical = self.db.canonical_hash(height)?.map(|h| h == hash).unwrap_or(false);
        let mut w = self.db.writer()?;
        w.put_block(&hash, &db::BlockMeta { height, prev, work, canonical }, raw, &[]);
        w.commit()
    }

    pub fn commit_block(
        &self,
        height: u64,
        hash: &[u8],
        prev: &[u8],
        work: &[u8],
        raw: &[u8],
        txs: &[([u8; 32], Vec<u8>)],
    ) -> Result<()> {
        let b = BlockCommit {
            height,
            hash: hash.try_into().map_err(|_| anyhow::anyhow!("invalid hash length"))?,
            prev: prev.try_into().map_err(|_| anyhow::anyhow!("invalid prev length"))?,
            work: work.try_into().map_err(|_| anyhow::anyhow!("invalid work length"))?,
            raw: raw.to_vec(),
            txs: txs.to_vec(),
            parsed_txs: Vec::new(),
            precomputed_txs: Vec::new(),
            proofs_verified: false,
        };
        self.commit_blocks_batch(&[b])
    }

    /// Prepare an ordered canonical commit without mutating persistent state.
    /// All consensus/state transition work is completed here against a RocksDB
    /// snapshot; the returned mutation plan can then be applied without
    /// repeating those expensive operations.
    pub fn prepare_commit_batch<'a>(&self, blocks: &'a [BlockCommit]) -> Result<PreparedCommit<'a>> {
        if blocks.is_empty() {
            return Ok(PreparedCommit {
                blocks,
                block_trees: Vec::new(),
                pending_nullifiers: Vec::new(),
                utxo_changes: chainstate::PreparedUtxoChanges::empty(),
                sprout_changes: chainstate::PreparedSproutChanges::empty(),
                working_sapling: SaplingConsensusState::new(),
                sprout_tree: SproutTree::new(),
                chain_sprout_value: 0,
                chain_sapling_value: 0,
                cache_parent_hit: false,
                normal_extension: true,
                expected_tip: None,
                prepare_us: 0,
                timing: CommitTiming::default(),
            });
        }
        validate_batch_shape(blocks)?;
        let assume_valid_height = self.assume_valid_height.load(Ordering::Relaxed);
        let total_started = Instant::now();
        let mut timing = CommitTiming { blocks: blocks.len() as u64, txs: blocks.iter().map(|b| b.txs.len() as u64).sum(), ..Default::default() };
        timing.bip30_checks = 0;
        // Fine-grained counters make the existing four-stage timing useful for
        // identifying whether the commit bottleneck is transaction/UTXO work,
        // script execution, batch construction, or the final atomic write.
        timing.bip30_checks = 0;

        // Zebra-style commit separation: perform the expensive consensus/state
        // preparation against a consistent read snapshot first. No write batch
        // is open while parsing, connecting UTXOs, or advancing the Sapling
        // frontier, and the single canonical writer cannot change state under
        // us because `apply_prepared_commit` rechecks the prepared tip before
        // mutating anything.
        let validation_started = Instant::now();
        let read_tx_started = Instant::now();
        // A RocksDB snapshot: a consistent point-in-time view of canonical
        // state that neither blocks nor is blocked by the committer.
        let read_tx = self.db.read_view()?;
        timing.read_transaction_us = read_tx_started.elapsed().as_micros() as u64;

        // Snapshot the exact canonical tip used for preparation. The apply
        // phase rechecks this value inside its WRITE transaction, closing the
        // prepare/apply gap so a concurrent set_tip/reorg cannot make a stale
        // prepared mutation plan commit onto a different state.
        let expected_tip = read_tx.canonical_tip()?;

        let first = &blocks[0];
        let first_height = first.height;
        const UTXO_CACHE_ENTRIES: usize = 50_000;
        let parent_started = Instant::now();

        // Cache hits are accepted only when the cached state is exactly the
        // canonical parent identified by the first block. This makes the cache
        // incapable of crossing a reorg boundary or being used for the wrong
        // branch.
        let (cache_parent_hit, cached_utxo_map, cached_sprout, cached_sprout_value, cached_sapling_value) = {
            let cache_guard = self.consensus_cache.lock().unwrap();
            let hit = cache_guard.as_ref().map(|c| {
                c.tip_height.saturating_add(1) == first.height && c.tip_hash == first.prev
            }).unwrap_or(false);
            if hit {
                let c = cache_guard.as_ref().unwrap();
                (true, Some(Arc::clone(&c.utxos)), Some(c.sprout.clone()), Some(c.chain_sprout_value), Some(c.chain_sapling_value))
            } else {
                (false, None, None, None, None)
            }
        };
        timing.parent_state_cache_hit = cache_parent_hit;
        let parent_frontier = if cache_parent_hit {
            let cache_guard = self.consensus_cache.lock().unwrap();
            cache_guard.as_ref().unwrap().sapling.clone()
        } else {
            let parent_frontier_started = Instant::now();
            let pf = load_parent_frontier(&read_tx, first.height, &first.prev)?;
            timing.parent_frontier_load_us = parent_frontier_started.elapsed().as_micros() as u64;
            pf
        };
        let mut working = parent_frontier;
        let mut valid_batch_roots = HashSet::new();
        valid_batch_roots.insert(working.root());

        let mut coins = CoinsView::new(first_height, cached_utxo_map.as_ref().map(|c| c.as_ref()));
        let sprout_started = Instant::now();
        let mut sprout = if let Some(tree) = cached_sprout {
            timing.sprout_state_cache_hit = true;
            SproutView::from_cached(first_height, tree, cached_sprout_value.unwrap_or(0), cached_sapling_value.unwrap_or(0))
        } else {
            timing.sprout_state_cache_hit = false;
            SproutView::load(&read_tx, first_height, &first.prev)?
        };
        timing.sprout_state_load_us = sprout_started.elapsed().as_micros() as u64;
        timing.parent_state_load_us = parent_started.elapsed().as_micros() as u64;
        timing.parent_state_load_ms = timing.parent_state_load_us / 1000;

        // Bulk-prefetch the canonical UTXO inputs before entering the ordered
        // transaction loop. This is deliberately done only for inputs whose
        // producing tx is outside this batch: outputs created by an earlier
        // transaction in this working state are resolved from `CoinsView`
        // instead of being negative-cached as missing. The result is a cheap
        // in-memory lookup during the expensive script/value checks below.
        //
        // This does not change consensus semantics: the same `ReadView`
        // snapshot is used, and `connect_tx()` still performs the authoritative
        // existence/maturity/value checks against the working view.
        let prefetch_started = Instant::now();
        let mut batch_txids: Vec<[u8; 32]> = Vec::with_capacity(blocks.iter().map(|b| b.txs.len()).sum());
        let mut prefetch_ops: Vec<([u8; 32], u32)> = Vec::new();
        for b in blocks {
            let block = ycash_chain::read_block_at_height(&b.raw, b.height)?;
            for (tx_index, rawtx) in block.txs.iter().enumerate() {
                let parsed_owned;
                let parsed = if !b.parsed_txs.is_empty() {
                    &b.parsed_txs[tx_index]
                } else {
                    let mut c = Cursor::new(rawtx.as_slice());
                    parsed_owned = ycash_chain::parse_transaction(&mut c)?;
                    &parsed_owned
                };
                let txid = ycash_chain::txid(rawtx);
                batch_txids.push(txid);
                prefetch_ops.extend(parsed.vin.iter().map(|input| (input.prev_txid, input.prev_index)));
            }
        }
        coins.reserve_batch_txids(batch_txids);
        coins.prefetch(&read_tx, &prefetch_ops)?;
        let prefetch_us = prefetch_started.elapsed().as_micros() as u64;
        timing.utxo_prefetch_us = timing.utxo_prefetch_us.saturating_add(prefetch_us);

        // Validate the complete batch against the canonical ancestor state before
        // changing any canonical flags. This makes a failed batch atomic both
        // logically and physically: no half-reorged anchor set is visible.
        let mut batch_nullifiers = HashSet::new();
        // v0.29.2: everything the write phase needs is collected here, so the
        // write phase never re-parses a block or transaction.
        let mut pending_nullifiers: Vec<([u8; 32], [u8; 32], u64)> = Vec::new();
        // Per-block Sapling root + frontier. v0.29.1 wrote the batch's FINAL
        // tree to every block's sapling_roots row; each row now gets its own.
        let mut block_trees: Vec<([u8; 32], Vec<u8>)> = Vec::with_capacity(blocks.len());
        for (i, b) in blocks.iter().enumerate() {
            let block_started = Instant::now();
            let block_parse_before = timing.block_parse_us;
            let tx_parse_before = timing.tx_parse_us;
            let txid_before = timing.txid_us;
            let tx_connect_before = timing.tx_connect_us;
            let sapling_before = timing.sapling_validate_us;
            let finalize_before = timing.block_finalize_us;
            let encode_before = timing.tree_encode_us;
            let header_hash_before = timing.header_hash_us;
            let connector_new_before = timing.connector_new_us;
            let block_root_before = timing.block_root_us;
            let parse_started = Instant::now();
            let block = ycash_chain::read_block_at_height(&b.raw, b.height)?;
            let parse_us = parse_started.elapsed().as_micros() as u64;
            timing.block_parse_us = timing.block_parse_us.saturating_add(parse_us);
            timing.block_parse_ms = timing.block_parse_us / 1000;
            let expected_prev = if i == 0 { b.prev } else { blocks[i - 1].hash };
            let header_hash_started = Instant::now();
            let computed_hash = block.header.hash();
            timing.header_hash_us = timing.header_hash_us.saturating_add(header_hash_started.elapsed().as_micros() as u64);
            if computed_hash != b.hash || block.header.prev != expected_prev {
                bail!("block commit does not match its supplied hash/previous hash");
            }

            if !b.parsed_txs.is_empty() && b.parsed_txs.len() != block.txs.len() {
                bail!("parsed transaction count does not match raw block at height {}", b.height);
            }
            let connector_started = Instant::now();
            let mut connector = BlockConnector::new(b.height, b.height > assume_valid_height);
            timing.connector_new_us = timing.connector_new_us.saturating_add(connector_started.elapsed().as_micros() as u64);
            let mut connect_timing = chainstate::ConnectTiming::default();
            let mut block_slowest_script_input_tx_index: u64 = 0;
            for (tx_index, rawtx) in block.txs.iter().enumerate() {
                let tx_started = Instant::now();
                let tx_parse_before = timing.tx_parse_us;
                let txid_before = timing.txid_us;
                let tx_connect_before = timing.tx_connect_us;
                let sapling_before = timing.sapling_validate_us;
                let tx_parse_started = Instant::now();
                // Reuse the parsed transaction handed over by stateless
                // validation. Legacy callers without parsed data still parse
                // here, but the normal Android/node pipeline no longer clones
                // every ParsedTransaction during ordered commit.
                let parsed_owned = if b.parsed_txs.is_empty() {
                    let mut c = Cursor::new(rawtx.as_slice());
                    Some(ycash_chain::parse_transaction(&mut c)?)
                } else {
                    None
                };
                let parsed = parsed_owned.as_ref().unwrap_or_else(|| &b.parsed_txs[tx_index]);
                timing.tx_parse_us = timing.tx_parse_us.saturating_add(tx_parse_started.elapsed().as_micros() as u64);
                let txid_started = Instant::now();
                let txid = ycash_chain::txid(rawtx);
                timing.txid_us = timing.txid_us.saturating_add(txid_started.elapsed().as_micros() as u64);

                // Build transaction-wide signature-hash data exactly once; the
                // parallel script workers share this immutable structure.
                let precomputed_generated = if b.precomputed_txs.is_empty() && parsed.overwintered {
                    Some(ycash_script::PrecomputedTxData::new(parsed))
                } else {
                    None
                };
                let precomputed = if !b.precomputed_txs.is_empty() {
                    if b.precomputed_txs.len() != block.txs.len() {
                        bail!("precomputed transaction count does not match raw block at height {}", b.height);
                    }
                    if parsed.overwintered { Some(&b.precomputed_txs[tx_index]) } else { None }
                } else {
                    precomputed_generated.as_ref()
                };
                // Transparent inputs/scripts/fees and Sprout requirements, then
                // connect the transaction's coins and Sprout effects. State
                // mutation remains strictly ordered even when script checks run in parallel.
                let script_slowest_input_before = connect_timing.script_slowest_input_us;
                connector.connect_tx(&read_tx, &mut coins, &mut sprout, parsed, &txid, precomputed, &mut connect_timing)?;
                if connect_timing.script_slowest_input_us > script_slowest_input_before {
                    block_slowest_script_input_tx_index = tx_index as u64;
                }

                let anchor_lookup_ms = Cell::new(0u64);
                let nullifier_lookup_ms = Cell::new(0u64);
                let anchor_queries = Cell::new(0u64);
                let nullifier_queries = Cell::new(0u64);
                let anchor_exists = |a: &[u8; 32]| -> bool {
                    if valid_batch_roots.contains(a) {
                        return true;
                    }
                    anchor_queries.set(anchor_queries.get().saturating_add(1));
                    let started = Instant::now();
                    // The anchor index stores the lowest canonical height at
                    // which each Sapling root appeared, so "a canonical root
                    // below this batch" is a single point lookup.
                    let result = read_tx
                        .sapling_anchor_height(a)
                        .ok()
                        .flatten()
                        .map(|h| h < first_height)
                        .unwrap_or(false);
                    anchor_lookup_ms.set(anchor_lookup_ms.get().saturating_add(started.elapsed().as_micros() as u64));
                    result
                };
                let nullifier_exists = |n: &[u8; 32]| -> bool {
                    if batch_nullifiers.contains(n) {
                        return true;
                    }
                    nullifier_queries.set(nullifier_queries.get().saturating_add(1));
                    let started = Instant::now();
                    // Nullifier rows exist only for canonical blocks: a reorg
                    // deletes them in the same atomic batch that demotes the
                    // block, so no main-chain join is needed.
                    let result = read_tx
                        .sapling_nullifier(n)
                        .ok()
                        .flatten()
                        .map(|rec| rec.height < first_height)
                        .unwrap_or(false);
                    nullifier_lookup_ms.set(nullifier_lookup_ms.get().saturating_add(started.elapsed().as_micros() as u64));
                    result
                };
                let tree_started = Instant::now();
                validate_sapling_transaction_state_opts(
                    &parsed,
                    b.height,
                    &mut working,
                    anchor_exists,
                    nullifier_exists,
                    !b.proofs_verified,
                )
                .map_err(|e| anyhow::anyhow!("sapling consensus failure at height {}: {e:?}", b.height))?;
                let sapling_elapsed_us = tree_started.elapsed().as_micros() as u64;
                let sapling_elapsed = sapling_elapsed_us / 1000;
                let anchor_us = anchor_lookup_ms.get();
                let nullifier_us = nullifier_lookup_ms.get();
                let anchor_ms = anchor_us / 1000;
                let nullifier_ms = nullifier_us / 1000;
                timing.tree_ms = timing.tree_ms.saturating_add(sapling_elapsed);
                timing.sapling_validate_us = timing.sapling_validate_us.saturating_add(sapling_elapsed_us);
                timing.sapling_validate_ms = timing.sapling_validate_us / 1000;
                timing.sapling_anchor_lookup_us = timing.sapling_anchor_lookup_us.saturating_add(anchor_us);
                timing.sapling_nullifier_lookup_us = timing.sapling_nullifier_lookup_us.saturating_add(nullifier_us);
                timing.sapling_anchor_lookup_ms = timing.sapling_anchor_lookup_us / 1000;
                timing.sapling_nullifier_lookup_ms = timing.sapling_nullifier_lookup_us / 1000;
                timing.sapling_tree_update_us = timing.sapling_tree_update_us.saturating_add(sapling_elapsed_us.saturating_sub(anchor_us).saturating_sub(nullifier_us));
                timing.sapling_tree_update_ms = timing.sapling_tree_update_us / 1000;
                timing.sapling_anchor_queries = timing.sapling_anchor_queries.saturating_add(anchor_queries.get());
                timing.sapling_nullifier_queries = timing.sapling_nullifier_queries.saturating_add(nullifier_queries.get());

                for spend in &parsed.sapling_spends {
                    if !batch_nullifiers.insert(spend.nullifier) {
                        bail!("Sapling nullifier is duplicated within the commit batch");
                    }
                    pending_nullifiers.push((spend.nullifier, b.hash, b.height));
                }
                let tx_elapsed_us = tx_started.elapsed().as_micros() as u64;
                let tx_named_us = timing.tx_parse_us.saturating_sub(tx_parse_before)
                    .saturating_add(timing.txid_us.saturating_sub(txid_before))
                    .saturating_add(timing.tx_connect_us.saturating_sub(tx_connect_before))
                    .saturating_add(timing.sapling_validate_us.saturating_sub(sapling_before));
                let tx_other_us = tx_elapsed_us.saturating_sub(tx_named_us);
                if tx_elapsed_us > timing.slowest_tx_us {
                    timing.slowest_tx_us = tx_elapsed_us;
                    timing.slowest_tx_height = b.height;
                    timing.slowest_tx_index = tx_index as u64;
                    timing.slowest_tx_other_us = tx_other_us;
                }
            }
            let finalize_started = Instant::now();
            connector.finish()?;
            sprout.finish_block(b.hash, b.height)?;
            let finalize_us = finalize_started.elapsed().as_micros() as u64;
            timing.block_finalize_us = timing.block_finalize_us.saturating_add(finalize_us);
            timing.block_finalize_ms = timing.block_finalize_us / 1000;
            timing.tx_connect_us = timing.tx_connect_us.saturating_add(connect_timing.tx_total_us);
            timing.tx_connect_ms = timing.tx_connect_us / 1000;
            timing.bip30_us = timing.bip30_us.saturating_add(connect_timing.bip30_us);
            timing.bip30_ms = timing.bip30_us / 1000;
            timing.sigops_us = timing.sigops_us.saturating_add(connect_timing.sigops_us);
            timing.sigops_ms = timing.sigops_us / 1000;
            timing.utxo_lookup_us = timing.utxo_lookup_us.saturating_add(connect_timing.utxo_lookup_us);
            timing.utxo_lookup_ms = timing.utxo_lookup_us / 1000;
            timing.sprout_requirements_us = timing.sprout_requirements_us.saturating_add(connect_timing.sprout_requirements_us);
            timing.sprout_requirements_ms = timing.sprout_requirements_us / 1000;
            timing.value_checks_us = timing.value_checks_us.saturating_add(connect_timing.value_checks_us);
            timing.value_checks_ms = timing.value_checks_us / 1000;
            timing.script_us = timing.script_us.saturating_add(connect_timing.script_us);
            timing.script_ms = timing.script_us / 1000;
            timing.coin_state_update_us = timing.coin_state_update_us.saturating_add(connect_timing.coin_state_update_us);
            timing.coin_state_update_ms = timing.coin_state_update_us / 1000;
            timing.sprout_apply_us = timing.sprout_apply_us.saturating_add(connect_timing.sprout_apply_us);
            timing.sprout_apply_ms = timing.sprout_apply_us / 1000;
            let connector_named_us = connect_timing.sigops_us
                .saturating_add(connect_timing.bip30_us)
                .saturating_add(connect_timing.utxo_lookup_us)
                .saturating_add(connect_timing.sprout_requirements_us)
                .saturating_add(connect_timing.value_checks_us)
                .saturating_add(connect_timing.script_us)
                .saturating_add(connect_timing.coin_state_update_us)
                .saturating_add(connect_timing.sprout_apply_us);
            timing.connector_other_us = timing.connector_other_us.saturating_add(
                connect_timing.tx_total_us.saturating_sub(connector_named_us));
            timing.utxo_lookups = timing.utxo_lookups.saturating_add(connect_timing.utxo_lookups);
            timing.script_checks = timing.script_checks.saturating_add(connect_timing.script_checks);
            timing.script_parallel_workers = timing.script_parallel_workers.max(connect_timing.script_parallel_workers);
            timing.script_parallel_us = timing.script_parallel_us.saturating_add(connect_timing.script_parallel_us);
            timing.script_input_work_us = timing.script_input_work_us.saturating_add(connect_timing.script_input_work_us);
            timing.script_transaction_input_extraction_us = timing.script_transaction_input_extraction_us.saturating_add(connect_timing.script_transaction_input_extraction_us);
            timing.script_sig_construction_us = timing.script_sig_construction_us.saturating_add(connect_timing.script_sig_construction_us);
            timing.script_pubkey_retrieval_us = timing.script_pubkey_retrieval_us.saturating_add(connect_timing.script_pubkey_retrieval_us);
            timing.script_parsing_us = timing.script_parsing_us.saturating_add(connect_timing.script_parsing_us);
            timing.signature_hash_preparation_us = timing.signature_hash_preparation_us.saturating_add(connect_timing.signature_hash_preparation_us);
            timing.ecdsa_verification_us = timing.ecdsa_verification_us.saturating_add(connect_timing.ecdsa_verification_us);
            timing.script_interpreter_us = timing.script_interpreter_us.saturating_add(connect_timing.script_interpreter_us);
            timing.script_cache_lookup_us = timing.script_cache_lookup_us.saturating_add(connect_timing.script_cache_lookup_us);
            timing.script_synchronization_us = timing.script_synchronization_us.saturating_add(connect_timing.script_synchronization_us);
            timing.script_permit_wait_us = timing.script_permit_wait_us.saturating_add(connect_timing.script_permit_wait_us);
            timing.script_active_peak = timing.script_active_peak.max(connect_timing.script_active_peak);
            timing.script_scheduler_gap_us = timing.script_scheduler_gap_us.saturating_add(connect_timing.script_scheduler_gap_us);
            for i in 0..4 {
                timing.script_worker_wall_us[i] = timing.script_worker_wall_us[i].saturating_add(connect_timing.script_worker_wall_us[i]);
                timing.script_worker_input_work_us[i] = timing.script_worker_input_work_us[i].saturating_add(connect_timing.script_worker_input_work_us[i]);
                timing.script_worker_inputs[i] = timing.script_worker_inputs[i].saturating_add(connect_timing.script_worker_inputs[i]);
            }
            timing.script_spawn_us = timing.script_spawn_us.saturating_add(connect_timing.script_spawn_us);
            timing.script_join_us = timing.script_join_us.saturating_add(connect_timing.script_join_us);
            timing.script_pool_overhead_us = timing.script_pool_overhead_us.saturating_add(connect_timing.script_pool_overhead_us);
            timing.script_pool_threads = timing.script_pool_threads.max(connect_timing.script_pool_threads);
            timing.script_worker_max_us = timing.script_worker_max_us.max(connect_timing.script_worker_max_us);
            if timing.script_worker_min_us == 0 { timing.script_worker_min_us = connect_timing.script_worker_min_us; } else if connect_timing.script_worker_min_us != 0 { timing.script_worker_min_us = timing.script_worker_min_us.min(connect_timing.script_worker_min_us); }
            if connect_timing.script_slowest_input_us > timing.script_slowest_input_us {
                timing.script_slowest_input_us = connect_timing.script_slowest_input_us;
                timing.script_slowest_input_index = connect_timing.script_slowest_input_index;
                timing.script_slowest_input_tx_height = b.height;
                timing.script_slowest_input_tx_index = block_slowest_script_input_tx_index;
            }
            timing.bip30_checks = timing.bip30_checks.saturating_add(connect_timing.bip30_checks);
            let root_started = Instant::now();
            let (root, root_timing) = working.root_with_timing();
            let measured_root_us = root_started.elapsed().as_micros() as u64;
            timing.block_root_us = timing.block_root_us.saturating_add(measured_root_us);
            if root_timing.root_cache_hit {
                timing.sapling_root_cache_hits = timing.sapling_root_cache_hits.saturating_add(1);
            }
            timing.sapling_empty_hashes_avoided = timing.sapling_empty_hashes_avoided.saturating_add(root_timing.empty_hashes_avoided);
            for level in 0..32 {
                timing.block_root_level_us[level] =
                    timing.block_root_level_us[level].saturating_add(root_timing.level_us[level]);
                timing.block_root_level_hashes[level] =
                    timing.block_root_level_hashes[level].saturating_add(root_timing.level_hashes[level]);
                timing.block_root_empty_us[level] =
                    timing.block_root_empty_us[level].saturating_add(root_timing.empty_us[level]);
                timing.block_root_empty_hashes[level] =
                    timing.block_root_empty_hashes[level].saturating_add(root_timing.empty_hashes[level]);
                timing.block_root_hash_us[level] =
                    timing.block_root_hash_us[level].saturating_add(root_timing.root_hash_us[level]);
                timing.block_root_hashes[level] =
                    timing.block_root_hashes[level].saturating_add(root_timing.root_hashes[level]);
            }
            valid_batch_roots.insert(root);
            let encode_started = Instant::now();
            let encoded_frontier = working.encode();
            timing.tree_encode_us = timing.tree_encode_us.saturating_add(encode_started.elapsed().as_micros() as u64);
block_trees.push((root, encoded_frontier));
        }
        timing.utxo_cache_hits = coins.cache_hits;
        timing.utxo_cache_misses = coins.cache_misses;

        let normal_extension = if first.height == 0 {
            true
        } else {
            read_tx.is_canonical_block(&first.prev, first.height - 1)?
        };

        // All consensus/state preparation above is deterministic from the
        // canonical ancestor and the ordered batch; the prepared tip/parent are
        // rechecked before the atomic write batch is applied.
        let read_commit_started = Instant::now();
        drop(read_tx);
        timing.read_transaction_commit_us = read_commit_started.elapsed().as_micros() as u64;
        timing.state_validation_us = validation_started.elapsed().as_micros() as u64;
        timing.state_validation_ms = timing.state_validation_us / 1000;
        let named_state_us = timing.read_transaction_us
            .saturating_add(timing.parent_state_load_us)
            .saturating_add(timing.block_parse_us)
            .saturating_add(timing.tx_parse_us)
            .saturating_add(timing.txid_us)
            .saturating_add(timing.tx_connect_us)
            .saturating_add(timing.sapling_validate_us)
            .saturating_add(timing.block_finalize_us)
            .saturating_add(timing.tree_encode_us)
            .saturating_add(timing.header_hash_us)
            .saturating_add(timing.connector_new_us)
            .saturating_add(timing.block_root_us)
            .saturating_add(timing.read_transaction_commit_us);
        timing.block_loop_other_us = timing.state_validation_us.saturating_sub(named_state_us);
        let top_level_accounted_us = timing.read_transaction_us
            .saturating_add(timing.parent_state_load_us)
            .saturating_add(timing.block_parse_us)
            .saturating_add(timing.tx_parse_us)
            .saturating_add(timing.txid_us)
            .saturating_add(timing.tx_connect_us)
            .saturating_add(timing.sapling_validate_us)
            .saturating_add(timing.block_finalize_us)
            .saturating_add(timing.tree_encode_us)
            .saturating_add(timing.read_transaction_commit_us);
        timing.state_unattributed_us = timing.state_validation_us.saturating_sub(top_level_accounted_us);

        // The mutation plan is now complete.  Clone the touched UTXO/Sprout
        // maps into owned prepared changes so the DB mutex and read transaction
        // can be released before the canonical write transaction begins.
        let utxo_changes = coins.prepare_changes();
        let sprout_changes = sprout.prepare_changes();
        let prepare_us = total_started.elapsed().as_micros() as u64;

        Ok(PreparedCommit {
            blocks,
            block_trees,
            pending_nullifiers,
            utxo_changes,
            sprout_changes,
            working_sapling: working,
            sprout_tree: sprout.tree.clone(),
            chain_sprout_value: sprout.chain_sprout_value,
            chain_sapling_value: sprout.chain_sapling_value,
            cache_parent_hit,
            normal_extension,
            expected_tip,
            prepare_us,
            timing,
        })
    }

    /// Apply the already prepared canonical mutation plan.
    ///
    /// This is the only phase that writes.  No block
    /// parsing, UTXO discovery, script verification, Sapling validation, or
    /// Sprout state calculation occurs here.  Consensus ordering is preserved
    /// by the preparation barrier and by re-checking the prepared parent tip
    /// inside the write transaction before any mutation is made.
    pub fn apply_prepared_commit(&self, prepared: PreparedCommit) -> Result<()> {
        if prepared.blocks.is_empty() {
            return Ok(());
        }

        let first = &prepared.blocks[0];
        let last = &prepared.blocks[prepared.blocks.len() - 1];
        let mut timing = prepared.timing;
        let apply_started = Instant::now();

        // One canonical writer. Everything below lands in a single RocksDB
        // WriteBatch, so the block state and the new tip marker become visible
        // together or not at all.
        let _writer = self.write_lock.lock().unwrap();
        let begin_started = Instant::now();
        let mut w = self.db.writer()?;
        timing.begin_ms = begin_started.elapsed().as_millis() as u64;

        let current_tip = self.db.canonical_tip()?;
        if current_tip != prepared.expected_tip {
            bail!("prepared commit canonical tip changed while waiting for apply at height {}", first.height);
        }

        // The canonical parent must still be exactly the parent used during
        // preparation. If another writer/reorg changed the chain in the gap,
        // abort instead of applying a stale state transition.
        let current_parent_ok = if first.height == 0 {
            true
        } else {
            self.db.canonical_hash(first.height - 1)?.map(|h| h == first.prev).unwrap_or(false)
        };
        if current_parent_ok != prepared.normal_extension {
            bail!("prepared commit parent changed while waiting for canonical apply at height {}", first.height);
        }

        // A normal extension must not silently replace an existing canonical
        // block at the same height.
        if prepared.normal_extension {
            if let Some(existing) = self.db.canonical_hash(first.height)? {
                if existing != first.hash {
                    bail!("prepared commit conflicts with current canonical block at height {}", first.height);
                }
            }
        }

        let rollback_started = Instant::now();
        let mut txs_removed = 0u64;
        if !prepared.normal_extension {
            pipeline_commit_log("REORG", first.height, last.height, &timing);
            txs_removed = self.stage_rollback(&mut w, first.height)?;
        }
        timing.rollback_ms = rollback_started.elapsed().as_millis() as u64;

        let db_write_started = Instant::now();
        let sql_started = Instant::now();
        let mut txs_added = 0u64;
        // Lowest canonical height per Sapling root seen in this batch, so a
        // repeated root does not raise the stored anchor height.
        let mut batch_anchors: HashMap<[u8; 32], u64> = HashMap::new();
        for (b, (root, frontier)) in prepared.blocks.iter().zip(prepared.block_trees.iter()) {
            let txids: Vec<[u8; 32]> = b.txs.iter().map(|(txid, _)| *txid).collect();
            w.put_block(
                &b.hash,
                &db::BlockMeta { height: b.height, prev: b.prev, work: b.work, canonical: true },
                &b.raw,
                &txids,
            );
            w.set_canonical_block(b.height, &b.hash);
            for (txid, txraw) in &b.txs {
                w.put_tx(txid, &db::TxRec { block_hash: b.hash, raw: txraw.clone() });
            }
            txs_added = txs_added.saturating_add(b.txs.len() as u64);
            w.put_sapling_tree(
                &b.hash,
                &db::SaplingTreeRec { root: *root, height: b.height, frontier: frontier.clone() },
            );
            let lower = match batch_anchors.get(root) {
                Some(h) => *h > b.height,
                None => match self.db.sapling_anchor_height(root)? {
                    // An anchor this batch's rollback removed must be rewritten
                    // for the canonical block that still carries the root.
                    Some(h) => h > b.height || w.sapling_anchor_deleted(root),
                    None => true,
                },
            };
            if lower {
                batch_anchors.insert(*root, b.height);
                w.put_sapling_anchor(root, b.height);
            }
        }
        timing.sql_write_ms = timing.sql_write_ms.saturating_add(sql_started.elapsed().as_millis() as u64);

        let index_started = Instant::now();
        for (nf, block_hash, height) in &prepared.pending_nullifiers {
            w.put_sapling_nullifier(nf, &db::NullifierRec { height: *height, block_hash: *block_hash });
        }
        timing.index_write_ms = timing.index_write_ms.saturating_add(index_started.elapsed().as_millis() as u64);

        // Apply only the already prepared UTXO/Sprout mutation sets. These
        // operations perform no consensus lookups and no parsing.
        prepared.utxo_changes.apply(&mut w)?;
        prepared.sprout_changes.apply(&mut w)?;

        let tip = last.height;
        if tip > SPENT_OUTPUT_RETENTION {
            self.stage_spent_output_pruning(&mut w, tip - SPENT_OUTPUT_RETENTION)?;
        }

        // The canonical tip marker is written in the same batch as the state
        // changes it describes.
        w.put_meta(db::META_TIP_HASH, &last.hash);
        w.put_meta_u64(db::META_TIP_HEIGHT, last.height);
        if self.db.meta(db::META_SAPLING_ROOTS_FROM)?.is_none() {
            w.put_meta_u64(db::META_SAPLING_ROOTS_FROM, first.height);
        }
        let final_frontier = prepared.working_sapling.encode();
        w.put_meta(db::META_SAPLING_FRONTIER, &final_frontier);
        let tx_count = self
            .db
            .meta_u64(db::META_TX_COUNT)?
            .unwrap_or(0)
            .saturating_sub(txs_removed)
            .saturating_add(txs_added);
        w.put_meta_u64(db::META_TX_COUNT, tx_count);

        timing.db_write_us = db_write_started.elapsed().as_micros() as u64;
        timing.db_write_ms = timing.db_write_us / 1000;
        let commit_started = Instant::now();
        w.commit()?;
        timing.sqlite_commit_us = commit_started.elapsed().as_micros() as u64;
        timing.sqlite_commit_ms = timing.sqlite_commit_us / 1000;
        timing.total_us = prepared.prepare_us.saturating_add(apply_started.elapsed().as_micros() as u64);
        timing.total_ms = timing.total_us / 1000;

        // Publish RAM state only after RocksDB has committed. The prepared
        // mutation set also supplies the cache delta, so no second state scan
        // or database read is needed here.
        let mut cache_guard = self.consensus_cache.lock().unwrap();
        let mut new_cache = ConsensusCache::new(
            last.hash,
            last.height,
            prepared.working_sapling.clone(),
            prepared.sprout_tree.clone(),
            prepared.chain_sprout_value,
            prepared.chain_sapling_value,
        );
        if prepared.cache_parent_hit {
            if let Some(old) = cache_guard.as_mut() {
                let cache = Arc::make_mut(&mut old.utxos);
                prepared.utxo_changes.update_cache(cache);
                new_cache.utxos = Arc::clone(&old.utxos);
            }
        } else {
            let mut cache = UtxoCache::empty();
            prepared.utxo_changes.update_cache(&mut cache);
            new_cache.utxos = Arc::new(cache);
        }
        *cache_guard = Some(new_cache);
        drop(cache_guard);

        pipeline_commit_log("COMMIT", first.height, last.height, &timing);
        *self.last_commit_timing.lock().unwrap() = timing;
        let mut sap = self.sapling.lock().unwrap();
        *sap = prepared.working_sapling;
        Ok(())
    }

    /// Stage the removal of every canonical state change at or above
    /// `from_height` into `w`. Nothing is visible until the caller commits the
    /// batch, so a reorg is as atomic as an extension. Returns the number of
    /// indexed transactions removed.
    fn stage_rollback(&self, w: &mut db::Writer<'_>, from_height: u64) -> Result<u64> {
        let tip = self.db.canonical_tip()?.map(|(_, h)| h).unwrap_or(0);
        let mut txs_removed = 0u64;
        let mut height = from_height;
        while height <= tip {
            if let Some(hash) = self.db.canonical_hash(height)? {
                if let Some(mut meta) = self.db.block_meta(&hash)? {
                    meta.canonical = false;
                    w.put_block_meta(&hash, &meta);
                }
                w.clear_canonical_block(height);

                for txid in self.db.block_txids(&hash)? {
                    w.delete_tx(&txid);
                    txs_removed = txs_removed.saturating_add(1);
                }
                w.delete_block_txids(&hash);

                if let Some(tree) = self.db.sapling_tree(&hash)? {
                    if let Some(anchor_height) = self.db.sapling_anchor_height(&tree.root)? {
                        // The stored height is the lowest canonical occurrence
                        // of the root: if it is being rolled back, every
                        // occurrence is.
                        if anchor_height >= from_height {
                            w.delete_sapling_anchor(&tree.root);
                        }
                    }
                    w.delete_sapling_tree(&hash);
                }

                for (key, _) in self.db.prefix_scan(db::CF_SAPLING_NF_BY_BLOCK, &hash)? {
                    if key.len() != 64 {
                        bail!("invalid Sapling nullifier index key length {}", key.len());
                    }
                    let mut nf = [0u8; 32];
                    nf.copy_from_slice(&key[32..64]);
                    w.delete_sapling_nullifier(&nf, &hash);
                }

                if let Some(state) = self.db.block_state(&hash)? {
                    if let Some(anchor) = self.db.sprout_anchor(&state.sprout_root)? {
                        if anchor.height >= from_height {
                            w.delete_sprout_anchor(&state.sprout_root);
                        }
                    }
                    w.delete_block_state(&hash);
                }
            }
            height = match height.checked_add(1) {
                Some(h) => h,
                None => break,
            };
        }

        for key in self.db.height_range_keys(db::CF_SPROUT_NF_BY_HEIGHT, from_height, u64::MAX)? {
            if key.len() != 40 {
                bail!("invalid Sprout nullifier index key length {}", key.len());
            }
            let h = u64::from_be_bytes(key[..8].try_into().unwrap());
            let mut nf = [0u8; 32];
            nf.copy_from_slice(&key[8..40]);
            w.delete_sprout_nullifier(&nf, h);
        }

        // Outputs created by rolled-back blocks disappear.
        for key in self.db.height_range_keys(db::CF_UTXO_BY_HEIGHT, from_height, u64::MAX)? {
            let (_, op) = db::height_outpoint_from_key(&key)?;
            if let Some(coin) = self.db.utxo(&op)? {
                w.delete_utxo(&op, &coin);
            }
        }

        // Outputs spent by rolled-back blocks become unspent again.
        if self.db.meta_u64(db::META_PRUNE_FLOOR)?.map(|f| f > from_height).unwrap_or(false) {
            w.put_meta_u64(db::META_PRUNE_FLOOR, from_height);
        }

        for key in self.db.height_range_keys(db::CF_UTXO_SPENT_BY_HEIGHT, from_height, u64::MAX)? {
            let (spent_height, op) = db::height_outpoint_from_key(&key)?;
            match self.db.utxo(&op)? {
                Some(coin) if coin.height < from_height => {
                    let restored = db::CoinRec { spent_height: None, ..coin };
                    w.spend_utxo(&op, &restored);
                    w.clear_utxo_spent_index(&op, spent_height);
                }
                _ => w.clear_utxo_spent_index(&op, spent_height),
            }
        }

        Ok(txs_removed)
    }

    /// Drop outputs spent deeper than the maximum reorg length ycashd enforces.
    ///
    /// Scanning starts at the last pruned height rather than at zero, so the
    /// tombstones left by earlier prunes are never walked again.
    fn stage_spent_output_pruning(&self, w: &mut db::Writer<'_>, cutoff: u64) -> Result<()> {
        if cutoff == 0 {
            return Ok(());
        }
        let floor = self.db.meta_u64(db::META_PRUNE_FLOOR)?.unwrap_or(0);
        if floor >= cutoff {
            return Ok(());
        }
        w.put_meta_u64(db::META_PRUNE_FLOOR, cutoff);
        for key in self.db.height_range_keys(db::CF_UTXO_SPENT_BY_HEIGHT, floor, cutoff - 1)? {
            let (spent_height, op) = db::height_outpoint_from_key(&key)?;
            match self.db.utxo(&op)? {
                Some(coin) if coin.spent_height.map(|h| h < cutoff).unwrap_or(false) => {
                    w.delete_utxo(&op, &coin);
                }
                _ => w.clear_utxo_spent_index(&op, spent_height),
            }
        }
        Ok(())
    }

    pub fn commit_blocks_batch(&self, blocks: &[BlockCommit]) -> Result<()> {
        let prepared = self.prepare_commit_batch(blocks)?;
        self.apply_prepared_commit(prepared)
    }

    pub fn last_commit_timing(&self) -> CommitTiming {
        self.last_commit_timing.lock().unwrap().clone()
    }

    pub fn transaction_count(&self) -> Result<u64> {
        Ok(self.db.meta_u64(db::META_TX_COUNT)?.unwrap_or(0))
    }

    pub fn set_tip(&self, tip: &Tip) -> Result<()> {
        let hash = hash32(&tip.hash, "tip hash")?;
        let _guard = self.write_lock.lock().unwrap();
        let mut w = self.db.writer()?;
        if let Some((_, current)) = self.db.canonical_tip()? {
            let mut h = tip.height.saturating_add(1);
            while h <= current {
                if let Some(old) = self.db.canonical_hash(h)? {
                    if let Some(mut meta) = self.db.block_meta(&old)? {
                        meta.canonical = false;
                        w.put_block_meta(&old, &meta);
                    }
                }
                w.clear_canonical_block(h);
                h = match h.checked_add(1) {
                    Some(next) => next,
                    None => break,
                };
            }
        }
        w.set_canonical_block(tip.height, &hash);
        if let Some(mut meta) = self.db.block_meta(&hash)? {
            meta.canonical = true;
            w.put_block_meta(&hash, &meta);
        }
        w.put_meta(db::META_TIP_HASH, &hash);
        w.put_meta_u64(db::META_TIP_HEIGHT, tip.height);
        w.commit()?;
        *self.consensus_cache.lock().unwrap() = None;
        Ok(())
    }

    pub fn tip_height(&self) -> Result<Option<u64>> {
        Ok(self.db.canonical_tip()?.map(|(_, height)| height))
    }

    pub fn tip_hash(&self) -> Result<Option<Vec<u8>>> {
        Ok(self.db.canonical_tip()?.map(|(hash, _)| hash.to_vec()))
    }

    pub fn has_block(&self, hash: &[u8]) -> Result<bool> {
        let Ok(hash) = hash32(hash, "block hash") else { return Ok(false) };
        Ok(self.db.block_meta(&hash)?.is_some())
    }

    pub fn put_header(&self, height: u64, hash: &[u8], prev: &[u8], time: u32, bits: u32, work: &[u8], raw: &[u8]) -> Result<()> {
        let row = HeaderRow {
            height,
            hash: hash32(hash, "header hash")?,
            prev: hash32(prev, "header previous hash")?,
            time,
            bits,
            work: hash32(work, "header work")?,
            raw: raw.to_vec(),
        };
        self.put_headers_batch(&[row])
    }

    /// Write a whole validated header batch in ONE atomic RocksDB batch.
    /// A header whose height already holds a different canonical hash demotes
    /// that hash and everything above it, exactly like the previous backend.
    pub fn put_headers_batch(&self, rows: &[HeaderRow]) -> Result<()> {
        if rows.is_empty() {
            return Ok(());
        }
        let _guard = self.write_lock.lock().unwrap();
        let mut w = self.db.writer()?;
        let mut canonical_tip = self.db.canonical_header_tip()?.map(|(_, height)| height);
        for r in rows {
            let conflict = self
                .db
                .canonical_header_hash(r.height)?
                .map(|existing| existing != r.hash)
                .unwrap_or(false);
            if conflict {
                if let Some(tip) = canonical_tip {
                    let mut h = r.height;
                    while h <= tip {
                        w.clear_canonical_header(h);
                        h = match h.checked_add(1) {
                            Some(next) => next,
                            None => break,
                        };
                    }
                }
            }
            w.put_header(
                &r.hash,
                &db::HeaderRec {
                    height: r.height,
                    prev: r.prev,
                    time: r.time,
                    bits: r.bits,
                    work: r.work,
                    raw: r.raw.clone(),
                },
            );
            w.set_canonical_header(r.height, &r.hash);
            canonical_tip = Some(canonical_tip.map(|t| t.max(r.height)).unwrap_or(r.height));
        }
        w.commit()
    }

    /// Canonical headers `start..=end` as (height, hash, work, raw).
    /// Seeds the in-memory header window for batched header sync.
    pub fn header_rows_range(&self, start: u64, end: u64) -> Result<Vec<(u64, [u8; 32], [u8; 32], Vec<u8>)>> {
        let mut out = Vec::new();
        for height in start..=end {
            let Some(hash) = self.db.canonical_header_hash(height)? else { continue };
            let Some(header) = self.db.header(&hash)? else { continue };
            out.push((height, hash, header.work, header.raw));
        }
        Ok(out)
    }

    pub fn header_by_height(&self, height: u64) -> Result<Option<Vec<u8>>> {
        Ok(self.db.canonical_header(height)?.map(|h| h.raw))
    }

    pub fn header_height_by_hash(&self, hash: &[u8]) -> Result<Option<u64>> {
        let Ok(hash) = hash32(hash, "header hash") else { return Ok(None) };
        let Some(header) = self.db.header(&hash)? else { return Ok(None) };
        // Only canonical headers have a height, as before.
        match self.db.canonical_header_hash(header.height)? {
            Some(canonical) if canonical == hash => Ok(Some(header.height)),
            _ => Ok(None),
        }
    }

    pub fn header_height(&self) -> Result<Option<u64>> {
        Ok(self.db.canonical_header_tip()?.map(|(_, height)| height))
    }

    pub fn header_hash_by_height(&self, height: u64) -> Result<Option<Vec<u8>>> {
        Ok(self.db.canonical_header_hash(height)?.map(|h| h.to_vec()))
    }

    pub fn header_work_by_height(&self, height: u64) -> Result<Option<Vec<u8>>> {
        Ok(self.db.canonical_header(height)?.map(|h| h.work.to_vec()))
    }

    pub fn header_hashes_range(&self, start: u64, end: u64) -> Result<HashMap<u64, [u8; 32]>> {
        let mut out = HashMap::new();
        for height in start..=end {
            if let Some(hash) = self.db.canonical_header_hash(height)? {
                out.insert(height, hash);
            }
        }
        Ok(out)
    }

    /// Chain work for every canonical header in `start..=end` (inclusive).
    /// Used by the parallel pipeline's fetch stage so verifier threads never
    /// touch the database.
    pub fn header_works_range(&self, start: u64, end: u64) -> Result<HashMap<u64, [u8; 32]>> {
        let mut out = HashMap::new();
        for height in start..=end {
            if let Some(header) = self.db.canonical_header(height)? {
                out.insert(height, header.work);
            }
        }
        Ok(out)
    }

    pub fn header_times_range(&self, start: u64, end: u64) -> Result<Vec<(u64, u32)>> {
        let mut out = Vec::new();
        let mut height = start;
        while height < end {
            if let Some(header) = self.db.canonical_header(height)? {
                out.push((height, header.time));
            }
            height += 1;
        }
        Ok(out)
    }

    pub fn header_time(&self, height: u64) -> Result<Option<u32>> {
        Ok(self.db.canonical_header(height)?.map(|h| h.time))
    }

    pub fn locator_hashes(&self) -> Result<Vec<[u8; 32]>> {
        let tip = self.header_height()?.unwrap_or(0);
        let mut heights = Vec::new();
        let mut h = tip;
        while h > 0 && heights.len() < 10 {
            heights.push(h);
            h = h.saturating_sub(1);
        }
        let mut step = 2u64;
        while h > 0 && heights.len() < 32 {
            heights.push(h);
            h = h.saturating_sub(step);
            step = step.saturating_mul(2);
        }
        heights.push(0);
        heights.sort_unstable();
        heights.dedup();
        heights.reverse();
        let mut out = Vec::new();
        for h in heights {
            if let Some(v) = self.header_hash_by_height(h)? {
                if v.len() == 32 {
                    let mut a = [0u8; 32];
                    a.copy_from_slice(&v);
                    out.push(a);
                }
            } else if h == 0 {
                out.push(ycash_chain::genesis_hash_internal());
            }
        }
        Ok(out)
    }

    /// Consistent chain export.
    ///
    /// RocksDB is a directory, so the export is a checkpoint packed into one
    /// uncompressed tar archive. The checkpoint is taken with hard links where
    /// possible, so it neither copies the whole chain nor stalls the committer.
    pub fn export_snapshot(&self, dest: &Path) -> Result<()> {
        db::export_checkpoint_tar(&self.db, dest)
    }

    /// Flush memtables to SST files (for example before the app is backgrounded).
    pub fn flush(&self) -> Result<()> {
        self.db.flush()
    }
}

fn hash32(bytes: &[u8], what: &str) -> Result<[u8; 32]> {
    <[u8; 32]>::try_from(bytes).map_err(|_| anyhow::anyhow!("invalid {what} length {}", bytes.len()))
}

fn telemetry_array_json(values: &[u64; 32]) -> String {
    let mut out = String::from("[");
    for (i, v) in values.iter().enumerate() {
        if i != 0 { out.push(','); }
        out.push_str(&v.to_string());
    }
    out.push(']');
    out
}

fn telemetry_array_json_32(values: &[u64; 32]) -> String {
    let mut out = String::from("[");
    for (i, v) in values.iter().enumerate() {
        if i != 0 { out.push(','); }
        out.push_str(&v.to_string());
    }
    out.push(']');
    out
}

fn pipeline_commit_log(stage: &str, first: u64, last: u64, t: &CommitTiming) {
    eprintln!(
        "[DBPIPE] stage={} range={}..{} total_ms={} begin_ms={} state_validate_ms={} state_validate_us={} state_unattributed_us={} header_hash_us={} connector_new_us={} connector_other_us={} block_root_us={} block_loop_other_us={} slowest_block_height={} slowest_block_us={} slowest_block_other_us={} slowest_tx_height={} slowest_tx_index={} slowest_tx_us={} slowest_tx_other_us={} parent_state_ms={} parent_state_us={} parent_frontier_us={} sprout_state_load_us={} block_parse_ms={} block_parse_us={} txid_us={} tx_parse_us={} tx_connect_ms={} tx_connect_us={} sigops_ms={} sigops_us={} bip30_ms={} bip30_us={} utxo_lookup_ms={} sprout_req_ms={} value_ms={} script_ms={} coin_state_ms={} sprout_apply_ms={} sapling_validate_ms={} sapling_anchor_ms={} sapling_nullifier_ms={} sapling_tree_ms={} block_finalize_ms={} tree_ms={} rollback_ms={} db_write_ms={} sql_write_ms={} index_write_ms={} sqlite_commit_ms={} blocks={} txs={} utxo_lookups={} bip30_checks={} script_checks={} script_parallel_workers={} script_parallel_us={} script_spawn_us={} script_join_us={} script_pool_overhead_us={} script_permit_wait_us={} script_scheduler_gap_us={} script_active_peak={} script_pool_threads={} script_worker_max_us={} script_worker_min_us={} script_worker_wall_us={} script_worker_input_work_us={} script_worker_inputs={} utxo_cache_hits={} utxo_cache_misses={} parent_state_cache_hit={} sprout_state_cache_hit={} sapling_anchor_queries={} sapling_nullifier_queries={} sapling_empty_hashes_avoided={} sapling_root_cache_hits={} root_levels_us={} root_level_hashes={} root_empty_us={} root_empty_hashes={} root_hash_us={} root_hashes={}",
        stage, first, last, t.total_ms, t.begin_ms, t.state_validation_ms, t.state_validation_us, t.state_unattributed_us, t.header_hash_us, t.connector_new_us, t.connector_other_us, t.block_root_us, t.block_loop_other_us, t.slowest_block_height, t.slowest_block_us, t.slowest_block_other_us, t.slowest_tx_height, t.slowest_tx_index, t.slowest_tx_us, t.slowest_tx_other_us, t.parent_state_load_ms, t.parent_state_load_us, t.parent_frontier_load_us, t.sprout_state_load_us, t.block_parse_ms, t.block_parse_us, t.txid_us, t.tx_parse_us, t.tx_connect_ms, t.tx_connect_us, t.sigops_ms, t.sigops_us, t.bip30_ms, t.bip30_us, t.utxo_lookup_ms, t.sprout_requirements_ms, t.value_checks_ms, t.script_ms, t.coin_state_update_ms, t.sprout_apply_ms, t.sapling_validate_ms, t.sapling_anchor_lookup_ms, t.sapling_nullifier_lookup_ms, t.sapling_tree_update_ms, t.block_finalize_ms, t.tree_ms, t.rollback_ms, t.db_write_ms, t.sql_write_ms, t.index_write_ms, t.sqlite_commit_ms, t.blocks, t.txs, t.utxo_lookups, t.bip30_checks, t.script_checks, t.script_parallel_workers, t.script_parallel_us, t.script_spawn_us, t.script_join_us, t.script_pool_overhead_us, t.script_permit_wait_us, t.script_scheduler_gap_us, t.script_active_peak, t.script_pool_threads, t.script_worker_max_us, t.script_worker_min_us, telemetry_array_json_32(&t.script_worker_wall_us), telemetry_array_json_32(&t.script_worker_input_work_us), telemetry_array_json_32(&t.script_worker_inputs), t.utxo_cache_hits, t.utxo_cache_misses, t.parent_state_cache_hit, t.sprout_state_cache_hit, t.sapling_anchor_queries, t.sapling_nullifier_queries, t.sapling_empty_hashes_avoided, t.sapling_root_cache_hits, telemetry_array_json(&t.block_root_level_us), telemetry_array_json(&t.block_root_level_hashes), telemetry_array_json(&t.block_root_empty_us), telemetry_array_json(&t.block_root_empty_hashes), telemetry_array_json(&t.block_root_hash_us), telemetry_array_json(&t.block_root_hashes)
    );
}

fn validate_batch_shape(blocks: &[BlockCommit]) -> Result<()> {
    for i in 1..blocks.len() {
        if blocks[i].height != blocks[i - 1].height + 1 || blocks[i].prev != blocks[i - 1].hash {
            bail!("block batch is not contiguous");
        }
    }
    Ok(())
}

fn load_parent_frontier(
    read: &db::ReadView<'_>,
    height: u64,
    prev: &[u8; 32],
) -> Result<SaplingConsensusState> {
    if height == 1 && *prev == ycash_chain::genesis_hash_internal() {
        return Ok(SaplingConsensusState::new());
    }
    if height == 0 {
        return Ok(SaplingConsensusState::new());
    }
    let parent_height = height - 1;
    if !read.is_canonical_block(prev, parent_height)? {
        bail!("missing canonical Sapling state for parent: parent is not on the main chain");
    }
    let rec = read
        .sapling_tree(prev)?
        .ok_or_else(|| anyhow::anyhow!("missing canonical Sapling state for parent"))?;
    if rec.height != parent_height {
        bail!("canonical Sapling state for parent is at height {}, expected {parent_height}", rec.height);
    }
    SaplingConsensusState::decode(&rec.frontier)
        .map_err(|e| anyhow::anyhow!("invalid canonical Sapling state for parent: {e:?}"))
}

// v0.22 adaptive sync pipeline
pub mod pipeline;

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp_db() -> std::path::PathBuf {
        std::env::temp_dir().join(format!(
            "ycash-state-test-{}-{}.rocksdb",
            std::process::id(),
            SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos()
        ))
    }

    #[test]
    fn fresh_database_creates_every_column_family() {
        let p = temp_db();
        let s = State::open(&p).unwrap();
        assert_eq!(s.transaction_count().unwrap(), 0);
        assert!(s.tip_height().unwrap().is_none());
        let database = s.database();
        for name in db::COLUMN_FAMILIES {
            assert!(database.cf(name).is_ok(), "missing column family {name}");
        }
        assert_eq!(database.meta_u64(db::META_SCHEMA_VERSION).unwrap(), Some(SCHEMA_VERSION));
        drop(s);
        let _ = fs::remove_dir_all(&p);
    }

    #[test]
    fn headers_round_trip_and_reopen() {
        let p = temp_db();
        {
            let s = State::open(&p).unwrap();
            let row = HeaderRow {
                height: 1,
                hash: [1u8; 32],
                prev: [0u8; 32],
                time: 1_600_000_000,
                bits: 0x1d00ffff,
                work: [2u8; 32],
                raw: vec![9u8; 80],
            };
            s.put_headers_batch(&[row]).unwrap();
            assert_eq!(s.header_height().unwrap(), Some(1));
            assert_eq!(s.header_time(1).unwrap(), Some(1_600_000_000));
            assert_eq!(s.header_hash_by_height(1).unwrap().unwrap(), vec![1u8; 32]);
            assert_eq!(s.header_height_by_hash(&[1u8; 32]).unwrap(), Some(1));
        }
        // Reopening must see the committed header: the batch was durable.
        let s = State::open(&p).unwrap();
        assert_eq!(s.header_height().unwrap(), Some(1));
        drop(s);
        let _ = fs::remove_dir_all(&p);
    }

    #[test]
    fn legacy_sqlite_file_is_moved_aside() {
        let p = temp_db();
        fs::write(&p, b"SQLite format 3\0").unwrap();
        let s = State::open(&p).unwrap();
        assert!(p.is_dir());
        assert!(p.with_extension("sqlite-legacy").exists());
        drop(s);
        let _ = fs::remove_dir_all(&p);
        let _ = fs::remove_file(p.with_extension("sqlite-legacy"));
    }
}
