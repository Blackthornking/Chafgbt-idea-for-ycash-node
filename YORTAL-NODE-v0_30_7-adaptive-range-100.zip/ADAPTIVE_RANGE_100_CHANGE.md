# v0.30.7 Adaptive Range Ceiling: 100

The synchronization scheduler now permits adaptive network ranges from 1 through 100 blocks.

- 16 blocks is only the initial operating point.
- 100 blocks is the scheduler ceiling.
- CPU, memory, DB, validation and network pressure continue to control the active window.
- Range scheduling still rejects overlaps/duplicates.
- Verified ranges still cross a strictly ordered canonical commit boundary.
- No consensus rule or cryptographic validity rule is changed by increasing the scheduler ceiling.
- CI must test invariants, not require a fixed range size.
