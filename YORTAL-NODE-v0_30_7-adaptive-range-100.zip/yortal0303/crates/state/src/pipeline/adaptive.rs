//! YORTAL Adaptive Parallel Sync controller.
//! Consensus-neutral scheduling policy: it only controls concurrency and buffering.

#[derive(Debug, Clone, Copy)]
pub struct ResourceSample {
    pub cpu_ratio: f64,
    pub memory_ratio: f64,
    pub db_queue_ratio: f64,
    pub network_ratio: f64,
    pub validation_queue_ratio: f64,
}

#[derive(Debug, Clone, Copy)]
pub struct AdaptiveConfig {
    pub min_window: usize,
    pub initial_window: usize,
    pub max_window: usize,
    pub step: usize,
    pub high_watermark: f64,
    pub low_watermark: f64,
    /// Maximum verifier workers permitted by the sync coordinator.
    pub max_validation_workers: usize,
    /// Maximum simultaneously in-flight ranges behind the ordered commit barrier.
    pub max_inflight_ranges: usize,
}

impl Default for AdaptiveConfig {
    fn default() -> Self {
        Self {
            // Fully adaptive range sizing. The controller may use any range
            // from 1 through 100 blocks; 16 is only the startup point, not a cap.
            min_window: 1,
            initial_window: 16,
            max_window: 100,
            step: 8,
            high_watermark: 0.90,
            low_watermark: 0.55,
            max_validation_workers: 1,
            max_inflight_ranges: 1,
        }
    }
}

#[derive(Debug, Clone)]
pub struct AdaptiveController {
    cfg: AdaptiveConfig,
    window: usize,
    workers: usize,
    inflight: usize,
}

impl AdaptiveController {
    pub fn new(cfg: AdaptiveConfig) -> Self {
        let window = cfg.initial_window.clamp(cfg.min_window, cfg.max_window);
        let workers = cfg.max_validation_workers.max(1);
        let inflight = cfg.max_inflight_ranges.max(1);
        Self { cfg, window, workers, inflight }
    }

    pub fn window(&self) -> usize { self.window }

    /// Maximum verifier workers permitted by the sync coordinator.
    pub fn max_validation_workers(&self) -> usize { self.cfg.max_validation_workers }

    /// Maximum simultaneously in-flight ranges behind the ordered commit barrier.
    pub fn max_inflight_ranges(&self) -> usize { self.cfg.max_inflight_ranges }

    pub fn current_workers(&self) -> usize { self.workers.max(1) }

    pub fn current_inflight(&self) -> usize { self.inflight.max(1) }

    /// Current worker budget. The coordinator may spawn a fixed-size pool and
    /// use this value as the number of workers allowed to take jobs. Keeping
    /// the pool fixed avoids thread churn while still adapting useful CPU
    /// concurrency.
    pub fn worker_budget(&self, pressure: f64) -> usize {
        let max = self.cfg.max_validation_workers.max(1);
        if pressure >= self.cfg.high_watermark { 1 }
        else if pressure >= self.cfg.low_watermark { (max / 2).max(1) }
        else { max }
    }

    /// Current range budget. This is derived from the same pressure signal as
    /// the window and is always bounded by the configured safety ceiling.
    pub fn inflight_budget(&self, pressure: f64) -> usize {
        let max = self.cfg.max_inflight_ranges.max(1);
        if pressure >= self.cfg.high_watermark { 1 }
        else if pressure >= self.cfg.low_watermark { (max / 2).max(1) }
        else { max }
    }

    /// AIMD-like controller. DB/memory pressure dominates network pressure.
    pub fn observe(&mut self, s: ResourceSample) -> usize {
        let pressure = s.cpu_ratio
            .max(s.memory_ratio)
            .max(s.db_queue_ratio)
            .max(s.validation_queue_ratio);

        if pressure >= self.cfg.high_watermark {
            self.window = self.window.saturating_sub(self.cfg.step.max(1))
                .max(self.cfg.min_window);
        } else if pressure <= self.cfg.low_watermark && s.network_ratio < 0.85 {
            self.window = (self.window + self.cfg.step.max(1)).min(self.cfg.max_window);
        }
        self.workers = self.worker_budget(pressure);
        self.inflight = self.inflight_budget(pressure);
        self.window
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn starts_at_configured_initial_window() {
        let cfg = AdaptiveConfig {
            min_window: 64, initial_window: 256, max_window: 4096,
            step: 128, high_watermark: 0.90, low_watermark: 0.55,
            max_validation_workers: 1, max_inflight_ranges: 1,
        };
        assert_eq!(AdaptiveController::new(cfg).window(), 256);
    }

    #[test]
    fn initial_window_is_clamped() {
        let cfg = AdaptiveConfig {
            min_window: 64, initial_window: 8192, max_window: 4096,
            step: 128, high_watermark: 0.90, low_watermark: 0.55,
            max_validation_workers: 1, max_inflight_ranges: 1,
        };
        assert_eq!(AdaptiveController::new(cfg).window(), 4096);
    }
}

#[cfg(test)]
mod adaptive_pressure_tests {
    use super::*;

    fn cfg() -> AdaptiveConfig {
        AdaptiveConfig {
            min_window: 16, initial_window: 32, max_window: 128, step: 16,
            high_watermark: 0.85, low_watermark: 0.50,
            max_validation_workers: 4, max_inflight_ranges: 4,
        }
    }

    #[test]
    fn low_pressure_enables_full_concurrency() {
        let mut c = AdaptiveController::new(cfg());
        c.observe(ResourceSample { cpu_ratio: 0.20, memory_ratio: 0.20,
            db_queue_ratio: 0.20, network_ratio: 0.20, validation_queue_ratio: 0.20 });
        assert_eq!(c.current_workers(), 4);
        assert_eq!(c.current_inflight(), 4);
        assert_eq!(c.window(), 48);
    }

    #[test]
    fn high_pressure_reduces_workers_inflight_and_window() {
        let mut c = AdaptiveController::new(cfg());
        c.observe(ResourceSample { cpu_ratio: 0.95, memory_ratio: 0.20,
            db_queue_ratio: 0.20, network_ratio: 0.20, validation_queue_ratio: 0.20 });
        assert_eq!(c.current_workers(), 1);
        assert_eq!(c.current_inflight(), 1);
        assert!(c.window() >= 1 && c.window() <= 100);
    }
}
