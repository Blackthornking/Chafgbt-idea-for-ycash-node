#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

state="$ROOT/crates/state/src/chainstate.rs"
config="$ROOT/config/pipeline.toml"
[[ -f "$state" ]] || { echo "ERROR: missing $state" >&2; exit 1; }

grep -q 'rayon.workspace = true' "$ROOT/crates/state/Cargo.toml" || { echo "ERROR: rayon dependency missing" >&2; exit 1; }
grep -q 'OnceLock<rayon::ThreadPool>' "$state" || { echo "ERROR: persistent script pool missing" >&2; exit 1; }
grep -q 'par_iter().enumerate()' "$state" || { echo "ERROR: per-input dynamic scheduling missing" >&2; exit 1; }
if grep -q 'std::thread::scope' "$state"; then
  echo "ERROR: per-transaction thread spawning remains in script verifier" >&2
  exit 1
fi
grep -q 'available_parallelism' "$state" || { echo "ERROR: adaptive CPU sizing missing" >&2; exit 1; }
grep -q 'YORTAL_SCRIPT_WORKERS' "$state" || { echo "ERROR: verifier worker override missing" >&2; exit 1; }
grep -q 'YORTAL_SCRIPT_PARALLEL_THRESHOLD' "$state" || { echo "ERROR: verifier threshold override missing" >&2; exit 1; }
# The pipeline is now adaptive: fixed one-worker/one-inflight assertions from
# the earlier sequential build are intentionally removed. Consensus safety is
# enforced by the ordered commit path, while the adaptive controller chooses
# worker/in-flight budgets within configured limits.
grep -q 'max_validation_workers' "$config" || { echo "ERROR: adaptive validation worker setting missing" >&2; exit 1; }
grep -q 'max_inflight_ranges' "$config" || { echo "ERROR: adaptive inflight setting missing" >&2; exit 1; }
grep -q 'max_range_len = 16' "$config" || { echo "ERROR: range limit is not 16" >&2; exit 1; }

echo "PASS: adaptive consensus-safe script pool and ordered pipeline checks present"
