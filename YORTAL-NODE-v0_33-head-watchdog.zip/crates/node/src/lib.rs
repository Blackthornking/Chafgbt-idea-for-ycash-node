//! YORTAL synchronisation engine.
//!
//! ```text
//!   peers (n)                 verifier pool (m)        ordered gate (1)     writer (1)
//!   ┌──────────────┐  block   ┌──────────────────┐     ┌───────────────┐    ┌─────────┐
//!   │ ≤48 in flight│ ───────► │ semantic verify  │ ──► │ prospective   │ ─► │ one     │
//!   │ replenish on │  stream  │ (context-free,   │     │ tree + chain  │    │ Write   │
//!   │ each arrival │          │  out of order)   │     │ selection +   │    │ Batch   │
//!   └──────────────┘          └──────────────────┘     │ contextual    │    └─────────┘
//!                                                      │ rules, in     │
//!                                                      │ ancestry order│
//!                                                      └───────────────┘
//! ```
//!
//! Everything left of the gate is parallel and unordered. Everything from the
//! gate rightwards is single-threaded and strictly ordered by ancestry. That
//! split is the whole design: it is what lets the node use every core without
//! any consensus rule depending on how many cores there are, how many blocks a
//! peer had in flight, or how many blocks shared a WriteBatch.

use std::sync::Arc;

use anyhow::Result;
use ycash_state::state_service::{StateService, StateServiceHandle, SyncMetrics, DEFAULT_PROSPECTIVE_CAPACITY};
use ycash_state::State;

pub mod downloader;
pub mod peer_manager;
pub mod verifier;

pub use downloader::{
    BlockAssigner, BlockRequest, InFlightRegistry, PeerDownloadSession, MAX_BLOCKS_IN_FLIGHT,
    MAX_BLOCKS_IN_TRANSIT_PER_PEER, REQUEST_TIMEOUT, CANONICAL_PARENT_RETRY_TIMEOUT,
};
pub use peer_manager::{PeerManager, PeerStats};
pub use verifier::{RawBlock, VerifierPool, ASSUME_VALID_HASH_DISPLAY, ASSUME_VALID_HEIGHT};

/// Transport and resource settings. None of these is a consensus parameter:
/// the same chain synchronised with any combination of them must produce the
/// same canonical state.
#[derive(Clone, Debug)]
pub struct SyncConfig {
    pub blocks_in_transit_per_peer: usize,
    pub max_blocks_in_flight: usize,
    pub prospective_capacity: usize,
    pub verifier_workers: usize,
    pub verifier_queue: usize,
    pub assume_valid: bool,
}

impl Default for SyncConfig {
    fn default() -> Self {
        Self {
            blocks_in_transit_per_peer: MAX_BLOCKS_IN_TRANSIT_PER_PEER,
            max_blocks_in_flight: MAX_BLOCKS_IN_FLIGHT,
            prospective_capacity: DEFAULT_PROSPECTIVE_CAPACITY,
            verifier_workers: verifier::default_verifier_workers(),
            verifier_queue: 64,
            assume_valid: false,
        }
    }
}

impl SyncConfig {
    /// Read the transport settings from the environment, so they can be changed
    /// on a device without rebuilding. Consensus cannot be changed this way.
    pub fn from_env() -> Self {
        let mut cfg = Self::default();
        if let Some(v) = env_usize("YORTAL_BLOCKS_IN_TRANSIT_PER_PEER") {
            cfg.blocks_in_transit_per_peer = v.clamp(1, MAX_BLOCKS_IN_TRANSIT_PER_PEER);
        }
        if let Some(v) = env_usize("YORTAL_MAX_BLOCKS_IN_FLIGHT") {
            cfg.max_blocks_in_flight = v.clamp(cfg.blocks_in_transit_per_peer, 4096);
        }
        if let Some(v) = env_usize("YORTAL_PROSPECTIVE_BLOCKS") {
            cfg.prospective_capacity = v.clamp(cfg.blocks_in_transit_per_peer, 4096);
        }
        // The candidate set must be able to hold everything the downloader can
        // have outstanding, plus room to spare. If the two ceilings are equal,
        // a full pipeline evicts on every arrival, and eviction churn around a
        // missing parent is what stalls the chain. Headroom makes eviction the
        // rare event it is meant to be.
        // A claim is held from request until the block is committed or
        // discarded, so buffered candidates occupy claim slots too. The
        // registry ceiling must therefore exceed what the candidate set can
        // hold, plus what the peers can have in transit -- otherwise the
        // registry fills with buffered blocks and no slot remains to fetch the
        // block that would drain them.
        cfg.max_blocks_in_flight = cfg
            .max_blocks_in_flight
            .max(cfg.prospective_capacity + cfg.blocks_in_transit_per_peer * 4);
        if let Some(v) = env_usize("YORTAL_VERIFY_THREADS") {
            // 0 is the documented automatic mode. Do not clamp it to 1: that
            // silently disabled the device-derived verifier width on Android.
            cfg.verifier_workers = if v == 0 {
                verifier::default_verifier_workers()
            } else {
                v.clamp(1, 64)
            };
        }
        cfg.assume_valid = std::env::var("YCASH_ASSUME_VALID").ok().as_deref() == Some("1")
            && std::env::var("YCASH_FULL_VERIFY").ok().as_deref() != Some("1");
        cfg
    }
}

fn env_usize(name: &str) -> Option<usize> {
    std::env::var(name).ok().and_then(|v| v.trim().parse::<usize>().ok())
}

/// Everything the peer threads need, started once per process.
#[derive(Clone)]
pub struct SyncEngine {
    pub state: Arc<State>,
    pub peers: Arc<PeerManager>,
    pub registry: Arc<InFlightRegistry>,
    pub assigner: Arc<BlockAssigner>,
    pub verifiers: VerifierPool,
    pub gate: StateServiceHandle,
    pub metrics: Arc<SyncMetrics>,
    pub config: SyncConfig,
}

impl SyncEngine {
    /// Start the ordered state gate, the canonical writer and the verifier
    /// pool. Fails if a canonical writer already exists.
    pub fn start(state: Arc<State>, config: SyncConfig) -> Result<Self> {
        let metrics = SyncMetrics::new();
        // One lifecycle registry spans transport, semantic verification and
        // ordered publication. The state gate releases entries only after a
        // successful canonical write or an explicit discard.
        let registry = Arc::new(InFlightRegistry::new(config.max_blocks_in_flight));
        let lifecycle: ycash_state::state_service::CandidateLifecycleHook = {
            let registry = Arc::clone(&registry);
            Arc::new(move |event: ycash_state::state_service::CandidateLifecycleEvent, hashes: Vec<[u8; 32]>| {
                match event {
                    ycash_state::state_service::CandidateLifecycleEvent::Committed
                    | ycash_state::state_service::CandidateLifecycleEvent::Discarded => registry.release_many(&hashes),
                }
            })
        };
        let gate = StateService::spawn_with_lifecycle_hook(
            Arc::clone(&state),
            config.prospective_capacity,
            Arc::clone(&metrics),
            Some(lifecycle),
        )?;
        let verifiers = VerifierPool::spawn(
            config.verifier_workers,
            config.verifier_queue,
            gate.clone(),
            Arc::clone(&metrics),
            Arc::clone(&registry),
            config.assume_valid,
        )?;
        let assigner = Arc::new(BlockAssigner::new(
            Arc::clone(&state),
            Arc::clone(&registry),
            Arc::clone(&metrics),
            // Never request further ahead than the candidate set can hold.
            config.prospective_capacity,
        ));
        assigner.rewind_to_canonical()?;
        let peers = Arc::new(PeerManager::new());
        if let Ok(Some(tip)) = state.tip_height() {
            metrics
                .canonical_height
                .store(tip, std::sync::atomic::Ordering::Relaxed);
        }
        Ok(Self { state, peers, registry, assigner, verifiers, gate, metrics, config })
    }

    /// Per-peer request window.
    pub fn session(&self, peer: &str) -> PeerDownloadSession {
        PeerDownloadSession::new(
            peer,
            Arc::clone(&self.assigner),
            Arc::clone(&self.registry),
            Arc::clone(&self.peers),
            Arc::clone(&self.metrics),
        )
        .with_limit(self.config.blocks_in_transit_per_peer)
    }

    /// Handle one `block` message: match it to an outstanding request, free the
    /// slot and queue it for semantic verification.
    ///
    /// A block nobody asked for is ignored rather than trusted, and an unknown
    /// hash is never counted against the peer's window.
    pub fn on_block_message(&self, session: &mut PeerDownloadSession, raw: Vec<u8>) -> Result<bool> {
        let Some(hash) = block_hash(&raw) else { return Ok(false) };
        let bytes = raw.len();
        let Some(request) = session.on_block(&hash, bytes) else { return Ok(false) };
        let source_peer = session.peer().to_string();
        if let Err(e) = self.verifiers.submit(RawBlock { request: request.clone(), raw, source_peer }) {
            self.registry.release(&request.hash);
            return Err(e);
        }
        Ok(true)
    }

    /// Hashes to put in the next `getdata`, refilling the peer's window.
    pub fn next_requests(&self, session: &mut PeerDownloadSession) -> Result<Vec<[u8; 32]>> {
        // The canonical parent is special: later blocks cannot be committed
        // around it, so do not make tip+1 wait for the normal 90s transport
        // timeout. A short head retry lets another peer take over quickly.
        session.retry_canonical_parent(CANONICAL_PARENT_RETRY_TIMEOUT)?;
        session.expire_stale(REQUEST_TIMEOUT);
        session.top_up()
    }

    /// Record an exact canonical-head transport event for diagnostics.
    pub fn trace_head(&self, peer: impl Into<String>, event: impl Into<String>, height: u64, hash: Option<[u8; 32]>, detail: impl Into<String>) {
        self.metrics.trace_head(peer, event, height, hash, detail);
    }

    /// Nudge the ordered gate, e.g. after the header chain advanced.
    pub fn poke(&self) {
        self.gate.poke();
    }
}

/// Block hash: double SHA-256 over the header including its Equihash solution.
pub fn block_hash(raw: &[u8]) -> Option<[u8; 32]> {
    use sha2::{Digest, Sha256};
    let mut cursor = 140usize;
    let solution_len = read_compact_size(raw, &mut cursor)? as usize;
    let end = cursor.checked_add(solution_len)?;
    let header = raw.get(..end)?;
    let digest = Sha256::digest(Sha256::digest(header));
    let mut out = [0u8; 32];
    out.copy_from_slice(&digest);
    Some(out)
}

fn read_compact_size(raw: &[u8], cursor: &mut usize) -> Option<u64> {
    let first = *raw.get(*cursor)?;
    *cursor += 1;
    let value = match first {
        0xfd => {
            let v = u16::from_le_bytes(raw.get(*cursor..*cursor + 2)?.try_into().ok()?) as u64;
            *cursor += 2;
            v
        }
        0xfe => {
            let v = u32::from_le_bytes(raw.get(*cursor..*cursor + 4)?.try_into().ok()?) as u64;
            *cursor += 4;
            v
        }
        0xff => {
            let v = u64::from_le_bytes(raw.get(*cursor..*cursor + 8)?.try_into().ok()?);
            *cursor += 8;
            v
        }
        n => n as u64,
    };
    Some(value)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transport_settings_stay_inside_their_bounds() {
        let cfg = SyncConfig::default();
        assert_eq!(cfg.blocks_in_transit_per_peer, 48);
        assert!(cfg.max_blocks_in_flight >= cfg.blocks_in_transit_per_peer);
        assert!(cfg.verifier_workers >= 1);
    }

    #[test]
    fn compact_size_decodes_every_width() {
        let mut c = 0;
        assert_eq!(read_compact_size(&[0x10], &mut c), Some(0x10));
        c = 0;
        assert_eq!(read_compact_size(&[0xfd, 0x01, 0x02], &mut c), Some(0x0201));
        c = 0;
        assert_eq!(read_compact_size(&[0xfe, 1, 0, 0, 0], &mut c), Some(1));
    }
}
