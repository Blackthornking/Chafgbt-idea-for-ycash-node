# Full blockchain mode

The Android node starts `ycashd` with `-prune=0`.

This explicitly disables block pruning so the node retains the complete
validated blockchain history in its persistent data directory. Initial sync
therefore downloads and stores the full chain rather than retaining only a
recent window of blocks.

The node's existing YTeleport index is built after initial synchronization.
The YTeleport index remains separate from the full blockchain database.

## Storage

The blockchain is stored under the app's private `ycash` data directory.
The Android dashboard reports the current on-disk size and states that full
blockchain storage is enabled.

## Important

A full node can require substantial storage and network bandwidth. The node
must finish initial synchronization before the YTeleport checkpoint index is
marked READY.
