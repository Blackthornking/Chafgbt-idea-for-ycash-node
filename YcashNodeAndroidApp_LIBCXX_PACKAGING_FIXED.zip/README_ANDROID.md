# Ycash Node Android app

This project turns the supplied Ycash 4.5.0 full-node source into an Android arm64-v8a node application shell.

## Important
The ZIP contains the real `ycashd` source, but **not a prebuilt Android daemon binary**. The APK is therefore not yet a synchronized mainnet node until `ycashd` has been cross-compiled with the Android NDK and its native/Rust dependencies.

## Build pipeline
1. Install Android Studio with SDK 35 and a pinned Android NDK.
2. Cross-compile the bundled `app/src/main/cpp/ycashd` for `aarch64-linux-android`.
3. Put the resulting executable at `app/src/main/jniLibs/arm64-v8a/libycashd.so`
   (e.g. via `YCASHD_BIN=/path/to/ycashd tools/package-android-daemon.sh`).
   It must live under `jniLibs/`, not as an asset copied to `filesDir` at
   runtime -- Android 10+ (targetSdk 29+) enforces W^X and refuses to execute
   anything in the app's own writable storage (this previously surfaced as
   `error=13, Permission denied` when starting the node).
4. Build with Gradle:
   `./gradlew :app:assembleDebug`
5. Install the APK on an arm64 Android device.
6. Start the node and verify peer discovery, header/block sync, restart/resume, and independent chain-height/hash checks.

The UI starts `libycashd.so` directly from `applicationInfo.nativeLibraryDir` with a private app data directory. RPC is restricted to localhost.

## Native build note
See `tools/build-android-arm64.md` in the bundled source. This is intentionally a real full-node build path rather than a Java/Kotlin lightwalletd mock.

## YTeleport checkpoint index

When the node reaches a synchronized state, the app builds a persistent SQLite checkpoint index at:
`<app data>/ycash/yteleport_index.db`

The index records periodic block checkpoints plus the current tip. The Android UI enables **SAVE YTELEPORT INDEX AS TEXT** only after the index has completed. Pressing it opens Android's document picker so the user can save `ycash_yteleport_checkpoint_index.txt` locally.

The exported file is a checkpoint/index artifact. It is not, by itself, a cryptographic BridgeSkip or ProofSkip proof.


## Portable YTeleport Proof Package export

The node should expose a `Build YTeleport Package` action after full-chain sync and a `Save YTeleport Package` action that writes `ycash_yteleport_proof_package.dat` through Android's document/file picker. The exporter must include only proof data actually generated or exposed by the node and must compute a SHA-256 integrity hash.

## Ycash.conf Options Editor

The Android node UI now includes **⚙ OPTIONS — Ycash.conf**. It edits the actual
node configuration at the application-private path:

`/data/user/0/org.ycash.node/files/ycash/ycash.conf`

The editor works on the complete configuration file, preserving advanced Ycash
settings. The node must be stopped before saving. Changes take effect on the
next node start. If the file does not exist, the app first creates the standard
Android-safe Ycash configuration automatically.
