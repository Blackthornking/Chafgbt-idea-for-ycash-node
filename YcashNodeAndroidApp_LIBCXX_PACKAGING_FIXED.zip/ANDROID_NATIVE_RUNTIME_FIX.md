# Android native runtime fix

This build packages `ycashd` and the exact `libc++_shared.so` from the same Android NDK (27.2.12479018) under `app/src/main/jniLibs/arm64-v8a/`.

The build deliberately uses the NDK shared libc++ runtime and verifies: 

- `libycashd.so` declares `libc++_shared.so` in ELF `DT_NEEDED`;
- the exact NDK `libc++_shared.so` exists beside the daemon;
- every other non-platform `DT_NEEDED` library is shipped;
- both native files are present in the final APK;
- both are stored uncompressed so Android extracts them to `nativeLibraryDir`;
- the APK is aligned and signed.

At runtime the app sets `LD_LIBRARY_PATH` to `ApplicationInfo.nativeLibraryDir` before starting `ycashd`.

This addresses the observed device error: `cannot locate symbol _ZTVNSt6__ndk119basic_ostringstream...` together with `libc++_shared.so present: false`.
