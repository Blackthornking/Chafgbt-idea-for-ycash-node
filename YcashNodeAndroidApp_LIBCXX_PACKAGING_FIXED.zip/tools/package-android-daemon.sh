#!/usr/bin/env bash
set -euo pipefail
: "${YCASHD_BIN:?Set YCASHD_BIN to an arm64 Android ycashd executable}"
# Must be under jniLibs/<abi>/, named lib*.so, so PackageManager installs it into
# applicationInfo.nativeLibraryDir (exec-only, not app-writable). Packaging it as
# an asset and copying it to filesDir at runtime fails with error=13 on Android
# 10+ (W^X): a location the app can write to can never also be executable there.
mkdir -p app/src/main/jniLibs/arm64-v8a
cp "$YCASHD_BIN" app/src/main/jniLibs/arm64-v8a/libycashd.so
chmod 755 app/src/main/jniLibs/arm64-v8a/libycashd.so
echo "Packaged: app/src/main/jniLibs/arm64-v8a/libycashd.so"
