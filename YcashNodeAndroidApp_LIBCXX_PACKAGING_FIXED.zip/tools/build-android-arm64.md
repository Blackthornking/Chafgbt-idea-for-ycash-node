# Android arm64 native build

`ycashd` is a large C++/Rust full node with Boost, LevelDB, libsodium, secp256k1 and
librustzcash dependencies. It should be cross-compiled with a pinned Android NDK toolchain;
it should not be replaced with a Java/Kotlin mock or lightwalletd client.

Required next build inputs:
- Android NDK version pinned by the build environment
- arm64-v8a target
- cross-compiled Rust target `aarch64-linux-android`
- Android-compatible Boost/LevelDB/libsodium dependencies
- reproducible configuration flags

After the native binary is built, the Android app should launch it with:
`-datadir=<app-private-ycash-dir>` and a node-only configuration, then expose
status/logs to the UI. RPC should bind only to localhost unless explicitly secured.
