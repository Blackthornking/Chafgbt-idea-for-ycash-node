#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../app/src/main/cpp/ycashd/ycash-4.5.0"
./autogen.sh
./configure --disable-wallet --disable-mining --disable-tests --disable-bench
make -j"$(getconf _NPROCESSORS_ONLN)"
echo "Built: src/ycashd"
