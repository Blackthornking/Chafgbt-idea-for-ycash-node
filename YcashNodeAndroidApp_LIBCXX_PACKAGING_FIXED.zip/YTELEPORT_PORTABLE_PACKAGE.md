# YTeleport Portable Proof Package

This project now supports building and saving a portable YTeleport data package from
the locally stored full blockchain/index.

The package is deliberately versioned and self-describing. It contains:

- network/chain identifier
- package format version
- indexed start/end heights and chain tip
- block heights, hashes and previous hashes
- timestamps and transaction counts where available
- chainwork where available
- commitment/tree roots when exposed by the node/index
- Merkle/authentication-path records when exposed by the node/index
- serialized proof records when exposed by the node/index
- proof type/version metadata
- package record counts and integrity SHA-256

Important: this exporter does NOT invent cryptographic proofs. If the current ycashd/
YTeleport implementation has not generated a particular proof/path/root, that field is
stored as absent rather than fabricated. The resulting package must therefore only be
called a complete BridgeSkip/ProofSkip proof package after the corresponding YTeleport
verification implementation validates all required proof fields.

Recommended wallet integration:
1. Run the full node and synchronize/validate the complete chain.
2. Build the YTeleport index/proof records.
3. Export the package with the Android Save dialog.
4. Bundle the resulting binary package with the wallet as a versioned resource.
5. On wallet startup, verify package checksum, network, format version and every proof
   record before using it for accelerated synchronization.
