use anyhow::{bail, Result};
use rocksdb::{ColumnFamilyDescriptor, DB, Options, SliceTransform, WriteBatch};
use std::collections::{HashMap, HashSet};
use std::io::Cursor;
use std::path::Path;
use std::sync::{Arc, Mutex};
use std::time::Instant;
use std::cell::Cell;
use crate::rocks_backend::{self, ReadDb, WriteCtx, CF_NAMES, CF_META, CF_BLOCKS, CF_BLOCKS_HEIGHT, CF_HEADERS, CF_HEADERS_HEIGHT, CF_TXS, CF_TXS_BLOCK, CF_NULLIFIERS, CF_NULLIFIERS_BLOCK, CF_SAPLING_ROOTS, CF_SAPLING_ROOT_INDEX, CF_UTXOS, CF_UTXO_HEIGHT, CF_UTXO_SPENT, CF_SPROUT_NULLIFIERS, CF_SPROUT_NULLIFIERS_HEIGHT, CF_BLOCK_STATE, CF_BLOCK_STATE_HEIGHT, CF_SPROUT_ROOT_INDEX};
use std::sync::atomic::{AtomicU64, Ordering};
use ycash_consensus::{validate_sapling_transaction_state_opts, SaplingConsensusState, SproutTree};

mod rocks_backend;
pub mod chainstate;
use chainstate::{
    BlockConnector, CoinsView, PreparedSproutChanges, PreparedUtxoChanges, SproutView,
    SPENT_OUTPUT_RETENTION, UtxoCache,
};

/// RocksDB state format v1. Column families replace the former RocksDB tables and indexes. (value/script/height/coinbase/spent_height),
/// Sprout nullifiers and per-block Sprout treestate + value pools.
const SCHEMA_VERSION: i64 = 1;

#[derive(Debug, Clone)]
pub struct Tip {
    pub hash: Vec<u8>,
    pub height: u64,
    pub work: [u8; 32],
}

#[derive(Debug, Clone, Default)]
pub struct CommitTiming {
    pub total_ms: u64,
    /// Time spent after a batch became commit-ready before state preparation began.
    /// Populated by the pipeline layer; zero for direct State callers.
    pub queue_wait_ms: u64,
    /// Head-of-line wait before the commit worker could obtain a contiguous batch.
    /// Populated by the pipeline layer; zero for direct State callers.
    pub head_of_line_wait_ms: u64,
    /// Full ordered commit wall time, including state preparation, SQL writes, and RocksDB COMMIT.
    pub state_validation_us: u64,
    pub state_unattributed_us: u64,
    /// Fine-grained residuals used to locate time that is not covered by the named consensus calls.
    pub header_hash_us: u64,
    pub connector_new_us: u64,
    pub connector_other_us: u64,
    pub block_root_us: u64,
    /// Deep Sapling root telemetry: per-root-level time/hash counts plus
    /// the repeated empty-subtree work that can dominate root construction.
    pub block_root_level_us: [u64; 32],
    pub block_root_level_hashes: [u64; 32],
    pub block_root_empty_us: [u64; 32],
    pub block_root_empty_hashes: [u64; 32],
    pub block_root_hash_us: [u64; 32],
    pub block_root_hashes: [u64; 32],
    pub block_loop_other_us: u64,
    pub slowest_block_height: u64,
    pub slowest_block_us: u64,
    pub slowest_block_other_us: u64,
    pub slowest_tx_height: u64,
    pub slowest_tx_index: u64,
    pub slowest_tx_us: u64,
    pub slowest_tx_other_us: u64,
    pub total_us: u64,
    pub state_validation_ms: u64,
    pub rollback_ms: u64,
    pub db_write_ms: u64,
    pub db_write_us: u64,
    /// Time to open the RocksDB batch preparation.
    pub begin_ms: u64,
    /// Time spent advancing Sapling/tree state during state validation.
    pub tree_ms: u64,
    /// Time spent executing block/transaction/tree/nullifier SQL statements.
    pub rocksdb_batch_ms: u64,
    /// Time spent on indexed state writes (tx/root/nullifier indexes).
    pub rocksdb_index_ms: u64,
    pub rocksdb_write_ms: u64,
    pub rocksdb_write_us: u64,
    pub blocks: u64,
    pub txs: u64,
    /// Number of transparent UTXO lookups performed during state validation.
    pub utxo_lookups: u64,
    /// Number of BIP30 existing-tx checks performed during state validation.
    pub bip30_checks: u64,
    /// Number of transaction inputs whose scripts were actually executed.
    pub script_checks: u64,
    /// Script verification telemetry: checks remain consensus-identical, but
    /// independent transparent inputs are verified in parallel before ordered state mutation.
    pub script_parallel_workers: u64,
    pub script_parallel_us: u64,
    pub script_input_work_us: u64,
    pub script_slowest_input_index: u64,
    pub script_slowest_input_us: u64,
    pub script_slowest_input_tx_height: u64,
    pub script_slowest_input_tx_index: u64,
    pub script_transaction_input_extraction_us: u64,
    pub script_sig_construction_us: u64,
    pub script_pubkey_retrieval_us: u64,
    pub script_parsing_us: u64,
    pub signature_hash_preparation_us: u64,
    pub ecdsa_verification_us: u64,
    pub script_interpreter_us: u64,
    pub script_cache_lookup_us: u64,
    pub script_synchronization_us: u64,
    /// Time script jobs spent waiting for the shared CPU permit.
    pub script_permit_wait_us: u64,
    /// Maximum simultaneous script jobs observed during this call.
    pub script_active_peak: u64,
    /// Wall time not covered by the longest observed worker span. Diagnostic only.
    pub script_scheduler_gap_us: u64,
    pub script_worker_wall_us: [u64; 32],
    pub script_worker_input_work_us: [u64; 32],
    pub script_worker_inputs: [u64; 32],
    pub script_spawn_us: u64,
    pub script_join_us: u64,
    pub script_pool_overhead_us: u64,
    pub script_pool_threads: u64,
    pub script_worker_max_us: u64,
    pub script_worker_min_us: u64,
    pub utxo_cache_hits: u64,
    pub utxo_cache_misses: u64,
    pub parent_state_cache_hit: bool,
    pub sprout_state_cache_hit: bool,
    /// Fine-grained ordered state-validation timings.
    pub parent_state_load_ms: u64,
    pub parent_state_load_us: u64,
    pub block_parse_ms: u64,
    pub block_parse_us: u64,
    pub txid_us: u64,
    pub tx_connect_ms: u64,
    pub tx_connect_us: u64,
    pub bip30_ms: u64,
    pub bip30_us: u64,
    pub sigops_ms: u64,
    pub sigops_us: u64,
    pub tx_parse_us: u64,
    pub utxo_lookup_ms: u64,
    pub utxo_lookup_us: u64,
    pub sprout_requirements_ms: u64,
    pub sprout_requirements_us: u64,
    pub value_checks_ms: u64,
    pub value_checks_us: u64,
    pub script_ms: u64,
    pub script_us: u64,
    pub coin_state_update_ms: u64,
    pub coin_state_update_us: u64,
    pub sprout_apply_ms: u64,
    pub sprout_apply_us: u64,
    pub sapling_validate_ms: u64,
    pub sapling_validate_us: u64,
    pub sapling_anchor_lookup_ms: u64,
    pub sapling_anchor_lookup_us: u64,
    pub sapling_nullifier_lookup_ms: u64,
    pub sapling_nullifier_lookup_us: u64,
    pub sapling_tree_update_ms: u64,
    pub sapling_tree_update_us: u64,
    pub block_finalize_ms: u64,
    pub block_finalize_us: u64,
    pub tree_encode_us: u64,
    pub read_transaction_us: u64,
    pub read_transaction_commit_us: u64,
    pub parent_frontier_load_us: u64,
    pub sprout_state_load_us: u64,
    pub sapling_anchor_queries: u64,
    pub sapling_nullifier_queries: u64,
    pub sapling_empty_hashes_avoided: u64,
    pub sapling_root_cache_hits: u64,
}

/// Bounded process-local cache of the exact canonical state at the last
/// successfully committed tip. It is an acceleration layer only: a miss always
/// falls back to RocksDB, and the cache is discarded on reorgs.
struct ConsensusCache {
    tip_hash: [u8; 32],
    tip_height: u64,
    sapling: SaplingConsensusState,
    sprout: SproutTree,
    chain_sprout_value: i64,
    chain_sapling_value: i64,
    utxos: Arc<UtxoCache>,
}


impl ConsensusCache {
    fn new(
        tip_hash: [u8; 32],
        tip_height: u64,
        sapling: SaplingConsensusState,
        sprout: SproutTree,
        chain_sprout_value: i64,
        chain_sapling_value: i64,
    ) -> Self {
        Self { tip_hash, tip_height, sapling, sprout, chain_sprout_value, chain_sapling_value, utxos: Arc::new(UtxoCache::empty()) }
    }
}

pub struct State {
    /// RocksDB is thread-safe for concurrent readers. Canonical mutation is
    /// still serialized by the single pipeline committer, while fetchers use
    /// immutable snapshots and never wait on the writer.
    pub(crate) db: Arc<DB>,
    sapling: Mutex<SaplingConsensusState>,
    /// Blocks at or below this height skip script verification, like ycashd
    /// under its last checkpoint (`fExpensiveChecks = false`). 0 = verify all.
    assume_valid_height: AtomicU64,
    last_commit_timing: Mutex<CommitTiming>,
    /// Canonical state/UTXO cache. This never replaces the DB as authority.
    consensus_cache: Mutex<Option<ConsensusCache>>,
}

/// One validated header, ready for `State::put_headers_batch`.
#[derive(Debug, Clone)]
pub struct HeaderRow {
    pub height: u64,
    pub hash: [u8; 32],
    pub prev: [u8; 32],
    pub time: u32,
    pub bits: u32,
    pub work: [u8; 32],
    pub raw: Vec<u8>,
}

#[derive(Debug, Clone)]
pub struct BlockCommit {
    pub height: u64,
    pub hash: [u8; 32],
    pub prev: [u8; 32],
    pub work: [u8; 32],
    pub raw: Vec<u8>,
    pub txs: Vec<([u8; 32], Vec<u8>)>,
    /// Already-parsed transactions from the stateless validation stage. Empty
    /// for legacy callers; commit falls back to parsing `raw` when absent.
    pub parsed_txs: Vec<ycash_chain::ParsedTransaction>,
    /// Transaction-wide ZIP143/243 signature-hash precomputation produced by
    /// the stateless verifier and carried into commit, so the ordered state
    /// phase does not rebuild it. Empty for legacy callers.
    pub precomputed_txs: Vec<ycash_script::PrecomputedTxData>,
    /// True when Sapling proofs/signatures already passed the verify stage
    /// (`validate_for_commit_opts` or `validate_for_commit_batched` + finish).
    /// The commit then checks anchors/nullifiers/tree without re-verifying proofs.
    pub proofs_verified: bool,
}

/// Zebra-style prepared commit envelope.
///
/// `prepare_commit_batch()` performs all consensus/state work against a
/// read-only RocksDB transaction and produces the complete mutation plan.  The
/// returned envelope contains only immutable data needed by the canonical
/// writer.  `apply_prepared_commit()` performs the short atomic RocksDB write
/// transaction and publishes the in-memory state only after COMMIT succeeds.
///
/// The original block slice is borrowed to avoid another copy of raw blocks;
/// all database/state mutations are owned by this envelope, so the expensive
/// state preparation never has to be repeated during application.
pub struct PreparedCommit<'a> {
    pub blocks: &'a [BlockCommit],
    pub(crate) block_trees: Vec<([u8; 32], Vec<u8>)>,
    pub(crate) pending_nullifiers: Vec<([u8; 32], [u8; 32])>,
    pub(crate) utxo_changes: PreparedUtxoChanges,
    pub(crate) sprout_changes: PreparedSproutChanges,
    pub(crate) working_sapling: SaplingConsensusState,
    pub(crate) sprout_tree: SproutTree,
    pub(crate) chain_sprout_value: i64,
    pub(crate) chain_sapling_value: i64,
    pub(crate) cache_parent_hit: bool,
    pub(crate) normal_extension: bool,
    pub(crate) expected_tip: Option<([u8; 32], u64)>,
    pub(crate) prepare_us: u64,
    pub(crate) timing: CommitTiming,
}

impl<'a> PreparedCommit<'a> {
    pub fn len(&self) -> usize { self.blocks.len() }
    pub fn is_empty(&self) -> bool { self.blocks.is_empty() }
}

impl State {
    pub fn open(p: impl AsRef<Path>) -> Result<Self> {
        let path=p.as_ref();
        if path.exists() && path.is_file() {
            let legacy=path.with_extension("rocksdb.legacy");
            if legacy.exists() { std::fs::remove_file(&legacy).ok(); }
            std::fs::rename(path,&legacy).map_err(|e| anyhow::anyhow!("cannot replace legacy RocksDB state with RocksDB directory: {e}"))?;
        }
        std::fs::create_dir_all(path)?;
        let mut opts=Options::default();
        opts.create_if_missing(true);
        opts.create_missing_column_families(true);
        opts.set_max_background_jobs(2);
        opts.set_max_write_buffer_number(3);
        opts.set_write_buffer_size(16*1024*1024);
        opts.set_bytes_per_sync(1<<20);
        let descriptors=CF_NAMES.iter().map(|name| {
            let mut o=Options::default();
            o.set_optimize_filters_for_hits(true);
            match *name {
                CF_UTXOS|CF_TXS_BLOCK|CF_NULLIFIERS_BLOCK|CF_SAPLING_ROOT_INDEX|CF_SPROUT_ROOT_INDEX => {
                    o.set_prefix_extractor(SliceTransform::create_fixed_prefix(32));
                    o.set_memtable_prefix_bloom_ratio(0.20);
                }
                CF_UTXO_HEIGHT|CF_UTXO_SPENT|CF_HEADERS_HEIGHT|CF_BLOCKS_HEIGHT|CF_BLOCK_STATE_HEIGHT|CF_SPROUT_NULLIFIERS_HEIGHT => {
                    o.set_prefix_extractor(SliceTransform::create_fixed_prefix(8));
                    o.set_memtable_prefix_bloom_ratio(0.15);
                }
                _ => {}
            }
            ColumnFamilyDescriptor::new(*name,o)
        }).collect::<Vec<_>>();
        let db=DB::open_cf_descriptors(&opts,path,descriptors)?;
        let db=Arc::new(db);
        let sapling=match db.get_cf(rocks_backend::cf(&db,CF_META)?,b"sapling_frontier")? {
            Some(v)=>SaplingConsensusState::decode(&v).map_err(|e|anyhow::anyhow!("invalid persisted Sapling state: {e:?}"))?,
            None=>SaplingConsensusState::new(),
        };
        Ok(Self{db,sapling:Mutex::new(sapling),assume_valid_height:AtomicU64::new(0),last_commit_timing:Mutex::new(CommitTiming::default()),consensus_cache:Mutex::new(None)})
    }

    fn read(&self) -> ReadDb<'_> { ReadDb::new(&self.db) }
    fn meta(&self,key:&[u8])->Result<Option<Vec<u8>>> { Ok(self.db.get_cf(rocks_backend::cf(&self.db,CF_META)?,key)?) }
    fn current_tip_from(&self, r:&ReadDb<'_>)->Result<Option<(Vec<u8>,u64)>> {
        let Some(h)=r.get(CF_META,b"tip_height")? else { return Ok(None) };
        let height=u64::from_be_bytes(h.try_into().map_err(|_|anyhow::anyhow!("invalid tip height"))?);
        let hash=r.get(CF_BLOCKS_HEIGHT,&rocks_backend::u64_key(height))?.ok_or_else(||anyhow::anyhow!("tip height points to missing block"))?;
        Ok(Some((hash,height)))
    }

    /// Skip transparent script verification for blocks at or below `height`
    /// (callers must only set this once the header at a hard-coded checkpoint
    /// has been verified to match). Everything else is still validated.
    pub fn set_assume_valid_height(&self, height: u64) {
        self.assume_valid_height.store(height, Ordering::Relaxed);
    }

    pub fn put_block(&self,height:u64,hash:&[u8],prev:&[u8],work:&[u8],raw:&[u8])->Result<()> {
        if hash.len()!=32 || prev.len()!=32 || work.len()!=32 { bail!("invalid hash/work length"); }
        let hash32:<[u8;32]>=hash.try_into().unwrap(); let prev32:<[u8;32]>=prev.try_into().unwrap(); let work32:<[u8;32]>=work.try_into().unwrap();
        let mut batch=WriteBatch::default(); let mut w=WriteCtx{db:&self.db,batch:&mut batch};
        w.put(CF_BLOCKS,&hash32,&rocks_backend::encode_block(height,&prev32,&work32,raw))?; self.db.write(batch)?; Ok(())
    }

    pub fn commit_block(
        &self,
        height: u64,
        hash: &[u8],
        prev: &[u8],
        work: &[u8],
        raw: &[u8],
        txs: &[([u8; 32], Vec<u8>)],
    ) -> Result<()> {
        let b = BlockCommit {
            height,
            hash: hash.try_into().map_err(|_| anyhow::anyhow!("invalid hash length"))?,
            prev: prev.try_into().map_err(|_| anyhow::anyhow!("invalid prev length"))?,
            work: work.try_into().map_err(|_| anyhow::anyhow!("invalid work length"))?,
            raw: raw.to_vec(),
            txs: txs.to_vec(),
            parsed_txs: Vec::new(),
            precomputed_txs: Vec::new(),
            proofs_verified: false,
        };
        self.commit_blocks_batch(&[b])
    }

    /// Prepare an ordered canonical commit without mutating persistent state.
    /// All consensus/state transition work is completed here against a RocksDB
    /// read transaction; the returned mutation plan can then be applied without
    /// repeating those expensive operations.
    pub fn prepare_commit_batch<'a>(&self, blocks: &'a [BlockCommit]) -> Result<PreparedCommit<'a>> {
        if blocks.is_empty() {
            return Ok(PreparedCommit {
                blocks,
                block_trees: Vec::new(),
                pending_nullifiers: Vec::new(),
                utxo_changes: chainstate::PreparedUtxoChanges::empty(),
                sprout_changes: chainstate::PreparedSproutChanges::empty(),
                working_sapling: SaplingConsensusState::new(),
                sprout_tree: SproutTree::new(),
                chain_sprout_value: 0,
                chain_sapling_value: 0,
                cache_parent_hit: false,
                normal_extension: true,
                expected_tip: None,
                prepare_us: 0,
                timing: CommitTiming::default(),
            });
        }
        validate_batch_shape(blocks)?;
        let assume_valid_height = self.assume_valid_height.load(Ordering::Relaxed);
        let total_started = Instant::now();
        let mut timing = CommitTiming { blocks: blocks.len() as u64, txs: blocks.iter().map(|b| b.txs.len() as u64).sum(), ..Default::default() };
        timing.bip30_checks = 0;
        // Fine-grained counters make the existing four-stage timing useful for
        // identifying whether the commit bottleneck is transaction/UTXO work,
        // script execution, database writes, or the final RocksDB COMMIT.
        timing.bip30_checks = 0;

        // Zcash-style commit separation: perform the expensive consensus/state
        // preparation against a read transaction first.  Do not hold RocksDB's
        // WRITE transaction open while parsing, connecting UTXOs, or advancing
        // the Sapling frontier.  The committer owns `self.db`, so no competing
        // canonical writer can change the state between these two transactions.
        // Preparation uses the dedicated read-only WAL connection when
        // available.  This is the key database-side separation: expensive
        // consensus validation no longer monopolizes the canonical WRITE
        // connection mutex.  `:memory:` databases fall back to `db`.
        let read_db = self.read();
        let validation_started = Instant::now();
        let read_tx_started = Instant::now();
        timing.read_transaction_us = read_tx_started.elapsed().as_micros() as u64;

        // Snapshot the exact canonical tip used for preparation. The apply
        // phase rechecks this value inside its WRITE transaction, closing the
        // prepare/apply gap so a concurrent set_tip/reorg cannot make a stale
        // prepared mutation plan commit onto a different state.
        let expected_tip = self.current_tip_from(&read_db)?.map(|(hash,height)| (<[u8;32]>::try_from(hash.as_slice()).map_err(|_| anyhow::anyhow!("invalid canonical tip hash length"))?,height)).transpose()?;

        let first = &blocks[0];
        let first_height = first.height;
        const UTXO_CACHE_ENTRIES: usize = 50_000;
        let parent_started = Instant::now();

        // Cache hits are accepted only when the cached state is exactly the
        // canonical parent identified by the first block. This makes the cache
        // incapable of crossing a reorg boundary or being used for the wrong
        // branch.
        let (cache_parent_hit, cached_utxo_map, cached_sprout, cached_sprout_value, cached_sapling_value) = {
            let cache_guard = self.consensus_cache.lock().unwrap();
            let hit = cache_guard.as_ref().map(|c| {
                c.tip_height.saturating_add(1) == first.height && c.tip_hash == first.prev
            }).unwrap_or(false);
            if hit {
                let c = cache_guard.as_ref().unwrap();
                (true, Some(Arc::clone(&c.utxos)), Some(c.sprout.clone()), Some(c.chain_sprout_value), Some(c.chain_sapling_value))
            } else {
                (false, None, None, None, None)
            }
        };
        timing.parent_state_cache_hit = cache_parent_hit;
        let parent_frontier = if cache_parent_hit {
            let cache_guard = self.consensus_cache.lock().unwrap();
            cache_guard.as_ref().unwrap().sapling.clone()
        } else {
            let parent_frontier_started = Instant::now();
            let pf = load_parent_frontier(&read_db, first.height, &first.prev)?;
            timing.parent_frontier_load_us = parent_frontier_started.elapsed().as_micros() as u64;
            pf
        };
        let mut working = parent_frontier;
        let mut valid_batch_roots = HashSet::new();
        valid_batch_roots.insert(working.root());

        let mut coins = CoinsView::new(first_height, cached_utxo_map.as_ref().map(|c| c.as_ref()));
        let sprout_started = Instant::now();
        let mut sprout = if let Some(tree) = cached_sprout {
            timing.sprout_state_cache_hit = true;
            SproutView::from_cached(first_height, tree, cached_sprout_value.unwrap_or(0), cached_sapling_value.unwrap_or(0))
        } else {
            timing.sprout_state_cache_hit = false;
            SproutView::load(&read_db, first_height, &first.prev)?
        };
        timing.sprout_state_load_us = sprout_started.elapsed().as_micros() as u64;
        timing.parent_state_load_us = parent_started.elapsed().as_micros() as u64;
        timing.parent_state_load_ms = timing.parent_state_load_us / 1000;

        // Validate the complete batch against the canonical ancestor state before
        // changing any canonical flags. This makes a failed batch atomic both
        // logically and physically: no half-reorged anchor set is visible.
        let mut batch_nullifiers = HashSet::new();
        // v0.29.2: everything the write phase needs is collected here, so the
        // write phase never re-parses a block or transaction.
        let mut pending_nullifiers: Vec<([u8; 32], [u8; 32])> = Vec::new();
        // Per-block Sapling root + frontier. v0.29.1 wrote the batch's FINAL
        // tree to every block's sapling_roots row; each row now gets its own.
        let mut block_trees: Vec<([u8; 32], Vec<u8>)> = Vec::with_capacity(blocks.len());
        for (i, b) in blocks.iter().enumerate() {
            let block_started = Instant::now();
            let block_parse_before = timing.block_parse_us;
            let tx_parse_before = timing.tx_parse_us;
            let txid_before = timing.txid_us;
            let tx_connect_before = timing.tx_connect_us;
            let sapling_before = timing.sapling_validate_us;
            let finalize_before = timing.block_finalize_us;
            let encode_before = timing.tree_encode_us;
            let header_hash_before = timing.header_hash_us;
            let connector_new_before = timing.connector_new_us;
            let block_root_before = timing.block_root_us;
            let parse_started = Instant::now();
            let block = ycash_chain::read_block_at_height(&b.raw, b.height)?;
            let parse_us = parse_started.elapsed().as_micros() as u64;
            timing.block_parse_us = timing.block_parse_us.saturating_add(parse_us);
            timing.block_parse_ms = timing.block_parse_us / 1000;
            let expected_prev = if i == 0 { b.prev } else { blocks[i - 1].hash };
            let header_hash_started = Instant::now();
            let computed_hash = block.header.hash();
            timing.header_hash_us = timing.header_hash_us.saturating_add(header_hash_started.elapsed().as_micros() as u64);
            if computed_hash != b.hash || block.header.prev != expected_prev {
                bail!("block commit does not match its supplied hash/previous hash");
            }

            if !b.parsed_txs.is_empty() && b.parsed_txs.len() != block.txs.len() {
                bail!("parsed transaction count does not match raw block at height {}", b.height);
            }
            let connector_started = Instant::now();
            let mut connector = BlockConnector::new(b.height, b.height > assume_valid_height);
            timing.connector_new_us = timing.connector_new_us.saturating_add(connector_started.elapsed().as_micros() as u64);
            let mut connect_timing = chainstate::ConnectTiming::default();
            let mut block_slowest_script_input_tx_index: u64 = 0;
            for (tx_index, rawtx) in block.txs.iter().enumerate() {
                let tx_started = Instant::now();
                let tx_parse_before = timing.tx_parse_us;
                let txid_before = timing.txid_us;
                let tx_connect_before = timing.tx_connect_us;
                let sapling_before = timing.sapling_validate_us;
                let tx_parse_started = Instant::now();
                // Reuse the parsed transaction handed over by stateless
                // validation. Legacy callers without parsed data still parse
                // here, but the normal Android/node pipeline no longer clones
                // every ParsedTransaction during ordered commit.
                let parsed_owned = if b.parsed_txs.is_empty() {
                    let mut c = Cursor::new(rawtx.as_slice());
                    Some(ycash_chain::parse_transaction(&mut c)?)
                } else {
                    None
                };
                let parsed = parsed_owned.as_ref().unwrap_or_else(|| &b.parsed_txs[tx_index]);
                timing.tx_parse_us = timing.tx_parse_us.saturating_add(tx_parse_started.elapsed().as_micros() as u64);
                let txid_started = Instant::now();
                let txid = ycash_chain::txid(rawtx);
                timing.txid_us = timing.txid_us.saturating_add(txid_started.elapsed().as_micros() as u64);

                // Build transaction-wide signature-hash data exactly once; the
                // parallel script workers share this immutable structure.
                let precomputed_generated = if b.precomputed_txs.is_empty() && parsed.overwintered {
                    Some(ycash_script::PrecomputedTxData::new(parsed))
                } else {
                    None
                };
                let precomputed = if !b.precomputed_txs.is_empty() {
                    if b.precomputed_txs.len() != block.txs.len() {
                        bail!("precomputed transaction count does not match raw block at height {}", b.height);
                    }
                    if parsed.overwintered { Some(&b.precomputed_txs[tx_index]) } else { None }
                } else {
                    precomputed_generated.as_ref()
                };
                // Transparent inputs/scripts/fees and Sprout requirements, then
                // connect the transaction's coins and Sprout effects. State
                // mutation remains strictly ordered even when script checks run in parallel.
                let script_slowest_input_before = connect_timing.script_slowest_input_us;
                connector.connect_tx(&read_db, &mut coins, &mut sprout, parsed, &txid, precomputed, &mut connect_timing)?;
                if connect_timing.script_slowest_input_us > script_slowest_input_before {
                    block_slowest_script_input_tx_index = tx_index as u64;
                }

                let anchor_lookup_ms = Cell::new(0u64);
                let nullifier_lookup_ms = Cell::new(0u64);
                let anchor_queries = Cell::new(0u64);
                let nullifier_queries = Cell::new(0u64);
                let anchor_exists = |a: &[u8; 32]| -> bool {
                    if valid_batch_roots.contains(a) {
                        return true;
                    }
                    anchor_queries.set(anchor_queries.get().saturating_add(1));
                    let started = Instant::now();
                    let result = read_db.prefix(CF_SAPLING_ROOT_INDEX, a).map(|rows| rows.into_iter().any(|(k,_)| k.len()==40 && u64::from_be_bytes(k[32..40].try_into().unwrap()) < first_height)).unwrap_or(false);
                    anchor_lookup_ms.set(anchor_lookup_ms.get().saturating_add(started.elapsed().as_micros() as u64));
                    result
                };
                let nullifier_exists = |n: &[u8; 32]| -> bool {
                    if batch_nullifiers.contains(n) {
                        return true;
                    }
                    nullifier_queries.set(nullifier_queries.get().saturating_add(1));
                    let started = Instant::now();
                    let result = match read_db.get(CF_NULLIFIERS,n)? { Some(bh)=>match read_db.get(CF_BLOCKS,bh)? { Some(v)=>rocks_backend::decode_block(&v).map(|(h,_,_,_)| h < first_height).unwrap_or(false), None=>false }, None=>false };
                    nullifier_lookup_ms.set(nullifier_lookup_ms.get().saturating_add(started.elapsed().as_micros() as u64));
                    result
                };
                let tree_started = Instant::now();
                validate_sapling_transaction_state_opts(
                    &parsed,
                    b.height,
                    &mut working,
                    anchor_exists,
                    nullifier_exists,
                    !b.proofs_verified,
                )
                .map_err(|e| anyhow::anyhow!("sapling consensus failure at height {}: {e:?}", b.height))?;
                let sapling_elapsed_us = tree_started.elapsed().as_micros() as u64;
                let sapling_elapsed = sapling_elapsed_us / 1000;
                let anchor_us = anchor_lookup_ms.get();
                let nullifier_us = nullifier_lookup_ms.get();
                let anchor_ms = anchor_us / 1000;
                let nullifier_ms = nullifier_us / 1000;
                timing.tree_ms = timing.tree_ms.saturating_add(sapling_elapsed);
                timing.sapling_validate_us = timing.sapling_validate_us.saturating_add(sapling_elapsed_us);
                timing.sapling_validate_ms = timing.sapling_validate_us / 1000;
                timing.sapling_anchor_lookup_us = timing.sapling_anchor_lookup_us.saturating_add(anchor_us);
                timing.sapling_nullifier_lookup_us = timing.sapling_nullifier_lookup_us.saturating_add(nullifier_us);
                timing.sapling_anchor_lookup_ms = timing.sapling_anchor_lookup_us / 1000;
                timing.sapling_nullifier_lookup_ms = timing.sapling_nullifier_lookup_us / 1000;
                timing.sapling_tree_update_us = timing.sapling_tree_update_us.saturating_add(sapling_elapsed_us.saturating_sub(anchor_us).saturating_sub(nullifier_us));
                timing.sapling_tree_update_ms = timing.sapling_tree_update_us / 1000;
                timing.sapling_anchor_queries = timing.sapling_anchor_queries.saturating_add(anchor_queries.get());
                timing.sapling_nullifier_queries = timing.sapling_nullifier_queries.saturating_add(nullifier_queries.get());

                for spend in &parsed.sapling_spends {
                    if !batch_nullifiers.insert(spend.nullifier) {
                        bail!("Sapling nullifier is duplicated within the commit batch");
                    }
                    pending_nullifiers.push((spend.nullifier, b.hash));
                }
                let tx_elapsed_us = tx_started.elapsed().as_micros() as u64;
                let tx_named_us = timing.tx_parse_us.saturating_sub(tx_parse_before)
                    .saturating_add(timing.txid_us.saturating_sub(txid_before))
                    .saturating_add(timing.tx_connect_us.saturating_sub(tx_connect_before))
                    .saturating_add(timing.sapling_validate_us.saturating_sub(sapling_before));
                let tx_other_us = tx_elapsed_us.saturating_sub(tx_named_us);
                if tx_elapsed_us > timing.slowest_tx_us {
                    timing.slowest_tx_us = tx_elapsed_us;
                    timing.slowest_tx_height = b.height;
                    timing.slowest_tx_index = tx_index as u64;
                    timing.slowest_tx_other_us = tx_other_us;
                }
            }
            let finalize_started = Instant::now();
            connector.finish()?;
            sprout.finish_block(b.hash, b.height)?;
            let finalize_us = finalize_started.elapsed().as_micros() as u64;
            timing.block_finalize_us = timing.block_finalize_us.saturating_add(finalize_us);
            timing.block_finalize_ms = timing.block_finalize_us / 1000;
            timing.tx_connect_us = timing.tx_connect_us.saturating_add(connect_timing.tx_total_us);
            timing.tx_connect_ms = timing.tx_connect_us / 1000;
            timing.bip30_us = timing.bip30_us.saturating_add(connect_timing.bip30_us);
            timing.bip30_ms = timing.bip30_us / 1000;
            timing.sigops_us = timing.sigops_us.saturating_add(connect_timing.sigops_us);
            timing.sigops_ms = timing.sigops_us / 1000;
            timing.utxo_lookup_us = timing.utxo_lookup_us.saturating_add(connect_timing.utxo_lookup_us);
            timing.utxo_lookup_ms = timing.utxo_lookup_us / 1000;
            timing.sprout_requirements_us = timing.sprout_requirements_us.saturating_add(connect_timing.sprout_requirements_us);
            timing.sprout_requirements_ms = timing.sprout_requirements_us / 1000;
            timing.value_checks_us = timing.value_checks_us.saturating_add(connect_timing.value_checks_us);
            timing.value_checks_ms = timing.value_checks_us / 1000;
            timing.script_us = timing.script_us.saturating_add(connect_timing.script_us);
            timing.script_ms = timing.script_us / 1000;
            timing.coin_state_update_us = timing.coin_state_update_us.saturating_add(connect_timing.coin_state_update_us);
            timing.coin_state_update_ms = timing.coin_state_update_us / 1000;
            timing.sprout_apply_us = timing.sprout_apply_us.saturating_add(connect_timing.sprout_apply_us);
            timing.sprout_apply_ms = timing.sprout_apply_us / 1000;
            let connector_named_us = connect_timing.sigops_us
                .saturating_add(connect_timing.bip30_us)
                .saturating_add(connect_timing.utxo_lookup_us)
                .saturating_add(connect_timing.sprout_requirements_us)
                .saturating_add(connect_timing.value_checks_us)
                .saturating_add(connect_timing.script_us)
                .saturating_add(connect_timing.coin_state_update_us)
                .saturating_add(connect_timing.sprout_apply_us);
            timing.connector_other_us = timing.connector_other_us.saturating_add(
                connect_timing.tx_total_us.saturating_sub(connector_named_us));
            timing.utxo_lookups = timing.utxo_lookups.saturating_add(connect_timing.utxo_lookups);
            timing.script_checks = timing.script_checks.saturating_add(connect_timing.script_checks);
            timing.script_parallel_workers = timing.script_parallel_workers.max(connect_timing.script_parallel_workers);
            timing.script_parallel_us = timing.script_parallel_us.saturating_add(connect_timing.script_parallel_us);
            timing.script_input_work_us = timing.script_input_work_us.saturating_add(connect_timing.script_input_work_us);
            timing.script_transaction_input_extraction_us = timing.script_transaction_input_extraction_us.saturating_add(connect_timing.script_transaction_input_extraction_us);
            timing.script_sig_construction_us = timing.script_sig_construction_us.saturating_add(connect_timing.script_sig_construction_us);
            timing.script_pubkey_retrieval_us = timing.script_pubkey_retrieval_us.saturating_add(connect_timing.script_pubkey_retrieval_us);
            timing.script_parsing_us = timing.script_parsing_us.saturating_add(connect_timing.script_parsing_us);
            timing.signature_hash_preparation_us = timing.signature_hash_preparation_us.saturating_add(connect_timing.signature_hash_preparation_us);
            timing.ecdsa_verification_us = timing.ecdsa_verification_us.saturating_add(connect_timing.ecdsa_verification_us);
            timing.script_interpreter_us = timing.script_interpreter_us.saturating_add(connect_timing.script_interpreter_us);
            timing.script_cache_lookup_us = timing.script_cache_lookup_us.saturating_add(connect_timing.script_cache_lookup_us);
            timing.script_synchronization_us = timing.script_synchronization_us.saturating_add(connect_timing.script_synchronization_us);
            timing.script_permit_wait_us = timing.script_permit_wait_us.saturating_add(connect_timing.script_permit_wait_us);
            timing.script_active_peak = timing.script_active_peak.max(connect_timing.script_active_peak);
            timing.script_scheduler_gap_us = timing.script_scheduler_gap_us.saturating_add(connect_timing.script_scheduler_gap_us);
            for i in 0..4 {
                timing.script_worker_wall_us[i] = timing.script_worker_wall_us[i].saturating_add(connect_timing.script_worker_wall_us[i]);
                timing.script_worker_input_work_us[i] = timing.script_worker_input_work_us[i].saturating_add(connect_timing.script_worker_input_work_us[i]);
                timing.script_worker_inputs[i] = timing.script_worker_inputs[i].saturating_add(connect_timing.script_worker_inputs[i]);
            }
            timing.script_spawn_us = timing.script_spawn_us.saturating_add(connect_timing.script_spawn_us);
            timing.script_join_us = timing.script_join_us.saturating_add(connect_timing.script_join_us);
            timing.script_pool_overhead_us = timing.script_pool_overhead_us.saturating_add(connect_timing.script_pool_overhead_us);
            timing.script_pool_threads = timing.script_pool_threads.max(connect_timing.script_pool_threads);
            timing.script_worker_max_us = timing.script_worker_max_us.max(connect_timing.script_worker_max_us);
            if timing.script_worker_min_us == 0 { timing.script_worker_min_us = connect_timing.script_worker_min_us; } else if connect_timing.script_worker_min_us != 0 { timing.script_worker_min_us = timing.script_worker_min_us.min(connect_timing.script_worker_min_us); }
            if connect_timing.script_slowest_input_us > timing.script_slowest_input_us {
                timing.script_slowest_input_us = connect_timing.script_slowest_input_us;
                timing.script_slowest_input_index = connect_timing.script_slowest_input_index;
                timing.script_slowest_input_tx_height = b.height;
                timing.script_slowest_input_tx_index = block_slowest_script_input_tx_index;
            }
            timing.bip30_checks = timing.bip30_checks.saturating_add(connect_timing.bip30_checks);
            let root_started = Instant::now();
            let (root, root_timing) = working.root_with_timing();
            let measured_root_us = root_started.elapsed().as_micros() as u64;
            timing.block_root_us = timing.block_root_us.saturating_add(measured_root_us);
            if root_timing.root_cache_hit {
                timing.sapling_root_cache_hits = timing.sapling_root_cache_hits.saturating_add(1);
            }
            timing.sapling_empty_hashes_avoided = timing.sapling_empty_hashes_avoided.saturating_add(root_timing.empty_hashes_avoided);
            for level in 0..32 {
                timing.block_root_level_us[level] =
                    timing.block_root_level_us[level].saturating_add(root_timing.level_us[level]);
                timing.block_root_level_hashes[level] =
                    timing.block_root_level_hashes[level].saturating_add(root_timing.level_hashes[level]);
                timing.block_root_empty_us[level] =
                    timing.block_root_empty_us[level].saturating_add(root_timing.empty_us[level]);
                timing.block_root_empty_hashes[level] =
                    timing.block_root_empty_hashes[level].saturating_add(root_timing.empty_hashes[level]);
                timing.block_root_hash_us[level] =
                    timing.block_root_hash_us[level].saturating_add(root_timing.root_hash_us[level]);
                timing.block_root_hashes[level] =
                    timing.block_root_hashes[level].saturating_add(root_timing.root_hashes[level]);
            }
            valid_batch_roots.insert(root);
            let encode_started = Instant::now();
            let encoded_frontier = working.encode();
            timing.tree_encode_us = timing.tree_encode_us.saturating_add(encode_started.elapsed().as_micros() as u64);
block_trees.push((root, encoded_frontier));
        }
        timing.utxo_cache_hits = coins.cache_hits;
        timing.utxo_cache_misses = coins.cache_misses;

        let normal_extension = if first.height == 0 || (first.height == 1 && first.prev == ycash_chain::genesis_hash_internal()) { true } else { read_db.get(CF_BLOCKS_HEIGHT,&rocks_backend::u64_key(first.height-1))?.map(|v|v.as_slice()==first.prev).unwrap_or(false) };

        // The RocksDB snapshot is immutable and gives the entire preparation phase
        // a single consistent view without holding a write lock. No read commit is needed.
        timing.state_validation_us = validation_started.elapsed().as_micros() as u64;
        timing.state_validation_ms = timing.state_validation_us / 1000;
        let named_state_us = timing.read_transaction_us
            .saturating_add(timing.parent_state_load_us)
            .saturating_add(timing.block_parse_us)
            .saturating_add(timing.tx_parse_us)
            .saturating_add(timing.txid_us)
            .saturating_add(timing.tx_connect_us)
            .saturating_add(timing.sapling_validate_us)
            .saturating_add(timing.block_finalize_us)
            .saturating_add(timing.tree_encode_us)
            .saturating_add(timing.header_hash_us)
            .saturating_add(timing.connector_new_us)
            .saturating_add(timing.block_root_us)
            .saturating_add(timing.read_transaction_commit_us);
        timing.block_loop_other_us = timing.state_validation_us.saturating_sub(named_state_us);
        let top_level_accounted_us = timing.read_transaction_us
            .saturating_add(timing.parent_state_load_us)
            .saturating_add(timing.block_parse_us)
            .saturating_add(timing.tx_parse_us)
            .saturating_add(timing.txid_us)
            .saturating_add(timing.tx_connect_us)
            .saturating_add(timing.sapling_validate_us)
            .saturating_add(timing.block_finalize_us)
            .saturating_add(timing.tree_encode_us)
            .saturating_add(timing.read_transaction_commit_us);
        timing.state_unattributed_us = timing.state_validation_us.saturating_sub(top_level_accounted_us);

        // The mutation plan is now complete.  Clone the touched UTXO/Sprout
        // maps into owned prepared changes so the DB mutex and read transaction
        // can be released before the canonical write transaction begins.
        let utxo_changes = coins.prepare_changes();
        let sprout_changes = sprout.prepare_changes();
        let prepare_us = total_started.elapsed().as_micros() as u64;
        drop(read_db);

        Ok(PreparedCommit {
            blocks,
            block_trees,
            pending_nullifiers,
            utxo_changes,
            sprout_changes,
            working_sapling: working,
            sprout_tree: sprout.tree.clone(),
            chain_sprout_value: sprout.chain_sprout_value,
            chain_sapling_value: sprout.chain_sapling_value,
            cache_parent_hit,
            normal_extension,
            expected_tip,
            prepare_us,
            timing,
        })
    }

    /// Apply the already prepared canonical mutation plan.
    ///
    /// This is the only phase that opens a RocksDB WRITE transaction.  No block
    /// parsing, UTXO discovery, script verification, Sapling validation, or
    /// Sprout state calculation occurs here.  Consensus ordering is preserved
    /// by the preparation barrier and by re-checking the prepared parent tip
    /// inside the write transaction before any mutation is made.
    pub fn apply_prepared_commit(&self, prepared: PreparedCommit) -> Result<()> {
        if prepared.blocks.is_empty() { return Ok(()); }
        let first=&prepared.blocks[0]; let last=&prepared.blocks[prepared.blocks.len()-1];
        let mut timing=prepared.timing; let apply_started=Instant::now();
        let read=self.read();
        let current_tip=self.current_tip_from(&read)?.map(|(h,n)|(<[u8;32]>::try_from(h.as_slice()).unwrap(),n));
        if current_tip!=prepared.expected_tip { bail!("prepared commit canonical tip changed while waiting for RocksDB apply at height {}",first.height); }
        let current_parent_ok=if first.height==0 || (first.height==1 && first.prev==ycash_chain::genesis_hash_internal()) {true} else {read.get(CF_BLOCKS_HEIGHT,&rocks_backend::u64_key(first.height-1))?.map(|v|v.as_slice()==first.prev).unwrap_or(false)};
        if current_parent_ok!=prepared.normal_extension { bail!("prepared commit parent changed while waiting for canonical apply at height {}",first.height); }
        if prepared.normal_extension {
            if let Some(v)=read.get(CF_BLOCKS_HEIGHT,&rocks_backend::u64_key(first.height))? { if v.as_slice()!=first.hash { bail!("prepared commit conflicts with current canonical block at height {}",first.height); } }
        }
        drop(read);

        let mut batch=WriteBatch::default();
        let mut w=WriteCtx{db:&self.db,batch:&mut batch};
        let write_started=Instant::now();

        if !prepared.normal_extension {
            let snapshot=self.read();
            let tip_height=current_tip.map(|x|x.1).unwrap_or(0);
            for h in first.height..=tip_height {
                let hk=rocks_backend::u64_key(h);
                let Some(bh)=snapshot.get(CF_BLOCKS_HEIGHT,&hk)? else { continue };
                w.delete(CF_BLOCKS_HEIGHT,&hk)?;
                if let Some(bv)=snapshot.get(CF_BLOCKS,&bh)? {
                    let (_height,_prev,_work,_raw)=rocks_backend::decode_block(&bv)?;
                    w.delete(CF_BLOCKS,&bh)?;
                }
                for (k,_) in snapshot.prefix(CF_TXS_BLOCK,&bh)? {
                    if k.len()==64 { w.delete(CF_TXS_BLOCK,&k)?; w.delete(CF_TXS,&k[32..])?; }
                }
                for (k,_) in snapshot.prefix(CF_NULLIFIERS_BLOCK,&bh)? {
                    if k.len()==64 { w.delete(CF_NULLIFIERS_BLOCK,&k)?; w.delete(CF_NULLIFIERS,&k[32..])?; }
                }
                if let Some(rv)=snapshot.get(CF_SAPLING_ROOTS,&bh)? {
                    let (rh,root,_frontier)=decode_root_record(&rv)?;
                    w.delete(CF_SAPLING_ROOTS,&bh)?; w.delete(CF_SAPLING_ROOT_INDEX,&rocks_backend::root_height_key(&root,rh))?;
                }
                if let Some(sv)=snapshot.get(CF_BLOCK_STATE,&bh)? {
                    let (sh,root,_a,_b,_f)=rocks_backend::decode_block_state(&sv)?;
                    w.delete(CF_BLOCK_STATE,&bh)?; w.delete(CF_BLOCK_STATE_HEIGHT,&rocks_backend::u64_key(sh))?;
                    w.delete(CF_SPROUT_ROOT_INDEX,&rocks_backend::root_height_key(&root,sh))?;
                }
            }
            // Remove outputs created by the abandoned branch and restore outputs
            // whose spends belonged to that branch. Both are indexed by height,
            // so reorg cleanup never scans the full UTXO keyspace.
            for h in first.height..=tip_height {
                let hp=rocks_backend::u64_key(h);
                for (k,_) in snapshot.prefix(CF_UTXO_HEIGHT,&hp)? {
                    if k.len()==44 { let op=&k[8..]; w.delete(CF_UTXO_HEIGHT,&k)?; w.delete(CF_UTXOS,op)?; }
                }
                for (k,_) in snapshot.prefix(CF_UTXO_SPENT,&hp)? {
                    if k.len()==44 { let op=&k[8..]; if let Some(v)=snapshot.get(CF_UTXOS,op)? { let (value,script,created,coinbase,_)=rocks_backend::decode_utxo(&v)?; w.put(CF_UTXOS,op,&rocks_backend::encode_utxo(value,&script,created,coinbase,None))?; } w.delete(CF_UTXO_SPENT,&k)?; }
                }
                for (k,_) in snapshot.prefix(CF_SPROUT_NULLIFIERS_HEIGHT,&hp)? { w.delete(CF_SPROUT_NULLIFIERS_HEIGHT,&k)?; if k.len()==40 { w.delete(CF_SPROUT_NULLIFIERS,&k[8..])?; } }
                w.delete(CF_BLOCK_STATE_HEIGHT,&hp)?;
            }
            drop(snapshot);
        }

        for (b,(root,frontier)) in prepared.blocks.iter().zip(prepared.block_trees.iter()) {
            w.put(CF_BLOCKS,&b.hash,&rocks_backend::encode_block(b.height,&b.prev,&b.work,&b.raw))?;
            w.put(CF_BLOCKS_HEIGHT,&rocks_backend::u64_key(b.height),&b.hash)?;
            let rv=encode_root_record(b.height,root,frontier);
            w.put(CF_SAPLING_ROOTS,&b.hash,&rv)?;
            w.put(CF_SAPLING_ROOT_INDEX,&rocks_backend::root_height_key(root,b.height),&b.hash)?;
            for (txid,txraw) in &b.txs {
                w.put(CF_TXS,txid,&rocks_backend::encode_tx(&b.hash,txraw))?;
                let mut tk=Vec::with_capacity(64);tk.extend_from_slice(&b.hash);tk.extend_from_slice(txid);w.put(CF_TXS_BLOCK,&tk,&[])?;
            }
        }
        for (nf,bh) in &prepared.pending_nullifiers {
            w.put(CF_NULLIFIERS,nf,bh)?;
            let mut k=Vec::with_capacity(64);k.extend_from_slice(bh);k.extend_from_slice(nf);w.put(CF_NULLIFIERS_BLOCK,&k,&[])?;
        }
        prepared.utxo_changes.apply(&mut w)?;
        prepared.sprout_changes.apply(&mut w)?;
        let final_frontier=prepared.working_sapling.encode();
        w.put(CF_META,b"sapling_frontier",&final_frontier)?;
        w.put(CF_META,b"tip_hash",&last.hash)?;
        w.put(CF_META,b"tip_height",&last.height.to_be_bytes())?;
        w.put(CF_META,b"schema_version",&1u64.to_be_bytes())?;

        // Retain only the recent reorg window for spent outputs. This uses the
        // spent-height index rather than a table-wide delete.
        let cutoff=last.height.saturating_sub(SPENT_OUTPUT_RETENTION);
        if cutoff>0 {
            let snapshot=self.read();
            for h in 0..cutoff {
                let hp=rocks_backend::u64_key(h);
                for (k,_) in snapshot.prefix(CF_UTXO_SPENT,&hp)? { if k.len()==44 { w.delete(CF_UTXO_SPENT,&k)?; w.delete(CF_UTXOS,&k[8..])?; } }
            }
            drop(snapshot);
        }
        timing.db_write_us=write_started.elapsed().as_micros() as u64; timing.db_write_ms=timing.db_write_us/1000;
        timing.rocksdb_write_us=timing.db_write_us;
        timing.rocksdb_write_ms=timing.db_write_ms;
        timing.rocksdb_batch_ms=timing.db_write_ms;
        timing.rocksdb_index_ms=0;
        let mut wo=rocksdb::WriteOptions::default();
        wo.set_sync(std::env::var("YORTAL_ROCKSDB_SYNC").map(|v|v=="1").unwrap_or(false));
        self.db.write_opt(batch,&wo)?;
        timing.total_us=prepared.prepare_us.saturating_add(apply_started.elapsed().as_micros() as u64); timing.total_ms=timing.total_us/1000;

        let mut cache_guard=self.consensus_cache.lock().unwrap();
        let mut new_cache=ConsensusCache::new(last.hash,last.height,prepared.working_sapling.clone(),prepared.sprout_tree.clone(),prepared.chain_sprout_value,prepared.chain_sapling_value);
        if prepared.cache_parent_hit {
            if let Some(old)=cache_guard.as_mut() { let cache=Arc::make_mut(&mut old.utxos); prepared.utxo_changes.update_cache(cache); new_cache.utxos=Arc::clone(&old.utxos); }
        } else { let mut cache=UtxoCache::empty(); prepared.utxo_changes.update_cache(&mut cache); new_cache.utxos=Arc::new(cache); }
        *cache_guard=Some(new_cache); drop(cache_guard);
        *self.last_commit_timing.lock().unwrap()=timing;
        *self.sapling.lock().unwrap()=prepared.working_sapling;
        pipeline_commit_log("COMMIT",first.height,last.height,&timing);
        Ok(())
    }

    pub fn commit_blocks_batch(&self,blocks:&[BlockCommit])->Result<()> { let prepared=self.prepare_commit_batch(blocks)?; self.apply_prepared_commit(prepared) }

    pub fn last_commit_timing(&self) -> CommitTiming {
        self.last_commit_timing.lock().unwrap().clone()
    }

    pub fn transaction_count(&self)->Result<u64> {
        let r=self.read(); Ok(r.all(CF_TXS)?.len() as u64)
    }
    pub fn set_tip(&self,tip:&Tip)->Result<()> {
        if tip.hash.len()!=32 { bail!("invalid tip hash"); }
        let mut b=WriteBatch::default(); let mut w=WriteCtx{db:&self.db,batch:&mut b};
        w.put(CF_BLOCKS_HEIGHT,&rocks_backend::u64_key(tip.height),&tip.hash)?;
        w.put(CF_META,b"tip_hash",&tip.hash)?; w.put(CF_META,b"tip_height",&tip.height.to_be_bytes())?; self.db.write(b)?; Ok(())
    }
    pub fn tip_height(&self)->Result<Option<u64>> { Ok(self.meta(b"tip_height")?.map(|v|u64::from_be_bytes(v.try_into().unwrap()))) }
    pub fn has_block(&self,hash:&[u8])->Result<bool>{Ok(self.read().exists(CF_BLOCKS,hash)?)}
    pub fn put_header(&self,height:u64,hash:&[u8],prev:&[u8],time:u32,bits:u32,work:&[u8],raw:&[u8])->Result<()> { let r=HeaderRow{height,hash:hash.try_into().map_err(|_|anyhow::anyhow!("invalid hash"))?,prev:prev.try_into().map_err(|_|anyhow::anyhow!("invalid prev"))?,time,bits,work:work.try_into().map_err(|_|anyhow::anyhow!("invalid work"))?,raw:raw.to_vec()}; self.put_headers_batch(&[r]) }
    pub fn put_headers_batch(&self,rows:&[HeaderRow])->Result<()> {
        if rows.is_empty(){return Ok(())}; let mut b=WriteBatch::default(); let mut w=WriteCtx{db:&self.db,batch:&mut b};
        for r in rows { w.put(CF_HEADERS,&r.hash,&rocks_backend::encode_header(r.height,&r.prev,r.time,r.bits,&r.work,&r.raw))?; w.put(CF_HEADERS_HEIGHT,&rocks_backend::u64_key(r.height),&r.hash)?; }
        self.db.write(b)?; Ok(())
    }
    pub fn header_rows_range(&self,start:u64,end:u64)->Result<Vec<(u64,[u8;32],[u8;32],Vec<u8>)>> { let r=self.read(); let mut out=Vec::new(); for h in start..=end { if let Some(hash)=r.get(CF_HEADERS_HEIGHT,&rocks_backend::u64_key(h))? { if let Some(v)=r.get(CF_HEADERS,&hash)? { let (hh,_prev,_t,_b,work,raw)=rocks_backend::decode_header(&v)?; if let Ok(a)=hash.as_slice().try_into(){out.push((hh,a,work,raw));} } } } Ok(out) }
    pub fn header_by_height(&self,height:u64)->Result<Option<Vec<u8>>>{let r=self.read();Ok(match r.get(CF_HEADERS_HEIGHT,&rocks_backend::u64_key(height))?{Some(h)=>r.get(CF_HEADERS,&h) .ok().flatten().and_then(|v|rocks_backend::decode_header(&v).ok().map(|x|x.5)),None=>None})}
    pub fn tip_hash(&self)->Result<Option<Vec<u8>>>{self.meta(b"tip_hash")}
    pub fn header_height_by_hash(&self,hash:&[u8])->Result<Option<u64>>{Ok(self.read().get(CF_HEADERS,hash)?.map(|v|rocks_backend::decode_header(&v).unwrap().0))}
    pub fn header_height(&self)->Result<Option<u64>>{Ok(self.read().iterator_height_max(CF_HEADERS_HEIGHT)?)}
    pub fn header_hash_by_height(&self,height:u64)->Result<Option<Vec<u8>>>{self.read().get(CF_HEADERS_HEIGHT,&rocks_backend::u64_key(height))}
    pub fn header_work_by_height(&self,height:u64)->Result<Option<Vec<u8>>>{let r=self.read();Ok(r.get(CF_HEADERS_HEIGHT,&rocks_backend::u64_key(height))?.and_then(|h|r.get(CF_HEADERS,&h).ok().flatten()).and_then(|v|rocks_backend::decode_header(&v).ok().map(|x|x.4.to_vec())))}
    pub fn header_hashes_range(&self,start:u64,end:u64)->Result<HashMap<u64,[u8;32]>>{let r=self.read();let mut out=HashMap::new();for h in start..=end{if let Some(v)=r.get(CF_HEADERS_HEIGHT,&rocks_backend::u64_key(h))?{if let Ok(a)=v.as_slice().try_into(){out.insert(h,a);}}}Ok(out)}
    pub fn header_works_range(&self,start:u64,end:u64)->Result<HashMap<u64,[u8;32]>>{let r=self.read();let mut out=HashMap::new();for h in start..=end{if let Some(hash)=r.get(CF_HEADERS_HEIGHT,&rocks_backend::u64_key(h))?{if let Some(v)=r.get(CF_HEADERS,&hash)?{if let Ok(a)=rocks_backend::decode_header(&v)?.4.try_into(){out.insert(h,a);}}}}Ok(out)}
    pub fn header_times_range(&self,start:u64,end:u64)->Result<Vec<(u64,u32)>>{let r=self.read();let mut out=Vec::new();for h in start..end{if let Some(hash)=r.get(CF_HEADERS_HEIGHT,&rocks_backend::u64_key(h))?{if let Some(v)=r.get(CF_HEADERS,&hash)?{let x=rocks_backend::decode_header(&v)?;out.push((h,x.2));}}}Ok(out)}
    pub fn header_time(&self,height:u64)->Result<Option<u32>>{let r=self.read();Ok(r.get(CF_HEADERS_HEIGHT,&rocks_backend::u64_key(height))?.and_then(|h|r.get(CF_HEADERS,&h).ok().flatten()).and_then(|v|rocks_backend::decode_header(&v).ok().map(|x|x.2)))}
    pub fn locator_hashes(&self)->Result<Vec<[u8;32]>>{let tip=self.header_height()?.unwrap_or(0);let mut heights=Vec::new();let mut h=tip;while h>0&&heights.len()<10{heights.push(h);h=h.saturating_sub(1);}let mut step=2u64;while h>0&&heights.len()<32{heights.push(h);h=h.saturating_sub(step);step=step.saturating_mul(2);}heights.push(0);heights.sort_unstable();heights.dedup();heights.reverse();let mut out=Vec::new();for h in heights{if let Some(v)=self.header_hash_by_height(h)?{if let Ok(a)=v.try_into(){out.push(a)}}else if h==0{out.push(ycash_chain::genesis_hash_internal())}}Ok(out)}
    pub fn export_snapshot(&self,dest:&Path)->Result<()> {
        use std::io::Write;
        let r=self.read(); let mut f=std::fs::File::create(dest)?;
        f.write_all(b"YORTAL-ROCKS-SNAPSHOT-v1\0")?;
        f.write_all(&(CF_NAMES.len() as u32).to_be_bytes())?;
        for name in CF_NAMES {
            let name_b=name.as_bytes(); f.write_all(&(name_b.len() as u16).to_be_bytes())?; f.write_all(name_b)?;
            let rows=r.all(name)?; f.write_all(&(rows.len() as u64).to_be_bytes())?;
            for (k,v) in rows { f.write_all(&(k.len() as u32).to_be_bytes())?; f.write_all(&(v.len() as u64).to_be_bytes())?; f.write_all(&k)?; f.write_all(&v)?; }
        }
        Ok(())
    }


fn encode_root_record(height:u64,root:&[u8;32],frontier:&[u8])->Vec<u8>{ let mut o=Vec::new(); rocks_backend::put_u64(height,&mut o); o.extend_from_slice(root); rocks_backend::put_bytes(frontier,&mut o); o }
fn decode_root_record(v:&[u8])->Result<(u64,[u8;32],Vec<u8>)>{ let mut d=rocks_backend::Decoder::new(v); Ok((d.u64()?,d.fixed()?,d.bytes()?)) }

fn pipeline_commit_log(stage: &str, first: u64, last: u64, t: &CommitTiming) {
    eprintln!(
        "[DBPIPE] stage={} range={}..{} total_ms={} begin_ms={} state_validate_ms={} state_validate_us={} state_unattributed_us={} header_hash_us={} connector_new_us={} connector_other_us={} block_root_us={} block_loop_other_us={} slowest_block_height={} slowest_block_us={} slowest_block_other_us={} slowest_tx_height={} slowest_tx_index={} slowest_tx_us={} slowest_tx_other_us={} parent_state_ms={} parent_state_us={} parent_frontier_us={} sprout_state_load_us={} block_parse_ms={} block_parse_us={} txid_us={} tx_parse_us={} tx_connect_ms={} tx_connect_us={} sigops_ms={} sigops_us={} bip30_ms={} bip30_us={} utxo_lookup_ms={} sprout_req_ms={} value_ms={} script_ms={} coin_state_ms={} sprout_apply_ms={} sapling_validate_ms={} sapling_anchor_ms={} sapling_nullifier_ms={} sapling_tree_ms={} block_finalize_ms={} tree_ms={} rollback_ms={} db_write_ms={} rocksdb_batch_ms={} rocksdb_index_ms={} rocksdb_write_ms={} blocks={} txs={} utxo_lookups={} bip30_checks={} script_checks={} script_parallel_workers={} script_parallel_us={} script_spawn_us={} script_join_us={} script_pool_overhead_us={} script_permit_wait_us={} script_scheduler_gap_us={} script_active_peak={} script_pool_threads={} script_worker_max_us={} script_worker_min_us={} script_worker_wall_us={} script_worker_input_work_us={} script_worker_inputs={} utxo_cache_hits={} utxo_cache_misses={} parent_state_cache_hit={} sprout_state_cache_hit={} sapling_anchor_queries={} sapling_nullifier_queries={} sapling_empty_hashes_avoided={} sapling_root_cache_hits={} root_levels_us={} root_level_hashes={} root_empty_us={} root_empty_hashes={} root_hash_us={} root_hashes={}",
        stage, first, last, t.total_ms, t.begin_ms, t.state_validation_ms, t.state_validation_us, t.state_unattributed_us, t.header_hash_us, t.connector_new_us, t.connector_other_us, t.block_root_us, t.block_loop_other_us, t.slowest_block_height, t.slowest_block_us, t.slowest_block_other_us, t.slowest_tx_height, t.slowest_tx_index, t.slowest_tx_us, t.slowest_tx_other_us, t.parent_state_load_ms, t.parent_state_load_us, t.parent_frontier_load_us, t.sprout_state_load_us, t.block_parse_ms, t.block_parse_us, t.txid_us, t.tx_parse_us, t.tx_connect_ms, t.tx_connect_us, t.sigops_ms, t.sigops_us, t.bip30_ms, t.bip30_us, t.utxo_lookup_ms, t.sprout_requirements_ms, t.value_checks_ms, t.script_ms, t.coin_state_update_ms, t.sprout_apply_ms, t.sapling_validate_ms, t.sapling_anchor_lookup_ms, t.sapling_nullifier_lookup_ms, t.sapling_tree_update_ms, t.block_finalize_ms, t.tree_ms, t.rollback_ms, t.db_write_ms, t.rocksdb_batch_ms, t.rocksdb_index_ms, t.rocksdb_write_ms, t.blocks, t.txs, t.utxo_lookups, t.bip30_checks, t.script_checks, t.script_parallel_workers, t.script_parallel_us, t.script_spawn_us, t.script_join_us, t.script_pool_overhead_us, t.script_permit_wait_us, t.script_scheduler_gap_us, t.script_active_peak, t.script_pool_threads, t.script_worker_max_us, t.script_worker_min_us, telemetry_array_json_32(&t.script_worker_wall_us), telemetry_array_json_32(&t.script_worker_input_work_us), telemetry_array_json_32(&t.script_worker_inputs), t.utxo_cache_hits, t.utxo_cache_misses, t.parent_state_cache_hit, t.sprout_state_cache_hit, t.sapling_anchor_queries, t.sapling_nullifier_queries, t.sapling_empty_hashes_avoided, t.sapling_root_cache_hits, telemetry_array_json(&t.block_root_level_us), telemetry_array_json(&t.block_root_level_hashes), telemetry_array_json(&t.block_root_empty_us), telemetry_array_json(&t.block_root_empty_hashes), telemetry_array_json(&t.block_root_hash_us), telemetry_array_json(&t.block_root_hashes)
    );
}

fn validate_batch_shape(blocks: &[BlockCommit]) -> Result<()> {
    for i in 1..blocks.len() {
        if blocks[i].height != blocks[i - 1].height + 1 || blocks[i].prev != blocks[i - 1].hash {
            bail!("block batch is not contiguous");
        }
    }
    Ok(())
}

fn load_parent_frontier(tx:&ReadDb<'_>,height:u64,prev:&[u8;32])->Result<SaplingConsensusState>{
    if height==1 && *prev==ycash_chain::genesis_hash_internal(){return Ok(SaplingConsensusState::new());}
    if height==0{return Ok(SaplingConsensusState::new());}
    let v=tx.get(CF_SAPLING_ROOTS,prev)?.ok_or_else(||anyhow::anyhow!("missing canonical Sapling state for parent"))?;
    let (_,_,frontier)=decode_root_record(&v)?;
    SaplingConsensusState::decode(&frontier).map_err(|e|anyhow::anyhow!("invalid canonical Sapling state for parent: {e:?}"))
}

#[cfg(test)]
mod tests {
    use super::*;
    use rocksdb::{Options,DB};
    use crate::rocks_backend::CF_NAMES;
    use std::time::{SystemTime,UNIX_EPOCH};
    fn temp_path()->std::path::PathBuf{std::env::temp_dir().join(format!("yortal-rocks-test-{}-{}",std::process::id(),SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos()))}
    #[test] fn fresh_database_creates_all_column_families(){let p=temp_path();let s=State::open(&p).unwrap();for n in CF_NAMES{assert!(s.db.cf_handle(n).is_some(),"missing CF {n}");}drop(s);let _=DB::destroy(&Options::default(),&p);}
}
