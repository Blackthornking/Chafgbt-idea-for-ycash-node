# YORTAL v0.31 — SQLite → RocksDB state backend

This build replaces the consensus/state SQLite backend with RocksDB and keeps the consensus ordering boundary intact.

## Architecture

```text
P2P fetch
   ↓
stateless validation / script workers
   ↓
RocksDB snapshot (immutable preparation view)
   ↓
UTXO RAM cache → RocksDB UTXO CF on miss → cache promotion
   ↓
BIP30 prefix-index lookup
   ↓
prepared consensus result
   ↓
ONE ordered canonical committer
   ↓
RocksDB WriteBatch + WAL
   ↓
publish RAM consensus cache
```

## Column families

- `blocks`, `blocks_height`
- `headers`, `headers_height`
- `txs`, `txs_block`
- `utxos`, `utxo_height`, `utxo_spent`
- `nullifiers`, `nullifiers_block`
- `sapling_roots`, `sapling_root_index`
- `sprout_nullifiers`, `sprout_nullifiers_height`
- `block_state`, `block_state_height`, `sprout_root_index`
- `meta`

Hot prefix families have fixed-prefix bloom filters. UTXO creation/spend indexes make reorg and retention operations range-local instead of table-wide.

## Consensus safety

- State preparation runs against one RocksDB snapshot.
- The canonical committer remains single and ordered.
- The apply phase rechecks the prepared canonical tip and parent.
- All canonical mutations for a commit are submitted as one RocksDB `WriteBatch`.
- RAM consensus state is published only after the RocksDB write succeeds.
- No SQLite database or SQLite transaction is used by the node.

## Android

The node data path is now `ycash-node.rocksdb` (a directory). Existing legacy SQLite files are not imported. If a legacy SQLite file is explicitly passed to `State::open`, it is renamed to `*.sqlite.legacy` before the new RocksDB directory is created.

`YORTAL_ROCKSDB_SYNC=1` can be used for synchronous WAL writes. The default is asynchronous WAL write submission to reduce Android commit stalls; RocksDB WAL remains enabled.

## Verification

Run:

```bash
tools/verify-rocksdb-migration.sh
```

The Android build also needs the normal NDK C/C++ toolchain because the Rust RocksDB binding builds the RocksDB native library.
