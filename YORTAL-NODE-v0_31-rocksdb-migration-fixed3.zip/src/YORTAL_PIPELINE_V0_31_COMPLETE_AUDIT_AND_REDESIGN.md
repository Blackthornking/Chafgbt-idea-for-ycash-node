# YORTAL v0.31 — Complete Pipeline Audit and Redesign

## Scope

Audited both YORTAL sync front ends in `crates/ycash-android-node` and
`crates/node`, plus the shared `crates/state/src/pipeline` scheduler, against
the supplied Zebra 6.3.0 source tree.

The redesign keeps all existing consensus primitives and canonical height
ordering. It changes scheduling, buffering, worker lifetime, and commit
coordination only.

## 1. Findings in the old YORTAL system

### A. There were actually two different pipeline implementations

**Android:** `crates/ycash-android-node/src/pipeline_sync.rs`

- Persistent verifier threads + a permanent commit thread.
- Multi-peer range leasing.
- A second adaptive controller/sampler.
- A separate script-worker budget.
- Head-of-line hedging.

**Node:** `crates/node/src/sync.rs`

- A permanent commit worker existed.
- But the network/validation worker pool was created and joined for every
  header response/window.
- Worker sockets therefore did not have the same lifetime as the sync loop.
- Adaptive state was observed after commits, rather than being a continuously
  running supervisor.
- The node and Android paths consequently had materially different scheduling
  behaviour.

**Shared state:** `crates/state/src/pipeline`

- `AdaptiveController` owned CPU pressure, window growth, worker count and
  inflight count.
- `RangeScheduler` owned range leases.
- The Android coordinator added another layer of worker-budget logic around
  the shared controller.

This was too many authorities for one pipeline.

### B. The Android CPU split was self-contradictory

The previous code advertised:

`Android reserve 1 / commit 1 / validation 1 / script 5`

on an 8-core device, but the sampler previously allowed the pressure-derived
validation count to replace the intended split outside the commit critical
section.

That meant the advertised split was not a persistent scheduling contract.

The redesign makes the distinction explicit:

- normal mode: validation receives the adaptive YORTAL CPU budget;
- canonical preparation: exactly one validation slot remains active and the
  commit owner reserves one slot, with the remainder assigned to script;
- canonical mutation remains one owner and height ordered.

### C. Window, range size and inflight capacity were mixed

The old code used:

- adaptive planning window,
- independent range-size ceiling,
- inflight-range budget,

but several paths treated these as if they were interchangeable.

The redesigned engine has one definition:

**window = maximum canonical lookahead in blocks**

The window is partitioned into ranges. Inflight ranges never multiply the
lookahead.

### D. Head-of-line failure could still dominate progress

A later range can validate successfully while the range at `next_commit`
is stalled. Since canonical state cannot skip a height, later work is not
useful unless the head eventually arrives.

The redesign preserves this invariant and makes the head lease explicitly
recoverable: a stalled lease can be returned to the scheduler and fetched by
another peer. No consensus height is skipped.

### E. Thread-pool lifetime was unnecessarily coupled to header batches

The node implementation repeatedly created worker threads for each header
window. That adds:

- thread creation/destruction overhead,
- repeated socket handshakes,
- loss of warmed peer connections,
- less stable adaptive measurements,
- more opportunities for an empty worker pool between windows.

The new node path uses persistent workers for the entire sync session.

### F. Consensus ordering was not the problem and must not be removed

The correct invariant is:

`fetch/verify may complete out of order -> canonical commit must not.`

The redesign retains a strict ordered commit barrier. A validated range can
only cross the barrier when its start height equals `next_commit`, its lease
generation is still current, and its blocks form a contiguous parent-linked
sequence.

## 2. What was learned from Zebra 6.3.0

The supplied Zebra source has the same fundamental separation, but with clearer
ownership:

### Zebra sync/download layer

`zebrad/src/components/sync.rs`

- Separate download concurrency and verification concurrency.
- A lookahead limit prevents downloads from running indefinitely ahead of
  state.
- Download/verify work is represented as independent pending tasks.
- The syncer pauses new downloads when the downstream pipeline is ahead.

### Zebra download/verify layer

`zebrad/src/components/sync/downloads.rs`

- Download and verification are a bounded pipeline.
- Verification is a service, separate from peer I/O.
- Futures are tracked independently.
- Cancellation and timeout are explicit.
- A failed request does not silently wedge the entire pipeline.
- Lookahead is a downstream backpressure mechanism, not a consensus rule.

### Zebra state layer

`zebra-state/src/service.rs` and `zebra-state/src/service/queued_blocks.rs`

- State receives verified blocks through explicit queues.
- Queued blocks are indexed by hash, parent and height.
- A separate block-write task owns state mutation.
- Sent/queued block tracking prevents duplicate processing.
- The state layer maintains ordering and parent availability independently of
  the network downloader.

### Design principle carried into YORTAL

The useful Zebra pattern is therefore not a literal copy of Zebra's code. It is:

**one owner per responsibility**

1. peer/network owner
2. range scheduler
3. stateless verifier pool
4. ordered canonical committer
5. resource supervisor

No component is allowed to redefine another component's budget.

## 3. New YORTAL v0.31 architecture

```text
                    HEADER SYNC
                         |
                         v
                canonical headers
                         |
                         v
              +---------------------+
              | Range Scheduler     |
              | bounded lookahead   |
              | generation leases   |
              +----------+----------+
                         |
                disjoint ranges
                         |
             +-----------+-----------+
             |                       |
          peer A                   peer B ...
             |                       |
          getdata                  getdata
             |                       |
             +-----------+-----------+
                         |
                         v
                +----------------+
                | Verify Pool    |
                | stateless only |
                +-------+--------+
                        |
                 validated ranges
                        |
                        v
              +---------------------+
              | Ordered Barrier     |
              | next_commit only    |
              +----------+----------+
                         |
                         v
              +---------------------+
              | Permanent Commit    |
              | prepare -> apply    |
              | one canonical owner |
              +----------+----------+
                         |
                         v
                    State / DB
```

### Resource control

The controller now controls only:

- validation worker budget,
- inflight range budget,
- total lookahead window.

It does **not** control:

- consensus ordering,
- commit ownership,
- peer correctness,
- whether a validated height may be skipped.

### CPU policy

On an 8-core device:

- 1 core is reserved outside YORTAL.
- 7 YORTAL CPU slots remain.
- During canonical preparation:
  - 1 commit owner,
  - 1 validation slot,
  - 5 script slots.
- Outside canonical preparation, validation can expand adaptively up to the
  available YORTAL ceiling; script receives only the CPU remainder.

This removes the previous permanent validation=1 bottleneck while retaining the
requested 1/1/5 commit-time split.

## 4. Backpressure rules

The redesigned system has three independent limits:

### Lookahead

Maximum canonical distance ahead of `next_commit`.

Default maximum: **2000 blocks**.

### Range size

Maximum blocks in one network lease.

Maximum: **100 blocks**.

This is a transport/scheduling limit, not a consensus rule.

### Inflight range count

Number of ranges simultaneously leased or pending.

It is independently bounded by the resource controller.

A full validation queue is treated as **demand**, not CPU pressure.

## 5. Failure handling

### Network failure

- Lease is returned.
- Retry count is recorded.
- Another peer can claim it.

### Validation failure

- The lease generation prevents a stale result from being committed.
- The supplying peer can be disconnected/penalized by the caller.
- The mandatory height remains in the scheduler.

### Head-of-line stall

- The lease is age-checked.
- It can be requeued.
- The scheduler never advances `next_commit` past it.

### Stale/hedged result

- Generation and start-height checks reject it.
- It never mutates canonical state.

### Commit failure

- The permanent commit owner remains alive.
- The affected lease can be retried.
- The canonical tip is rechecked by `apply_prepared_commit`.

## 6. Changes implemented in this package

### Shared pipeline

Replaced the previous adaptive/range implementation with a smaller
stage-aware coordinator:

- bounded adaptive resource controller,
- bounded range scheduler,
- explicit range leases and generations,
- no completed-range accumulation,
- window means actual lookahead,
- separate worker and inflight budgets,
- pressure and workload are separate signals.

### Android

- Removed the old leftover-CPU calculation.
- Restored adaptive validation concurrency outside commit preparation.
- Preserved one permanent canonical commit owner.
- Preserved commit-time 1 validation slot.
- Script budget receives the remaining CPU during canonical preparation.
- Raised adaptive maximum lookahead to 2000.
- Initial lookahead is 64.
- Range ceiling remains 100.

### Desktop/node

- Replaced per-header-window worker creation with persistent sync workers.
- Workers wait for scheduler leases instead of exiting when a window is empty.
- Active validation worker count is updated by the resource controller.
- One permanent commit worker remains responsible for `prepare -> apply`.
- Ordered commit remains the only route to canonical state.

### Configuration

`config/pipeline.toml` now starts at 64 blocks and can adapt to 2000.

The 16-block setting is no longer treated as the operating ceiling.

## 7. Consensus safety

The redesign does **not** introduce a shortcut around consensus.

The intended sequence remains:

1. validate header
2. persist canonical header
3. fetch body by expected header hash
4. run block/transaction stateless validation
5. complete proof verification
6. wait for the exact canonical predecessor
7. prepare state transition against the current canonical state
8. recheck canonical tip during apply
9. atomically mutate state
10. advance `next_commit`

No range may be committed out of order.

No block may be skipped because another range is ready.

No adaptive signal can change a consensus rule.

## 8. Important build limitation

The supplied environment does not contain the Rust toolchain (`cargo` was not
installed), so a real `cargo check --workspace` / Android NDK build could not
be executed here.

Static source checks were performed after the redesign, including balanced
Rust delimiters and cross-file API usage. The package should therefore be
treated as a source-level redesign requiring the project's normal CI build
before flashing to a device.

## 9. Recommended verification sequence

CI should verify, in this order:

1. `cargo test --workspace --all-targets`
2. `cargo check --workspace`
3. Android ARM64 native build
4. APK/AAR packaging
5. fresh-install runtime test
6. header sync from genesis
7. block sync with multiple peers
8. ordered commit assertion
9. 2,096-block full-consensus audit
10. long-run test beyond the initial 2,000-block lookahead

Runtime telemetry should report:

- total logical cores
- Android-reserved slots
- current validation workers
- current script budget
- current lookahead
- active ranges
- pending ranges
- verification queue
- commit queue
- head lease age
- commit preparation time
- RocksDB write/commit time
- retry count
- stale-result count
- current canonical height

## Result

The central architectural problem was not that YORTAL needed more knobs.
It had too many overlapping controllers.

v0.31 reduces the system to one scheduling authority and one canonical commit
authority:

**adaptive scheduling decides how much work may be in flight; the ordered
committer decides what is allowed to become canonical.**

That separation is the key invariant of the redesign.
