# Yortal Zebra Commit Architecture Implementation

Implemented from the 2026-09-18 Zebra 6.3.0 commit-stage audit.

## Implemented

- One permanent `yortal-commit` worker for the desktop node in `crates/node/src/sync.rs`.
- Desktop sync validated ranges now cross a bounded channel to that permanent worker instead of the coordinator directly owning canonical commits.
- Explicit `PreparedCommit` API in `crates/state/src/lib.rs`:
  - `State::prepare_commit_batch()`
  - `State::apply_prepared_commit()`
  - `State::commit_blocks_batch()` remains as the compatibility wrapper.
- Commit preparation/application boundary is now explicit; raw `BlockCommit` data remains borrowed while touched UTXO/Sprout mutation sets are owned by the prepared plan.
- Android ordered committer now uses the prepared/apply API.
- Android commit barrier checks contiguous heights and parent/hash linkage before committing a sequence.
- Recoverable Android candidate/state commit failures are requeued instead of permanently setting `halted`.
- UTXO changes now expose `CoinsView::prepare_changes()` and `PreparedUtxoChanges` before atomic SQL application.
- Sprout/nullifier changes now expose `SproutView::prepare_changes()` and `PreparedSproutChanges` before atomic SQL application.
- Existing `ConsensusCache` hot-state mechanism remains the canonical commit acceleration layer and is preserved across sequential commits.
- Existing parsed/precomputed transaction handoff remains in `BlockCommit`; the commit path continues to reuse it when supplied.
- RocksDB remains the atomic commit backend; no unrequested database migration to RocksDB was made.

## Consensus-safety decision

`BlockConnector::connect_tx()` remains ordered because it combines checks that depend on the canonical sequential state with state mutation. It must not be blindly parallelized. The safe boundary is parallel immutable/stateless preparation followed by ordered canonical checks and mutation.

## Validation limitation

The execution environment used to modify this archive does not contain `cargo` or `rustc`, so a local Rust compilation/test pass could not be executed here. Structural source checks were performed, but CI/build validation is still required before APK/AAR release.

## Recommended CI validation

1. `cargo fmt --all -- --check`
2. `cargo test --workspace --all-targets`
3. ARM64 Android build
4. Android package verification
5. Consensus regression/differential tests
6. Runtime sync test confirming one permanent commit worker and adaptive validation workers
7. Telemetry comparison of preparation/state/DB/RocksDB commit timings
