# Ycash Android Node — Remaining Development Stages

This roadmap is part of the project and is the authoritative implementation checklist.

CURRENT STATUS
Stages 1–11 have been scaffolded progressively. Stages below remain to be implemented and verified.

## STAGE 12 — COMPLETE TRANSACTION RELAY
- Implement inv/getdata/transaction relay.
- Duplicate suppression.
- Peer relay scheduling.
- Rate limiting.
- Misbehavior scoring.
- Relay only after transaction validation.

Exit criteria:
- Interoperates with Ycash peers.
- Invalid transactions cannot enter relay.
- Resource use is bounded.

## STAGE 13 — RPC / LOCAL NODE API
- Expand localhost API.
- Node status.
- Chain height.
- Sync progress.
- Peer information.
- Mempool information.
- Chain information.
- Wallet-facing calls.
- Safe local authentication/access controls where required.

Exit criteria:
- UI and wallet receive real node telemetry.
- API cannot bypass consensus.

## STAGE 14 — YORTAL WALLET INTEGRATION
- Connect wallet to local node.
- Real chain height/sync state.
- Peer status.
- Transaction submission.
- Node unavailable/offline handling.

Exit criteria:
- Wallet and node agree on chain state.
- Wallet can reliably detect synchronization.

## STAGE 15 — ANDROID RELIABILITY
- Android lifecycle integration.
- Background operation where appropriate.
- Network-change handling.
- Battery-aware operation.
- Storage-space checks.
- Graceful shutdown.
- Crash recovery.
- Database integrity/recovery.
- Configurable resource limits.

Exit criteria:
- Node survives normal Android lifecycle events.
- State corruption is detected safely.

## STAGE 16 — PERFORMANCE OPTIMIZATION
- Profile CPU.
- Profile allocations.
- Profile database I/O.
- Optimize hashing/Keccak/SHAKE paths where applicable.
- Optimize block parsing/state access.
- Optimize peer scheduling.
- Add bounded caches.
- Benchmark ARM64 devices.

Exit criteria:
- Measurable performance improvement.
- No consensus/serialization/verification regression.

## STAGE 17 — SECURITY HARDENING
- Fuzz network parsers.
- Fuzz block/transaction parsers.
- Fuzz consensus boundaries.
- Test malformed proofs.
- Test invalid PoW/Merkle roots.
- Test double spends/nullifier conflicts.
- Test deep reorgs.
- Test resource exhaustion.
- Audit unsafe Rust/FFI.

Exit criteria:
- Fuzzing and security regression suites pass.
- No known validation bypass remains.

## STAGE 18 — DIFFERENTIAL & HISTORICAL REPLAY
- Replay historical Ycash blocks.
- Compare acceptance/rejection with Ycash 4.5.0.
- Compare state transitions.
- Compare chain selection/reorgs.
- Compare transaction validation.
- Compare serialization and relevant RPC results.

Exit criteria:
- Rust implementation agrees with the reference corpus.
- Any intentional difference is documented and proven non-consensus-affecting.

## STAGE 19 — LONG-RUN MAINNET TEST
- Fresh mainnet sync.
- Multi-day continuous operation.
- Peer churn.
- Network interruption.
- Android sleep/restart.
- Storage pressure.
- Reorg testing.
- CPU/RAM/battery monitoring.
- Compare final state with reference node.

Exit criteria:
- Stable long-running operation.
- No unexplained consensus divergence.
- No unrecoverable state corruption.

## STAGE 20 — RELEASE BUILD
- Pin Rust dependencies.
- Pin Android/NDK environment.
- Reproducible ARM64 build.
- APK/AAB signing.
- Checksums.
- Release notes.
- Configuration/data-directory documentation.
- Recovery procedure.
- Known limitations.

Exit criteria:
- Reproducible release artifact.
- Installation and mainnet sync succeed.
- Consensus/security suite passes.

## STAGE 21 — PRODUCTION OPERATION
- Monitor peer connectivity and synchronization.
- Crash/error monitoring.
- Maintain Ycash compatibility.
- Add regression tests before upgrades.
- Review upstream Ycash/Zcash developments for useful non-consensus improvements.
- Never adopt consensus changes without explicit Ycash compatibility analysis.

## FINAL DEFINITION OF DONE
The project is finished only when the node:
- connects to Ycash mainnet;
- completes the Ycash P2P handshake;
- downloads and validates the chain;
- persists chain state;
- handles forks/reorganizations;
- rejects invalid blocks and transactions;
- agrees with Ycash 4.5.0 on the differential corpus;
- survives Android restarts/network interruptions;
- exposes reliable local telemetry/API;
- integrates with Yortal Wallet;
- passes fuzzing/security/regression tests;
- builds reproducibly for Android ARM64.

## IMPLEMENTATION RULE
Do not mark a stage complete merely because scaffolding exists. A stage is complete only after its exit criteria are implemented, tested, and recorded.

## v0.19.13 implementation note
Stage 12 block acquisition groundwork is now implemented: complete Ycash v1-v4 transaction framing, Merkle-root validation, RocksDB transaction indexing, atomic block/tip commit, and block-level diagnostics. Full transaction consensus/proof validation, relay, and differential agreement with Ycash 4.5.0 reference implementation remain required before Stage 12 is considered complete.
