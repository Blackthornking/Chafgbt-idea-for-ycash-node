# YORTAL v0.30.1 — State/Commit Instrumentation + ETA UI

## Changes

- State-validation timing now records microseconds internally so sub-millisecond work is no longer displayed as `0 ms`.
- Split parent-state loading into:
  - parent frontier load
  - Sprout state load
  - combined parent-state total
- Added explicit timing for:
  - read transaction begin/commit
  - block decoding/parsing
  - transaction parsing
  - transaction ID/hash calculation
  - transparent transaction connect
  - sigops/BIP30/UTXO/Sprout/value/script/coin-state stages
  - Sapling validation and anchor/nullifier lookups
  - Sapling tree work
  - block finalization
  - Sapling frontier/tree encoding
- Added `state_unattributed_us`: total state-validation time minus all measured top-level state stages. This exposes the previously hidden portion of the 326–510 ms phase.
- Added microsecond DB-write and RocksDB-COMMIT timing while retaining millisecond compatibility fields.
- Dashboard wording now distinguishes the full ordered commit from the actual RocksDB WRITE.
- The state-validation breakdown displays sub-millisecond timings instead of rounding them away.
- Added an `Estimated time left` field at the bottom of the node-status/network section.
- ETA is calculated as:

  `max(target_height - local_height, 0) / live blocks_per_second`

  using the same end-to-end blocks/s rate shown by the dashboard.

## Consensus behavior

This change is instrumentation/UI only. It does not alter consensus rules, block ordering, batch size, validation semantics, or the configured single-worker/single-range pipeline.

## Verification performed in this environment

- Android layout XML parses successfully.
- MainActivity Java braces are balanced.
- Status JSON format placeholders and arguments are balanced (102/102).
- Rust timing-field references were checked for missing struct fields.
- Full Rust/Android compilation could not be run in this environment because the Rust toolchain is unavailable and the supplied Gradle wrapper is missing `GradleWrapperMain`.
