//! Bounded range scheduler. It tracks only unfinished work, so its memory and
//! scan cost stay proportional to the active lookahead rather than chain height.

use std::collections::{BTreeMap, HashMap};
use std::time::{Duration, Instant};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct RangeId(pub u64);
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct HeightRange { pub start:u64, pub end:u64 }
impl HeightRange { pub fn len(&self)->u64 { self.end.saturating_sub(self.start)+1 } }
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RangeState { Pending, Leased, Complete, Quarantined }
#[derive(Debug, Clone)]
pub struct RangeLease {
    pub id:RangeId, pub range:HeightRange, pub peer:String, pub state:RangeState,
    pub retries:u32, pub generation:u64, pub claimed_at:Option<Instant>,
}
#[derive(Debug,Default)]
pub struct RangeScheduler { next_id:u64, ranges:BTreeMap<RangeId,RangeLease>, peer_load:HashMap<String,usize> }

impl RangeScheduler {
    pub fn enqueue(&mut self,start:u64,end:u64)->RangeId {
        assert!(start<=end);
        let id=RangeId(self.next_id); self.next_id+=1;
        self.ranges.insert(id,RangeLease{id,range:HeightRange{start,end},peer:String::new(),
            state:RangeState::Pending,retries:0,generation:0,claimed_at:None}); id
    }
    pub fn enqueue_if_disjoint(&mut self,start:u64,end:u64)->Option<RangeId>{
        if start>end{return None}
        if self.ranges.values().any(|r| matches!(r.state,RangeState::Pending|RangeState::Leased|RangeState::Quarantined)
            && r.range.start<=end && start<=r.range.end){None}else{Some(self.enqueue(start,end))}
    }
    pub fn claim_upto(&mut self,peer:&str,max_end:u64)->Option<RangeLease>{
        let id=self.ranges.iter().find(|(_,r)|r.state==RangeState::Pending&&r.range.end<=max_end).map(|(i,_)|*i)?;
        let r=self.ranges.get_mut(&id)?; r.peer=peer.into();r.state=RangeState::Leased;
        r.generation=r.generation.saturating_add(1);r.claimed_at=Some(Instant::now());
        *self.peer_load.entry(peer.into()).or_default()+=1;Some(r.clone())
    }
    pub fn claim(&mut self,peer:&str)->Option<RangeLease>{self.claim_upto(peer,u64::MAX)}
    pub fn complete(&mut self,id:RangeId){if let Some(r)=self.ranges.remove(&id){if let Some(v)=self.peer_load.get_mut(&r.peer){*v=v.saturating_sub(1);}}}
    pub fn release(&mut self,id:RangeId){if let Some(r)=self.ranges.get_mut(&id){
        if let Some(v)=self.peer_load.get_mut(&r.peer){*v=v.saturating_sub(1)}
        r.retries=r.retries.saturating_add(1);r.peer.clear();r.claimed_at=None;r.generation+=1;
        r.state=if r.retries>=3{RangeState::Quarantined}else{RangeState::Pending};
    }}
    pub fn requeue(&mut self,id:RangeId){if let Some(r)=self.ranges.get_mut(&id){
        if let Some(v)=self.peer_load.get_mut(&r.peer){*v=v.saturating_sub(1)}
        r.retries=0;r.peer.clear();r.claimed_at=None;r.generation+=1;r.state=RangeState::Pending;
    }}
    pub fn unlease(&mut self,id:RangeId){if let Some(r)=self.ranges.get_mut(&id){
        if let Some(v)=self.peer_load.get_mut(&r.peer){*v=v.saturating_sub(1)}
        r.peer.clear();r.claimed_at=None;r.generation+=1;r.state=RangeState::Pending;
    }}
    pub fn lease_age(&self,id:RangeId)->Option<Duration>{self.ranges.get(&id)?.claimed_at.map(|x|x.elapsed())}
    pub fn is_current_lease(&self,id:RangeId,g:u64)->bool{self.ranges.get(&id).map(|r|r.state==RangeState::Leased&&r.generation==g).unwrap_or(false)}
    pub fn state(&self,id:RangeId)->Option<RangeState>{self.ranges.get(&id).map(|r|r.state)}
    pub fn range_end(&self,id:RangeId)->Option<u64>{self.ranges.get(&id).map(|r|r.range.end)}
    pub fn id_at_start(&self,start:u64)->Option<RangeId>{self.ranges.values().find(|r|r.range.start==start).map(|r|r.id)}
    pub fn outstanding_heights(&self)->u64{self.ranges.values().filter(|r|matches!(r.state,RangeState::Pending|RangeState::Leased)).map(|r|r.range.len()).sum()}
    pub fn pending_ranges(&self)->usize{self.ranges.values().filter(|r|r.state==RangeState::Pending).count()}
    pub fn leased_ranges(&self)->usize{self.ranges.values().filter(|r|r.state==RangeState::Leased).count()}
    pub fn contiguous_covered_end(&self,from:u64)->Option<u64>{
        let mut end=from.saturating_sub(1);
        loop{
            let next=end+1;
            let x=self.ranges.values().filter(|r|matches!(r.state,RangeState::Pending|RangeState::Leased))
                .filter(|r|r.range.start<=next&&r.range.end>=next).map(|r|r.range.end).max();
            match x{Some(v) if v>end=>end=v,_=>break}
        }
        (end>=from).then_some(end)
    }
}
