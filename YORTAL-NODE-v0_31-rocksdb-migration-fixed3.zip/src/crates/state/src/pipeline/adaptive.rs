//! Stage-aware pipeline control.
//!
//! This module intentionally contains no consensus or commit logic. It only
//! computes bounded resource budgets. A full validation worker budget and the
//! script budget are separate: the ordered state committer owns canonical order.

use std::thread;

/// Number of consecutive critical-pressure observations required before the
/// emergency 1/1 budget is allowed. A single slow DB/CPU sample must not
/// destroy pipeline lookahead; the emergency floor is reserved for sustained
/// pressure.
const CRITICAL_PRESSURE_SAMPLES: u8 = 3;

#[derive(Clone, Copy, Debug)]
pub struct AdaptiveConfig {
    pub min_window: usize,
    pub initial_window: usize,
    pub max_window: usize,
    pub step: usize,
    pub high_watermark: f64,
    pub low_watermark: f64,
    pub max_validation_workers: usize,
    pub max_inflight_ranges: usize,
    pub max_range_len: usize,
}

impl Default for AdaptiveConfig {
    fn default() -> Self {
        let cores = thread::available_parallelism().map(|n| n.get()).unwrap_or(1);
        let validation = cores.saturating_sub(1).max(1);
        Self {
            min_window: 16,
            initial_window: 64,
            max_window: 2000,
            step: 100,
            high_watermark: 0.85,
            low_watermark: 0.50,
            max_validation_workers: validation,
            max_inflight_ranges: validation.saturating_mul(2).max(1),
            max_range_len: 100,
        }
    }
}

#[derive(Clone, Copy, Debug, Default)]
pub struct ResourceSample {
    pub cpu_ratio: f64,
    pub memory_ratio: f64,
    pub db_queue_ratio: f64,
    pub network_ratio: f64,
    pub validation_queue_ratio: f64,
}

impl ResourceSample {
    /// Only resource contention can throttle. Queue depth is demand, not pressure.
    pub fn pressure(self) -> f64 {
        self.cpu_ratio.max(self.memory_ratio).max(self.db_queue_ratio)
    }
    pub fn demand(self) -> f64 { self.validation_queue_ratio.clamp(0.0, 1.0) }
    pub fn network_stalled(self) -> bool { self.network_ratio >= 0.95 }
}

#[derive(Clone, Copy, Debug)]
pub struct StageBudget {
    pub validation_workers: usize,
    pub inflight_ranges: usize,
    pub window: usize,
}

pub struct AdaptiveController {
    cfg: AdaptiveConfig,
    window: usize,
    workers: usize,
    inflight: usize,
    pressure: f64,
    demand: f64,
    critical_pressure_samples: u8,
}

impl AdaptiveController {
    pub fn new(mut cfg: AdaptiveConfig) -> Self {
        cfg.min_window = cfg.min_window.max(1);
        cfg.max_window = cfg.max_window.max(cfg.min_window);
        cfg.initial_window = cfg.initial_window.clamp(cfg.min_window, cfg.max_window);
        cfg.step = cfg.step.max(1);
        cfg.max_validation_workers = cfg.max_validation_workers.max(1);
        cfg.max_inflight_ranges = cfg.max_inflight_ranges.max(1);
        cfg.max_range_len = cfg.max_range_len.clamp(1, 100);
        let window = cfg.initial_window;
        let workers = cfg.max_validation_workers;
        let inflight = cfg.max_inflight_ranges;
        Self { cfg, window, workers, inflight, pressure: 0.0, demand: 0.0, critical_pressure_samples: 0 }
    }

    fn budgets(&self, pressure: f64, emergency: bool) -> (usize, usize) {
        let maxw = self.cfg.max_validation_workers.max(1);
        let maxi = self.cfg.max_inflight_ranges.max(1);
        // Do not collapse the producer to a single verifier on an ordinary
        // high-pressure sample. The high-watermark branch already halves the
        // budget; reserve the 1/1 emergency floor for genuinely critical
        // pressure. This prevents a transient spike from creating a long
        // head-of-line stall while downstream ranges are buffered.
        if emergency { return (1, 1); }
        if pressure >= self.cfg.high_watermark {
            return (((maxw + 1) / 2).max(1), ((maxi + 1) / 2).max(1));
        }
        if pressure <= self.cfg.low_watermark {
            return (maxw, maxi);
        }
        let f = ((self.cfg.high_watermark - pressure) /
            (self.cfg.high_watermark - self.cfg.low_watermark).max(f64::EPSILON)).clamp(0.0, 1.0);
        let w = (1.0 + f * (maxw.saturating_sub(1) as f64)).round() as usize;
        let i = (1.0 + f * (maxi.saturating_sub(1) as f64)).round() as usize;
        (w.clamp(1,maxw), i.clamp(1,maxi))
    }

    pub fn observe(&mut self, s: ResourceSample) -> usize {
        let raw = s.pressure();
        self.demand = s.demand();

        // EWMA is the normal control signal. This is deliberately the value
        // passed to budgets(): a single slow commit therefore degrades
        // concurrency proportionally instead of instantly collapsing it.
        self.pressure = 0.25 * raw + 0.75 * self.pressure;

        // A hard 1/1 floor is an emergency mechanism, not ordinary throttling.
        // Require sustained critical pressure so a single 213 ms commit (or
        // one transient CPU/memory spike) cannot strand the producer behind
        // one peer. Clear the streak as soon as pressure is no longer critical.
        if raw >= 0.98 {
            self.critical_pressure_samples = self.critical_pressure_samples
                .saturating_add(1)
                .min(CRITICAL_PRESSURE_SAMPLES);
        } else {
            self.critical_pressure_samples = 0;
        }
        let emergency = self.critical_pressure_samples >= CRITICAL_PRESSURE_SAMPLES;
        let effective = self.pressure;
        if effective >= self.cfg.high_watermark {
            self.window = self.window.saturating_sub(self.cfg.step).max(self.cfg.min_window);
        } else if effective <= self.cfg.low_watermark && !s.network_stalled() {
            self.window = (self.window + self.cfg.step).min(self.cfg.max_window);
        }
        (self.workers, self.inflight) = self.budgets(effective, emergency);
        self.window
    }

    pub fn window(&self)->usize { self.window }
    pub fn current_workers(&self)->usize { self.workers.max(1) }
    pub fn current_inflight(&self)->usize { self.inflight.max(1) }
    pub fn max_workers(&self)->usize { self.cfg.max_validation_workers }
    pub fn max_inflight(&self)->usize { self.cfg.max_inflight_ranges }
    pub fn min_window(&self)->usize { self.cfg.min_window }
    pub fn max_window(&self)->usize { self.cfg.max_window }
    pub fn step(&self)->usize { self.cfg.step }
    pub fn max_range_len(&self)->usize { self.cfg.max_range_len }
    pub fn high(&self)->f64 { self.cfg.high_watermark }
    pub fn low(&self)->f64 { self.cfg.low_watermark }
    pub fn pressure(&self)->f64 { self.pressure }
    pub fn demand(&self)->f64 { self.demand }
    pub fn critical_pressure_samples(&self)->u8 { self.critical_pressure_samples }
}
