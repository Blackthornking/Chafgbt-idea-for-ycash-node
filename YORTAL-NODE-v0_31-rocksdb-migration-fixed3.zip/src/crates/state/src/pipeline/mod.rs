//! YORTAL v0.31 pipeline coordinator.
//!
//! The old pipeline mixed CPU adaptation, range ownership, network fetching,
//! validation, and canonical commit policy. This redesign separates them:
//!
//! network -> bounded range leases -> stateless verification -> ordered commit
//!
//! Only the scheduler is adaptive. Consensus ordering is never adaptive.
//! There is one canonical commit owner; stale/duplicate results are rejected
//! by lease generation and the commit barrier.

pub mod adaptive;
pub mod range_scheduler;
pub mod telemetry;
pub use adaptive::{AdaptiveConfig, AdaptiveController, ResourceSample, StageBudget};
pub use range_scheduler::{HeightRange, RangeId, RangeLease, RangeScheduler, RangeState};
pub use telemetry::{PipelineSnapshot, PipelineStats};

pub struct PipelineEngine {
    adaptive: AdaptiveController,
    scheduler: RangeScheduler,
    stats: PipelineStats,
}

impl PipelineEngine {
    pub fn new(cfg: AdaptiveConfig)->Self {
        let mut stats=PipelineStats::default(); stats.start();
        stats.current_window=cfg.initial_window as u64;
        stats.validation_workers=cfg.max_validation_workers.max(1) as u64;
        stats.max_inflight_ranges=cfg.max_inflight_ranges.max(1) as u64;
        Self{adaptive:AdaptiveController::new(cfg),scheduler:RangeScheduler::default(),stats}
    }

    pub fn plan_parallel_ranges(&mut self,next:u64,tip:u64,_workers:usize)->Vec<RangeId>{
        if next>tip{return Vec::new()}
        let window=self.adaptive.window().max(1) as u64;
        let slots=self.adaptive.current_inflight().max(1);
        let max_len=self.adaptive.max_range_len() as u64;
        let target=next.saturating_add(window-1).min(tip);
        let mut start=match self.scheduler.contiguous_covered_end(next){Some(x)=>x+1,None=>next};
        if start>target{return Vec::new()}
        let capacity=(slots as u64).saturating_mul(max_len);
        let total=(target-start+1).min(capacity.saturating_sub(self.scheduler.outstanding_heights()));
        if total==0{return Vec::new()}
        let mut ids=Vec::new(); let mut remaining=total;
        while remaining>0 && ids.len()<slots {
            let slots_left=(slots-ids.len()).max(1) as u64;
            let len=(remaining+slots_left-1)/slots_left;
            let end=start+len.min(max_len)-1;
            if let Some(id)=self.scheduler.enqueue_if_disjoint(start,end){ids.push(id)}
            start=end+1; remaining=remaining.saturating_sub(len.min(max_len));
        }
        self.stats.current_window=window; self.stats.validation_workers=self.adaptive.current_workers() as u64;
        self.stats.max_inflight_ranges=self.adaptive.current_inflight() as u64;
        self.stats.blocks_in_flight=self.scheduler.outstanding_heights();
        self.stats.request_rounds+=u64::from(!ids.is_empty()); ids
    }
    pub fn claim(&mut self,p:&str)->Option<RangeLease>{self.scheduler.claim(p)}
    pub fn claim_upto(&mut self,p:&str,e:u64)->Option<RangeLease>{self.scheduler.claim_upto(p,e)}
    pub fn leased_ranges(&self)->usize{self.scheduler.leased_ranges()}
    pub fn pending_ranges(&self)->usize{self.scheduler.pending_ranges()}
    pub fn outstanding_heights(&self)->u64{self.scheduler.outstanding_heights()}
    pub fn range_end(&self,id:RangeId)->Option<u64>{self.scheduler.range_end(id)}
    pub fn lease_age(&self,id:RangeId)->Option<std::time::Duration>{self.scheduler.lease_age(id)}
    pub fn range_ids_at_start(&self,s:u64)->Option<RangeId>{self.scheduler.id_at_start(s)}
    pub fn is_current_lease(&self,id:RangeId,g:u64)->bool{self.scheduler.is_current_lease(id,g)}
    pub fn range_terminal(&self,id:RangeId)->bool{matches!(self.scheduler.state(id),None|Some(RangeState::Complete|RangeState::Quarantined))}
    pub fn requeue_if_lease_stalled(&mut self,id:RangeId,d:std::time::Duration)->bool{
        if self.scheduler.lease_age(id).map(|x|x>=d).unwrap_or(false){self.scheduler.requeue(id);true}else{false}
    }
    pub fn requeue_if_quarantined_at(&mut self,start:u64)->bool{
        if let Some(id)=self.scheduler.id_at_start(start){if self.scheduler.state(id)==Some(RangeState::Quarantined){self.scheduler.requeue(id);return true}} false
    }
    pub fn requeue_lease(&mut self,id:RangeId){self.scheduler.unlease(id)}
    pub fn release(&mut self,id:RangeId){self.scheduler.release(id);self.stats.retried_ranges+=1}
    pub fn release_if_current(&mut self,id:RangeId,g:u64)->bool{if self.scheduler.is_current_lease(id,g){self.release(id);true}else{false}}
    pub fn complete(&mut self,id:RangeId,blocks:u64,bytes:u64){self.scheduler.complete(id);self.stats.blocks_received+=blocks;self.stats.blocks_committed+=blocks;self.stats.blocks_in_flight=self.stats.blocks_in_flight.saturating_sub(blocks);self.stats.completed_ranges+=1;self.stats.bytes_received+=bytes}
    pub fn observe(&mut self,s:ResourceSample)->PipelineSnapshot{
        self.adaptive.observe(s); self.stats.current_window=self.window(); self.stats.validation_workers=self.current_validation_workers() as u64;
        self.stats.max_inflight_ranges=self.max_inflight_ranges() as u64; self.stats.blocks_in_flight=self.outstanding_heights(); self.stats.snapshot()
    }
    pub fn window(&self)->u64{self.adaptive.window() as u64}
    pub fn lookahead(&self)->u64{self.window().max(1)}
    pub fn current_pressure(&self)->f64{self.adaptive.pressure()}
    pub fn current_demand(&self)->f64{self.adaptive.demand()}
    pub fn current_validation_workers(&self)->usize{self.adaptive.current_workers()}
    pub fn max_inflight_ranges(&self)->usize{self.adaptive.current_inflight()}
    pub fn configured_max_validation_workers(&self)->usize{self.adaptive.max_workers()}
    pub fn configured_max_inflight_ranges(&self)->usize{self.adaptive.max_inflight()}
    pub fn configured_min_window(&self)->usize{self.adaptive.min_window()}
    pub fn configured_max_window(&self)->usize{self.adaptive.max_window()}
    pub fn configured_window_step(&self)->usize{self.adaptive.step()}
    pub fn configured_max_range_len(&self)->usize{self.adaptive.max_range_len()}
    pub fn configured_high_watermark(&self)->f64{self.adaptive.high()}
    pub fn configured_low_watermark(&self)->f64{self.adaptive.low()}
    pub fn snapshot(&self)->PipelineSnapshot{self.stats.snapshot()}
}

#[cfg(test)]
mod tests {
 use super::*;
 #[test] fn bounds_and_no_overlap(){
  let mut e=PipelineEngine::new(AdaptiveConfig{min_window:16,initial_window:32,max_window:128,step:16,high_watermark:0.85,low_watermark:0.5,max_validation_workers:4,max_inflight_ranges:4,max_range_len:16});
  let ids=e.plan_parallel_ranges(1,128,4); assert!(!ids.is_empty()); assert!(e.outstanding_heights()<=32);
 }
 #[test] fn transient_critical_pressure_does_not_collapse_budget(){
  let cfg=AdaptiveConfig{min_window:16,initial_window:64,max_window:2000,step:100,high_watermark:0.85,low_watermark:0.50,max_validation_workers:8,max_inflight_ranges:10,max_range_len:16};
  let mut c=AdaptiveController::new(cfg);
  c.observe(ResourceSample{cpu_ratio:0.99,..Default::default()});
  assert_eq!(c.critical_pressure_samples(),1);
  assert!(c.current_workers()>1);
  assert!(c.current_inflight()>1);
 }
 #[test] fn sustained_critical_pressure_uses_emergency_floor(){
  let cfg=AdaptiveConfig{min_window:16,initial_window:64,max_window:2000,step:100,high_watermark:0.85,low_watermark:0.50,max_validation_workers:8,max_inflight_ranges:10,max_range_len:16};
  let mut c=AdaptiveController::new(cfg);
  for _ in 0..3 { c.observe(ResourceSample{cpu_ratio:0.99,..Default::default()}); }
  assert_eq!(c.critical_pressure_samples(),3);
  assert_eq!(c.current_workers(),1);
  assert_eq!(c.current_inflight(),1);
 }
 #[test] fn recovery_clears_emergency_streak(){
  let cfg=AdaptiveConfig{min_window:16,initial_window:64,max_window:2000,step:100,high_watermark:0.85,low_watermark:0.50,max_validation_workers:8,max_inflight_ranges:10,max_range_len:16};
  let mut c=AdaptiveController::new(cfg);
  for _ in 0..3 { c.observe(ResourceSample{cpu_ratio:0.99,..Default::default()}); }
  assert_eq!(c.current_workers(),1);
  c.observe(ResourceSample::default());
  assert_eq!(c.critical_pressure_samples(),0);
  assert!(c.current_workers()>1);
  assert!(c.current_inflight()>1);
 }
}
