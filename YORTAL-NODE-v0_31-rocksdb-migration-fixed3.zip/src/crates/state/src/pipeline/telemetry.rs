//! Pipeline telemetry primitives.

use std::time::{Duration, Instant};

#[derive(Debug, Default, Clone)]
pub struct PipelineStats {
    pub headers_received: u64,
    pub blocks_received: u64,
    pub blocks_validated: u64,
    pub blocks_committed: u64,
    pub bytes_received: u64,
    pub db_bytes_written: u64,
    pub request_rounds: u64,
    pub completed_ranges: u64,
    pub retried_ranges: u64,
    pub quarantined_ranges: u64,
    pub blocks_in_flight: u64,
    pub validation_queue: u64,
    pub commit_queue: u64,
    pub current_window: u64,
    pub validation_workers: u64,
    pub max_inflight_ranges: u64,
    pub validation_time_ns: u128,
    pub db_commit_time_ns: u128,
    started: Option<Instant>,
}

impl PipelineStats {
    pub fn start(&mut self) { self.started = Some(Instant::now()); }

    pub fn bps(&self) -> f64 {
        self.started.map(|t| {
            let secs = t.elapsed().as_secs_f64().max(0.001);
            self.blocks_received as f64 / secs
        }).unwrap_or(0.0)
    }

    pub fn rx_bytes_per_sec(&self) -> f64 {
        self.started.map(|t| {
            let secs = t.elapsed().as_secs_f64().max(0.001);
            self.bytes_received as f64 / secs
        }).unwrap_or(0.0)
    }

    pub fn validation_ms_avg(&self) -> f64 {
        if self.blocks_validated == 0 { return 0.0; }
        self.validation_time_ns as f64 / self.blocks_validated as f64 / 1_000_000.0
    }

    pub fn db_commit_ms_avg(&self) -> f64 {
        if self.completed_ranges == 0 { return 0.0; }
        self.db_commit_time_ns as f64 / self.completed_ranges as f64 / 1_000_000.0
    }

    pub fn snapshot(&self) -> PipelineSnapshot {
        PipelineSnapshot {
            bps: self.bps(),
            rx_bps: self.rx_bytes_per_sec(),
            validation_ms_avg: self.validation_ms_avg(),
            db_commit_ms_avg: self.db_commit_ms_avg(),
            blocks_in_flight: self.blocks_in_flight,
            validation_queue: self.validation_queue,
            commit_queue: self.commit_queue,
            window: self.current_window,
            workers: self.validation_workers,
            max_inflight_ranges: self.max_inflight_ranges,
            completed_ranges: self.completed_ranges,
            retried_ranges: self.retried_ranges,
            quarantined_ranges: self.quarantined_ranges,
        }
    }
}

#[derive(Debug, Clone)]
pub struct PipelineSnapshot {
    pub bps: f64,
    pub rx_bps: f64,
    pub validation_ms_avg: f64,
    pub db_commit_ms_avg: f64,
    pub blocks_in_flight: u64,
    pub validation_queue: u64,
    pub commit_queue: u64,
    pub window: u64,
    pub workers: u64,
    pub max_inflight_ranges: u64,
    pub completed_ranges: u64,
    pub retried_ranges: u64,
    pub quarantined_ranges: u64,
}
