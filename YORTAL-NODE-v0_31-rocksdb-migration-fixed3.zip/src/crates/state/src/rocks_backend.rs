use anyhow::{anyhow, bail, Result};
use rocksdb::{ColumnFamily, DB, Direction, IteratorMode, ReadOptions, Snapshot, WriteBatch};

pub const CF_META: &str = "meta";
pub const CF_BLOCKS: &str = "blocks";
pub const CF_BLOCKS_HEIGHT: &str = "blocks_height";
pub const CF_HEADERS: &str = "headers";
pub const CF_HEADERS_HEIGHT: &str = "headers_height";
pub const CF_TXS: &str = "txs";
pub const CF_TXS_BLOCK: &str = "txs_block";
pub const CF_NULLIFIERS: &str = "nullifiers";
pub const CF_NULLIFIERS_BLOCK: &str = "nullifiers_block";
pub const CF_SAPLING_ROOTS: &str = "sapling_roots";
pub const CF_SAPLING_ROOT_INDEX: &str = "sapling_root_index";
pub const CF_UTXOS: &str = "utxos";
pub const CF_UTXO_HEIGHT: &str = "utxo_height";
pub const CF_UTXO_SPENT: &str = "utxo_spent";
pub const CF_SPROUT_NULLIFIERS: &str = "sprout_nullifiers";
pub const CF_SPROUT_NULLIFIERS_HEIGHT: &str = "sprout_nullifiers_height";
pub const CF_BLOCK_STATE: &str = "block_state";
pub const CF_BLOCK_STATE_HEIGHT: &str = "block_state_height";
pub const CF_SPROUT_ROOT_INDEX: &str = "sprout_root_index";

pub const CF_NAMES: &[&str] = &[
    CF_META, CF_BLOCKS, CF_BLOCKS_HEIGHT, CF_HEADERS, CF_HEADERS_HEIGHT,
    CF_TXS, CF_TXS_BLOCK, CF_NULLIFIERS, CF_NULLIFIERS_BLOCK,
    CF_SAPLING_ROOTS, CF_SAPLING_ROOT_INDEX, CF_UTXOS, CF_UTXO_HEIGHT,
    CF_UTXO_SPENT, CF_SPROUT_NULLIFIERS, CF_SPROUT_NULLIFIERS_HEIGHT,
    CF_BLOCK_STATE, CF_BLOCK_STATE_HEIGHT, CF_SPROUT_ROOT_INDEX,
];

pub fn cf<'a>(db: &'a DB, name: &str) -> Result<&'a ColumnFamily> {
    db.cf_handle(name).ok_or_else(|| anyhow!("missing RocksDB column family {name}"))
}

pub fn u64_key(v: u64) -> [u8; 8] { v.to_be_bytes() }
pub fn i64_key(v: i64) -> [u8; 8] { v.to_be_bytes() }

pub fn outpoint_key(txid: &[u8; 32], vout: u32) -> [u8; 36] {
    let mut k = [0u8; 36]; k[..32].copy_from_slice(txid); k[32..].copy_from_slice(&vout.to_be_bytes()); k
}
pub fn height_outpoint_key(height: u64, txid: &[u8; 32], vout: u32) -> [u8; 44] {
    let mut k = [0u8; 44]; k[..8].copy_from_slice(&height.to_be_bytes()); k[8..40].copy_from_slice(txid); k[40..].copy_from_slice(&vout.to_be_bytes()); k
}
pub fn height_hash_key(height: u64, hash: &[u8; 32]) -> [u8; 40] {
    let mut k = [0u8; 40]; k[..8].copy_from_slice(&height.to_be_bytes()); k[8..].copy_from_slice(hash); k
}
pub fn root_height_key(root: &[u8; 32], height: u64) -> [u8; 40] {
    let mut k = [0u8; 40]; k[..32].copy_from_slice(root); k[32..].copy_from_slice(&height.to_be_bytes()); k
}

pub fn put_u64(v: u64, out: &mut Vec<u8>) { out.extend_from_slice(&v.to_be_bytes()); }
pub fn put_i64(v: i64, out: &mut Vec<u8>) { out.extend_from_slice(&v.to_be_bytes()); }
pub fn put_u32(v: u32, out: &mut Vec<u8>) { out.extend_from_slice(&v.to_be_bytes()); }
pub fn put_bytes(v: &[u8], out: &mut Vec<u8>) { put_u32(v.len() as u32, out); out.extend_from_slice(v); }

pub struct Decoder<'a> { b: &'a [u8], p: usize }
impl<'a> Decoder<'a> {
    pub fn new(b: &'a [u8]) -> Self { Self { b, p: 0 } }
    fn take(&mut self, n: usize) -> Result<&'a [u8]> { if self.p + n > self.b.len() { bail!("truncated RocksDB record") } let x=&self.b[self.p..self.p+n]; self.p+=n; Ok(x) }
    pub fn u64(&mut self) -> Result<u64> { Ok(u64::from_be_bytes(self.take(8)?.try_into().unwrap())) }
    pub fn i64(&mut self) -> Result<i64> { Ok(i64::from_be_bytes(self.take(8)?.try_into().unwrap())) }
    pub fn u32(&mut self) -> Result<u32> { Ok(u32::from_be_bytes(self.take(4)?.try_into().unwrap())) }
    pub fn u8(&mut self) -> Result<u8> { Ok(self.take(1)?[0]) }
    pub fn bytes(&mut self) -> Result<Vec<u8>> { let n=self.u32()? as usize; Ok(self.take(n)?.to_vec()) }
    pub fn fixed<const N: usize>(&mut self) -> Result<[u8;N]> { Ok(self.take(N)?.try_into().unwrap()) }
    pub fn done(&self) -> bool { self.p == self.b.len() }
}

pub struct ReadDb<'a> {
    pub db: &'a DB,
    pub snapshot: Snapshot<'a>,
}
impl<'a> ReadDb<'a> {
    pub fn new(db: &'a DB) -> Self { Self { db, snapshot: db.snapshot() } }
    pub fn get(&self, cf_name: &str, key: &[u8]) -> Result<Option<Vec<u8>>> { Ok(self.snapshot.get_cf(cf(self.db, cf_name)?, key)?) }
    pub fn exists(&self, cf_name: &str, key: &[u8]) -> Result<bool> { Ok(self.get(cf_name,key)?.is_some()) }
    pub fn multi_get(&self, cf_name:&str, keys:&[Vec<u8>])->Result<Vec<Option<Vec<u8>>>> { let handle=cf(self.db,cf_name)?; self.snapshot.multi_get_cf(keys.iter().map(|k|(handle,k.as_slice()))).into_iter().map(|r|r.map_err(Into::into)).collect() }
    pub fn iterator_height_max(&self, cf_name:&str)->Result<Option<u64>> { let mut it=self.snapshot.iterator_cf(cf(self.db,cf_name)?, IteratorMode::End); if let Some(item)=it.next(){ let (k,_)=item?; if k.len()>=8{return Ok(Some(u64::from_be_bytes(k[..8].try_into().unwrap())))} } Ok(None) }
    pub fn all(&self, cf_name:&str)->Result<Vec<(Vec<u8>,Vec<u8>)>> { let mut it=self.snapshot.iterator_cf(cf(self.db,cf_name)?,IteratorMode::Start); let mut out=Vec::new(); while let Some(item)=it.next(){let (k,v)=item?;out.push((k.to_vec(),v.to_vec()));} Ok(out) }
    pub fn prefix(&self, cf_name: &str, prefix: &[u8]) -> Result<Vec<(Vec<u8>,Vec<u8>)>> {
        let handle=cf(self.db,cf_name)?;
        let mut ro=ReadOptions::default(); ro.set_prefix_same_as_start(true);
        let mut it=self.snapshot.iterator_cf_opt(handle, ro, IteratorMode::From(prefix, Direction::Forward));
        let mut out=Vec::new();
        while let Some(item)=it.next() { let (k,v)=item?; if !k.starts_with(prefix) { break; } out.push((k.to_vec(),v.to_vec())); }
        Ok(out)
    }
}

pub struct WriteCtx<'a> { pub db: &'a DB, pub batch: &'a mut WriteBatch }
impl<'a> WriteCtx<'a> {
    pub fn put(&mut self, cf_name:&str, key:&[u8], value:&[u8]) -> Result<()> { self.batch.put_cf(cf(self.db,cf_name)?,key,value); Ok(()) }
    pub fn delete(&mut self, cf_name:&str, key:&[u8]) -> Result<()> { self.batch.delete_cf(cf(self.db,cf_name)?,key); Ok(()) }
    pub fn delete_prefix(&mut self, cf_name:&str, prefix:&[u8]) -> Result<()> { let rows=ReadDb::new(self.db).prefix(cf_name,prefix)?; for (k,_) in rows { self.delete(cf_name,&k)?; } Ok(()) }
}

pub fn encode_block(height:u64, prev:&[u8;32], work:&[u8;32], raw:&[u8]) -> Vec<u8> { let mut o=Vec::with_capacity(8+32+32+4+raw.len()); put_u64(height,&mut o); o.extend_from_slice(prev); o.extend_from_slice(work); put_bytes(raw,&mut o); o }
pub fn decode_block(v:&[u8])->Result<(u64,[u8;32],[u8;32],Vec<u8>)>{ let mut d=Decoder::new(v); Ok((d.u64()?,d.fixed()?,d.fixed()?,d.bytes()?)) }

pub fn encode_header(height:u64, prev:&[u8;32], time:u32, bits:u32, work:&[u8;32], raw:&[u8])->Vec<u8>{ let mut o=Vec::with_capacity(8+32+4+4+32+4+raw.len()); put_u64(height,&mut o); o.extend_from_slice(prev); put_u32(time,&mut o); put_u32(bits,&mut o); o.extend_from_slice(work); put_bytes(raw,&mut o); o }
pub fn decode_header(v:&[u8])->Result<(u64,[u8;32],u32,u32,[u8;32],Vec<u8>)>{let mut d=Decoder::new(v);Ok((d.u64()?,d.fixed()?,d.u32()?,d.u32()?,d.fixed()?,d.bytes()?))}

pub fn encode_tx(block_hash:&[u8;32], raw:&[u8])->Vec<u8>{let mut o=Vec::with_capacity(36+raw.len());o.extend_from_slice(block_hash);put_bytes(raw,&mut o);o}
pub fn decode_tx(v:&[u8])->Result<([u8;32],Vec<u8>)>{let mut d=Decoder::new(v);Ok((d.fixed()?,d.bytes()?))}

pub fn encode_utxo(value:i64, script:&[u8], height:u64, coinbase:bool, spent:Option<u64>)->Vec<u8>{let mut o=Vec::with_capacity(8+4+script.len()+8+1+8);put_i64(value,&mut o);put_u64(height,&mut o);o.push(coinbase as u8);put_i64(spent.map(|x|x as i64).unwrap_or(-1),&mut o);put_bytes(script,&mut o);o}
pub fn decode_utxo(v:&[u8])->Result<(i64,Vec<u8>,u64,bool,Option<u64>)>{let mut d=Decoder::new(v);let value=d.i64()?;let height=d.u64()?;let coinbase=d.u8()?!=0;let spent=d.i64()?;let script=d.bytes()?;Ok((value,script,height,coinbase,if spent<0{None}else{Some(spent as u64)}))}

pub fn encode_block_state(height:u64, root:&[u8;32], frontier:&[u8], sprout:i64, sapling:i64)->Vec<u8>{let mut o=Vec::new();put_u64(height,&mut o);o.extend_from_slice(root);put_i64(sprout,&mut o);put_i64(sapling,&mut o);put_bytes(frontier,&mut o);o}
pub fn decode_block_state(v:&[u8])->Result<(u64,[u8;32],i64,i64,Vec<u8>)>{let mut d=Decoder::new(v);Ok((d.u64()?,d.fixed()?,d.i64()?,d.i64()?,d.bytes()?))}
