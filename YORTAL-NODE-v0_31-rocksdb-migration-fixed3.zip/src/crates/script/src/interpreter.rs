//! Script evaluation, mirroring ycashd 4.5.0 `script/interpreter.cpp`
//! (`EvalScript`, `VerifyScript`, `TransactionSignatureChecker`).
//!
//! Zcash/Ycash differences from Bitcoin that matter here:
//! * OP_CODESEPARATOR is disabled, so scriptCode is always the whole script
//!   being executed and there is no FindAndDelete.
//! * Strict DER (BIP66) is always enforced, without a flag.
//! * Block validation uses exactly `SCRIPT_VERIFY_P2SH | SCRIPT_VERIFY_CHECKLOCKTIMEVERIFY`.

use crate::num::{ScriptNum, DEFAULT_MAX_NUM_SIZE};
use crate::opcodes::{self as op, get_op};
use crate::sighash::{signature_hash, PrecomputedTxData};
use ripemd::Ripemd160;
use sha1::Sha1;
use sha2::{Digest, Sha256};
use ycash_chain::ParsedTransaction;
use std::cell::RefCell;

pub const SCRIPT_VERIFY_NONE: u32 = 0;
pub const SCRIPT_VERIFY_P2SH: u32 = 1 << 0;
pub const SCRIPT_VERIFY_STRICTENC: u32 = 1 << 1;
pub const SCRIPT_VERIFY_NULLDUMMY: u32 = 1 << 4;
pub const SCRIPT_VERIFY_SIGPUSHONLY: u32 = 1 << 5;
pub const SCRIPT_VERIFY_MINIMALDATA: u32 = 1 << 6;
pub const SCRIPT_VERIFY_DISCOURAGE_UPGRADABLE_NOPS: u32 = 1 << 7;
pub const SCRIPT_VERIFY_CLEANSTACK: u32 = 1 << 8;
pub const SCRIPT_VERIFY_CHECKLOCKTIMEVERIFY: u32 = 1 << 9;

/// Flags `ConnectBlock` uses for every block.
pub const BLOCK_SCRIPT_VERIFY_FLAGS: u32 = SCRIPT_VERIFY_P2SH | SCRIPT_VERIFY_CHECKLOCKTIMEVERIFY;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ScriptError {
    Unknown,
    EvalFalse,
    OpReturn,
    ScriptSize,
    PushSize,
    OpCount,
    StackSize,
    SigCount,
    PubkeyCount,
    Verify,
    EqualVerify,
    CheckMultisigVerify,
    CheckSigVerify,
    NumEqualVerify,
    BadOpcode,
    DisabledOpcode,
    InvalidStackOperation,
    InvalidAltstackOperation,
    UnbalancedConditional,
    NegativeLocktime,
    UnsatisfiedLocktime,
    SigHashtype,
    SigDer,
    MinimalData,
    SigPushOnly,
    SigNullDummy,
    PubkeyType,
    CleanStack,
    DiscourageUpgradableNops,
}

pub trait SignatureChecker {
    fn check_sig(&self, sig: &[u8], pubkey: &[u8], script_code: &[u8]) -> bool;
    fn check_lock_time(&self, lock_time: i64) -> bool;
    fn script_timing_sink(&self) -> Option<&ScriptTimingSink> { None }
}

fn cast_to_bool(v: &[u8]) -> bool {
    for (i, b) in v.iter().enumerate() {
        if *b != 0 {
            // negative zero
            if i == v.len() - 1 && *b == 0x80 {
                return false;
            }
            return true;
        }
    }
    false
}

fn need(len: usize, n: usize) -> Result<(), ScriptError> {
    if len < n { Err(ScriptError::InvalidStackOperation) } else { Ok(()) }
}

fn num(v: &[u8], require_minimal: bool) -> Result<ScriptNum, ScriptError> {
    ScriptNum::from_bytes(v, require_minimal, DEFAULT_MAX_NUM_SIZE).map_err(|_| ScriptError::Unknown)
}

fn bool_vec(b: bool) -> Vec<u8> {
    if b { vec![1] } else { Vec::new() }
}

fn is_compressed_or_uncompressed_pubkey(pk: &[u8]) -> bool {
    if pk.len() < 33 {
        return false;
    }
    match pk[0] {
        0x04 => pk.len() == 65,
        0x02 | 0x03 => pk.len() == 33,
        _ => false,
    }
}

/// BIP66 strict DER, including the trailing hashtype byte.
pub fn is_valid_signature_encoding(sig: &[u8]) -> bool {
    if sig.len() < 9 || sig.len() > 73 { return false; }
    if sig[0] != 0x30 { return false; }
    if sig[1] as usize != sig.len() - 3 { return false; }
    let len_r = sig[3] as usize;
    if 5 + len_r >= sig.len() { return false; }
    let len_s = sig[5 + len_r] as usize;
    if len_r + len_s + 7 != sig.len() { return false; }
    if sig[2] != 0x02 { return false; }
    if len_r == 0 { return false; }
    if sig[4] & 0x80 != 0 { return false; }
    if len_r > 1 && sig[4] == 0x00 && sig[5] & 0x80 == 0 { return false; }
    if sig[len_r + 4] != 0x02 { return false; }
    if len_s == 0 { return false; }
    if sig[len_r + 6] & 0x80 != 0 { return false; }
    if len_s > 1 && sig[len_r + 6] == 0x00 && sig[len_r + 7] & 0x80 == 0 { return false; }
    true
}

fn is_defined_hashtype_signature(sig: &[u8]) -> bool {
    if sig.is_empty() { return false; }
    let t = sig[sig.len() - 1] & !(0x80u8);
    (1..=3).contains(&t)
}

fn check_signature_encoding(sig: &[u8], flags: u32) -> Result<(), ScriptError> {
    if sig.is_empty() {
        return Ok(());
    }
    if !is_valid_signature_encoding(sig) {
        return Err(ScriptError::SigDer);
    }
    if flags & SCRIPT_VERIFY_STRICTENC != 0 && !is_defined_hashtype_signature(sig) {
        return Err(ScriptError::SigHashtype);
    }
    Ok(())
}

fn check_pubkey_encoding(pk: &[u8], flags: u32) -> Result<(), ScriptError> {
    if flags & SCRIPT_VERIFY_STRICTENC != 0 && !is_compressed_or_uncompressed_pubkey(pk) {
        return Err(ScriptError::PubkeyType);
    }
    Ok(())
}

fn check_minimal_push(data: &[u8], opcode: u8) -> bool {
    if data.is_empty() {
        opcode == op::OP_0
    } else if data.len() == 1 && data[0] >= 1 && data[0] <= 16 {
        opcode == op::OP_1 + (data[0] - 1)
    } else if data.len() == 1 && data[0] == 0x81 {
        opcode == op::OP_1NEGATE
    } else if data.len() <= 75 {
        opcode as usize == data.len()
    } else if data.len() <= 255 {
        opcode == op::OP_PUSHDATA1
    } else if data.len() <= 65535 {
        opcode == op::OP_PUSHDATA2
    } else {
        true
    }
}

fn is_disabled(opcode: u8) -> bool {
    matches!(
        opcode,
        op::OP_CAT | op::OP_SUBSTR | op::OP_LEFT | op::OP_RIGHT | op::OP_INVERT | op::OP_AND | op::OP_OR
            | op::OP_XOR | op::OP_2MUL | op::OP_2DIV | op::OP_MUL | op::OP_DIV | op::OP_MOD
            | op::OP_LSHIFT | op::OP_RSHIFT | op::OP_CODESEPARATOR
    )
}

pub fn eval_script(
    stack: &mut Vec<Vec<u8>>,
    script: &[u8],
    flags: u32,
    checker: &dyn SignatureChecker,
) -> Result<(), ScriptError> {
    if script.len() > op::MAX_SCRIPT_SIZE {
        return Err(ScriptError::ScriptSize);
    }
    let mut pc = 0usize;
    let mut vf_exec: Vec<bool> = Vec::new();
    let mut altstack: Vec<Vec<u8>> = Vec::new();
    let mut n_op_count: i32 = 0;
    let rm = flags & SCRIPT_VERIFY_MINIMALDATA != 0;

    while pc < script.len() {
        let f_exec = !vf_exec.iter().any(|v| !*v);

        let parse_started = std::time::Instant::now();
        let (opcode, push) = get_op(script, &mut pc).ok_or(ScriptError::BadOpcode)?;
        let parse_us = parse_started.elapsed().as_micros() as u64;
        if let Some(sink) = checker.script_timing_sink() {
            sink.add(|t| t.script_parsing_us = t.script_parsing_us.saturating_add(parse_us));
        }
        let exec_started = std::time::Instant::now();
        let exec_timing_before = checker.script_timing_sink().map(|s| s.snapshot());
        if push.len() > op::MAX_SCRIPT_ELEMENT_SIZE {
            return Err(ScriptError::PushSize);
        }
        // OP_RESERVED does not count towards the opcode limit.
        if opcode > op::OP_16 {
            n_op_count += 1;
            if n_op_count > op::MAX_OPS_PER_SCRIPT {
                return Err(ScriptError::OpCount);
            }
        }
        if is_disabled(opcode) {
            return Err(ScriptError::DisabledOpcode);
        }

        if f_exec && opcode <= op::OP_PUSHDATA4 {
            if rm && !check_minimal_push(push, opcode) {
                return Err(ScriptError::MinimalData);
            }
            stack.push(push.to_vec());
        } else if f_exec || (op::OP_IF <= opcode && opcode <= op::OP_ENDIF) {
            match opcode {
                op::OP_1NEGATE | op::OP_1..=op::OP_16 => {
                    let n = opcode as i64 - (op::OP_1 as i64 - 1);
                    stack.push(ScriptNum(n).to_bytes());
                }
                op::OP_NOP => {}
                op::OP_CHECKLOCKTIMEVERIFY => {
                    if flags & SCRIPT_VERIFY_CHECKLOCKTIMEVERIFY == 0 {
                        if flags & SCRIPT_VERIFY_DISCOURAGE_UPGRADABLE_NOPS != 0 {
                            return Err(ScriptError::DiscourageUpgradableNops);
                        }
                    } else {
                        need(stack.len(), 1)?;
                        let lock_time = ScriptNum::from_bytes(&stack[stack.len() - 1], rm, 5)
                            .map_err(|_| ScriptError::Unknown)?;
                        if lock_time.0 < 0 {
                            return Err(ScriptError::NegativeLocktime);
                        }
                        if !checker.check_lock_time(lock_time.0) {
                            return Err(ScriptError::UnsatisfiedLocktime);
                        }
                    }
                }
                op::OP_NOP1 | op::OP_NOP3 | op::OP_NOP4 | op::OP_NOP5 | op::OP_NOP6 | op::OP_NOP7
                | op::OP_NOP8 | op::OP_NOP9 | op::OP_NOP10 => {
                    if flags & SCRIPT_VERIFY_DISCOURAGE_UPGRADABLE_NOPS != 0 {
                        return Err(ScriptError::DiscourageUpgradableNops);
                    }
                }
                op::OP_IF | op::OP_NOTIF => {
                    let mut value = false;
                    if f_exec {
                        if stack.is_empty() {
                            return Err(ScriptError::UnbalancedConditional);
                        }
                        value = cast_to_bool(&stack[stack.len() - 1]);
                        if opcode == op::OP_NOTIF {
                            value = !value;
                        }
                        stack.pop();
                    }
                    vf_exec.push(value);
                }
                op::OP_ELSE => {
                    match vf_exec.last_mut() {
                        Some(v) => *v = !*v,
                        None => return Err(ScriptError::UnbalancedConditional),
                    }
                }
                op::OP_ENDIF => {
                    if vf_exec.pop().is_none() {
                        return Err(ScriptError::UnbalancedConditional);
                    }
                }
                op::OP_VERIFY => {
                    need(stack.len(), 1)?;
                    if cast_to_bool(&stack[stack.len() - 1]) {
                        stack.pop();
                    } else {
                        return Err(ScriptError::Verify);
                    }
                }
                op::OP_RETURN => return Err(ScriptError::OpReturn),
                op::OP_TOALTSTACK => {
                    need(stack.len(), 1)?;
                    let v = stack.pop().unwrap();
                    altstack.push(v);
                }
                op::OP_FROMALTSTACK => {
                    match altstack.pop() {
                        Some(v) => stack.push(v),
                        None => return Err(ScriptError::InvalidAltstackOperation),
                    }
                }
                op::OP_2DROP => {
                    need(stack.len(), 2)?;
                    stack.pop();
                    stack.pop();
                }
                op::OP_2DUP => {
                    need(stack.len(), 2)?;
                    let l = stack.len();
                    let (a, b) = (stack[l - 2].clone(), stack[l - 1].clone());
                    stack.push(a);
                    stack.push(b);
                }
                op::OP_3DUP => {
                    need(stack.len(), 3)?;
                    let l = stack.len();
                    let (a, b, c) = (stack[l - 3].clone(), stack[l - 2].clone(), stack[l - 1].clone());
                    stack.push(a);
                    stack.push(b);
                    stack.push(c);
                }
                op::OP_2OVER => {
                    need(stack.len(), 4)?;
                    let l = stack.len();
                    let (a, b) = (stack[l - 4].clone(), stack[l - 3].clone());
                    stack.push(a);
                    stack.push(b);
                }
                op::OP_2ROT => {
                    need(stack.len(), 6)?;
                    let l = stack.len();
                    let (a, b) = (stack[l - 6].clone(), stack[l - 5].clone());
                    stack.drain(l - 6..l - 4).for_each(drop);
                    stack.push(a);
                    stack.push(b);
                }
                op::OP_2SWAP => {
                    need(stack.len(), 4)?;
                    let l = stack.len();
                    stack.swap(l - 4, l - 2);
                    stack.swap(l - 3, l - 1);
                }
                op::OP_IFDUP => {
                    need(stack.len(), 1)?;
                    let v = stack[stack.len() - 1].clone();
                    if cast_to_bool(&v) {
                        stack.push(v);
                    }
                }
                op::OP_DEPTH => {
                    let n = ScriptNum(stack.len() as i64);
                    stack.push(n.to_bytes());
                }
                op::OP_DROP => {
                    need(stack.len(), 1)?;
                    stack.pop();
                }
                op::OP_DUP => {
                    need(stack.len(), 1)?;
                    let v = stack[stack.len() - 1].clone();
                    stack.push(v);
                }
                op::OP_NIP => {
                    need(stack.len(), 2)?;
                    let l = stack.len();
                    stack.remove(l - 2);
                }
                op::OP_OVER => {
                    need(stack.len(), 2)?;
                    let v = stack[stack.len() - 2].clone();
                    stack.push(v);
                }
                op::OP_PICK | op::OP_ROLL => {
                    need(stack.len(), 2)?;
                    let n = num(&stack[stack.len() - 1], rm)?.getint();
                    stack.pop();
                    if n < 0 || n as usize >= stack.len() {
                        return Err(ScriptError::InvalidStackOperation);
                    }
                    let idx = stack.len() - (n as usize) - 1;
                    let v = stack[idx].clone();
                    if opcode == op::OP_ROLL {
                        stack.remove(idx);
                    }
                    stack.push(v);
                }
                op::OP_ROT => {
                    need(stack.len(), 3)?;
                    let l = stack.len();
                    stack.swap(l - 3, l - 2);
                    stack.swap(l - 2, l - 1);
                }
                op::OP_SWAP => {
                    need(stack.len(), 2)?;
                    let l = stack.len();
                    stack.swap(l - 2, l - 1);
                }
                op::OP_TUCK => {
                    need(stack.len(), 2)?;
                    let l = stack.len();
                    let v = stack[l - 1].clone();
                    stack.insert(l - 2, v);
                }
                op::OP_SIZE => {
                    need(stack.len(), 1)?;
                    let n = ScriptNum(stack[stack.len() - 1].len() as i64);
                    stack.push(n.to_bytes());
                }
                op::OP_EQUAL | op::OP_EQUALVERIFY => {
                    need(stack.len(), 2)?;
                    let b = stack.pop().unwrap();
                    let a = stack.pop().unwrap();
                    let equal = a == b;
                    stack.push(bool_vec(equal));
                    if opcode == op::OP_EQUALVERIFY {
                        if equal {
                            stack.pop();
                        } else {
                            return Err(ScriptError::EqualVerify);
                        }
                    }
                }
                op::OP_1ADD | op::OP_1SUB | op::OP_NEGATE | op::OP_ABS | op::OP_NOT | op::OP_0NOTEQUAL => {
                    need(stack.len(), 1)?;
                    let bn = num(&stack[stack.len() - 1], rm)?.0;
                    let r = match opcode {
                        op::OP_1ADD => bn + 1,
                        op::OP_1SUB => bn - 1,
                        op::OP_NEGATE => -bn,
                        op::OP_ABS => bn.abs(),
                        op::OP_NOT => (bn == 0) as i64,
                        _ => (bn != 0) as i64,
                    };
                    stack.pop();
                    stack.push(ScriptNum(r).to_bytes());
                }
                op::OP_ADD | op::OP_SUB | op::OP_BOOLAND | op::OP_BOOLOR | op::OP_NUMEQUAL
                | op::OP_NUMEQUALVERIFY | op::OP_NUMNOTEQUAL | op::OP_LESSTHAN | op::OP_GREATERTHAN
                | op::OP_LESSTHANOREQUAL | op::OP_GREATERTHANOREQUAL | op::OP_MIN | op::OP_MAX => {
                    need(stack.len(), 2)?;
                    let l = stack.len();
                    let bn1 = num(&stack[l - 2], rm)?.0;
                    let bn2 = num(&stack[l - 1], rm)?.0;
                    let r = match opcode {
                        op::OP_ADD => bn1 + bn2,
                        op::OP_SUB => bn1 - bn2,
                        op::OP_BOOLAND => (bn1 != 0 && bn2 != 0) as i64,
                        op::OP_BOOLOR => (bn1 != 0 || bn2 != 0) as i64,
                        op::OP_NUMEQUAL | op::OP_NUMEQUALVERIFY => (bn1 == bn2) as i64,
                        op::OP_NUMNOTEQUAL => (bn1 != bn2) as i64,
                        op::OP_LESSTHAN => (bn1 < bn2) as i64,
                        op::OP_GREATERTHAN => (bn1 > bn2) as i64,
                        op::OP_LESSTHANOREQUAL => (bn1 <= bn2) as i64,
                        op::OP_GREATERTHANOREQUAL => (bn1 >= bn2) as i64,
                        op::OP_MIN => bn1.min(bn2),
                        _ => bn1.max(bn2),
                    };
                    stack.pop();
                    stack.pop();
                    stack.push(ScriptNum(r).to_bytes());
                    if opcode == op::OP_NUMEQUALVERIFY {
                        if cast_to_bool(&stack[stack.len() - 1]) {
                            stack.pop();
                        } else {
                            return Err(ScriptError::NumEqualVerify);
                        }
                    }
                }
                op::OP_WITHIN => {
                    need(stack.len(), 3)?;
                    let l = stack.len();
                    let bn1 = num(&stack[l - 3], rm)?.0;
                    let bn2 = num(&stack[l - 2], rm)?.0;
                    let bn3 = num(&stack[l - 1], rm)?.0;
                    let value = bn2 <= bn1 && bn1 < bn3;
                    stack.pop();
                    stack.pop();
                    stack.pop();
                    stack.push(bool_vec(value));
                }
                op::OP_RIPEMD160 | op::OP_SHA1 | op::OP_SHA256 | op::OP_HASH160 | op::OP_HASH256 => {
                    need(stack.len(), 1)?;
                    let v = stack.pop().unwrap();
                    let h: Vec<u8> = match opcode {
                        op::OP_RIPEMD160 => Ripemd160::digest(&v).to_vec(),
                        op::OP_SHA1 => Sha1::digest(&v).to_vec(),
                        op::OP_SHA256 => Sha256::digest(&v).to_vec(),
                        op::OP_HASH160 => Ripemd160::digest(Sha256::digest(&v)).to_vec(),
                        _ => Sha256::digest(Sha256::digest(&v)).to_vec(),
                    };
                    stack.push(h);
                }
                op::OP_CHECKSIG | op::OP_CHECKSIGVERIFY => {
                    need(stack.len(), 2)?;
                    let l = stack.len();
                    check_signature_encoding(&stack[l - 2], flags)?;
                    check_pubkey_encoding(&stack[l - 1], flags)?;
                    let success = checker.check_sig(&stack[l - 2], &stack[l - 1], script);
                    stack.pop();
                    stack.pop();
                    stack.push(bool_vec(success));
                    if opcode == op::OP_CHECKSIGVERIFY {
                        if success {
                            stack.pop();
                        } else {
                            return Err(ScriptError::CheckSigVerify);
                        }
                    }
                }
                op::OP_CHECKMULTISIG | op::OP_CHECKMULTISIGVERIFY => {
                    let mut i: usize = 1;
                    need(stack.len(), i)?;
                    let mut n_keys = num(&stack[stack.len() - i], rm)?.getint();
                    if n_keys < 0 || n_keys > op::MAX_PUBKEYS_PER_MULTISIG {
                        return Err(ScriptError::PubkeyCount);
                    }
                    n_op_count += n_keys;
                    if n_op_count > op::MAX_OPS_PER_SCRIPT {
                        return Err(ScriptError::OpCount);
                    }
                    i += 1;
                    let mut ikey = i;
                    i += n_keys as usize;
                    need(stack.len(), i)?;
                    let mut n_sigs = num(&stack[stack.len() - i], rm)?.getint();
                    if n_sigs < 0 || n_sigs > n_keys {
                        return Err(ScriptError::SigCount);
                    }
                    i += 1;
                    let mut isig = i;
                    i += n_sigs as usize;
                    need(stack.len(), i)?;

                    let l = stack.len();
                    let mut success = true;
                    while success && n_sigs > 0 {
                        let sig = &stack[l - isig];
                        let pubkey = &stack[l - ikey];
                        check_signature_encoding(sig, flags)?;
                        check_pubkey_encoding(pubkey, flags)?;
                        if checker.check_sig(sig, pubkey, script) {
                            isig += 1;
                            n_sigs -= 1;
                        }
                        ikey += 1;
                        n_keys -= 1;
                        if n_sigs > n_keys {
                            success = false;
                        }
                    }
                    // Pop keys count, keys, sigs count and sigs (i - 1 items).
                    for _ in 1..i {
                        stack.pop();
                    }
                    // The extra (dummy) element from the original CHECKMULTISIG bug.
                    if stack.is_empty() {
                        return Err(ScriptError::InvalidStackOperation);
                    }
                    if flags & SCRIPT_VERIFY_NULLDUMMY != 0 && !stack[stack.len() - 1].is_empty() {
                        return Err(ScriptError::SigNullDummy);
                    }
                    stack.pop();
                    stack.push(bool_vec(success));
                    if opcode == op::OP_CHECKMULTISIGVERIFY {
                        if success {
                            stack.pop();
                        } else {
                            return Err(ScriptError::CheckMultisigVerify);
                        }
                    }
                }
                _ => return Err(ScriptError::BadOpcode),
            }
        }

        if stack.len() + altstack.len() > op::MAX_STACK_SIZE {
            return Err(ScriptError::StackSize);
        }
        if let Some(sink) = checker.script_timing_sink() {
            let exec_us = exec_started.elapsed().as_micros() as u64;
            let before = exec_timing_before.unwrap_or_default();
            let after = sink.snapshot();
            let crypto_us = after.signature_hash_preparation_us
                .saturating_sub(before.signature_hash_preparation_us)
                .saturating_add(after.ecdsa_verification_us.saturating_sub(before.ecdsa_verification_us));
            sink.add(|t| {
                t.script_interpreter_us = t.script_interpreter_us
                    .saturating_add(exec_us.saturating_sub(crypto_us.min(exec_us)));
            });
        }
    }

    if !vf_exec.is_empty() {
        return Err(ScriptError::UnbalancedConditional);
    }
    Ok(())
}

pub fn verify_script(
    script_sig: &[u8],
    script_pubkey: &[u8],
    flags: u32,
    checker: &dyn SignatureChecker,
) -> Result<(), ScriptError> {
    if flags & SCRIPT_VERIFY_SIGPUSHONLY != 0 && !crate::sigops::is_push_only(script_sig) {
        return Err(ScriptError::SigPushOnly);
    }
    let mut stack: Vec<Vec<u8>> = Vec::new();
    eval_script(&mut stack, script_sig, flags, checker)?;
    let stack_copy = if flags & SCRIPT_VERIFY_P2SH != 0 { stack.clone() } else { Vec::new() };
    eval_script(&mut stack, script_pubkey, flags, checker)?;
    match stack.last() {
        Some(top) if cast_to_bool(top) => {}
        _ => return Err(ScriptError::EvalFalse),
    }

    if flags & SCRIPT_VERIFY_P2SH != 0 && crate::sigops::is_pay_to_script_hash(script_pubkey) {
        if !crate::sigops::is_push_only(script_sig) {
            return Err(ScriptError::SigPushOnly);
        }
        stack = stack_copy;
        // Cannot be empty: the P2SH scriptPubKey needs at least one element
        // to have evaluated true above.
        let redeem = stack.pop().ok_or(ScriptError::Unknown)?;
        eval_script(&mut stack, &redeem, flags, checker)?;
        match stack.last() {
            Some(top) if cast_to_bool(top) => {}
            _ => return Err(ScriptError::EvalFalse),
        }
    }

    if flags & SCRIPT_VERIFY_CLEANSTACK != 0 && stack.len() != 1 {
        return Err(ScriptError::CleanStack);
    }
    // Script parsing and opcode execution are instrumented inside eval_script;
    // signature hashing and ECDSA are instrumented by TransactionChecker.
    // Keeping these measurements at their natural call sites avoids double-counting.
    Ok(())
}

/// `CPubKey(vch).IsValid()`: header byte implies a length and it matches.
fn pubkey_is_valid(pk: &[u8]) -> bool {
    if pk.is_empty() {
        return false;
    }
    let expected = match pk[0] {
        0x02 | 0x03 => 33,
        0x04 | 0x06 | 0x07 => 65,
        _ => return false,
    };
    pk.len() == expected
}

/// `CPubKey::Verify`: libsecp256k1 pubkey parse (accepts hybrid keys),
/// strict DER parse, normalise to low-S, verify.
pub fn ecdsa_verify(pubkey: &[u8], der_sig: &[u8], hash: &[u8; 32]) -> bool {
    use secp256k1::{ecdsa::Signature, Message, PublicKey, Secp256k1, VerifyOnly};
    use std::sync::OnceLock;
    static CTX: OnceLock<Secp256k1<VerifyOnly>> = OnceLock::new();
    let secp = CTX.get_or_init(Secp256k1::verification_only);

    let pk = match PublicKey::from_slice(pubkey) {
        Ok(pk) => pk,
        Err(_) => return false,
    };
    if der_sig.is_empty() {
        return false;
    }
    let mut sig = match Signature::from_der(der_sig) {
        Ok(s) => s,
        Err(_) => return false,
    };
    sig.normalize_s();
    let msg = match Message::from_digest_slice(hash) {
        Ok(m) => m,
        Err(_) => return false,
    };
    secp.verify_ecdsa(&msg, &sig, &pk).is_ok()
}


/// Fine-grained, non-consensus telemetry for transparent script verification.
/// All fields are diagnostic only and are deliberately kept out of the
/// consensus decision path. Timings are wall-clock microseconds for the
/// current input/checker invocation.
#[derive(Clone, Copy, Debug, Default)]
pub struct ScriptVerifyTiming {
    pub transaction_input_extraction_us: u64,
    pub script_sig_construction_us: u64,
    pub script_pubkey_retrieval_us: u64,
    pub script_parsing_us: u64,
    pub signature_hash_preparation_us: u64,
    pub ecdsa_verification_us: u64,
    pub script_interpreter_us: u64,
    pub cache_lookup_us: u64,
    pub synchronization_us: u64,
    pub signature_hash_calls: u64,
    pub ecdsa_calls: u64,
}

pub struct ScriptTimingSink {
    timing: RefCell<ScriptVerifyTiming>,
}

impl ScriptTimingSink {
    pub fn new() -> Self {
        Self { timing: RefCell::new(ScriptVerifyTiming::default()) }
    }

    pub fn snapshot(&self) -> ScriptVerifyTiming {
        *self.timing.borrow()
    }

    fn add<F: FnOnce(&mut ScriptVerifyTiming)>(&self, f: F) {
        f(&mut self.timing.borrow_mut());
    }
}

impl Default for ScriptTimingSink {
    fn default() -> Self { Self::new() }
}

/// `TransactionSignatureChecker` for input `n_in` of `tx`.
pub struct TransactionChecker<'a> {
    pub tx: &'a ParsedTransaction,
    pub n_in: usize,
    pub amount: i64,
    pub consensus_branch_id: u32,
    pub precomputed: Option<&'a PrecomputedTxData>,
    /// Optional diagnostic sink; None keeps the legacy zero-overhead path.
    pub timing: Option<&'a ScriptTimingSink>,
}

impl SignatureChecker for TransactionChecker<'_> {
    fn check_sig(&self, sig_in: &[u8], pubkey: &[u8], script_code: &[u8]) -> bool {
        let pubkey_started = std::time::Instant::now();
        if !pubkey_is_valid(pubkey) {
            return false;
        }
        let pubkey_us = pubkey_started.elapsed().as_micros() as u64;
        let Some((&hash_type, sig)) = sig_in.split_last() else { return false };
        let cache_lookup_started = std::time::Instant::now();
        let _has_precomputed = self.precomputed.is_some();
        let cache_lookup_us = cache_lookup_started.elapsed().as_micros() as u64;
        let prep_started = std::time::Instant::now();
        let hash = match signature_hash(
            self.tx,
            script_code,
            Some(self.n_in),
            hash_type as u32,
            self.amount,
            self.consensus_branch_id,
            self.precomputed,
        ) {
            Some(h) => h,
            None => return false,
        };
        let prep_us = prep_started.elapsed().as_micros() as u64;
        let ecdsa_started = std::time::Instant::now();
        let ok = ecdsa_verify(pubkey, sig, &hash);
        let ecdsa_us = ecdsa_started.elapsed().as_micros() as u64;
        if let Some(sink) = self.timing {
            // The immutable precomputed-tx cache selection is timed separately;
            // actual signature hashing remains attributed to hash preparation.
            // The scriptPubKey bytes themselves are retrieved by the state/UTXO
            // layer before this function; pubkey validation is included here as
            // the local key-material preparation cost.
            sink.add(|t| {
                t.script_pubkey_retrieval_us = t.script_pubkey_retrieval_us.saturating_add(pubkey_us);
                t.signature_hash_preparation_us = t.signature_hash_preparation_us.saturating_add(prep_us);
                t.cache_lookup_us = t.cache_lookup_us.saturating_add(cache_lookup_us);
                t.ecdsa_verification_us = t.ecdsa_verification_us.saturating_add(ecdsa_us);
                t.signature_hash_calls = t.signature_hash_calls.saturating_add(1);
                t.ecdsa_calls = t.ecdsa_calls.saturating_add(1);
            });
        }
        ok
    }

    fn script_timing_sink(&self) -> Option<&ScriptTimingSink> {
        self.timing
    }

    fn check_lock_time(&self, lock_time: i64) -> bool {
        let tx_lock_time = self.tx.lock_time as i64;
        let same_kind = (tx_lock_time < op::LOCKTIME_THRESHOLD && lock_time < op::LOCKTIME_THRESHOLD)
            || (tx_lock_time >= op::LOCKTIME_THRESHOLD && lock_time >= op::LOCKTIME_THRESHOLD);
        if !same_kind {
            return false;
        }
        if lock_time > tx_lock_time {
            return false;
        }
        // A final input would make nLockTime unenforced, so CLTV fails.
        if self.tx.vin[self.n_in].sequence == 0xffff_ffff {
            return false;
        }
        true
    }
}
