//! Ycash transparent consensus: script interpreter, signature hashing and
//! sigop counting. A from-scratch Rust implementation that follows ycashd
//! 4.5.0 behaviour; it does not link or embed ycashd.

pub mod interpreter;
pub mod num;
pub mod opcodes;
pub mod sighash;
pub mod sigops;

pub use interpreter::{
    ecdsa_verify, eval_script, verify_script, ScriptError, ScriptTimingSink, ScriptVerifyTiming,
    SignatureChecker, TransactionChecker, BLOCK_SCRIPT_VERIFY_FLAGS,
    SCRIPT_VERIFY_CHECKLOCKTIMEVERIFY, SCRIPT_VERIFY_P2SH,
};
pub use sighash::{signature_hash, PrecomputedTxData, SIGHASH_ALL, SIGHASH_ANYONECANPAY, SIGHASH_NONE, SIGHASH_SINGLE};
pub use sigops::{is_pay_to_script_hash, is_push_only, is_unspendable, legacy_sig_op_count, p2sh_sig_op_count, sig_op_count};

#[cfg(test)]
mod tests {
    use super::*;

    struct NoSig;
    impl SignatureChecker for NoSig {
        fn check_sig(&self, _: &[u8], _: &[u8], _: &[u8]) -> bool { false }
        fn check_lock_time(&self, _: i64) -> bool { false }
    }

    fn run(sig: &[u8], pk: &[u8]) -> Result<(), ScriptError> {
        verify_script(sig, pk, BLOCK_SCRIPT_VERIFY_FLAGS, &NoSig)
    }

    #[test]
    fn arithmetic_and_flow() {
        use opcodes::*;
        // 2 3 ADD 5 EQUAL
        assert!(run(&[OP_1 + 1, OP_1 + 2], &[OP_ADD, OP_1 + 4, OP_EQUAL]).is_ok());
        // 1 IF 0 ELSE 1 ENDIF
        assert!(run(&[OP_1], &[OP_IF, OP_0, OP_ELSE, OP_1, OP_ENDIF]).is_err());
        assert!(run(&[OP_0], &[OP_IF, OP_0, OP_ELSE, OP_1, OP_ENDIF]).is_ok());
        // disabled opcode fails even in an unexecuted branch
        assert_eq!(run(&[OP_0], &[OP_IF, OP_CAT, OP_ENDIF, OP_1]), Err(ScriptError::DisabledOpcode));
        // OP_RETURN
        assert_eq!(run(&[OP_1], &[OP_RETURN]), Err(ScriptError::OpReturn));
        // 1-of-1 multisig with a failing checker leaves false on the stack
        assert_eq!(
            run(&[OP_0, 0x01, 0x30], &[OP_1, 0x01, 0x02, OP_1, OP_CHECKMULTISIG]),
            Err(ScriptError::SigDer)
        );
    }

    #[test]
    fn p2sh_sigops() {
        use opcodes::*;
        let redeem = [OP_1 + 1, OP_CHECKMULTISIG];
        let mut spk = vec![OP_HASH160, 0x14];
        spk.extend_from_slice(&[0u8; 20]);
        spk.push(OP_EQUAL);
        let script_sig = [redeem.len() as u8, redeem[0], redeem[1]];
        assert_eq!(p2sh_sig_op_count(&spk, &script_sig), 2);
        assert_eq!(sig_op_count(&redeem, false), 20);
    }
}
