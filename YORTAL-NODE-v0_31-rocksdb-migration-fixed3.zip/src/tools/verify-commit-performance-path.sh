#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
state="$ROOT/crates/state/src/chainstate.rs"
lib="$ROOT/crates/state/src/lib.rs"
pipeline="$ROOT/crates/ycash-android-node/src/pipeline_sync.rs"
runtime="$ROOT/crates/ycash-android-node/src/runtime.rs"
main="$ROOT/crates/ycash-android-node/src/main.rs"
service="$ROOT/android-app/app/src/main/java/com/ycash/androidnode/NodeService.java"

[[ -f "$state" && -f "$lib" && -f "$pipeline" && -f "$runtime" && -f "$main" && -f "$service" ]]
grep -q 'OnceLock<rayon::ThreadPool>' "$state"
grep -q 'ScriptPermit::acquire' "$state"
grep -q 'pub fn script_worker_budget' "$state"
grep -q 'script_permit_wait_us' "$state"
grep -q 'script_active_peak' "$state"
grep -q 'script_scheduler_gap_us' "$state"
grep -q 'pub fn prefetch' "$state"
grep -q 'const CHUNK: usize = 64' "$state"
grep -q 'struct UtxoCache' "$state"
grep -q 'VecDeque<OutPoint>' "$state"
grep -q 'Arc::make_mut' "$lib"
grep -q 'update_commit_cpu_budget' "$pipeline"
grep -q 'script_worker_budget()' "$pipeline"
grep -q 'pipeline_script_budget' "$runtime"
grep -q 'pipeline_script_pool_threads' "$runtime"
grep -q 'last_script_permit_wait_us' "$runtime"
grep -q 'last_script_active_peak' "$runtime"
grep -q 'last_script_scheduler_gap_us' "$main"
grep -q 'SCRIPT_WORKERS' "$service"
if grep -q 'std::thread::scope' "$state"; then
  echo 'ERROR: per-transaction OS thread spawning remains in script verifier' >&2
  exit 1
fi
if grep -q 'new_utxos.extend(old.utxos.iter' "$lib"; then
  echo 'ERROR: full 50k-entry cache clone remains in commit publication' >&2
  exit 1
fi
grep -Eq '^max_range_len[[:space:]]*=[[:space:]]*100([[:space:]]*(#.*)?)?$' "$ROOT/config/pipeline.toml"
echo 'PASS: v0.30.9 prepared-commit CPU, UTXO read/cache, and telemetry path checks present'
