#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "[rocksdb] checking dependency migration"
grep -q 'rocksdb = ' Cargo.toml
! grep -RqiE 'rusqlite|sqlite|SQLITE' crates/state crates/ycash-android-node/src android-app/app/src/main/java/com/ycash/androidnode --include='*.rs' --include='*.java'
grep -q 'CF_UTXOS' crates/state/src/rocks_backend.rs
grep -q 'CF_SAPLING_ROOT_INDEX' crates/state/src/rocks_backend.rs
grep -q 'CF_SPROUT_ROOT_INDEX' crates/state/src/rocks_backend.rs
grep -q 'WriteBatch' crates/state/src/lib.rs
grep -q 'snapshot' crates/state/src/rocks_backend.rs
grep -q 'set_sync' crates/state/src/lib.rs
grep -q 'ycash-node.rocksdb' crates/ycash-android-node/src/main.rs

echo "[rocksdb] checking ordered commit boundary"
grep -q 'pub fn prepare_commit_batch' crates/state/src/lib.rs
grep -q 'pub fn apply_prepared_commit' crates/state/src/lib.rs
grep -q 'self.db.write_opt' crates/state/src/lib.rs

echo "[rocksdb] migration verification passed"
