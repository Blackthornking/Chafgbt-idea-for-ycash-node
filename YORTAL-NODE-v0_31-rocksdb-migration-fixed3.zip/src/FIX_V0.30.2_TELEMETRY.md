# YORTAL v0.30.2 — dashboard telemetry fix

## Symptom
Live throughput stuck at "—", bottleneck stuck on "waiting for commit telemetry",
state breakdown never filled, P2P/RPC/API all shown DOWN, connection "None" —
while height, peers and range counters did update.

## Cause
`MainActivity.applyStatus()` built the bottleneck line with `%.1f%%`, but the
argument came from `pct()`, which already returns a String. As soon as the first
commit reported `last_state_validation_us > 0`, `String.format` threw
`IllegalFormatConversionException`. The exception was swallowed by
`catch(Exception ignored){}`, so every poll aborted halfway: everything after that
line (breakdown, commit line, network panel) was never set, and `lastPollAt` was
never saved, so rates could never be computed.

## Fix
- Bottleneck format uses `%s` for the percentage.
- The catch block now logs to logcat and shows the error in the status line
  instead of hiding it.
- versionCode 302 / versionName 0.30.2-node.

No Rust / consensus changes.
