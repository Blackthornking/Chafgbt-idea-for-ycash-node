# YORTAL v0.30.9 prepared-commit pipeline fix

## Implemented

- Consensus preparation remains in `State::prepare_commit_batch()` and the canonical write remains in `State::apply_prepared_commit()`. No consensus ordering was changed.
- The adaptive controller no longer treats total consensus/state-preparation time as database pressure. Android now measures DB pressure only from the actual RocksDB write + RocksDB WRITE critical section.
- The post-commit feedback loop no longer immediately feeds the just-finished full commit duration back into the adaptive controller. The 500 ms sampler is the single adaptation path.
- During ordered state preparation, the permanent commit worker gets an explicit CPU slot; one verifier worker remains active and the persistent script pool receives the remaining CPU budget. This prevents the previous `7 verifier + 1 script` inversion on an 8-core device.
- The stage-aware CPU split is held for the whole prepare/apply operation so the adaptive sampler cannot overwrite it halfway through a batch. It is restored to the controller's current worker budget after success or retry.
- Dashboard `active_block_workers` now reports the actual worker gate rather than only the controller's desired worker count.
- Commit linger defaults to 50 ms (configurable through `YORTAL_COMMIT_LINGER_MS` / `commit_linger_ms`) instead of 300 ms, reducing avoidable saw-tooth latency.
- Android `pipeline.conf` accepts `commit_linger_ms`.

## Expected telemetry

On an 8-core device, while a large commit is being prepared, expect approximately:

- commit worker: 1
- validation worker: 1
- script verifier budget: 5
- Android/other reserved capacity: 1

The script pool still has a persistent 7-thread pool, but only the stage-aware budget is permitted to execute simultaneously. The budget is not a consensus rule.

## Consensus safety

Canonical state mutation is still performed by exactly one permanent ordered committer. Preparation is derived from the exact canonical tip and `apply_prepared_commit()` rechecks that tip/parent before mutation. Only CPU scheduling, feedback signals, and batching latency were changed.
