# Android feature parity with YORTAL v0.23.4

This package keeps the Android execution fix while preserving the node features present in `YORTAL-NODE-v0_23_4-pipeline-perf.zip`.

## Preserved features

### P2P / automatic peer connection
- `NodeService` performs automatic discovery for `seed.ycash.xyz`.
- It also tries the configured Ycash service hosts and DNS-over-HTTPS fallback.
- Discovered addresses are passed to Rust through `YCASH_AUTO_PEER`.
- Rust also consumes `YCASH_PEER`, `YCASH_AUTO_PEER`, `peers.dat`, and fixed-seed fallbacks.
- Successful peers and learned `addr` messages are persisted to `peers.dat`.
- The peer supervisor maintains multiple outbound sessions (up to 12).
- Real VERSION/VERACK handshakes are required before a peer is counted.

### Database / persistence
- The Android service sets `YCASH_NODE_DB` to `getFilesDir()/ycash-node.rocksdb`.
- `YCASH_DATA_DIR` is also explicitly set to the same app-private data directory.
- The Rust node opens the RocksDB state database before starting its APIs/P2P listener.
- Existing database state is loaded on startup for header/tip recovery.
- Pipeline commits remain persisted and restart recovery remains enabled.

### Automatic service restart
- `NodeService` retains `START_STICKY` for normal starts, matching v0.23.4 behavior.
- A STOP request remains `START_NOT_STICKY`, so an intentional stop is not automatically restarted.

> Note: v0.23.4 did **not** contain an Android `BOOT_COMPLETED` receiver. "Automatic startup" here therefore means the same sticky service/restart behavior and automatic peer connection used by v0.23.4, not launching the node after every device reboot.

## Changed deliberately

The only functional Android behavior changed from v0.23.4 is executable resolution:

- The node must be packaged as `libycashandroidnode.so` under `jniLibs/arm64-v8a/`.
- The service no longer copies an executable into `getFilesDir()` and attempts `chmod` there.
- This prevents the Android 10+ private-storage execution failure seen in the broken build.
- The UI reports `STARTING` until `/status` on port 8834 actually responds, rather than displaying `RUNNING` optimistically.

The Rust P2P, peer database, RocksDB database, sync pipeline, RPC, status API, and service lifecycle code are otherwise retained from the fixed v0.27.1 tree.
