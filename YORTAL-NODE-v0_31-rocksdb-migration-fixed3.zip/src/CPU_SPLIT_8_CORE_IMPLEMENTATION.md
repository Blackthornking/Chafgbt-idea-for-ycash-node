# YORTAL 8-core CPU split

The Android node uses a device-derived, stage-aware CPU budget. On an 8-core device the intended commit-preparation split is:

- Android/process reserve: **1**
- permanent ordered canonical committer: **1**
- active block-validation worker: **1**
- transparent script verification: **5**

`available_parallelism()` supplies the device ceiling. `YORTAL_VERIFY_THREADS=0` and `YORTAL_SCRIPT_WORKERS=0` mean automatic mode. NodeService seeds those values explicitly before applying user configuration. The script Rayon pool can contain 7 threads, but ScriptPermit caps simultaneous script execution to the active stage budget of 5.

Consensus state mutation remains strictly height ordered through the single permanent commit worker.
