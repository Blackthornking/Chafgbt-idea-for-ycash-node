# YORTAL v0.29.1 — Zebra-style batching

Consensus rules unchanged. This release changes how work is grouped, not what is checked.

## Measured problem (v0.29.0 on device)
- Header sync ~361 headers/s. Every header did ~6 RocksDB reads (prev hash, prev raw,
  11 times, 28-header history, prev work) plus 2 autocommit writes.
- Commits stuck at 16 blocks: one slow peer on the head-of-line range kept every
  later validated range waiting.

## 1. Batched header stage (main.rs)
Per `headers` message (≤160):
1. `first_bad_pow` — Equihash for all headers on all cores; returns the lowest failing index.
2. `HeaderWindow::seed` — ONE query loads the 28 canonical headers below the batch.
3. `HeaderWindow::apply` — contextual rules in height order, answering from memory
   exactly what the DB answered: prev hash, MTP (`[max(h-11,1),h)` + genesis time),
   28-header difficulty history, previous chain work. Zero DB reads per header.
4. `State::put_headers_batch` — ONE transaction running the same two statements
   `put_header` ran for each row.

If header k fails, headers 0..k-1 are committed first and then the same error is
returned — identical end state to the old one-at-a-time loop.

## 2. Hedged head-of-line range (pipeline_sync.rs)
Like Zebra's hedged block requests: if the range at `next_commit` has been leased
20 s while later ranges wait in the buffer (80 s otherwise), it is re-offered to a
second peer. First valid copy wins; the other is dropped as `DUPLICATE`.
Lease failures now use `release_if_current(id, generation)` so a stale fetcher can't
disturb the hedged lease. Ranges already downloaded and in verification are never hedged.

## 3. Commit linger
When blocks are ready the committer waits up to 300 ms for more contiguous ranges
(unless the batch is full or nothing is being verified), so one RocksDB transaction
carries more blocks.

## 4. Dashboard
Sync shows blocks and headers with 2 decimals; TARGET/BEHIND on separate rows;
height numbers no longer wrap.

## Log lines
`[HEADERS] batch a..b n=160 ms=… headers_per_sec=…`,
`[PIPELINE] stage=HEDGE`, `stage=DUPLICATE`, `COMMIT_OK … blocks=…`.

## Still not batched (needs a dependency upgrade)
Groth16/RedJubjub batch verification: ycash-crypto uses bellman 0.8, which has no
batch verifier (added in later bellman). Upgrading the proving stack is a separate,
consensus-sensitive release.
