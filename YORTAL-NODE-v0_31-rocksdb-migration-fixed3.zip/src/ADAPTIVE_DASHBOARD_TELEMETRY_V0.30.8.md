# v0.30.8 Adaptive Dashboard Telemetry

The Android dashboard now refreshes the adaptive CPU telemetry with the existing live status poll (2 seconds):

- CPU cores: detected by Android `Runtime.getRuntime().availableProcessors()`.
- Reserved for Android: one logical core whenever the device has more than one.
- Max adaptive workers: the native pipeline verifier ceiling, derived from native available parallelism minus one.
- Current adaptive workers: the live pressure-controlled worker budget.

The native verifier ceiling is device-derived by default; `YORTAL_VERIFY_THREADS` remains an optional benchmarking/configuration override. The active script budget is separately stage-aware while the permanent commit worker is preparing state. The adaptive controller can still reduce the **current** worker count under CPU, memory, DB, or validation pressure.

Consensus behaviour is unchanged: these values only control scheduling/concurrency and do not change block or transaction validation rules or ordered commits.


## v0.30.9 script/commit diagnostics

The dashboard and status API now distinguish the persistent script pool from the shared active permit budget and report:

- script pool threads
- active script budget
- observed active peak
- total script permit wait
- scheduler gap (wall time outside the longest worker span)

This prevents the old `pool threads: 7` / `script workers: 1` ambiguity from being mistaken for healthy seven-way execution.
