# Adaptive Pipeline Stall Fix

## Problem
A single critical DB/CPU sample could bypass the EWMA and force the adaptive
controller to `(1 worker, 1 inflight)`. With only one range in flight, a peer
handshake failure could leave the fetch side at 0 headers/s until the hedge
watchdog released the range.

## Fix
- Normal adaptive budgets now use the EWMA (`effective`) pressure signal.
- The emergency `(1,1)` floor is no longer selected from one raw sample.
- Critical pressure must be observed for 3 consecutive samples before the
  emergency floor is enabled.
- A non-critical sample immediately clears the critical streak, allowing the
  controller to recover from the emergency state without changing consensus
  ordering or canonical commit ownership.
- Regression tests cover transient critical pressure, sustained critical
  pressure, and recovery.

This deliberately changes scheduling/backpressure only. It does not change
validation rules, canonical commit order, lease-generation checks, or consensus
state-transition logic.

## Expected behavior

Single 213 ms DB write+commit sample:

`raw=critical -> EWMA rises -> normal bounded budget reduction`

rather than:

`raw=critical -> immediate (1,1) -> one peer failure -> producer stall`

Three consecutive critical samples:

`critical x3 -> emergency (1,1)`

Then one non-critical sample clears the emergency streak; the EWMA continues
to provide gradual recovery rather than an immediate full reset.
