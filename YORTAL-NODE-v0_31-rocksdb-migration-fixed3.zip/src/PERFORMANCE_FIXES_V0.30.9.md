# YORTAL v0.30.9 — Prepared Commit / Database Performance Fixes

## Findings implemented

The supplied runtime telemetry showed that the apparent block-height/database slowdown was dominated by transparent script verification during the ordered state-preparation stage, not by RocksDB WRITE itself.

Representative telemetry from the supplied screenshots:

- state validation: 1.569 s
- TX connect: 1.452 s (92.5% of state validation)
- script checks: 943.50 ms
- script parallel verification: 943.50 ms with only 1 active worker
- persistent pool: 7 threads
- RocksDB WRITE: about 1.02 ms
- DB write: about 1.69 ms

A second sample showed the same pattern with 1.513 s script verification and one active worker. The implementation therefore targets the execution gate and the state-read/cache path while preserving one canonical ordered committer.

## Implemented changes

### 1. Stage-aware script CPU allocation

During canonical state preparation the permanent commit worker reserves one CPU slot, one pipeline verifier remains alive, and the remaining device CPU budget is assigned to transparent script verification.

For an 8-core device the intended healthy split is:

- 1 Android/housekeeping reserve
- 1 permanent ordered commit worker
- 1 live pipeline verifier
- 5 script-verification permits

The shared `ScriptPermit` gate is retained to prevent oversubscription, but it is no longer effectively a permanent one-worker limit. The active budget is changed by the pipeline at the commit-stage boundary.

### 2. Automatic script-budget fallback

If no pipeline explicitly configures a script budget, the state crate now derives a cores-minus-one default rather than silently serializing direct state callers to one worker.

`YORTAL_SCRIPT_WORKERS=0` is treated as automatic/device-derived instead of meaning one worker.

### 3. Script scheduling telemetry

Added:

- permit wait time
- observed active script peak
- scheduler/wall gap
- active script budget
- persistent script pool size

The status API exposes the values and the Android dashboard displays them. Script worker arrays are exported for all 32 telemetry slots rather than only a misleading four-slot view.

### 4. Batched UTXO prefetch

Transaction inputs are collected before lookup and missing UTXOs are fetched from RocksDB in bounded groups of 64 input pairs. The existing canonical-state height/spent-height predicates are preserved.

The batch lookup is an acceleration only; the same UTXO rows and consensus checks remain authoritative.

### 5. Bounded LRU UTXO cache

The previous arbitrary `HashMap::keys().next()` eviction was replaced by an explicit bounded LRU cache with a 50,000-entry ceiling.

Cache hits are recorded locally during state preparation and promoted at the canonical publication boundary, avoiding a global lock on the hot validation path. Promotion is performed in one pass to avoid O(n²) behavior when a high-input batch touches many cached UTXOs.

### 6. Remove full 50k cache clone per commit

The previous commit publication path copied the complete cached UTXO map into a new `HashMap` on every successful cache hit.

The new path reuses the existing cache allocation through `Arc::make_mut` when it is unique and uses safe copy-on-write if another reader still holds the Arc. This removes the recurring O(50k) clone from the normal commit path without weakening canonical-state checks.

### 7. Consensus ordering preserved

The following were deliberately NOT changed:

- exactly one canonical ordered commit worker
- height ordering
- canonical-parent checks
- prepared-commit validation/apply separation
- RocksDB atomic write transaction
- consensus validation rules
- reorg safety checks
- RocksDB as authoritative persistent state

### 8. Android runtime configuration

`pipeline.conf` now accepts optional:

- `script_workers`
- `script_parallel_threshold`

The default remains automatic. The native process logs the device-derived verifier count, script pool size, and active script budget.

## Verification performed in this environment

Passed source-level project checks:

- `tools/verify-commit-performance-path.sh`
- `tools/verify-script-pool.sh`
- `tools/verify-adaptive-pipeline.sh`

A native Rust/Android build could not be executed in the current environment because the Rust toolchain/Cargo is not installed here. The supplied ZIP therefore contains the source-level implementation and verification changes; the Android APK/AAR should be built by the project's CI/Android toolchain before device deployment.
