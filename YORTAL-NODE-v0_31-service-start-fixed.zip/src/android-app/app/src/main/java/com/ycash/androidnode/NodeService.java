package com.ycash.androidnode;

import android.app.*;
import android.content.*;
import android.os.*;
import java.io.*;

public class NodeService extends Service {
    static final String START="START", STOP="STOP";
    static final String PREF_MANUAL_PEER="manual_peer";
    // Must match the filename placed under app/src/main/jniLibs/<abi>/ (see tools/package-node-binary.sh).
    // The "lib" prefix and ".so" suffix are required by Android's APK packager to treat this as a
    // native library, which is what makes it end up in an OS location apps are allowed to exec from.
    static final String NATIVE_LIB_NAME="libycashandroidnode.so";
    static java.lang.Process process;
    @Override public void onCreate(){
        super.onCreate();
        // A START action is delivered through onStartCommand().  The service must
        // enter the foreground before doing any native work on Android 8+.
        // The foreground notification is created here as well so both START and
        // any subsequent restart have a valid notification/channel.
        ensureNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId){
        String action = intent == null ? START : intent.getAction();
        if (STOP.equals(action)) {
            stopNode();
            stopForeground(true);
            stopSelfResult(startId);
            return START_NOT_STICKY;
        }

        try {
            Notification n = notification();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(1001, n);
            }
        } catch (Throwable t) {
            appendLog(new File(getFilesDir(), "node.log"),
                "FATAL: unable to enter foreground service: " + t);
            stopSelfResult(startId);
            return START_NOT_STICKY;
        }

        if (!isNodeAlive()) startNode();
        return START_NOT_STICKY;
    }

    private void ensureNotificationChannel(){
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                NotificationChannel c = new NotificationChannel(
                    "ycash-node", "Ycash Node", NotificationManager.IMPORTANCE_LOW);
                c.setDescription("Ycash node foreground service");
                c.setShowBadge(false);
                nm.createNotificationChannel(c);
            }
        }
    }
    static boolean isNodeAlive(){ java.lang.Process p=process; return p!=null && p.isAlive(); }
    /** Return the native node PID for diagnostics; -1 when the process has not started. */
    static long nodePid() {
        java.lang.Process p = process;
        if (p == null || !p.isAlive()) return -1L;

        try {
            java.lang.reflect.Method m =
                    java.lang.Process.class.getMethod("pid");
            Object value = m.invoke(p);
            return value instanceof Long ? ((Long) value).longValue() : -1L;
        } catch (Throwable ignored) {
            return -1L;
        }
    }
    void startNode(){ new Thread(()->{
        File log=new File(getFilesDir(),"node.log");
        try {
            File bin=resolveBinary(log);
            File dataDir=getFilesDir();
            ProcessBuilder pb=new ProcessBuilder(bin.getAbsolutePath()); pb.directory(dataDir);
            java.util.Map<String,String> env=pb.environment();
            String dbPath=new File(dataDir,"ycash-node.rocksdb").getAbsolutePath();
            env.put("YCASH_NODE_DB", dbPath);
            // Explicit, not just inferred from YCASH_NODE_DB's parent, so peer_supervisor()'s directory
            // choice can't silently change if the db path convention ever changes.
            env.put("YCASH_DATA_DIR", dataDir.getAbsolutePath());
            // Belt-and-braces: harmless for this Rust binary (it doesn't consult HOME), but keeps this
            // service safe if the binary is ever swapped back to something that does.
            env.put("HOME", dataDir.getAbsolutePath());
            // Explicit automatic CPU scheduling defaults prevent an inherited/stale
            // process environment from pinning verification to one worker. The native
            // scheduler derives the stage split from available_parallelism():
            // 8-core device -> 1 Android reserve + 1 commit + 1 validation + 5 script.
            // pipeline.conf / SharedPreferences may still intentionally override these.
            env.put("YORTAL_VERIFY_THREADS", "0");
            env.put("YORTAL_SCRIPT_WORKERS", "0");
            applyPipelineEnv(env, dataDir, log);
            String auto=discoverPeers(log);
            if(!auto.isEmpty()) env.put("YCASH_AUTO_PEER", auto);
            String manual=getSharedPreferences("ycash_node",MODE_PRIVATE).getString(PREF_MANUAL_PEER,"").trim();
            if(!manual.isEmpty()){
                // Accept "ip" or "ip:port"; default Ycash mainnet port 8833. Rust splits on , and ;
                StringBuilder sb=new StringBuilder();
                for(String part:manual.split("[,;\\s]+")){ if(part.isEmpty()) continue;
                    String hostPart=part, portPart="8833";
                    int colon=part.lastIndexOf(':'); if(colon>0 && part.indexOf(':')==colon){ hostPart=part.substring(0,colon); portPart=part.substring(colon+1); }
                    // Resolve hostnames here (system DNS, then DNS-over-HTTPS) so the Rust node gets plain IPs
                    // even if its own DNS lookup fails; keep the hostname too as a fallback.
                    java.util.List<String> ips=hostPart.matches("[0-9.]+")?java.util.Collections.singletonList(hostPart):systemDns(hostPart);
                    if(ips.isEmpty()) ips=doh(hostPart);
                    appendLog(log, "Manual peer "+hostPart+" -> "+(ips.isEmpty()?"no DNS result":ips));
                    for(String ip:ips){ if(sb.length()>0) sb.append(','); sb.append(ip).append(':').append(portPart); }
                    if(!hostPart.matches("[0-9.]+")){ if(sb.length()>0) sb.append(','); sb.append(hostPart).append(':').append(portPart); } }
                env.put("YCASH_PEER", sb.toString());
                appendLog(log, "Manual peers: "+sb);
            }
            appendLog(log, "BOOT: launching native binary " + bin.getAbsolutePath());
            appendLog(log, "BOOT: db=" + dbPath);
            pb.redirectErrorStream(true); pb.redirectOutput(log);
            process=pb.start();
            appendLog(log, "BOOT: native process started");
            int exitCode=process.waitFor();
            appendLog(log, "PROCESS EXITED with code "+exitCode+
                (exitCode==0 ? "" : " (non-zero exit almost always means it never reached the point of opening the P2P/status ports)"));
        } catch(Exception e) {
            appendLog(log, "START ERROR: "+e+
                (e instanceof IOException ? " -- if this is a permission/exec error, the binary is most likely still in getFilesDir()/assets instead of jniLibs; Android 10+ blocks executing files an app wrote to its own private data directory." : ""));
        }
    }).start(); }

    /**
     * Pipeline tunables the native node reads from its environment. These used to be
     * compiled into the binary (AdaptiveConfig was a literal in BlockPipeline::new), so
     * editing config/pipeline.toml changed nothing on Android -- that file is only read
     * by the desktop node. Precedence, lowest first:
     *
     *   1. the Rust defaults (anything not set here)
     *   2. <externalFilesDir>/pipeline.conf  -- key=value per line, '#' starts a comment.
     *      This is /sdcard/Android/data/com.ycash.androidnode/files/, reachable from a
     *      file manager, so settings can be changed on an unrooted device with no rebuild.
     *   3. <filesDir>/pipeline.conf          -- same format, private dir (adb run-as/root)
     *   4. SharedPreferences("ycash_node"), key "pipeline_<lowercased name>"
     *
     * pipeline.conf accepts either the bare name or the full env name, e.g. both
     * "max_inflight_ranges = 20" and "YORTAL_MAX_INFLIGHT_RANGES=20" work. The node
     * clamps every value, so a bad edit degrades rather than wedging the scheduler.
     */
    static final String[] PIPELINE_KEYS={
        "MIN_WINDOW","INITIAL_WINDOW","MAX_WINDOW","WINDOW_STEP",
        "HIGH_WATERMARK","LOW_WATERMARK","VERIFY_THREADS",
        "MAX_INFLIGHT_RANGES","MAX_RANGE_LEN","COMMIT_BATCH_CAP","COMMIT_LINGER_MS","SCRIPT_WORKERS","SCRIPT_PARALLEL_THRESHOLD"
    };
    void applyPipelineEnv(java.util.Map<String,String> env, File dataDir, File log){
        java.util.Map<String,String> resolved=new java.util.LinkedHashMap<>();
        File ext=getExternalFilesDir(null);
        java.util.List<File> candidates=new java.util.ArrayList<>();
        if(ext!=null){ File extConf=new File(ext,"pipeline.conf"); writeTemplateIfMissing(extConf, log); candidates.add(extConf); }
        candidates.add(new File(dataDir,"pipeline.conf"));
        for(File conf:candidates) readPipelineConf(conf, resolved, log);
        SharedPreferences prefs=getSharedPreferences("ycash_node",MODE_PRIVATE);
        for(String k:PIPELINE_KEYS){
            String v=prefs.getString("pipeline_"+k.toLowerCase(java.util.Locale.US),"").trim();
            if(!v.isEmpty()) resolved.put(k,v);
        }
        if(resolved.isEmpty()){ appendLog(log, "Pipeline settings: node defaults (no pipeline.conf, no overrides)"); return; }
        StringBuilder sb=new StringBuilder();
        for(java.util.Map.Entry<String,String> e:resolved.entrySet()){
            env.put("YORTAL_"+e.getKey(), e.getValue());
            if(sb.length()>0) sb.append(", ");
            sb.append(e.getKey()).append('=').append(e.getValue());
        }
        appendLog(log, "Pipeline settings: "+sb);
    }

    /**
     * Drop a commented template next to the node's external files on first run, so the
     * settings are discoverable and editable without a rebuild. Every line is commented
     * out, so an untouched template changes nothing.
     */
    private static void writeTemplateIfMissing(File conf, File log){
        if(conf==null || conf.exists()) return;
        try {
            File parent=conf.getParentFile(); if(parent!=null) parent.mkdirs();
            try(PrintWriter w=new PrintWriter(new FileWriter(conf))){
                w.println("# YORTAL pipeline settings. Uncomment a line and restart the node.");
                w.println("# Values are clamped by the node; range length is capped at 100 blocks.");
                w.println("# min_window = 16");
                w.println("# initial_window = 100");
                w.println("# max_window = 2000");
                w.println("# window_step = 100");
                w.println("# high_watermark = 0.85");
                w.println("# low_watermark = 0.50");
                w.println("# verify_threads = 0  # 0 = device CPU cores - 1");
                w.println("# max_inflight_ranges = 0  # 0 = 2 * (device CPU cores - 1)");
                w.println("# max_range_len = 100");
                w.println("# commit_batch_cap = 512  # active commit batch follows the adaptive window");
                w.println("# commit_linger_ms = 50  # short coalescing delay; bounded to 0..300 ms");
                w.println("# script_workers = 0  # 0 = device cores - 1; active script budget is stage-aware");
                w.println("# script_parallel_threshold = 2");
            }
            appendLog(log, "Wrote pipeline.conf template to "+conf.getAbsolutePath());
        } catch(Exception e){ appendLog(log, "pipeline.conf template write failed: "+e); }
    }

    /** Overlay one key=value config file onto `into`. Unknown keys are ignored. */
    private static void readPipelineConf(File conf, java.util.Map<String,String> into, File log){
        if(conf==null || !conf.isFile()) return;
        try(BufferedReader r=new BufferedReader(new FileReader(conf))){
                String line;
                while((line=r.readLine())!=null){
                    int hash=line.indexOf('#'); if(hash>=0) line=line.substring(0,hash);
                    int eq=line.indexOf('='); if(eq<=0) continue;
                    String k=line.substring(0,eq).trim().toUpperCase(java.util.Locale.US);
                    String v=line.substring(eq+1).trim().replace("\"","");
                    if(k.startsWith("YORTAL_")) k=k.substring(7);
                    if(v.isEmpty()) continue;
                    for(String known:PIPELINE_KEYS) if(known.equals(k)) into.put(k,v);
                }
            appendLog(log, "Read pipeline settings from "+conf.getAbsolutePath());
        } catch(Exception e){ appendLog(log, "pipeline.conf read error ("+conf+"): "+e); }
    }

    /**
     * Resolve only the PackageManager-installed native executable. Never copy the node
     * into getFilesDir(): Android 10+ can reject execution of files an app writes there.
     */
    private File resolveBinary(File log) throws IOException {
        File nativeLib=new File(getApplicationInfo().nativeLibraryDir, NATIVE_LIB_NAME);
        if (!nativeLib.isFile()) {
            appendLog(log, "FATAL: "+NATIVE_LIB_NAME+" is missing from nativeLibraryDir: "+
                getApplicationInfo().nativeLibraryDir+". Rebuild the APK after running tools/build-android-arm64.sh.");
            throw new FileNotFoundException("Missing packaged native node: "+nativeLib);
        }
        if (!nativeLib.canExecute()) {
            appendLog(log, "FATAL: packaged node is not executable: "+nativeLib);
            throw new IOException("Packaged native node is not executable: "+nativeLib);
        }
        appendLog(log, "Using packaged native node: "+nativeLib);
        return nativeLib;
    }

    /**
     * Automatic peer discovery, no manual IP needed:
     *  1. seed.ycash.xyz through the phone's DNS,
     *  2. the same name through DNS-over-HTTPS (Cloudflare, Google), in case the mobile
     *     network's DNS is failing or filtering it,
     *  3. IPs of known Ycash service hosts, tried on P2P port 8833, because operators often run
     *     the server on the same endpoint. These are best guesses; the Rust node only counts a peer
     *     after a real VERSION/VERACK handshake, so a wrong guess just fails and is skipped.
     */
    private String discoverPeers(File log){
        java.util.LinkedHashSet<String> out=new java.util.LinkedHashSet<>();
        String[] seeds={"seed.ycash.xyz"};
        // explorer.ycash.xyz and lite.ycash.xyz were given by the Ycash community (Discord #general) as P2P 8833 nodes.
        String[] serviceHosts={"explorer.ycash.xyz","lite.ycash.xyz","ycash.xyz","lightwalletd.ycash.xyz","node.ycash.xyz","yecblockexplorer.com"};
        for(String h:seeds){ addAll(out, systemDns(h), log, "system DNS "+h); addAll(out, doh(h), log, "DoH "+h); }
        for(String h:serviceHosts){ java.util.List<String> ips=systemDns(h); if(ips.isEmpty()) ips=doh(h); addAll(out, ips, log, "service host "+h); }
        StringBuilder sb=new StringBuilder();
        for(String ip:out){ if(sb.length()>0) sb.append(','); sb.append(ip).append(":8833"); }
        appendLog(log, "Auto-discovery candidates: "+(sb.length()==0?"none":sb));
        return sb.toString();
    }
    private static void addAll(java.util.Set<String> out, java.util.List<String> ips, File log, String label){
        appendLog(log, label+" -> "+(ips.isEmpty()?"no result":ips)); out.addAll(ips);
    }
    private static java.util.List<String> systemDns(String host){
        java.util.List<String> r=new java.util.ArrayList<>();
        try{ for(java.net.InetAddress a:java.net.InetAddress.getAllByName(host)) if(a instanceof java.net.Inet4Address) r.add(a.getHostAddress()); }catch(Exception ignored){}
        return r;
    }
    private static java.util.List<String> doh(String host){
        String[] urls={"https://cloudflare-dns.com/dns-query?type=A&name=","https://dns.google/resolve?type=A&name="};
        java.util.List<String> r=new java.util.ArrayList<>();
        for(String u:urls){
            try{
                java.net.HttpURLConnection c=(java.net.HttpURLConnection)new java.net.URL(u+host).openConnection();
                c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setRequestProperty("Accept","application/dns-json");
                StringBuilder body=new StringBuilder();
                try(BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()))){ String line; while((line=br.readLine())!=null) body.append(line); }
                java.util.regex.Matcher m=java.util.regex.Pattern.compile("\"type\"\\s*:\\s*1\\s*,[^}]*?\"data\"\\s*:\\s*\"(\\d+\\.\\d+\\.\\d+\\.\\d+)\"").matcher(body);
                while(m.find()) if(!r.contains(m.group(1))) r.add(m.group(1));
                if(!r.isEmpty()) break;
            }catch(Exception ignored){}
        }
        return r;
    }

    private static void appendLog(File log, String line) {
        try (FileWriter w=new FileWriter(log, true)) { w.write(line+"\n"); } catch(Exception ignored) {}
    }
    void stopNode(){ if(process!=null && process.isAlive()) process.destroy(); process=null; }
    Notification notification(){
        ensureNotificationChannel();
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) b = new Notification.Builder(this, "ycash-node");
        else b = new Notification.Builder(this);
        return b.setContentTitle("Ycash Android Node")
            .setContentText("Ycash node is running")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build();
    }
    public IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){
        stopNode();
        stopForeground(true);
        super.onDestroy();
    }
}
