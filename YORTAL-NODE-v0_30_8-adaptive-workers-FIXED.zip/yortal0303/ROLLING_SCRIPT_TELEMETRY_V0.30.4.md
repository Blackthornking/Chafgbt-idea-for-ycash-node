# YORTAL v0.30.4 Rolling + Deep Script Telemetry

## Rolling performance window

The native node now keeps a rolling window of the most recent **up to 500 committed blocks**. The window is recorded at commit time rather than UI polling time, so fast batches are not lost between Android status refreshes.

The status API exposes `rolling_telemetry` with:
- committed blocks and transactions in the window
- sustained blocks/second over the window
- per-block average commit/state-validation/TX-connect/script time
- per-block SQLite COMMIT and DB-write time
- per-block script substage timings

The UI renders the rolling window below the last-batch state-validation breakdown.

## Deep transparent-script instrumentation

The most recent committed batch now reports:
- transaction/input extraction from the UTXO view
- scriptSig construction (currently zero when the parsed transaction already owns the immutable script bytes)
- scriptPubKey retrieval/key-material validation
- script parsing (`get_op`)
- signature/hash preparation
- ECDSA verification
- script interpreter opcode/stack execution residual
- precomputed signature-hash cache selection/lookup overhead
- synchronization/thread scheduling residual

All measurements are diagnostic only. No consensus rule, validation ordering, transaction data, or acceptance decision is changed by the instrumentation.

Script parsing and interpreter timings are recorded at their natural call sites, while signature-hash and ECDSA timings are recorded inside the transaction signature checker. This avoids attributing the same work to multiple top-level stages.

## Interpretation

`Input/UTXO extraction` is deliberately marked pre-script because the UTXO lookup happens before `verify_script`. `scriptSig construction` can legitimately remain zero because YORTAL receives the parsed transaction with the scriptSig already materialized. `scriptPubKey retrieval` is similarly tied to the UTXO coin lookup; the script-layer field currently measures local public-key validation rather than copying consensus bytes.

The rolling metrics are intended to identify sustained bottlenecks across variable transaction mixes, rather than treating a single batch as representative.
