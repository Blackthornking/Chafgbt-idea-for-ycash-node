# YORTAL v0.30.1 — Consensus/State Commit Audit Changes

This build is configured as a **sequential full-verification diagnostic build**.

## Pipeline invariant


Configuration: `min_window=16`, `initial_window=16`, `max_window=16`,
and `max_range_len=16`.

No assume-valid shortcut is enabled by the full-verification path.

## State/SQLite instrumentation

`CommitTiming` now exposes: `begin_ms`, `state_validation_ms`, `tree_ms`,
`rollback_ms`, `db_write_ms`, `sql_write_ms`, `index_write_ms`, and
`sqlite_commit_ms`. `[DBPIPE]` log records emit all of these values for each
ordered commit batch.

The instrumentation is observational only; it does not alter consensus rules.
The existing Sapling consensus-state validation and existing Sapling proof
verification remain the authoritative validation path.

## Reference-implementation principle

Ycash reference behavior should be incorporated only where it is a documented
consensus/state rule. Cryptographic verification is not replaced by a new
Groth16 implementation in this change.

## Validation limitation

The container used for this edit does not have the Rust toolchain installed, so
`cargo test --workspace --all-targets` could not be executed here. The modified
workspace must be compiled/tested in CI before treating the APK as release-ready.
