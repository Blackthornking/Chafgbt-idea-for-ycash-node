//! Consensus-neutral multi-peer range scheduler.
//! Ranges are leases. Slow/dead peers can have their unfinished lease returned
//! to the scheduler and assigned to another peer.

use std::collections::{BTreeMap, HashMap};
use std::time::{Duration, Instant};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct RangeId(pub u64);

#[derive(Debug, Clone, Copy)]
pub struct HeightRange {
    pub start: u64,
    pub end: u64, // inclusive
}

impl HeightRange {
    pub fn len(&self) -> u64 { self.end.saturating_sub(self.start) + 1 }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RangeState { Pending, Leased, Complete, Quarantined }

#[derive(Debug, Clone)]
pub struct RangeLease {
    pub id: RangeId,
    pub range: HeightRange,
    pub peer: String,
    pub state: RangeState,
    pub retries: u32,
    pub generation: u64,
    pub claimed_at: Option<Instant>,
}

#[derive(Debug, Default)]
pub struct RangeScheduler {
    next_id: u64,
    ranges: BTreeMap<RangeId, RangeLease>,
    peer_load: HashMap<String, usize>,
}

impl RangeScheduler {
    pub fn enqueue(&mut self, start: u64, end: u64) -> RangeId {
        debug_assert!(start <= end, "invalid empty range");
        let id = RangeId(self.next_id);
        self.next_id += 1;
        self.ranges.insert(id, RangeLease {
            id, range: HeightRange { start, end },
            peer: String::new(),
            state: RangeState::Pending,
            retries: 0,
            generation: 0,
            claimed_at: None,
        });
        id
    }


    /// Enqueue a range only when it does not overlap any existing pending or
    /// leased range. Completed/quarantined entries are not reusable work and
    /// therefore do not block a new range. This is the scheduler's primary
    /// anti-duplication invariant: planning may be called repeatedly while
    /// peers are active, but an already-covered height can never be enqueued
    /// a second time.
    pub fn enqueue_if_disjoint(&mut self, start: u64, end: u64) -> Option<RangeId> {
        if start > end { return None; }
        let overlaps = self.ranges.values().any(|r| {
            matches!(r.state, RangeState::Pending | RangeState::Leased | RangeState::Quarantined)
                && r.range.start <= end
                && start <= r.range.end
        });
        if overlaps { return None; }
        Some(self.enqueue(start, end))
    }

    /// Return the highest height covered by pending/leased work at or after
    /// `from`, if coverage is contiguous from `from`.
    pub fn contiguous_covered_end(&self, from: u64) -> Option<u64> {
        let mut end = from.saturating_sub(1);
        loop {
            let next = end.saturating_add(1);
            let candidate = self.ranges.values()
                .filter(|r| matches!(r.state, RangeState::Pending | RangeState::Leased))
                .filter(|r| r.range.start <= next && r.range.end >= next)
                .map(|r| r.range.end)
                .max();
            match candidate {
                Some(e) if e > end => end = e,
                _ => break,
            }
        }
        if end >= from { Some(end) } else { None }
    }

    pub fn claim(&mut self, peer: &str) -> Option<RangeLease> {
        self.claim_upto(peer, u64::MAX)
    }

    /// Claim the lowest pending range that this peer can actually serve
    /// (its whole range is at or below the height the peer advertised).
    /// Handing a range above a peer's own tip to that peer guarantees a
    /// timeout/notfound, burns a retry, and drops the connection.
    pub fn claim_upto(&mut self, peer: &str, max_end: u64) -> Option<RangeLease> {
        let id = self.ranges.iter()
            .find(|(_, r)| r.state == RangeState::Pending && r.range.end <= max_end)
            .map(|(id, _)| *id)?;
        let r = self.ranges.get_mut(&id)?;
        r.peer = peer.to_owned();
        r.state = RangeState::Leased;
        r.generation = r.generation.saturating_add(1);
        r.claimed_at = Some(Instant::now());
        *self.peer_load.entry(peer.to_owned()).or_default() += 1;
        Some(r.clone())
    }

    pub fn complete(&mut self, id: RangeId) {
        if let Some(r) = self.ranges.get_mut(&id) {
            r.state = RangeState::Complete;
            if let Some(v) = self.peer_load.get_mut(&r.peer) { *v = v.saturating_sub(1); }
        }
        // Drop finished ranges. They used to stay in the map forever, so every
        // claim/lookup scanned tens of thousands of completed entries by the
        // time sync reached millions of heights. `state()` returns None for a
        // removed id, which callers treat as complete.
        self.ranges.remove(&id);
    }

    /// Requeues an unfinished lease. After repeated failures, quarantine it
    /// for diagnostic/duplicate-fetch handling rather than silently accepting it.
    pub fn release(&mut self, id: RangeId) {
        if let Some(r) = self.ranges.get_mut(&id) {
            if let Some(v) = self.peer_load.get_mut(&r.peer) { *v = v.saturating_sub(1); }
            r.retries += 1;
            r.peer.clear();
            r.claimed_at = None;
            r.generation = r.generation.saturating_add(1);
            r.state = if r.retries >= 3 {
                RangeState::Quarantined
            } else {
                RangeState::Pending
            };
        }
    }


    pub fn lease_age(&self, id: RangeId) -> Option<Duration> {
        self.ranges.get(&id).and_then(|r| r.claimed_at.map(|t| t.elapsed()))
    }

    pub fn is_current_lease(&self, id: RangeId, generation: u64) -> bool {
        self.ranges.get(&id).map(|r| r.state == RangeState::Leased && r.generation == generation).unwrap_or(false)
    }

    pub fn state(&self, id: RangeId) -> Option<RangeState> {
        self.ranges.get(&id).map(|r| r.state)
    }

    pub fn range_end(&self, id: RangeId) -> Option<u64> {
        self.ranges.get(&id).map(|r| r.range.end)
    }

    /// Find the range whose lease begins at `start`, if any. Used by the
    /// commit coordinator to look up "the range currently blocking
    /// `next_commit`" without needing to track its `RangeId` separately.
    pub fn id_at_start(&self, start: u64) -> Option<RangeId> {
        self.ranges.iter().find(|(_, r)| r.range.start == start).map(|(id, _)| *id)
    }

    /// Give a range another shot at being claimed, resetting its retry
    /// count. Unlike `release`, this always lands back on `Pending`, even if
    /// the range was previously `Quarantined`.
    ///
    /// Ranges can never be safely skipped -- every height must be committed
    /// in order for consensus -- so once the range blocking `next_commit`
    /// hits the retry limit in `release`, it must not be left `Quarantined`
    /// forever: nothing else in the pipeline knows how to unstick it, and
    /// every range validated behind it would otherwise buffer up
    /// unboundedly waiting for a commit that can never happen. Requeuing it
    /// is the safe failure mode: keep retrying (ideally against a different
    /// peer next time) rather than deadlocking the whole sync.
    pub fn requeue(&mut self, id: RangeId) {
        if let Some(r) = self.ranges.get_mut(&id) {
            r.retries = 0;
            r.peer.clear();
            r.claimed_at = None;
            r.generation = r.generation.saturating_add(1);
            r.state = RangeState::Pending;
        }
    }

    /// Hand a lease back without counting it as a retry (the failure was not
    /// the peer's fault).
    pub fn unlease(&mut self, id: RangeId) {
        if let Some(r) = self.ranges.get_mut(&id) {
            if let Some(v) = self.peer_load.get_mut(&r.peer) { *v = v.saturating_sub(1); }
            r.peer.clear();
            r.claimed_at = None;
            r.generation = r.generation.saturating_add(1);
            r.state = RangeState::Pending;
        }
    }

    /// Number of heights still waiting to be fetched or currently being fetched.
    pub fn outstanding_heights(&self) -> u64 {
        self.ranges.values()
            .filter(|r| matches!(r.state, RangeState::Pending | RangeState::Leased))
            .map(|r| r.range.len())
            .sum()
    }

    pub fn pending_or_leased(&self) -> usize {
        self.ranges.values().filter(|r| matches!(r.state, RangeState::Pending | RangeState::Leased)).count()
    }

    /// Number of ranges currently leased to peers. Kept separate from the
    /// total pending+leased count so telemetry can distinguish scheduler
    /// backlog from actual network fetches.
    pub fn leased_ranges(&self) -> usize {
        self.ranges.values().filter(|r| r.state == RangeState::Leased).count()
    }

    /// Number of ranges waiting to be claimed by a peer.
    pub fn pending_ranges(&self) -> usize {
        self.ranges.values().filter(|r| r.state == RangeState::Pending).count()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn enqueue_if_disjoint_rejects_overlapping_pending_ranges() {
        let mut s = RangeScheduler::default();
        assert!(s.enqueue_if_disjoint(1, 16).is_some());
        assert!(s.enqueue_if_disjoint(8, 24).is_none());
        assert!(s.enqueue_if_disjoint(17, 32).is_some());
    }

    #[test]
    fn contiguous_coverage_finds_existing_planned_window() {
        let mut s = RangeScheduler::default();
        s.enqueue(1, 16);
        s.enqueue(17, 32);
        assert_eq!(s.contiguous_covered_end(1), Some(32));
        assert_eq!(s.contiguous_covered_end(33), None);
    }
}
