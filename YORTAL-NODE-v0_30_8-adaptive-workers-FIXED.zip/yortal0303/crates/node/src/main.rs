use anyhow::Result;
use std::path::PathBuf;
use ycash_state::pipeline::{AdaptiveConfig, PipelineEngine};
use ycash_state::State;

mod sync;

#[tokio::main]
async fn main()->Result<()>{
 tracing_subscriber::fmt::init();
 let db=std::env::var_os("YCASH_NODE_DB").map(PathBuf::from).unwrap_or_else(||PathBuf::from("ycash-node.sqlite"));
 let state=State::open(db)?;
 tracing::info!(tip=?state.tip_height()?,"Ycash Android Node state engine initialized");

 // v0.22 adaptive sync pipeline. The TOML defaults are embedded so the
 // packaged binary does not silently fall back to a different window.
 let pipeline=PipelineEngine::new(load_pipeline_config());
 let cfg=sync::SyncConfig::default();
 if cfg.seeds.is_empty() {
     tracing::warn!("no sync seeds configured");
 }
 let handle=tokio::task::spawn_blocking(move||{
     sync::run_sync_loop(state,pipeline,cfg);
 });
 handle.await?;
 Ok(())
}

fn load_pipeline_config() -> AdaptiveConfig {
    let text = std::env::var_os("YCASH_PIPELINE_CONFIG")
        .and_then(|p| std::fs::read_to_string(p).ok())
        .unwrap_or_else(|| include_str!("../../../config/pipeline.toml").to_owned());
    let mut cfg = AdaptiveConfig::default();
    for line in text.lines() {
        let line = line.split('#').next().unwrap_or("").trim();
        let Some((key, value)) = line.split_once('=') else { continue };
        let value = value.trim().trim_matches('"');
        let Ok(n) = value.parse::<usize>() else {
            if let Ok(v) = value.parse::<f64>() {
                match key.trim() {
                    "high_watermark" => cfg.high_watermark = v,
                    "low_watermark" => cfg.low_watermark = v,
                    _ => {}
                }
            }
            continue;
        };
        match key.trim() {
            "min_window" => cfg.min_window = n,
            "initial_window" => cfg.initial_window = n,
            "max_window" => cfg.max_window = n,
            "window_step" => cfg.step = n,
            "max_validation_workers" => cfg.max_validation_workers = n,
            "max_inflight_ranges" => cfg.max_inflight_ranges = n,
            "max_range_len" => cfg.max_range_len = n.clamp(1, 100),
            _ => {}
        }
    }
    if cfg.min_window == 0 || cfg.max_window < cfg.min_window || cfg.step == 0 {
        tracing::warn!("invalid pipeline window configuration; using compiled defaults");
        return AdaptiveConfig::default();
    }
    cfg
}
