#!/usr/bin/env bash
# Install the cross-compiled Android ARM64 node as a packaged native executable.
#
# Android 10+ does not allow an app to chmod + exec a file it created in its own
# private data directory.  Putting the ELF under jniLibs/arm64-v8a makes Gradle/
# PackageManager install it in the app's native-library directory, which is the
# execution path used by NodeService.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${BINARY:?Set BINARY to the built aarch64-linux-android ycash-android-node binary}"
ABI="${ABI:-arm64-v8a}"
DEST_DIR="$ROOT/android-app/app/src/main/jniLibs/$ABI"
DEST="$DEST_DIR/libycashandroidnode.so"

if [[ ! -f "$BINARY" ]]; then
  echo "ERROR: binary does not exist: $BINARY" >&2
  exit 1
fi
if [[ ! -r "$BINARY" ]]; then
  echo "ERROR: binary is not readable: $BINARY" >&2
  exit 1
fi

# The packaged file is deliberately named .so because AGP treats files under
# jniLibs/<ABI>/ as native libraries.  It must still be an EXECUTABLE ELF, not
# a cdylib/shared object and not a text placeholder.
if command -v file >/dev/null 2>&1; then
  desc="$(file -b "$BINARY")"
  case "$desc" in
    *ELF*executable*|*ELF*pie*executable*) ;;
    *) echo "ERROR: BINARY is not an ELF executable: $desc" >&2; exit 1 ;;
  esac
  case "$desc" in
    *aarch64*|*AArch64*|*ARM64*) ;;
    *) echo "ERROR: BINARY is not ARM64/aarch64: $desc" >&2; exit 1 ;;
  esac
fi

mkdir -p "$DEST_DIR"
cp "$BINARY" "$DEST"
chmod 755 "$DEST"

# Never leave the old placeholder beside the real binary.
rm -f "$DEST_DIR/PLACE_BINARY_HERE.md"

echo "Installed Android ARM64 node: $DEST"

# --- libc++_shared.so -------------------------------------------------------
# Since v0.31, the state backend is RocksDB (C++), so the linked binary has a
# DT_NEEDED dependency on the NDK's C++ runtime. Because Gradle only knows about
# this one packaged "native library" (really our executable, named .so so AGP
# will install it under nativeLibraryDir), it has no reason to bundle
# libc++_shared.so on its own -- there's no other JNI lib in this app that would
# normally pull it in. Without a copy sitting next to the binary at runtime, the
# dynamic linker fails to load it and NodeService sees "CANNOT LINK EXECUTABLE"
# before the node ever opens the P2P/status ports.
find_libcxx_shared() {
  local ndk="$1" host_tag="$2" candidate=""
  if [[ -n "$ndk" ]]; then
    if [[ -n "$host_tag" ]]; then
      candidate="$ndk/toolchains/llvm/prebuilt/$host_tag/sysroot/usr/lib/aarch64-linux-android/libc++_shared.so"
      [[ -f "$candidate" ]] && { echo "$candidate"; return 0; }
    fi
    # Host tag wasn't passed (or was wrong) -- search the sysroot directly rather
    # than guessing linux/darwin/host-arch combinations again.
    candidate="$(find "$ndk/toolchains/llvm/prebuilt" -path '*/sysroot/usr/lib/aarch64-linux-android/libc++_shared.so' 2>/dev/null | head -1)"
    [[ -n "$candidate" ]] && { echo "$candidate"; return 0; }
  fi
  return 1
}

# Fall back to the standard NDK env vars in case this script is run standalone
# rather than via build-android-arm64.sh (which already exports NDK/HOST_TAG).
NDK="${NDK:-${ANDROID_NDK_ROOT:-${ANDROID_NDK_HOME:-}}}"
LIBCXX_SRC="$(find_libcxx_shared "${NDK:-}" "${HOST_TAG:-}" || true)"
if [[ -z "$LIBCXX_SRC" ]]; then
  echo "ERROR: could not locate libc++_shared.so under NDK (NDK=${NDK:-<unset>}, HOST_TAG=${HOST_TAG:-<unset>})." >&2
  echo "        Set NDK to the NDK root (e.g. ANDROID_NDK_ROOT) and re-run. The RocksDB-backed" >&2
  echo "        node binary needs this file bundled next to it or it will fail on-device with" >&2
  echo "        'CANNOT LINK EXECUTABLE'." >&2
  exit 1
fi
cp "$LIBCXX_SRC" "$DEST_DIR/libc++_shared.so"
chmod 644 "$DEST_DIR/libc++_shared.so"
echo "Installed Android ARM64 C++ runtime: $DEST_DIR/libc++_shared.so (from $LIBCXX_SRC)"
