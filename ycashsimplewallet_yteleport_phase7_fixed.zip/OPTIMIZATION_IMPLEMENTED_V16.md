# Ycash Simple Wallet — V16 Optimization Implementation

## Implemented

- Zero-copy-style cross-block output representation: cross-block scratch no longer clones protobuf `CompactOutput` objects; it stores fixed-size protocol bytes and original block/output indices.
- Prepared IVK state remains persistent across blocks and is invalidated only when the viewing-key byte set changes.
- Whole-block crypto matching remains ahead of ordered tree/witness commit.
- Removed the full `CompactBlock` clone from the production `scan_compact_block_with_pool` path by capturing immutable transaction IDs before moving the block into the scanner.
- Nullifier candidate indexing now stores positions into one backing vector rather than cloning nullifier bytes into every prefix bucket.
- Commit-side nullifier lookup is prefix indexed instead of linear over all tracked notes, with exact equality verification retained.
- Cross-block matching reuses scratch buffers and fixed-size output representations.
- AWBS prefetch depth is recalculated whenever the adaptive batch size changes.
- SQLite storage now uses WAL with `synchronous=FULL`, preserving durability while improving reader/writer concurrency.
- Added useful SQLite indexes for account/spent, authenticated-note position, nullifier height, and transaction-history height.
- Phase-42 batch persistence uses prepared/cached SQL statements inside the same atomic transaction.
- Transaction history upserts use an index instead of a linear txid search; sorted presentation order is preserved.
- Release profile explicitly enables `opt-level=3`, ThinLTO, one codegen unit, and symbol stripping.
- ProofSkip remains disabled; no authenticated validation or signature behavior is bypassed.

## Deliberately preserved

- Ycash consensus behavior.
- Ordered commitment-tree and witness mutation.
- Reorg height/hash checks.
- Trial decryption and authenticated matching semantics.
- Existing signature serialization and verification behavior.
- Existing wallet serialization format.
- Full SQLite durability (`synchronous=FULL`).

## Not claimed without a Rust build environment

The supplied environment does not contain `cargo`/`rustc`, so the archive cannot be honestly certified as compiled or benchmarked here. The changes were kept source-compatible in structure and formatted conservatively, but a clean Android/release build and the full cryptographic regression suite must be run in the project's Rust/Android CI before release.

## Recommended validation

1. `cargo check --release`
2. `cargo test --release`
3. Existing SHAKE-256 KATs.
4. Existing ring differential/identity tests.
5. Existing sign/verify tests and 1140-byte invariant tests.
6. Full Ycash sync regression.
7. Compare blocks/sec, crypto ops/sec, peak RAM, allocations, DB time, and network utilization on low/high-end Android devices.
