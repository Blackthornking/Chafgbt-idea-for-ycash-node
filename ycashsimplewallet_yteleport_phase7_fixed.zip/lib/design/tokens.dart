import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design tokens for the Ycash black-and-orange identity.
class YColors {
  YColors._();

  // Backgrounds — deep black with warm charcoal surfaces.
  static const Color spaceDeep = Color(0xFF000000);
  static const Color spaceSurface = Color(0xFF000000);
  static const Color spaceSurfaceRaised = Color(0xFF000000);

  // Orange identity matched to the supplied Ycash branding.
  static const Color shieldedPrimary = Color(0xFFFF7A00);
  static const Color shieldedSecondary = Color(0xFFFF4D00);
  static const Color transparentAccent = Color(0xFFFF9D1A);
  static const Color goldLight = Color(0xFFFFB347);
  static const Color goldDark = Color(0xFF7A2400);
  static const Color success = Color(0xFF7BD88F);
  static const Color danger = Color(0xFFFF6B5F);

  // Text — warm white and muted orange-grey for the new identity.
  static const Color textPrimary = Color(0xFFFFF8F2);
  static const Color textSecondary = Color(0xFFE8C3A3);
  static const Color textMuted = Color(0xFF9D806B);

  static const LinearGradient shieldedGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [goldLight, shieldedPrimary, shieldedSecondary],
  );

  static const LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [goldLight, shieldedPrimary, goldDark],
  );
}

class YSpacing {
  YSpacing._();
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 32;
  static const double xxl = 48;
}

class YRadius {
  YRadius._();
  static const double card = 20;
  static const double button = 16;
  static const double pill = 999;
}

class YMotion {
  YMotion._();
  static const Duration fast = Duration(milliseconds: 150);
  static const Duration base = Duration(milliseconds: 300);
  static const Duration slow = Duration(milliseconds: 500);
  static const Curve standard = Curves.easeOutCubic;
}

ThemeData buildYcashTheme() {
  final baseText = GoogleFonts.spaceGroteskTextTheme();

  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: YColors.spaceDeep,
    colorScheme: const ColorScheme.dark(
      primary: YColors.shieldedPrimary,
      onPrimary: Color(0xFF1A0B00),
      secondary: YColors.goldLight,
      onSecondary: Color(0xFF1A0B00),
      surface: YColors.spaceSurface,
      onSurface: YColors.textPrimary,
      error: YColors.danger,
    ),
    textTheme: baseText.apply(
      bodyColor: YColors.textPrimary,
      displayColor: YColors.textPrimary,
    ),
    cardTheme: CardThemeData(
      color: YColors.spaceSurface,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(YRadius.card),
        side: const BorderSide(color: Color(0xFF4A210C)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: YColors.spaceSurfaceRaised,
      contentPadding: const EdgeInsets.symmetric(
          horizontal: YSpacing.md, vertical: YSpacing.md),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: const BorderSide(color: Color(0xFF4A210C)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: const BorderSide(color: Color(0xFF4A210C)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: const BorderSide(color: YColors.shieldedPrimary, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: const BorderSide(color: YColors.danger),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(YRadius.button),
        borderSide: const BorderSide(color: YColors.danger, width: 1.5),
      ),
      labelStyle: const TextStyle(color: YColors.textSecondary),
      hintStyle: const TextStyle(color: YColors.textMuted),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: YColors.shieldedPrimary,
        foregroundColor: const Color(0xFF1A0B00),
        padding: const EdgeInsets.symmetric(
          vertical: YSpacing.md,
          horizontal: YSpacing.lg,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(YRadius.button),
        ),
        textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: YColors.goldLight,
        side: const BorderSide(color: YColors.goldDark),
        padding: const EdgeInsets.symmetric(vertical: YSpacing.md, horizontal: YSpacing.lg),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(YRadius.button)),
      ),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.black,
      elevation: 0,
      foregroundColor: YColors.textPrimary,
    ),
    dividerColor: const Color(0xFF4A210C),
    progressIndicatorTheme: const ProgressIndicatorThemeData(
      color: YColors.shieldedPrimary,
      linearTrackColor: YColors.spaceSurfaceRaised,
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: Colors.black,
      surfaceTintColor: Colors.black,
    ),
    dialogTheme: const DialogThemeData(
      backgroundColor: Colors.black,
      surfaceTintColor: Colors.black,
    ),
  );
}

ThemeData buildYcashLightTheme() {
  final baseText = GoogleFonts.spaceGroteskTextTheme();
  const ink = Color(0xFF171411);
  const paper = Color(0xFFFFFBF7);
  const surface = Color(0xFFFFFFFF);
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    scaffoldBackgroundColor: paper,
    colorScheme: const ColorScheme.light(
      primary: YColors.shieldedPrimary,
      onPrimary: Colors.white,
      secondary: YColors.shieldedSecondary,
      surface: surface,
      onSurface: ink,
      error: YColors.danger,
    ),
    textTheme: baseText.apply(bodyColor: ink, displayColor: ink),
    appBarTheme: const AppBarTheme(backgroundColor: paper, foregroundColor: ink, elevation: 0),
    cardTheme: CardThemeData(color: surface, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(YRadius.card), side: const BorderSide(color: Color(0xFFE9DED5)))),
    dividerColor: const Color(0xFFE9DED5),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: surface, border: OutlineInputBorder(borderRadius: BorderRadius.circular(YRadius.button), borderSide: const BorderSide(color: Color(0xFFE0D5CD)))),
    elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(backgroundColor: YColors.shieldedPrimary, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: YSpacing.md, horizontal: YSpacing.lg), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(YRadius.button)))),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(foregroundColor: YColors.shieldedSecondary, side: const BorderSide(color: YColors.shieldedPrimary), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(YRadius.button)))),
  );
}
