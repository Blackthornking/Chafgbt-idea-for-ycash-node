import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'dart:async';
import 'app.dart';
import 'screens/fatal_error.dart';

void main() {
  // Final safety net, not the primary handler -- app.dart's own try/catch
  // around the startup wallet check is what normally catches a startup
  // failure and shows it. This is here for anything *outside* that (a
  // widget build error elsewhere, an unawaited Future throwing), so the
  // worst case is still visible error text instead of a blank screen or a
  // release build that just quietly fails to render anything, which is
  // Flutter's actual default behavior for an uncaught error outside debug
  // mode.
  var showingFatalScreen = false;
  runZonedGuarded(() {
    WidgetsFlutterBinding.ensureInitialized();
    FlutterError.onError = (details) {
      FlutterError.presentError(details);
      debugPrint('FlutterError: ${details.exceptionAsString()}\n${details.stack}');
      // FlutterError.onError fires for framework-level build errors --
      // including ones during State construction, before app.dart's own
      // try/catch is even in scope (e.g. if SimpleWallet's constructor
      // chain fails). Those previously only got logged here, invisibly in
      // a release build, while the app itself was left showing nothing.
      // Guarded against re-entrancy: if FatalErrorScreen's own build
      // somehow triggered another FlutterError, this must not recurse.
      if (!showingFatalScreen) {
        showingFatalScreen = true;
        runApp(FatalErrorScreen(message: '${details.exceptionAsString()}\n\n${details.stack}'));
      }
    };
    runApp(const YcashSimpleApp());
  }, (error, stack) {
    debugPrint('Uncaught zone error: $error\n$stack');
    if (!showingFatalScreen) {
      showingFatalScreen = true;
      runApp(FatalErrorScreen(message: '$error\n\n$stack'));
    }
  });
}
