import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/wallet.dart';

/// Shown once, immediately after a new wallet is created.
///
/// This is the only moment the phrase has certainly never been recorded
/// anywhere. Everything else in the wallet — the PIN, biometrics, the
/// encrypted wallet file — protects the device's copy; only these 24 words
/// survive losing the device. So the continue button stays disabled until the
/// warning has been acknowledged, rather than letting it be skipped past.
class SeedBackup extends StatefulWidget {
  final SimpleWallet wallet;
  const SeedBackup({super.key, required this.wallet});
  @override
  State<SeedBackup> createState() => _SeedBackupState();
}

class _SeedBackupState extends State<SeedBackup> {
  String? _seed;
  String? _err;
  bool _confirmed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final s = await widget.wallet.revealSeed();
      if (mounted) setState(() => _seed = s);
    } catch (e) {
      if (mounted) setState(() => _err = '$e');
    }
  }

  @override
  Widget build(BuildContext c) {
    final words = (_seed ?? '').trim().split(RegExp(r'\s+'))
      ..removeWhere((w) => w.isEmpty);

    return PopScope(
      // Backing out of this screen skips the one irreplaceable step in setup.
      canPop: false,
      child: Scaffold(
        appBar: AppBar(title: const Text('Your recovery phrase'), automaticallyImplyLeading: false),
        body: _err != null
          ? Center(child: Padding(padding: const EdgeInsets.all(24),
              child: Text('Could not read the phrase:\n\n$_err', textAlign: TextAlign.center)))
          : _seed == null
            ? const Center(child: CircularProgressIndicator())
            : ListView(padding: const EdgeInsets.all(20), children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.amber.withValues(alpha: 0.5)),
                    borderRadius: BorderRadius.circular(14),
                    color: Colors.amber.withValues(alpha: 0.08)),
                  child: const Text(
                    'Write these 24 words down on paper, in order, and keep them '
                    'somewhere safe and offline.\n\n'
                    'They are the only way to recover this wallet if you lose the '
                    'phone. Anyone who has them can spend your funds — never type '
                    'them into a website or send them to anyone, including anyone '
                    'claiming to be support.',
                    style: TextStyle(fontSize: 13, height: 1.4)),
                ),
                const SizedBox(height: 20),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (var i = 0; i < words.length; i++)
                    Container(
                      width: 150,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        border: Border.all(color: Theme.of(c).dividerColor),
                        borderRadius: BorderRadius.circular(10)),
                      child: Row(children: [
                        SizedBox(width: 24, child: Text('${i + 1}',
                          style: TextStyle(fontSize: 12, color: Theme.of(c).hintColor))),
                        Expanded(child: Text(words[i],
                          style: const TextStyle(fontWeight: FontWeight.w600))),
                      ]),
                    ),
                ]),
                const SizedBox(height: 18),
                OutlinedButton.icon(
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: _seed!));
                    ScaffoldMessenger.of(c).showSnackBar(const SnackBar(
                      content: Text('Copied — paste it somewhere safe, then clear your clipboard')));
                  },
                  icon: const Icon(Icons.copy, size: 18),
                  label: const Text('Copy recovery phrase')),
                const SizedBox(height: 20),
                CheckboxListTile(
                  value: _confirmed,
                  onChanged: (v) => setState(() => _confirmed = v ?? false),
                  contentPadding: EdgeInsets.zero,
                  controlAffinity: ListTileControlAffinity.leading,
                  title: const Text('I have written these words down'),
                ),
                const SizedBox(height: 8),
                FilledButton(
                  onPressed: _confirmed ? () => Navigator.pop(c, true) : null,
                  child: const Text('Continue')),
                const SizedBox(height: 8),
                Text(
                  'You can see this again at any time under Settings > Security.',
                  style: TextStyle(fontSize: 12, color: Theme.of(c).hintColor)),
                const SizedBox(height: 24),
              ])),
    );
  }
}
