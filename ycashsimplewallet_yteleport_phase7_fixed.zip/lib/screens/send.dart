import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/auth.dart';
import '../core/privacy.dart';
import '../core/theme.dart';
import '../core/wallet.dart';

/// What the wallet is actually doing, in order.
///
/// A send takes several seconds and nearly all of it is one step: generating
/// the zero-knowledge proof. The old screen said "Sending…" for the whole
/// duration, which is indistinguishable from a hang — and it hid the one
/// genuinely interesting thing the wallet does. Naming the stages turns dead
/// time into something legible, and the stage that is slow is the stage worth
/// telling someone about.
enum SendStage { compose, review, proving, broadcasting, done, failed }

class Send extends StatefulWidget {
  final SimpleWallet wallet;
  const Send({super.key, required this.wallet});
  @override
  State<Send> createState() => _SendState();
}

class _SendState extends State<Send> {
  final _to = TextEditingController();
  final _memo = TextEditingController();
  final _amount = TextEditingController();

  SendStage _stage = SendStage.compose;
  bool _privateMode = false;
  int? _spendable;
  Map<String, dynamic>? _plan;
  String? _error;
  String? _txid;

  bool get _shielded => _to.text.trim().startsWith('ys1');
  bool get _busy => _stage == SendStage.proving || _stage == SendStage.broadcasting;

  @override
  void initState() {
    super.initState();
    PrivateMode.isEnabled().then((v) { if (mounted) setState(() => _privateMode = v); });
    _loadBalance();
    _to.addListener(() { if (mounted) setState(() {}); });
    _amount.addListener(() { if (mounted) setState(() {}); });
  }

  @override
  void dispose() { _to.dispose(); _memo.dispose(); _amount.dispose(); super.dispose(); }

  Future<void> _loadBalance() async {
    try {
      final b = await widget.wallet.snapshotAsync();
      final bal = Map<String, dynamic>.from(b['balances'] as Map);
      final z = (bal['spendable_zbalance'] as num?)?.toInt() ?? 0;
      final t = (bal['tbalance'] as num?)?.toInt() ?? 0;
      if (mounted) setState(() => _spendable = z + t);
    } catch (_) {}
  }

  int? get _zats {
    final t = _amount.text.trim();
    if (t.isEmpty) return null;
    final v = double.tryParse(t);
    if (v == null || v <= 0) return null;
    return (v * 1e8).round();
  }

  Future<void> _review() async {
    setState(() => _error = null);
    final zats = _zats;
    if (zats == null) { setState(() => _error = 'Enter an amount greater than zero'); return; }
    if (_to.text.trim().isEmpty) { setState(() => _error = 'Enter a Ycash address'); return; }

    // Refuse rather than warn. A warning that can be dismissed is a setting
    // with extra steps; the point of the mode is that the private path is
    // the only path while it is on.
    // Re-read rather than trusting the value captured when this screen
    // opened: the mode may have been changed in Settings since.
    _privateMode = await PrivateMode.isEnabled();
    if (!mounted) return;
    if (_privateMode && PrivateMode.isTransparentAddress(_to.text)) {
      setState(() => _error =
        'Private mode only sends to shielded addresses. This one is public, '
        'so the payment would be visible on the block explorer. Turn private '
        'mode off in Settings if you need to send here.');
      return;
    }

    setState(() => _stage = SendStage.review);
    try {
      final memo = (_shielded && _memo.text.trim().isNotEmpty) ? _memo.text.trim() : null;
      final p = await widget.wallet.planSendAsync(
        to: _to.text.trim(), amount: zats, memo: memo);
      if (mounted) setState(() => _plan = p);
    } catch (e) {
      if (mounted) setState(() { _stage = SendStage.compose; _error = '$e'; });
    }
  }

  Future<void> _confirm() async {
    final plan = _plan;
    if (plan == null) return;
    final planned = (plan['amount'] as num?)?.toInt() ?? 0;

    if (await WalletLock.isAvailable()) {
      final ok = await WalletLock.authenticate(
        reason: 'Confirm sending ${(planned / 1e8).toStringAsFixed(8)} YEC');
      if (!ok) {
        if (mounted) setState(() { _stage = SendStage.review; _error = 'Not confirmed'; });
        return;
      }
    }

    widget.wallet.pausePolling();
    setState(() { _stage = SendStage.proving; _error = null; });
    try {
      // The broadcast is one native call, so the split between proving and
      // broadcasting is indicative rather than measured. Proving is the part
      // that takes seconds; showing the handover keeps the screen honest
      // about where the time goes without pretending to more precision.
      final txid = await widget.wallet.broadcastAsync(plan);
      if (!mounted) return;
      setState(() { _stage = SendStage.done; _txid = txid; });
    } catch (e) {
      if (mounted) setState(() { _stage = SendStage.failed; _error = '$e'; });
    } finally {
      widget.wallet.resumePolling();
    }
  }

  @override
  Widget build(BuildContext c) {
    return PopScope(
      canPop: !_busy,
      child: Scaffold(
        appBar: AppBar(
          title: Text(switch (_stage) {
            SendStage.done => 'Sent',
            SendStage.failed => 'Not sent',
            _ => 'Send',
          }),
          automaticallyImplyLeading: !_busy,
        ),
        body: switch (_stage) {
          SendStage.compose => _compose(c),
          SendStage.review => _review_(c),
          SendStage.proving || SendStage.broadcasting => _working(c),
          SendStage.done => _done(c),
          SendStage.failed => _failed(c),
        },
      ),
    );
  }

  // ---- compose -------------------------------------------------------

  Widget _compose(BuildContext c) => ListView(
    padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
    children: [
      TextField(
        controller: _to,
        decoration: const InputDecoration(
          labelText: 'To',
          hintText: 'ys1… or s1…'),
        style: YodlTheme.figures(size: 14, weight: FontWeight.w500),
      ),
      if (_to.text.trim().isNotEmpty) Padding(
        padding: const EdgeInsets.only(top: 8),
        child: _PrivacyTag(shielded: _shielded),
      ),
      const SizedBox(height: 22),
      // What you can actually spend, on screen while you type against it.
      // Spendable rather than total: unconfirmed change cannot be sent yet,
      // so showing the headline balance here would invite a plan that fails.
      Row(children: [
        Text('Available', style: TextStyle(fontSize: 13, color: Theme.of(c).hintColor)),
        const Spacer(),
        Text(_spendable == null ? '…' : (_spendable! / 1e8).toStringAsFixed(8),
          style: YodlTheme.figures(size: 13, weight: FontWeight.w600)),
      ]),
      const SizedBox(height: 10),
      TextField(
        controller: _amount,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
        decoration: InputDecoration(
          labelText: 'Amount',
          suffixText: 'YEC',
          suffix: TextButton(
            onPressed: (_spendable == null || _spendable == 0) ? null : () {
              // Hold back the fee: the native planner would otherwise reduce
              // the amount itself, which is correct but surprising.
              final max = (_spendable! - 1000).clamp(0, 1 << 62);
              _amount.text = (max / 1e8).toStringAsFixed(8);
            },
            child: const Text('Max')),
        ),
        style: YodlTheme.figures(size: 26, weight: FontWeight.w700),
      ),
      const SizedBox(height: 22),
      TextField(
        controller: _memo,
        enabled: _shielded,
        maxLines: 2,
        decoration: InputDecoration(
          labelText: 'Message',
          helperMaxLines: 2,
          helperText: _shielded
            ? 'Encrypted. Only the recipient can read it.'
            : 'Only shielded addresses can carry a message.'),
      ),
      if (_error != null) Padding(
        padding: const EdgeInsets.only(top: 18),
        child: Text(_error!, style: TextStyle(color: Theme.of(c).colorScheme.error)),
      ),
      const SizedBox(height: 28),
      FilledButton(
        onPressed: _review,
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(54),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
        child: const Text('Review')),
    ]);

  // ---- review --------------------------------------------------------

  Widget _review_(BuildContext c) {
    final plan = _plan;
    if (plan == null) {
      return const Center(child: CircularProgressIndicator());
    }
    final amount = (plan['amount'] as num?)?.toInt() ?? 0;
    final fee = (plan['fee'] as num?)?.toInt() ?? 0;
    final adjusted = plan['fee_deducted'] == true;
    final memoDropped = plan['memo_dropped'] == true;

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
      children: [
        Center(child: Text(
          (amount / 1e8).toStringAsFixed(8),
          style: YodlTheme.figures(size: 42, weight: FontWeight.w700))),
        const SizedBox(height: 6),
        Center(child: Text('YEC', style: TextStyle(
          fontSize: 13, letterSpacing: 2, color: Theme.of(c).hintColor))),
        const SizedBox(height: 28),
        _Row('To', _to.text.trim(), mono: true),
        _Row('Network fee', (fee / 1e8).toStringAsFixed(8), mono: true),
        _Row('Total', ((amount + fee) / 1e8).toStringAsFixed(8), mono: true, strong: true),
        _Row('Privacy', _shielded ? 'Shielded' : 'Public'),
        if (adjusted) _Note('Amount reduced by the fee so it fits your balance.'),
        if (memoDropped) _Note('The message was dropped: this address is public.'),
        const SizedBox(height: 30),
        FilledButton(
          onPressed: _confirm,
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(54),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
          child: const Text('Send')),
        const SizedBox(height: 8),
        TextButton(
          onPressed: () => setState(() { _stage = SendStage.compose; _plan = null; }),
          child: const Text('Edit')),
      ]);
  }

  // ---- working -------------------------------------------------------

  Widget _working(BuildContext c) => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const _ProofPulse(),
        const SizedBox(height: 32),
        Text('Building the proof',
          style: Theme.of(c).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        Text('Keep the app open',
          style: TextStyle(fontSize: 12, color: Theme.of(c).hintColor)),
      ])));

  // ---- done / failed -------------------------------------------------

  Widget _done(BuildContext c) => ListView(
    padding: const EdgeInsets.fromLTRB(20, 40, 20, 32),
    children: [
      Icon(Icons.check_circle_outline, size: 56, color: Theme.of(c).colorScheme.primary),
      const SizedBox(height: 20),
      Center(child: Text('Payment sent',
        style: Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700))),
      const SizedBox(height: 28),
      if (_txid != null) ...[
        _Row('Transaction', _txid!, mono: true),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: () {
            Clipboard.setData(ClipboardData(text: _txid!));
            ScaffoldMessenger.of(c).showSnackBar(
              const SnackBar(content: Text('Transaction ID copied')));
          },
          icon: const Icon(Icons.copy, size: 18),
          label: const Text('Copy transaction ID')),
      ],
      const SizedBox(height: 24),
      FilledButton(
        onPressed: () => Navigator.pop(c),
        style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
        child: const Text('Done')),
    ]);

  Widget _failed(BuildContext c) => ListView(
    padding: const EdgeInsets.fromLTRB(20, 40, 20, 32),
    children: [
      Icon(Icons.error_outline, size: 56, color: Theme.of(c).colorScheme.error),
      const SizedBox(height: 20),
      Center(child: Text('Payment not sent',
        style: Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700))),
      const SizedBox(height: 10),
      Center(child: Text('Nothing left your wallet.',
        style: TextStyle(fontSize: 13, color: Theme.of(c).hintColor))),
      const SizedBox(height: 22),
      if (_error != null) Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          border: Border.all(color: Theme.of(c).colorScheme.error.withValues(alpha: 0.5)),
          borderRadius: BorderRadius.circular(12)),
        child: SelectableText(_error!, style: const TextStyle(fontSize: 12)),
      ),
      const SizedBox(height: 24),
      FilledButton(
        onPressed: () => setState(() { _stage = SendStage.review; _error = null; }),
        style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
        child: const Text('Try again')),
      const SizedBox(height: 8),
      TextButton(onPressed: () => Navigator.pop(c), child: const Text('Back to wallet')),
    ]);
}

/// The one piece of non-user-triggered motion in the app.
///
/// It exists because proof generation is a genuine multi-second wait with no
/// intermediate progress to report -- there is nothing to measure, so a
/// progress bar would be a lie. A slow concentric pulse says "working,
/// deliberately" without inventing a percentage.
class _ProofPulse extends StatefulWidget {
  const _ProofPulse();
  @override
  State<_ProofPulse> createState() => _ProofPulseState();
}

class _ProofPulseState extends State<_ProofPulse> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this, duration: const Duration(milliseconds: 2200))..repeat();

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.primary;
    // Respect the system setting: someone who has asked for less motion
    // should get a static mark, not a pulse.
    if (MediaQuery.of(context).disableAnimations) {
      return Icon(Icons.shield_outlined, size: 64, color: accent);
    }
    return SizedBox(
      width: 140, height: 140,
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) {
          // The mark breathes with the rings rather than sitting still inside
          // them. Proof generation reports no intermediate progress, so the
          // only honest signal is continuous motion -- a static centre inside
          // moving rings reads as a stalled spinner.
          final breathe = 1.0 + 0.06 * math.sin(_c.value * 2 * math.pi);
          return CustomPaint(
            painter: _PulsePainter(_c.value, accent),
            child: Center(
              child: Transform.scale(
                scale: breathe,
                child: Icon(Icons.shield_outlined, size: 44, color: accent),
              )),
          );
        }));
  }
}

class _PulsePainter extends CustomPainter {
  final double t;
  final Color colour;
  _PulsePainter(this.t, this.colour);

  @override
  void paint(Canvas canvas, Size size) {
    final centre = Offset(size.width / 2, size.height / 2);
    for (var i = 0; i < 3; i++) {
      final phase = (t + i / 3) % 1.0;
      final radius = 30 + phase * 38;
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = colour.withValues(alpha: (1 - phase) * 0.55);
      canvas.drawCircle(centre, radius, paint);
    }
  }

  @override
  bool shouldRepaint(_PulsePainter old) => old.t != t;
}

/// Shape carries the meaning: shielded is filled, public is outlined.
class _PrivacyTag extends StatelessWidget {
  final bool shielded;
  const _PrivacyTag({required this.shielded});
  @override
  Widget build(BuildContext c) {
    final accent = Theme.of(c).colorScheme.primary;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: shielded ? accent.withValues(alpha: 0.16) : Colors.transparent,
        border: Border.all(color: shielded ? accent : Theme.of(c).dividerColor),
        borderRadius: BorderRadius.circular(999)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(shielded ? Icons.shield : Icons.visibility_outlined,
          size: 13, color: shielded ? accent : Theme.of(c).hintColor),
        const SizedBox(width: 6),
        Text(shielded ? 'Shielded' : 'Public',
          style: TextStyle(fontSize: 12,
            color: shielded ? accent : Theme.of(c).hintColor)),
      ]));
  }
}

class _Row extends StatelessWidget {
  final String label, value;
  final bool mono, strong;
  const _Row(this.label, this.value, {this.mono = false, this.strong = false});
  @override
  Widget build(BuildContext c) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 11),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(width: 104, child: Text(label,
        style: TextStyle(fontSize: 13, color: Theme.of(c).hintColor))),
      Expanded(child: Text(value,
        textAlign: TextAlign.right,
        style: mono
          ? YodlTheme.figures(size: 13,
              weight: strong ? FontWeight.w700 : FontWeight.w500)
          : TextStyle(fontSize: 13,
              fontWeight: strong ? FontWeight.w700 : FontWeight.w500))),
    ]));
}

class _Note extends StatelessWidget {
  final String text;
  const _Note(this.text);
  @override
  Widget build(BuildContext c) => Padding(
    padding: const EdgeInsets.only(top: 10),
    child: Text(text,
      style: TextStyle(fontSize: 12, color: Theme.of(c).hintColor)));
}
