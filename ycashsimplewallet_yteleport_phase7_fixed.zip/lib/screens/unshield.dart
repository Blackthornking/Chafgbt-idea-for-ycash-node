import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/auth.dart';
import '../core/theme.dart';
import '../core/wallet.dart';

/// Move shielded funds to this wallet's own transparent address.
///
/// Deliberately not a button on the home screen. Shielding is offered up
/// front because it only ever improves your position; unshielding gives
/// something up permanently, and it belongs next to the explanation of what
/// transparent means rather than one tap from the balance.
///
/// The wording avoids alarm language. It states what becomes public and lets
/// the person decide — a warning triangle would imply the wallet disapproves,
/// when transparent funds are a legitimate need (many exchanges still refuse
/// to send to a shielded address).
class Unshield extends StatefulWidget {
  final SimpleWallet wallet;
  const Unshield({super.key, required this.wallet});
  @override
  State<Unshield> createState() => _UnshieldState();
}

class _UnshieldState extends State<Unshield> {
  final _amount = TextEditingController();
  int? _spendable;
  bool _busy = false;
  String? _error;
  String? _txid;

  @override
  void initState() {
    super.initState();
    _amount.addListener(() { if (mounted) setState(() {}); });
    _load();
  }

  @override
  void dispose() { _amount.dispose(); super.dispose(); }

  Future<void> _load() async {
    try {
      final v = await widget.wallet.spendableShieldedAsync();
      if (mounted) setState(() => _spendable = v);
    } catch (_) {}
  }

  int? get _zats {
    final t = _amount.text.trim();
    if (t.isEmpty) return null;
    final v = double.tryParse(t);
    if (v == null || v <= 0) return null;
    return (v * 1e8).round();
  }

  Future<void> _go() async {
    final zats = _zats;
    if (zats == null) { setState(() => _error = 'Enter an amount greater than zero'); return; }
    final available = _spendable ?? 0;
    if (zats > available) {
      setState(() => _error = 'More than your spendable shielded balance');
      return;
    }

    final confirmed = await showDialog<bool>(context: context, builder: (d) => AlertDialog(
      title: const Text('Move to transparent'),
      content: Text(
        'Moves ${(zats / 1e8).toStringAsFixed(8)} YEC to your own transparent '
        'address, less the network fee.\n\n'
        'Once there, the amount and the address are permanently visible on the '
        'block explorer, and these coins become linkable to any other activity '
        'on that address.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Move')),
      ]));
    if (confirmed != true || !mounted) return;

    // Same bar as sending: this spends, and it gives up privacy.
    if (await WalletLock.isAvailable()) {
      final ok = await WalletLock.authenticate(reason: 'Confirm moving funds to transparent');
      if (!ok) { if (mounted) setState(() => _error = 'Not confirmed'); return; }
    }

    if (!mounted) return;
    setState(() { _busy = true; _error = null; });
    widget.wallet.pausePolling();
    try {
      final tx = await widget.wallet.unshieldAsync(amount: zats);
      if (mounted) setState(() => _txid = tx);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      widget.wallet.resumePolling();
      if (mounted) setState(() => _busy = false);
      _load();
    }
  }

  @override
  Widget build(BuildContext c) {
    final available = _spendable;
    return Scaffold(
      appBar: AppBar(title: const Text('Move to transparent')),
      body: _busy
        ? const Center(child: Padding(
            padding: EdgeInsets.all(32),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              CircularProgressIndicator(),
              SizedBox(height: 24),
              Text('Building the proof'),
              SizedBox(height: 8),
              Text('Keep the app open', style: TextStyle(fontSize: 12)),
            ])))
        : ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 32), children: [
            Text(
              'Sends shielded funds to your own transparent address. Useful '
              'when something will only accept a transparent (s1…) address.',
              style: TextStyle(fontSize: 13, height: 1.5, color: Theme.of(c).hintColor)),
            const SizedBox(height: 22),

            // The balance sits directly above the field, so the number you
            // are typing against is on screen while you type it.
            Row(children: [
              Text('Available', style: TextStyle(fontSize: 13, color: Theme.of(c).hintColor)),
              const Spacer(),
              Text(available == null ? '…' : (available / 1e8).toStringAsFixed(8),
                style: YodlTheme.figures(size: 13, weight: FontWeight.w600)),
            ]),
            const SizedBox(height: 10),
            TextField(
              controller: _amount,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
              decoration: InputDecoration(
                labelText: 'Amount',
                suffixText: 'YEC',
                suffix: TextButton(
                  onPressed: available == null || available == 0 ? null : () {
                    // Leave the fee behind so the plan cannot come back short.
                    final max = (available - 1000).clamp(0, 1 << 62);
                    _amount.text = (max / 1e8).toStringAsFixed(8);
                  },
                  child: const Text('Max')),
              ),
              style: YodlTheme.figures(size: 24, weight: FontWeight.w700),
            ),
            if (_error != null) Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Text(_error!, style: TextStyle(color: Theme.of(c).colorScheme.error))),
            if (_txid != null) Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Moved', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                SelectableText(_txid!, style: YodlTheme.figures(size: 12)),
              ])),
            const SizedBox(height: 26),
            FilledButton(
              onPressed: _go,
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
              child: const Text('Move to transparent')),
          ]),
    );
  }
}
