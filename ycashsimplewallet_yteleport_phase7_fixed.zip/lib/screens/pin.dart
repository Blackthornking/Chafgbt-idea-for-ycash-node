import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/pin.dart';

/// Ask for the existing PIN. Pops `true` on success, `false`/null otherwise.
class PinEntry extends StatefulWidget {
  final String title;
  final String subtitle;
  const PinEntry({super.key, this.title = 'Enter PIN', required this.subtitle});
  @override
  State<PinEntry> createState() => _PinEntryState();

  /// Convenience: push the screen and report whether the PIN was accepted.
  static Future<bool> ask(BuildContext c, String subtitle) async {
    if (!await WalletPin.isSet()) {
      if (!c.mounted) return false;
      ScaffoldMessenger.of(c).showSnackBar(const SnackBar(
        content: Text('Set a PIN first, under Settings > Security')));
      return false;
    }
    if (!c.mounted) return false;
    final ok = await Navigator.push<bool>(c, MaterialPageRoute(
      builder: (_) => PinEntry(subtitle: subtitle)));
    return ok == true;
  }
}

class _PinEntryState extends State<PinEntry> {
  final _c = TextEditingController();
  String? _err;
  bool _busy = false;

  Future<void> _submit() async {
    final wait = await WalletPin.lockoutRemaining();
    if (wait > 0) {
      setState(() => _err = 'Too many attempts. Try again in ${wait}s.');
      return;
    }
    setState(() { _busy = true; _err = null; });
    final ok = await WalletPin.verify(_c.text);
    if (!mounted) return;
    if (ok) {
      Navigator.pop(context, true);
      return;
    }
    final remaining = await WalletPin.lockoutRemaining();
    if (!mounted) return;
    setState(() {
      _busy = false;
      _c.clear();
      _err = remaining > 0
        ? 'Incorrect PIN. Locked for ${remaining}s.'
        : 'Incorrect PIN.';
    });
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: Text(widget.title)),
    body: ListView(padding: const EdgeInsets.all(28), children: [
      const SizedBox(height: 20),
      const Icon(Icons.pin_outlined, size: 44),
      const SizedBox(height: 18),
      Text(widget.subtitle, textAlign: TextAlign.center,
        style: TextStyle(color: Theme.of(c).hintColor)),
      const SizedBox(height: 28),
      _PinField(controller: _c, onSubmit: _submit),
      if (_err != null) Padding(padding: const EdgeInsets.only(top: 14),
        child: Text(_err!, textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.redAccent))),
      const SizedBox(height: 24),
      FilledButton(onPressed: _busy ? null : _submit,
        child: Text(_busy ? 'Checking…' : 'Confirm')),
    ]));
}

/// Set or change the PIN. Requires typing it twice.
class PinSetup extends StatefulWidget {
  const PinSetup({super.key});
  @override
  State<PinSetup> createState() => _PinSetupState();
}

class _PinSetupState extends State<PinSetup> {
  final _a = TextEditingController(), _b = TextEditingController();
  String? _err;

  Future<void> _save() async {
    if (!WalletPin.isValidFormat(_a.text)) {
      setState(() => _err = 'The PIN must be exactly 6 digits.');
      return;
    }
    if (_a.text != _b.text) {
      setState(() => _err = 'The two PINs do not match.');
      return;
    }
    // Sequences and repeats are the first things anyone tries.
    if (RegExp(r'^(\d)\1{5}$').hasMatch(_a.text) ||
        '0123456789'.contains(_a.text) ||
        '9876543210'.contains(_a.text)) {
      setState(() => _err = 'Choose a less predictable PIN.');
      return;
    }
    await WalletPin.setPin(_a.text);
    if (!mounted) return;
    Navigator.pop(context, true);
  }

  @override
  void dispose() { _a.dispose(); _b.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Set PIN')),
    body: ListView(padding: const EdgeInsets.all(28), children: [
      Text(
        'A 6-digit PIN. Biometrics alone will still unlock the app — this PIN '
        'is asked for on top, only when revealing your recovery phrase or '
        'resetting the wallet.',
        style: TextStyle(color: Theme.of(c).hintColor)),
      const SizedBox(height: 24),
      const Text('New PIN', style: TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      _PinField(controller: _a),
      const SizedBox(height: 20),
      const Text('Confirm PIN', style: TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      _PinField(controller: _b, onSubmit: _save),
      if (_err != null) Padding(padding: const EdgeInsets.only(top: 14),
        child: Text(_err!, style: const TextStyle(color: Colors.redAccent))),
      const SizedBox(height: 24),
      FilledButton(onPressed: _save, child: const Text('Save PIN')),
      const SizedBox(height: 16),
      Text(
        'If you forget this PIN it cannot be recovered. Your 24-word phrase is '
        'what restores the wallet, so keep that written down somewhere safe.',
        style: TextStyle(fontSize: 12, color: Theme.of(c).hintColor)),
    ]));
}

class _PinField extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback? onSubmit;
  const _PinField({required this.controller, this.onSubmit});

  @override
  Widget build(BuildContext c) => TextField(
    controller: controller,
    obscureText: true,
    keyboardType: TextInputType.number,
    maxLength: WalletPin.length,
    autofocus: true,
    textAlign: TextAlign.center,
    style: const TextStyle(fontSize: 28, letterSpacing: 14),
    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
    // No placeholder dots. Six greyed-out bullets in an obscured field are
    // indistinguishable from six entered digits, so an empty field looked
    // like a full one.
    decoration: const InputDecoration(counterText: ''),
    onSubmitted: (_) => onSubmit?.call(),
  );
}
