import 'package:flutter/material.dart';
import '../design/tokens.dart';

/// Shown whenever something fails badly enough, early enough, that the
/// normal screens can't take over -- a startup crash, or anything caught
/// by the zone-level handler in main.dart.
///
/// This exists because Flutter's default uncaught-error behavior (the red
/// "error" screen) is a *debug-mode-only* feature -- a release build (which
/// is what a CI-built APK is) normally just fails to render, silently,
/// with no visible indication anything went wrong at all. Without this,
/// "doesn't open" has no more diagnostic information than a black screen;
/// with it, the actual error text is on-screen and can be read directly or
/// screenshotted, without needing adb/logcat access to the device.
class FatalErrorScreen extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;
  const FatalErrorScreen({super.key, required this.message, this.onRetry});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, brightness: Brightness.dark, scaffoldBackgroundColor: YColors.spaceDeep),
      home: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 24),
                const Icon(Icons.error_outline_rounded, color: YColors.danger, size: 40),
                const SizedBox(height: 16),
                const Text('Something went wrong opening Ycash',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 16),
                Expanded(
                  child: SingleChildScrollView(
                    child: SelectableText(
                      message,
                      style: const TextStyle(fontSize: 13, color: YColors.textSecondary, fontFamily: 'monospace'),
                    ),
                  ),
                ),
                if (onRetry != null) ...[
                  const SizedBox(height: 16),
                  SizedBox(width: double.infinity, child: ElevatedButton(onPressed: onRetry, child: const Text('Try again'))),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
