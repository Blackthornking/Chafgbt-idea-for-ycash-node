import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Device-level unlock gate for the wallet.
///
/// This deliberately does NOT use Keystore's `setUserAuthenticationRequired`
/// on the seed entry, even though that would be the stronger primitive.
/// Android invalidates such keys when the enrolled biometrics change — adding
/// a fingerprint, or a factory-reset-and-restore, would make the stored seed
/// permanently undecryptable. For a wallet whose seed is the only route back
/// to the funds, that failure mode is worse than the attack it prevents.
///
/// So the seed stays in ordinary hardware-backed secure storage, and this adds
/// an authentication check in front of reading it. An attacker with a rooted
/// device and physical access can still get past a gate like this; a thief
/// with an unlocked phone cannot, which is the realistic threat.
class WalletLock {
  static const _enabledKey = 'ycash.simple.requireUnlock';

  /// How long the app can sit in the background before it re-locks.
  /// Short enough to matter, long enough that glancing at sync progress and
  /// switching back doesn't demand a fingerprint every time.
  static const relockAfter = Duration(seconds: 60);

  static final _auth = LocalAuthentication();

  static Future<bool> isEnabled() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(_enabledKey) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> setEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_enabledKey, value);
  }

  /// Whether this device can authenticate at all — biometric *or* PIN,
  /// pattern or password. Checked before the setting can be turned on, so
  /// nobody enables a lock their device can't satisfy.
  static Future<bool> isAvailable() async {
    try {
      if (!await _auth.isDeviceSupported()) return false;
      final biometrics = await _auth.getAvailableBiometrics();
      // isDeviceSupported() is true when a device credential exists, so an
      // empty biometrics list is fine — PIN/pattern still works.
      return biometrics.isNotEmpty || await _auth.isDeviceSupported();
    } catch (_) {
      return false;
    }
  }

  /// Prompt for unlock. Returns true only on success.
  ///
  /// `biometricOnly: false` is important: it allows the device PIN, pattern
  /// or password as a fallback, so a failed or unenrolled fingerprint can
  /// never lock someone out of their own wallet.
  static Future<bool> authenticate({String reason = 'Unlock your Ycash wallet'}) async {
    try {
      return await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(
          biometricOnly: false,
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );
    } catch (_) {
      return false;
    }
  }
}
