import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'config.dart';

/// A named accent colour for the whole app.
///
/// Only the accent varies. Every scheme keeps the near-black background: a
/// wallet is read in the dark as often as not, and a light surface behind an
/// eight-decimal balance is harder to scan.
class YodlTheme {
  final String id;
  final String name;
  final Color seed;
  const YodlTheme(this.id, this.name, this.seed);

  static const purple = YodlTheme('purple', 'Purple', Color(0xFFB79CED));
  static const orange = YodlTheme('orange', 'Orange', Color(0xFFFF7A1A));
  static const green = YodlTheme('green', 'Green', Color(0xFF4ADE80));
  static const blue = YodlTheme('blue', 'Blue', Color(0xFF4D96FF));
  static const red = YodlTheme('red', 'Red', Color(0xFFFF5C5C));
  static const teal = YodlTheme('teal', 'Teal', Color(0xFF00C8D7));
  static const gold = YodlTheme('gold', 'Gold', Color(0xFFF5C542));
  static const pink = YodlTheme('pink', 'Pink', Color(0xFFFF5CA8));
  static const mint = YodlTheme('mint', 'Mint', Color(0xFF9FE6B8));
  static const light = YodlTheme('light', 'Minimal', Color(0xFFFFFFFF));

  static const all = <YodlTheme>[
    purple, orange, green, blue, red, teal, gold, pink, mint, light,
  ];

  static YodlTheme byId(String? id) =>
      all.firstWhere((t) => t.id == id, orElse: () => purple);

  static Future<YodlTheme> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return byId(prefs.getString(YcashConfig.themeKey));
    } catch (_) {
      return purple;
    }
  }

  static Future<void> save(YodlTheme t) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(YcashConfig.themeKey, t.id);
    } catch (_) {}
  }

  /// Figures: JetBrains Mono, for tabular numerals.
  ///
  /// Balances and block heights update continuously. In a proportional face
  /// the digits have different widths, so the number visibly jitters as it
  /// ticks and the decimal point wanders. Monospaced figures hold their
  /// column, which is what makes a readout look like an instrument rather
  /// than a web page. Used only for numbers -- prose stays in Space Grotesk.
  static TextStyle figures({
    required double size,
    FontWeight weight = FontWeight.w600,
    Color? color,
    double? letterSpacing,
  }) => GoogleFonts.jetBrainsMono(
        fontSize: size,
        fontWeight: weight,
        color: color,
        letterSpacing: letterSpacing ?? -0.5,
        height: 1.0,
      );

  ThemeData get data {
    final scheme = ColorScheme.fromSeed(
      seedColor: seed,
      brightness: Brightness.dark,
    ).copyWith(
      primary: seed,
      // Readable label on a saturated accent: light accents need dark text,
      // dark ones need light. Chosen by luminance rather than per-scheme
      // constants so a new accent cannot be added with an unreadable button.
      onPrimary: seed.computeLuminance() > 0.5 ? Colors.black : Colors.white,
      surface: const Color(0xFF080807),
    );
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
      textTheme: GoogleFonts.spaceGroteskTextTheme(
        ThemeData(brightness: Brightness.dark).textTheme),
      scaffoldBackgroundColor: const Color(0xFF080807),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: const Color(0xFF121211),
        indicatorColor: seed.withValues(alpha: 0.22),
        labelTextStyle: WidgetStatePropertyAll(
          TextStyle(fontSize: 11, color: scheme.onSurface)),
      ),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF121211)),
    );
  }
}
