import 'package:shared_preferences/shared_preferences.dart';
import 'config.dart';

/// Private mode: shielded is the only path.
///
/// This is a stance, not a convenience toggle. With it on, the wallet refuses
/// to send to a transparent address, buries its own transparent address
/// behind a warning, and moves any transparent funds that arrive into the
/// shielded pool without being asked.
///
/// What it CANNOT do, and says so plainly rather than implying otherwise:
///
///  - Stop someone sending you transparent funds. That transaction is public
///    the moment it confirms. Shielding afterwards conceals where the money
///    goes next, not where it came from.
///  - Run while the app is closed. There is no background service, so
///    auto-shielding happens when the wallet is open and caught up.
///  - Be free. Each shield costs a network fee, which is why small amounts
///    wait until they are worth moving rather than being swept instantly.
class PrivateMode {
  static const _key = YcashConfig.privateModeKey;

  /// Don't auto-shield below this. A shield costs 1,000 zatoshi, so sweeping
  /// dust would spend a meaningful fraction of it on fees -- and would do so
  /// repeatedly if small amounts keep arriving.
  static const minimumToShield = 100000; // 0.001 YEC

  /// Wait for the funds to be a few blocks deep before moving them. Shielding
  /// something that then gets reorganised out would produce an invalid spend.
  static const minimumConfirmations = 3;

  static Future<bool> isEnabled() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(_key) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> setEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_key, value);
  }

  /// A transparent recipient — the thing private mode refuses to send to.
  static bool isTransparentAddress(String address) {
    final a = address.trim();
    return a.startsWith('s1') || a.startsWith('s3');
  }

  static bool isShieldedAddress(String address) => address.trim().startsWith('ys1');

  /// Whether to sweep the transparent balance right now.
  ///
  /// Deliberately conservative: only when the wallet is caught up, only above
  /// the dust threshold, and only when nothing else is mid-flight. Sweeping
  /// during a sync would build a transaction against a stale note set.
  static bool shouldAutoShield({
    required bool enabled,
    required int transparentZats,
    required bool caughtUp,
    required bool busy,
  }) =>
      enabled &&
      caughtUp &&
      !busy &&
      transparentZats >= minimumToShield;
}


/// Testnet selection.
///
/// Read once at launch and never changed in place. Switching networks
/// requires a restart because the native engine keeps an open wallet, a data
/// directory and a configured server in process-global state -- flipping
/// those underneath a running wallet is how you end up showing a testnet
/// balance to someone who believes it is real money.
class Testnet {
  static Future<bool> isEnabled() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(YcashConfig.testnetKey) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> setEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(YcashConfig.testnetKey, value);
  }
}
