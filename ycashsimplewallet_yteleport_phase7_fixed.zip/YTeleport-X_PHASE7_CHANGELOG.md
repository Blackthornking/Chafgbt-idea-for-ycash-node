# YTeleport-X Phase 7 — Automatic Validation Gate

Implemented an automatic, fail-closed Phase 7 validation harness and exposed it to the wallet's YTeleport-X Settings page.

## What is automatic

- The YTeleport-X statistics page runs the native Phase 7 self-test when opened.
- Refresh reruns the test.
- The test executes locally and deterministically.
- It verifies ChainRoot derivation/verification, StateTransitionProof verification, compressed transition construction/verification, and tamper rejection.
- Results are displayed as PASS/FAIL with individual checks and elapsed time.

## Safety

- The self-test does not modify wallet state.
- It does not invent live peer/scanner telemetry.
- It does not bypass consensus or proof verification.
- Failures are reported as FAIL rather than being hidden.

## Native API

Added:

`ycash_yteleport_phase7_self_test_json`

and the Dart wrapper:

`YcashCoreNative.yteleportPhase7SelfTest()`

with `SimpleWallet.yteleportPhase7SelfTestAsync()`.

## Important scope boundary

This phase establishes the automatic cryptographic validation gate. A true live end-to-end equivalence test still requires wiring the YTeleport-X verified state output into the production scanner and comparing its wallet state with the existing scanner over the same live chain range. That is the next integration step and is not falsely represented as complete here.
