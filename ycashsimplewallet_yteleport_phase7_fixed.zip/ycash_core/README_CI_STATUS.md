# CI status

This directory is an older experimental native-core tree retained in the source
archive for reference. It is not the production Rust crate used by the Flutter
YCash wallet.

The production crate is:

`packages/ycash_core_ffi/rust`

GitHub Actions builds and tests that production crate, using the pinned YCash
vendored sources declared in `YCASH_UPSTREAM_LOCK.toml`.
