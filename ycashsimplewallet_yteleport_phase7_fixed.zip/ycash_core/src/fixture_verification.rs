use std::fs;
use std::path::Path;

pub fn sha256_file(path: impl AsRef<Path>) -> Result<String, String> {
    // The actual production implementation should use the pinned sha2 crate.
    // This boundary intentionally does not fake a cryptographic result.
    let bytes = fs::read(path).map_err(|e| e.to_string())?;
    if bytes.is_empty() {
        return Err("fixture is empty".into());
    }
    Err("sha256 backend must be wired to the pinned cryptographic dependency".into())
}

#[derive(Debug, Clone)]
pub struct FixtureExpectation {
    pub owned_notes: u64,
    pub spent_nullifiers: u64,
    pub confirmed_balance: u64,
}

pub fn require_real_fixture(
    source: &str,
    sha256: &str,
    template_only: bool,
) -> Result<(), String> {
    if template_only {
        return Err("template fixture cannot be used for cryptographic validation".into());
    }
    if source.trim().is_empty() {
        return Err("fixture source missing".into());
    }
    if sha256.len() != 64 || !sha256.chars().all(|c| c.is_ascii_hexdigit()) {
        return Err("fixture SHA-256 is invalid".into());
    }
    Ok(())
}
