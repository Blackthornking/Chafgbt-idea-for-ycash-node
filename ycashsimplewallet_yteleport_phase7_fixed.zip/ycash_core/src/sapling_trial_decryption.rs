//! Phase 27: Ycash Sapling trial-decryption integration boundary.
//!
//! A compact output is considered wallet-owned only after a pinned,
//! Ycash-compatible cryptographic backend verifies ownership.

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct IncomingViewingKey(pub Vec<u8>);

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CompactSaplingOutput {
    pub cmu: Vec<u8>,
    pub ephemeral_key: Vec<u8>,
    pub ciphertext: Vec<u8>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VerifiedNote {
    pub note_id: Vec<u8>,
    pub value: u64,
    pub nullifier: Vec<u8>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TrialDecryptResult {
    NotOwned,
    Owned(VerifiedNote),
}

pub trait SaplingTrialDecryptor {
    fn trial_decrypt(
        &self,
        ivk: &IncomingViewingKey,
        output: &CompactSaplingOutput,
    ) -> Result<TrialDecryptResult, String>;
}

pub trait NullifierMatcher {
    fn matches_wallet_nullifier(&self, nullifier: &[u8]) -> bool;
}

/// Production gate: implementations must be backed by the pinned
/// Ycash-compatible Sapling backend before real wallet funds are enabled.
pub fn require_verified_backend(backend_name: &str, pinned: bool) -> Result<(), String> {
    if backend_name.is_empty() {
        return Err("missing Sapling backend identity".into());
    }
    if !pinned {
        return Err("Sapling backend is not pinned to a verified Ycash revision".into());
    }
    Ok(())
}
