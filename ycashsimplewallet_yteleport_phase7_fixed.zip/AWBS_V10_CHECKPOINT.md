# AWBS V10 — Self-Updating Height Database

The wallet now maintains a lightweight SQLite height index at `awbs_sync.sqlite`.

## Policy

- Checkpoint interval: 500 committed blocks.
- Wallet persistence happens first.
- SQLite checkpoint is written only after wallet persistence succeeds.
- Final sync completion always writes the latest height.
- Manual save and rescan completion also write the latest height.
- SQLite uses WAL mode and `synchronous=FULL` for durable metadata writes.

## Safety

The SQLite database is not used to invent wallet state or skip blocks. The existing
wallet/light-client state remains authoritative. This avoids a database-ahead-of-
wallet failure mode.

## Performance

The index write itself is tiny, but wallet serialization is still required at each
500-block durable checkpoint because the checkpoint must correspond to persisted
wallet state. If future profiling shows wallet serialization is a bottleneck, the
next optimization should be an incremental wallet-state journal rather than simply
increasing the checkpoint interval.
