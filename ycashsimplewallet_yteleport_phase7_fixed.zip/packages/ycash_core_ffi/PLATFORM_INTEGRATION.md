# Rust FFI Platform Integration

Target layout:

- Android: Cargo NDK / `.so` libraries
- iOS: static libraries or XCFramework
- Linux: `.so`
- macOS: `.dylib`
- Windows: `.dll`

The Dart API must remain platform-independent. Platform hosts only load the
native library and provide the minimum secure-storage/native integration needed.

Cryptographic ownership and transaction authorization remain in Rust.
