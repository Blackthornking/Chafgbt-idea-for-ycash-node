# Phase 22 fixtures

This directory is intentionally empty of invented cryptographic vectors.

Add fixtures only when they are generated from a pinned Ycash-compatible backend
or captured from a reproducible Ycash test environment. Each fixture must record:

- upstream repository and exact commit
- network = ycash-mainnet
- derivation mode
- input seed/key identifier (never production secrets)
- expected public address/key output
- fixture SHA-256

Do not enable spending from fixture presence alone.
