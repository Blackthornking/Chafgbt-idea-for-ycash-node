//! YTeleport-X Phase 7: automatic end-to-end validation gate.
//!
//! This harness exercises the cryptographic pipeline without trusting peer
//! supplied state. It is deliberately deterministic and fail-closed. It does
//! not fabricate live peer/scanner telemetry; live integration remains a
//! separate transport/scanner wiring step.

use super::phase5::CompressedStateTransitionProof;
use super::yteleport::{ChainAnchor, ChainCheckpoint, Hash32, StateTransitionProof, StateUpdate, StateUpdateProof};
use serde::Serialize;
use std::time::Instant;

#[derive(Debug, Clone, Serialize)]
pub struct Phase7Check {
    pub name: String,
    pub passed: bool,
    pub detail: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct Phase7Report {
    pub protocol: String,
    pub passed: bool,
    pub checks: Vec<Phase7Check>,
    pub elapsed_ms: u64,
}

fn check(name: &str, result: Result<(), String>) -> Phase7Check {
    match result {
        Ok(()) => Phase7Check { name: name.into(), passed: true, detail: "verified".into() },
        Err(e) => Phase7Check { name: name.into(), passed: false, detail: e },
    }
}

fn valid_transition() -> StateTransitionProof {
    let siblings = vec![Hash32([0x33; 32]); 256];
    let u = StateUpdateProof::from_update(&StateUpdate {
        key: b"wallet/test-note".to_vec(),
        old_value: Hash32([0x11; 32]),
        new_value: Hash32([0x22; 32]),
    }, siblings).expect("deterministic fixture");
    StateTransitionProof::derive(
        u.root_for_for_test(Hash32([0x11; 32])),
        u.root_for_for_test(Hash32([0x22; 32])),
        vec![u],
    ).expect("deterministic fixture")
}

pub fn run() -> Phase7Report {
    let started = Instant::now();
    let mut checks = Vec::new();

    checks.push(check("protocol", {
        if super::yteleport::PROTOCOL_VERSION == 1 { Ok(()) } else { Err("unsupported protocol version".into()) }
    }));

    let anchor = ChainAnchor {
        network: "YcashMainnet".into(),
        height: 100,
        block_hash: Hash32([0x44; 32]),
        consensus_validated: true,
    };
    let checkpoint = ChainCheckpoint::derive(anchor, Hash32::ZERO)
        .map_err(|e| e.to_string());
    checks.push(check("chainroot derivation", checkpoint.as_ref().map(|_| ()).map_err(|e| e.clone())));
    if let Ok(cp) = checkpoint {
        checks.push(check("chainroot verification", cp.verify(Hash32::ZERO)));
    } else {
        checks.push(check("chainroot verification", Err("derivation failed".into())));
    }

    let transition = valid_transition();
    checks.push(check("state transition verification", transition.verify()));

    let compressed = CompressedStateTransitionProof::from_full(&transition)
        .map_err(|e| e.to_string());
    checks.push(check("compressed transition construction", compressed.as_ref().map(|_| ()).map_err(|e| e.clone())));
    if let Ok(cp) = compressed {
        checks.push(check("compressed transition verification", cp.verify().map(|_| ())));
    } else {
        checks.push(check("compressed transition verification", Err("construction failed".into())));
    }

    let mut tampered = transition.clone();
    tampered.updates[0].new_value.0[0] ^= 1;
    checks.push(check("tamper rejection", match tampered.verify() {
        Ok(_) => Err("tampering accepted".into()),
        Err(_) => Ok(()),
    }));

    let mut wrong_checkpoint = ChainCheckpoint::derive(
        ChainAnchor { network: "YcashMainnet".into(), height: 101, block_hash: Hash32([0x55; 32]), consensus_validated: true },
        Hash32::ZERO,
    ).expect("fixture");
    wrong_checkpoint.chain_root.0[0] ^= 1;
    checks.push(check("checkpoint tamper rejection", match wrong_checkpoint.verify(Hash32::ZERO) {
        Ok(_) => Err("tampering accepted".into()),
        Err(_) => Ok(()),
    }));

    let passed = checks.iter().all(|c| c.passed);
    Phase7Report {
        protocol: "YTeleport-X Phase 7".into(),
        passed,
        checks,
        elapsed_ms: started.elapsed().as_millis() as u64,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn automatic_gate_passes() {
        let r = run();
        assert!(r.passed, "phase 7 report: {:?}", r.checks);
    }
}
