//! AWBS bridge/skip infrastructure.
//!
//! A bridge is a server-supplied, wallet-independent summary of the
//! commitment-tree work between two authenticated heights.  When a range has
//! no newly received notes, a compatible bridge can replace the expensive
//! per-output witness/tree hashing.  We deliberately fail closed: a bridge
//! is used only when its endpoints, chain linkage and authenticated digest
//! match the requested range.  Without a bridge, the normal scanner remains
//! authoritative.
//!
//! Ycash lightwalletd does not currently expose the private WarpSync-2 bridge
//! API, so this module is bridge-ready rather than pretending the existing
//! endpoint supplies bridge data. A future bridge endpoint can populate the
//! cache without changing the scanner's correctness rules.

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fs;
use std::path::{Path, PathBuf};

const FILE_NAME: &str = "awbs_bridges.json";
const SCHEMA_VERSION: u32 = 1;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Bridge {
    pub start_height: u64,
    pub end_height: u64,
    pub start_root: [u8; 32],
    pub end_root: [u8; 32],
    /// Witness/tree transition payload supplied by a trusted bridge source.
    /// Its interpretation belongs to the exact Ycash tree implementation;
    /// arbitrary bytes are never treated as a valid bridge.
    pub payload: Vec<u8>,
    pub digest: [u8; 32],
}

impl Bridge {
    pub fn new(
        start_height: u64,
        end_height: u64,
        start_root: [u8; 32],
        end_root: [u8; 32],
        payload: Vec<u8>,
    ) -> Self {
        let digest = digest(start_height, end_height, &start_root, &end_root, &payload);
        Self { start_height, end_height, start_root, end_root, payload, digest }
    }

    pub fn is_well_formed(&self) -> bool {
        self.start_height < self.end_height
            && self.digest == digest(
                self.start_height,
                self.end_height,
                &self.start_root,
                &self.end_root,
                &self.payload,
            )
    }

    pub fn covers(&self, start: u64, end: u64) -> bool {
        self.start_height == start && self.end_height == end && self.is_well_formed()
    }
}

fn digest(start: u64, end: u64, start_root: &[u8; 32], end_root: &[u8; 32], payload: &[u8]) -> [u8; 32] {
    let mut h = Sha256::new();
    h.update(b"AWBS-BRIDGE-V1");
    h.update(start.to_le_bytes());
    h.update(end.to_le_bytes());
    h.update(start_root);
    h.update(end_root);
    h.update((payload.len() as u64).to_le_bytes());
    h.update(payload);
    h.finalize().into()
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct BridgeFile {
    schema_version: u32,
    bridges: Vec<Bridge>,
}

#[derive(Debug, Clone)]
pub struct BridgeStore {
    path: PathBuf,
    bridges: Vec<Bridge>,
}

impl BridgeStore {
    pub fn open(data_dir: &str) -> Result<Self, String> {
        fs::create_dir_all(data_dir).map_err(|e| format!("cannot create bridge directory: {}", e))?;
        let path = Path::new(data_dir).join(FILE_NAME);
        if !path.exists() {
            return Ok(Self { path, bridges: Vec::new() });
        }
        let bytes = fs::read(&path).map_err(|e| format!("cannot read bridge cache: {}", e))?;
        let file: BridgeFile = serde_json::from_slice(&bytes)
            .map_err(|e| format!("invalid AWBS bridge cache: {}", e))?;
        if file.schema_version != SCHEMA_VERSION {
            return Err("unsupported AWBS bridge cache schema".into());
        }
        let bridges = file.bridges.into_iter().filter(|b| b.is_well_formed()).collect();
        Ok(Self { path, bridges })
    }

    pub fn insert(&mut self, bridge: Bridge) -> Result<(), String> {
        if !bridge.is_well_formed() {
            return Err("invalid AWBS bridge digest or range".into());
        }
        self.bridges.retain(|b| !(b.start_height == bridge.start_height && b.end_height == bridge.end_height));
        self.bridges.push(bridge);
        self.bridges.sort_by_key(|b| (b.start_height, b.end_height));
        self.persist()
    }

    pub fn find(&self, start: u64, end: u64) -> Option<&Bridge> {
        self.bridges.iter().find(|b| b.covers(start, end))
    }

    pub fn count(&self) -> usize { self.bridges.len() }

    fn persist(&self) -> Result<(), String> {
        let tmp = self.path.with_extension("json.tmp");
        let bytes = serde_json::to_vec_pretty(&BridgeFile { schema_version: SCHEMA_VERSION, bridges: self.bridges.clone() })
            .map_err(|e| format!("cannot encode bridge cache: {}", e))?;
        fs::write(&tmp, bytes).map_err(|e| format!("cannot write bridge cache: {}", e))?;
        fs::rename(&tmp, &self.path).map_err(|e| format!("cannot commit bridge cache: {}", e))
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RangeMode {
    Normal,
    BridgeSkip,
}

/// Selects the safe path for a range. A missing or malformed bridge always
/// falls back to normal processing.
pub fn choose_range_mode(store: &BridgeStore, start: u64, end: u64, received_note_count: usize) -> RangeMode {
    if received_note_count == 0 && store.find(start, end).is_some() {
        RangeMode::BridgeSkip
    } else {
        RangeMode::Normal
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    #[test]
    fn bridge_digest_and_lookup_are_deterministic() {
        let dir = tempdir().unwrap();
        let mut store = BridgeStore::open(dir.path().to_str().unwrap()).unwrap();
        let bridge = Bridge::new(100, 200, [1; 32], [2; 32], vec![3, 4, 5]);
        store.insert(bridge.clone()).unwrap();
        assert_eq!(store.find(100, 200), Some(&bridge));
        assert_eq!(choose_range_mode(&store, 100, 200, 0), RangeMode::BridgeSkip);
        assert_eq!(choose_range_mode(&store, 100, 200, 1), RangeMode::Normal);
    }

    #[test]
    fn tampering_fails_closed() {
        let bridge = Bridge::new(1, 2, [0; 32], [1; 32], vec![9]);
        let mut bad = bridge.clone();
        bad.payload.push(10);
        assert!(!bad.is_well_formed());
    }
}
