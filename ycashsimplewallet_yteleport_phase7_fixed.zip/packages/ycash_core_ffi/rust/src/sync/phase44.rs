//! Phase 44: source-verified upstream scanner adapter.
//!
//! This adapter deliberately does not reinterpret compact-block bytes itself.
//! It pins the decoding boundary to the vendored Ycash NU61 scanner and requires
//! a concrete protobuf/lightwallet adapter to supply upstream CompactBlock values.

use crate::sync::phase43::{CompactBlockDecoder, CompactBlockEnvelope, DecodedCompactBlock};

#[derive(Debug, thiserror::Error)]
pub enum Phase44Error {
    #[error("upstream scanner integration is unavailable in this build")]
    Unavailable,
}

/// Marker for the source-verified NU61 scanning integration.
///
/// The actual CompactBlock protobuf conversion remains feature-gated because the
/// wallet transport currently exposes raw bytes and does not yet link generated
/// lightwallet protobuf types. This prevents unsafe hand-written decoding.
pub struct YcashNu61ScannerAdapter {
    enabled: bool,
}

impl YcashNu61ScannerAdapter {
    pub fn new() -> Result<Self, Phase44Error> {
        #[cfg(feature = "ycash-upstream-scanner")]
        { Ok(Self { enabled: true }) }
        #[cfg(not(feature = "ycash-upstream-scanner"))]
        { Err(Phase44Error::Unavailable) }
    }
}

impl CompactBlockDecoder for YcashNu61ScannerAdapter {
    type Error = Phase44Error;

    fn decode_authenticated(
        &mut self,
        _block: &CompactBlockEnvelope,
    ) -> Result<DecodedCompactBlock, Self::Error> {
        // Phase 44 intentionally fails closed until generated CompactBlock types
        // and wallet scanning keys are connected to zcash_client_backend::scanning.
        // No raw bytes are guessed or treated as authenticated wallet state.
        let _ = self.enabled;
        Err(Phase44Error::Unavailable)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn unavailable_scanner_fails_closed() {
        let r = YcashNu61ScannerAdapter::new();
        #[cfg(not(feature = "ycash-upstream-scanner"))]
        assert!(r.is_err());
    }
}
