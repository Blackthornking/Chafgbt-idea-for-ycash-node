//! YTeleport-X P2P foundation.
//!
//! Phase 1 implements the serverless synchronization primitives that are safe
//! to add before wiring raw Ycash P2P transport:
//! - deterministic ChainRoot/checkpoints
//! - fail-closed checkpoint validation
//! - peer discovery/health state
//! - peer scoring
//! - authenticated state-transition envelope
//!
//! This module deliberately does NOT claim that a state transition is valid
//! merely because a peer supplied it. Consensus validation remains a required
//! input to `ChainAnchorVerifier`. The next phase can connect this verifier to
//! the exact Ycash v4.5.0 P2P wire protocol.

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::io::{self, Read, Write};
use std::net::{IpAddr, SocketAddr, TcpStream, ToSocketAddrs};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

pub const PROTOCOL_VERSION: u32 = 1;
const CHAINROOT_DOMAIN: &[u8] = b"YT/CHAIN/v1";
const TRANSITION_DOMAIN: &[u8] = b"YT/TRANSITION/v1";

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
pub struct Hash32(pub [u8; 32]);

impl Hash32 {
    pub const ZERO: Self = Self([0; 32]);
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ChainAnchor {
    pub network: String,
    pub height: u64,
    pub block_hash: Hash32,
    /// Consensus proof/work validation must be performed by the caller.
    pub consensus_validated: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ChainCheckpoint {
    pub protocol_version: u32,
    pub anchor: ChainAnchor,
    pub chain_root: Hash32,
}

impl ChainCheckpoint {
    pub fn derive(anchor: ChainAnchor, previous_root: Hash32) -> Result<Self, String> {
        if !anchor.consensus_validated {
            return Err("cannot derive checkpoint from an unvalidated anchor".into());
        }

        let mut h = Sha256::new();
        h.update(CHAINROOT_DOMAIN);
        h.update((anchor.network.len() as u64).to_le_bytes());
        h.update(anchor.network.as_bytes());
        h.update(anchor.height.to_le_bytes());
        h.update(anchor.block_hash.0);
        h.update(previous_root.0);

        Ok(Self {
            protocol_version: PROTOCOL_VERSION,
            anchor,
            chain_root: Hash32(h.finalize().into()),
        })
    }

    pub fn verify(&self, previous_root: Hash32) -> Result<(), String> {
        if self.protocol_version != PROTOCOL_VERSION {
            return Err("unsupported YTeleport-X checkpoint version".into());
        }
        let expected = Self::derive(self.anchor.clone(), previous_root)?;
        if expected.chain_root != self.chain_root {
            return Err("ChainRoot mismatch".into());
        }
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct StateTransitionEnvelope {
    pub protocol_version: u32,
    pub from: ChainCheckpoint,
    pub to: ChainCheckpoint,
    pub delta_root: Hash32,
    pub transition_root: Hash32,
}

impl StateTransitionEnvelope {
    pub fn derive(
        from: ChainCheckpoint,
        to: ChainCheckpoint,
        delta_root: Hash32,
    ) -> Result<Self, String> {
        if from.anchor.network != to.anchor.network {
            return Err("network mismatch".into());
        }
        if to.anchor.height <= from.anchor.height {
            return Err("transition must move forward".into());
        }

        let mut h = Sha256::new();
        h.update(TRANSITION_DOMAIN);
        h.update(from.chain_root.0);
        h.update(to.chain_root.0);
        h.update(delta_root.0);

        Ok(Self {
            protocol_version: PROTOCOL_VERSION,
            from,
            to,
            delta_root,
            transition_root: Hash32(h.finalize().into()),
        })
    }

    pub fn verify_envelope(&self, previous_from_root: Hash32) -> Result<(), String> {
        if self.protocol_version != PROTOCOL_VERSION {
            return Err("unsupported YTeleport-X transition version".into());
        }
        self.from.verify(previous_from_root)?;
        if !self.to.anchor.consensus_validated {
            return Err("destination anchor is not consensus validated".into());
        }

        let expected = Self::derive(
            self.from.clone(),
            self.to.clone(),
            self.delta_root,
        )?;

        if expected.transition_root != self.transition_root {
            return Err("transition root mismatch".into());
        }
        Ok(())
    }
}

/// Consensus is intentionally injected rather than implemented by this
/// acceleration layer. A peer response must first become a validated anchor.
pub trait ChainAnchorVerifier {
    fn verify_anchor(&self, anchor: &ChainAnchor) -> Result<(), String>;
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PeerState {
    Discovered,
    Connecting,
    Handshaking,
    Ready,
    Suspicious,
    Banned,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PeerRecord {
    pub address: String,
    pub port: u16,
    pub protocol_version: u32,
    pub starting_height: u64,
    pub last_seen_unix: u64,
    pub latency_ms: u32,
    pub successes: u32,
    pub failures: u32,
    pub invalid_proofs: u32,
    pub invalid_blocks: u32,
    pub score: i64,
    pub state: PeerState,
}

impl PeerRecord {
    pub fn new(address: String, port: u16) -> Self {
        Self {
            address,
            port,
            protocol_version: 0,
            starting_height: 0,
            last_seen_unix: 0,
            latency_ms: u32::MAX,
            successes: 0,
            failures: 0,
            invalid_proofs: 0,
            invalid_blocks: 0,
            score: 0,
            state: PeerState::Discovered,
        }
    }

    pub fn reward_success(&mut self, latency_ms: u32) {
        self.successes = self.successes.saturating_add(1);
        self.score = self.score.saturating_add(10);
        self.latency_ms = latency_ms;
        self.state = PeerState::Ready;
    }

    pub fn penalize_timeout(&mut self) {
        self.failures = self.failures.saturating_add(1);
        self.score = self.score.saturating_sub(5);
        if self.failures >= 3 && self.state != PeerState::Banned {
            self.state = PeerState::Suspicious;
        }
    }

    pub fn reject_invalid_proof(&mut self) {
        self.invalid_proofs = self.invalid_proofs.saturating_add(1);
        self.score = self.score.saturating_sub(100);
        self.state = PeerState::Banned;
    }

    pub fn reject_invalid_block(&mut self) {
        self.invalid_blocks = self.invalid_blocks.saturating_add(1);
        self.score = self.score.saturating_sub(100);
        self.state = PeerState::Banned;
    }
}

#[derive(Debug, Default)]
pub struct PeerManager {
    peers: HashMap<String, PeerRecord>,
}

impl PeerManager {
    pub fn upsert(&mut self, peer: PeerRecord) {
        self.peers.insert(peer.address.clone(), peer);
    }

    pub fn get(&self, address: &str) -> Option<&PeerRecord> {
        self.peers.get(address)
    }

    pub fn get_mut(&mut self, address: &str) -> Option<&mut PeerRecord> {
        self.peers.get_mut(address)
    }

    pub fn ready_peers(&self, limit: usize) -> Vec<&PeerRecord> {
        let mut peers: Vec<_> = self.peers.values()
            .filter(|p| p.state == PeerState::Ready)
            .collect();
        peers.sort_by(|a, b| b.score.cmp(&a.score).then(a.latency_ms.cmp(&b.latency_ms)));
        peers.truncate(limit);
        peers
    }

    pub fn len(&self) -> usize { self.peers.len() }
    pub fn is_empty(&self) -> bool { self.peers.is_empty() }
}



/// Ycash v4.x P2P network parameters used by the transport adapter.
///
/// These values are transport parameters, not consensus parameters.  The
/// wallet still validates every received chain object independently.
pub const YCASH_MAINNET_P2P_PORT: u16 = 8833;
pub const YCASH_TESTNET_P2P_PORT: u16 = 18833;
pub const YCASH_MAINNET_MAGIC: [u8; 4] = [0x24, 0xe9, 0x27, 0x64];
pub const YCASH_TESTNET_MAGIC: [u8; 4] = [0xfa, 0x1a, 0xf9, 0xbf];
pub const YT_P2P_PROTOCOL_VERSION: i32 = 270013;
pub const YT_INIT_PROTO_VERSION: i32 = 209;
pub const YT_DEFAULT_OUTBOUND: usize = 8;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum YcashNetwork {
    Mainnet,
    Testnet,
}

impl YcashNetwork {
    pub fn magic(self) -> [u8; 4] {
        match self {
            Self::Mainnet => YCASH_MAINNET_MAGIC,
            Self::Testnet => YCASH_TESTNET_MAGIC,
        }
    }

    pub fn default_port(self) -> u16 {
        match self {
            Self::Mainnet => YCASH_MAINNET_P2P_PORT,
            Self::Testnet => YCASH_TESTNET_P2P_PORT,
        }
    }

    pub fn dns_seeds(self) -> &'static [&'static str] {
        match self {
            Self::Mainnet => &["seed.ycash.xyz"],
            Self::Testnet => &["testseed.ycash.xyz"],
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DiscoveredAddress {
    pub address: SocketAddr,
    pub services: u64,
    pub last_seen_unix: u64,
}

#[derive(Debug, Clone)]
pub struct YcashP2PConfig {
    pub network: YcashNetwork,
    pub connect_timeout: Duration,
    pub read_timeout: Duration,
    pub user_agent: String,
    pub local_height: i32,
    pub max_message_size: usize,
}

impl Default for YcashP2PConfig {
    fn default() -> Self {
        Self {
            network: YcashNetwork::Mainnet,
            connect_timeout: Duration::from_secs(8),
            read_timeout: Duration::from_secs(10),
            user_agent: "/YTeleport-X:1.0/".to_owned(),
            local_height: 0,
            max_message_size: 8 * 1024 * 1024,
        }
    }
}

#[derive(Debug)]
pub struct YcashPeerConnection {
    stream: TcpStream,
    pub remote: SocketAddr,
    pub negotiated_version: i32,
    pub starting_height: i32,
}

#[derive(Debug)]
pub enum P2PError {
    Io(io::Error),
    InvalidHeader(&'static str),
    InvalidChecksum,
    OversizedMessage(usize),
    InvalidPayload(&'static str),
    UnsupportedVersion(i32),
}

impl From<io::Error> for P2PError {
    fn from(value: io::Error) -> Self { Self::Io(value) }
}

fn compact_size(n: usize, out: &mut Vec<u8>) {
    if n < 253 { out.push(n as u8); }
    else if n <= u16::MAX as usize { out.push(253); out.extend_from_slice(&(n as u16).to_le_bytes()); }
    else if n <= u32::MAX as usize { out.push(254); out.extend_from_slice(&(n as u32).to_le_bytes()); }
    else { out.push(255); out.extend_from_slice(&(n as u64).to_le_bytes()); }
}

fn read_compact_size(data: &[u8], pos: &mut usize) -> Result<usize, P2PError> {
    if *pos >= data.len() { return Err(P2PError::InvalidPayload("missing compact size")); }
    let tag = data[*pos]; *pos += 1;
    let v = match tag {
        0..=252 => tag as u64,
        253 => { let x = take(data, pos, 2)?; u16::from_le_bytes([x[0],x[1]]) as u64 },
        254 => { let x = take(data, pos, 4)?; u32::from_le_bytes([x[0],x[1],x[2],x[3]]) as u64 },
        255 => { let x = take(data, pos, 8)?; u64::from_le_bytes(x.try_into().unwrap()) },
    };
    usize::try_from(v).map_err(|_| P2PError::InvalidPayload("compact size overflow"))
}

fn take<'a>(data: &'a [u8], pos: &mut usize, n: usize) -> Result<&'a [u8], P2PError> {
    let end = pos.checked_add(n).ok_or(P2PError::InvalidPayload("offset overflow"))?;
    if end > data.len() { return Err(P2PError::InvalidPayload("truncated payload")); }
    let r = &data[*pos..end]; *pos = end; Ok(r)
}

fn sha256d(data: &[u8]) -> [u8; 32] {
    let a = Sha256::digest(data);
    let b = Sha256::digest(a);
    b.into()
}

fn encode_net_addr(addr: Option<SocketAddr>, services: u64, out: &mut Vec<u8>) {
    out.extend_from_slice(&services.to_le_bytes());
    let ip = addr.map(|x| x.ip()).unwrap_or(IpAddr::V4(std::net::Ipv4Addr::UNSPECIFIED));
    match ip {
        IpAddr::V4(v4) => {
            out.extend_from_slice(&[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0xff,0xff]);
            out.extend_from_slice(&v4.octets());
        }
        IpAddr::V6(v6) => out.extend_from_slice(&v6.octets()),
    }
    let port = addr.map(|x| x.port()).unwrap_or(0);
    out.extend_from_slice(&port.to_be_bytes());
}

fn encode_version(cfg: &YcashP2PConfig, remote: SocketAddr) -> Vec<u8> {
    let mut p = Vec::with_capacity(128);
    p.extend_from_slice(&YT_P2P_PROTOCOL_VERSION.to_le_bytes());
    p.extend_from_slice(&0u64.to_le_bytes());
    let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs() as i64;
    p.extend_from_slice(&now.to_le_bytes());
    encode_net_addr(Some(remote), 0, &mut p);
    encode_net_addr(None, 0, &mut p);
    let nonce = now as u64 ^ (remote.port() as u64) << 32;
    p.extend_from_slice(&nonce.to_le_bytes());
    compact_size(cfg.user_agent.len(), &mut p);
    p.extend_from_slice(cfg.user_agent.as_bytes());
    p.extend_from_slice(&cfg.local_height.to_le_bytes());
    p.push(1); // relay transactions
    p
}

fn encode_message(magic: [u8; 4], command: &str, payload: &[u8]) -> Result<Vec<u8>, P2PError> {
    if command.len() > 12 { return Err(P2PError::InvalidPayload("command too long")); }
    if payload.len() > u32::MAX as usize { return Err(P2PError::OversizedMessage(payload.len())); }
    let mut out = Vec::with_capacity(24 + payload.len());
    out.extend_from_slice(&magic);
    let mut cmd = [0u8; 12]; cmd[..command.len()].copy_from_slice(command.as_bytes());
    out.extend_from_slice(&cmd);
    out.extend_from_slice(&(payload.len() as u32).to_le_bytes());
    out.extend_from_slice(&sha256d(payload)[..4]);
    out.extend_from_slice(payload);
    Ok(out)
}

impl YcashPeerConnection {
    pub fn connect(cfg: &YcashP2PConfig, remote: SocketAddr) -> Result<Self, P2PError> {
        let stream = TcpStream::connect_timeout(&remote, cfg.connect_timeout)?;
        stream.set_read_timeout(Some(cfg.read_timeout))?;
        stream.set_write_timeout(Some(cfg.read_timeout))?;
        let mut conn = Self { stream, remote, negotiated_version: YT_INIT_PROTO_VERSION, starting_height: 0 };
        let payload = encode_version(cfg, remote);
        let msg = encode_message(cfg.network.magic(), "version", &payload)?;
        conn.stream.write_all(&msg)?;
        conn.handshake(cfg)?;
        Ok(conn)
    }

    fn handshake(&mut self, cfg: &YcashP2PConfig) -> Result<(), P2PError> {
        let mut saw_version = false;
        let mut saw_verack = false;
        for _ in 0..8 {
            let (cmd, payload) = self.read_message(cfg)?;
            match cmd.as_str() {
                "version" => {
                    let (version, height) = parse_version(&payload)?;
                    if version < YT_INIT_PROTO_VERSION { return Err(P2PError::UnsupportedVersion(version)); }
                    self.negotiated_version = version.min(YT_P2P_PROTOCOL_VERSION);
                    self.starting_height = height;
                    saw_version = true;
                    self.stream.write_all(&encode_message(cfg.network.magic(), "verack", &[])?)?;
                }
                "verack" => { saw_verack = true; }
                "sendheaders" | "sendcmpct" | "feefilter" | "ping" | "addr" | "addrv2" => {
                    // Optional negotiation/advertisement messages are handled by
                    // the caller; ping is answered below for liveness.
                    if cmd == "ping" { self.stream.write_all(&encode_message(cfg.network.magic(), "pong", &payload)?)?; }
                }
                _ => {}
            }
            if saw_version && saw_verack { return Ok(()); }
        }
        Err(P2PError::InvalidPayload("version/verack handshake incomplete"))
    }

    pub fn request_addresses(&mut self, cfg: &YcashP2PConfig) -> Result<Vec<DiscoveredAddress>, P2PError> {
        self.stream.write_all(&encode_message(cfg.network.magic(), "getaddr", &[])?)?;
        loop {
            let (cmd, payload) = self.read_message(cfg)?;
            match cmd.as_str() {
                "addr" => return parse_addr(&payload),
                "addrv2" => return parse_addrv2(&payload),
                "ping" => self.stream.write_all(&encode_message(cfg.network.magic(), "pong", &payload)?)?,
                "version" | "verack" | "sendheaders" | "sendcmpct" | "feefilter" => {},
                _ => {}
            }
        }
    }

    fn read_message(&mut self, cfg: &YcashP2PConfig) -> Result<(String, Vec<u8>), P2PError> {
        let mut header = [0u8; 24];
        self.stream.read_exact(&mut header)?;
        if header[..4] != cfg.network.magic() { return Err(P2PError::InvalidHeader("network magic mismatch")); }
        let command_end = header[4..16].iter().position(|&b| b == 0).unwrap_or(12);
        let command = std::str::from_utf8(&header[4..4+command_end]).map_err(|_| P2PError::InvalidHeader("invalid command"))?.to_owned();
        let size = u32::from_le_bytes(header[16..20].try_into().unwrap()) as usize;
        if size > cfg.max_message_size { return Err(P2PError::OversizedMessage(size)); }
        let expected = &header[20..24];
        let mut payload = vec![0u8; size];
        self.stream.read_exact(&mut payload)?;
        if &sha256d(&payload)[..4] != expected { return Err(P2PError::InvalidChecksum); }
        Ok((command, payload))
    }
}

fn parse_version(payload: &[u8]) -> Result<(i32, i32), P2PError> {
    if payload.len() < 4 + 8 + 8 + 26 + 26 + 8 { return Err(P2PError::InvalidPayload("version payload too short")); }
    let version = i32::from_le_bytes(payload[0..4].try_into().unwrap());
    let mut pos = 4 + 8 + 8 + 26 + 26 + 8;
    let ua_len = read_compact_size(payload, &mut pos)?;
    let _ua = take(payload, &mut pos, ua_len)?;
    let h = take(payload, &mut pos, 4)?;
    Ok((version, i32::from_le_bytes(h.try_into().unwrap())))
}

fn parse_addr(payload: &[u8]) -> Result<Vec<DiscoveredAddress>, P2PError> {
    let mut pos = 0;
    let count = read_compact_size(payload, &mut pos)?;
    if count > 1000 { return Err(P2PError::InvalidPayload("too many peer addresses")); }
    let mut out = Vec::with_capacity(count);
    for _ in 0..count {
        let t = take(payload, &mut pos, 4)?;
        let last_seen_unix = u32::from_le_bytes(t.try_into().unwrap()) as u64;
        let services = u64::from_le_bytes(take(payload, &mut pos, 8)?.try_into().unwrap());
        let ip = take(payload, &mut pos, 16)?;
        let port = u16::from_be_bytes(take(payload, &mut pos, 2)?.try_into().unwrap());
        let ip = if ip[..12] == [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0xff,0xff] {
            IpAddr::V4(std::net::Ipv4Addr::new(ip[12],ip[13],ip[14],ip[15]))
        } else {
            // Ipv6Addr implements From<[u8; 16]>, not From<&[u8]>, so the
            // slice has to become an owned array before conversion. `take`
            // already guaranteed the length, hence the unwrap.
            {
                let octets: [u8; 16] = ip.try_into().unwrap();
                IpAddr::V6(std::net::Ipv6Addr::from(octets))
            }
        };
        out.push(DiscoveredAddress { address: SocketAddr::new(ip, port), services, last_seen_unix });
    }
    Ok(out)
}

fn parse_addrv2(payload: &[u8]) -> Result<Vec<DiscoveredAddress>, P2PError> {
    // Ycash v4.x primarily uses legacy addr exchange. Keep addrv2 fail-closed
    // until its exact service/network encoding is explicitly implemented.
    let _ = payload;
    Err(P2PError::InvalidPayload("addrv2 not enabled in this adapter"))
}

impl PeerManager {
    pub fn discover_dns(&mut self, network: YcashNetwork) -> io::Result<usize> {
        let mut added = 0;
        for seed in network.dns_seeds() {
            let host = format!("{}:{}", seed, network.default_port());
            for addr in host.to_socket_addrs()? {
                let key = addr.ip().to_string();
                if !self.peers.contains_key(&key) {
                    self.upsert(PeerRecord::new(addr.ip().to_string(), addr.port()));
                    added += 1;
                }
            }
        }
        Ok(added)
    }

    pub fn discovered_peers(&self, limit: usize) -> Vec<SocketAddr> {
        let mut v = Vec::new();
        for p in self.peers.values() {
            if matches!(p.state, PeerState::Banned) { continue; }
            if let Ok(ip) = p.address.parse() { v.push(SocketAddr::new(ip, p.port)); }
            if v.len() >= limit { break; }
        }
        v
    }

    pub fn record_discovered(&mut self, addresses: impl IntoIterator<Item = DiscoveredAddress>) {
        for a in addresses {
            let key = a.address.ip().to_string();
            let mut p = PeerRecord::new(key.clone(), a.address.port());
            p.last_seen_unix = a.last_seen_unix;
            p.protocol_version = YT_P2P_PROTOCOL_VERSION as u32;
            self.upsert(p);
        }
    }
}


/// A wire-level Ycash v4.x block header returned by `headers`.
///
/// The header is retained byte-for-byte because the consensus implementation
/// is responsible for calculating the real Ycash/Equihash block hash. This
/// layer deliberately does not substitute SHA256d for Ycash block hashing.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct YcashBlockHeaderWire {
    pub raw: Vec<u8>,
    pub prev_hash: Hash32,
    pub merkle_root: Hash32,
    pub light_client_root: Hash32,
    pub time: u32,
    pub bits: u32,
    pub nonce: Hash32,
    pub solution: Vec<u8>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct HeaderChainCandidate {
    pub peer: SocketAddr,
    pub headers: Vec<YcashBlockHeaderWire>,
    pub start_height: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ChainAnchorCandidate {
    pub network: YcashNetwork,
    pub height: u64,
    pub block_hash: Hash32,
    pub header: YcashBlockHeaderWire,
}

/// Consensus adapter for the exact Ycash implementation.
///
/// YTeleport-X must not invent a block-hash or Equihash verifier. The wallet's
/// Ycash consensus engine supplies this implementation and decides whether a
/// header is valid at a particular height.
pub trait YcashHeaderConsensus {
    fn block_hash(&self, header: &YcashBlockHeaderWire) -> Result<Hash32, String>;
    fn validate_header(
        &self,
        header: &YcashBlockHeaderWire,
        height: u64,
        previous_hash: Option<Hash32>,
    ) -> Result<(), String>;
}

impl YcashPeerConnection {
    /// Request a header chain using the standard Ycash `getheaders` locator.
    /// `locator` should contain hashes from the wallet's best known chain,
    /// newest-first. `hash_stop` is normally zero for an open-ended request.
    pub fn request_headers(
        &mut self,
        cfg: &YcashP2PConfig,
        locator: &[Hash32],
        hash_stop: Hash32,
    ) -> Result<Vec<YcashBlockHeaderWire>, P2PError> {
        if locator.is_empty() {
            return Err(P2PError::InvalidPayload("empty block locator"));
        }
        if locator.len() > 101 {
            return Err(P2PError::InvalidPayload("block locator too large"));
        }

        let mut payload = Vec::with_capacity(4 + 9 + locator.len() * 32 + 32);
        payload.extend_from_slice(&self.negotiated_version.to_le_bytes());
        compact_size(locator.len(), &mut payload);
        for h in locator {
            payload.extend_from_slice(&h.0);
        }
        payload.extend_from_slice(&hash_stop.0);
        self.stream.write_all(&encode_message(cfg.network.magic(), "getheaders", &payload)?)?;

        loop {
            let (cmd, payload) = self.read_message(cfg)?;
            match cmd.as_str() {
                "headers" => return parse_headers(&payload, cfg.max_message_size),
                "ping" => self.stream.write_all(&encode_message(cfg.network.magic(), "pong", &payload)?)?,
                "addr" | "addrv2" | "sendheaders" | "sendcmpct" | "feefilter" | "verack" => {},
                _ => {},
            }
        }
    }
}

fn parse_headers(payload: &[u8], max_message_size: usize) -> Result<Vec<YcashBlockHeaderWire>, P2PError> {
    if payload.len() > max_message_size {
        return Err(P2PError::OversizedMessage(payload.len()));
    }
    let mut pos = 0;
    let count = read_compact_size(payload, &mut pos)?;
    if count > 2000 {
        return Err(P2PError::InvalidPayload("too many headers"));
    }
    let mut out = Vec::with_capacity(count);
    for _ in 0..count {
        let start = pos;
        let version = take(payload, &mut pos, 4)?;
        let _ = version;
        let prev = Hash32(take(payload, &mut pos, 32)?.try_into().unwrap());
        let merkle = Hash32(take(payload, &mut pos, 32)?.try_into().unwrap());
        let light = Hash32(take(payload, &mut pos, 32)?.try_into().unwrap());
        let time = u32::from_le_bytes(take(payload, &mut pos, 4)?.try_into().unwrap());
        let bits = u32::from_le_bytes(take(payload, &mut pos, 4)?.try_into().unwrap());
        let nonce = Hash32(take(payload, &mut pos, 32)?.try_into().unwrap());
        let solution_len = read_compact_size(payload, &mut pos)?;
        if solution_len > 10_000 {
            return Err(P2PError::InvalidPayload("Equihash solution too large"));
        }
        let solution = take(payload, &mut pos, solution_len)?.to_vec();
        // The `headers` message serializes a zero transaction-count after each
        // header. Require it to be exactly zero; accepting transactions here
        // would violate the protocol semantics and could desynchronize parsing.
        let tx_count = read_compact_size(payload, &mut pos)?;
        if tx_count != 0 {
            return Err(P2PError::InvalidPayload("headers message contains transactions"));
        }
        let raw = payload[start..pos - 1].to_vec();
        out.push(YcashBlockHeaderWire {
            raw,
            prev_hash: prev,
            merkle_root: merkle,
            light_client_root: light,
            time,
            bits,
            nonce,
            solution,
        });
    }
    if pos != payload.len() {
        return Err(P2PError::InvalidPayload("trailing bytes in headers message"));
    }
    Ok(out)
}

/// Validate a complete header response without assuming a particular
/// consensus hash implementation. The supplied consensus adapter is the only
/// authority allowed to mark an anchor valid.
pub fn validate_header_candidate<C: YcashHeaderConsensus>(
    consensus: &C,
    network: YcashNetwork,
    peer: SocketAddr,
    start_height: u64,
    headers: Vec<YcashBlockHeaderWire>,
) -> Result<HeaderChainCandidate, String> {
    if headers.is_empty() {
        return Err("peer returned an empty header chain".into());
    }
    let mut previous_hash = None;
    for (i, header) in headers.iter().enumerate() {
        let height = start_height.checked_add(i as u64)
            .ok_or_else(|| "header height overflow".to_string())?;
        consensus.validate_header(header, height, previous_hash)?;
        previous_hash = Some(consensus.block_hash(header)?);
    }
    let _ = network;
    Ok(HeaderChainCandidate { peer, headers, start_height })
}

/// Select an anchor only when at least `quorum` independently validated peers
/// agree on the same height and block hash. A majority of unvalidated data is
/// never sufficient.
pub fn select_quorum_anchor<C: YcashHeaderConsensus>(
    consensus: &C,
    network: YcashNetwork,
    candidates: &[HeaderChainCandidate],
    quorum: usize,
) -> Result<ChainAnchorCandidate, String> {
    if quorum == 0 {
        return Err("quorum must be non-zero".into());
    }
    use std::collections::HashMap;
    let mut votes: HashMap<(u64, Hash32), Vec<usize>> = HashMap::new();
    for (idx, c) in candidates.iter().enumerate() {
        if c.headers.is_empty() { continue; }
        let h = c.start_height + c.headers.len() as u64 - 1;
        let bh = consensus.block_hash(c.headers.last().unwrap())?;
        votes.entry((h, bh)).or_default().push(idx);
    }
    let ((height, block_hash), idxs) = votes.into_iter()
        .max_by_key(|(_, peers)| peers.len())
        .ok_or_else(|| "no valid anchor candidates".to_string())?;
    if idxs.len() < quorum {
        return Err("no anchor reached cryptographic peer quorum".into());
    }
    let chosen = &candidates[idxs[0]];
    let header = chosen.headers.last().unwrap().clone();
    Ok(ChainAnchorCandidate { network, height, block_hash, header })
}


// -----------------------------------------------------------------------------
// Phase 4: authenticated state root + real state-transition proofs.
//
// This is an application-layer authenticated state commitment. It is NOT a
// replacement for Ycash consensus. A transition is accepted only when every
// update proof independently transforms the claimed prior root into the next
// root. The construction uses a 256-level sparse Merkle tree keyed by a
// SHA-256 key and domain-separated leaf/branch hashes.
// -----------------------------------------------------------------------------

const STATE_LEAF_DOMAIN: &[u8] = b"YT/STATE/LEAF/v1";
const STATE_BRANCH_DOMAIN: &[u8] = b"YT/STATE/BRANCH/v1";
const STATE_EMPTY_DOMAIN: &[u8] = b"YT/STATE/EMPTY/v1";
const STATE_TRANSITION_DOMAIN: &[u8] = b"YT/STATE-TRANSITION/v1";

fn state_hash(domain: &[u8], parts: &[&[u8]]) -> Hash32 {
    let mut h = Sha256::new();
    h.update(domain);
    for p in parts { h.update(p); }
    Hash32(h.finalize().into())
}

fn state_key(key: &[u8]) -> Hash32 {
    state_hash(b"YT/STATE/KEY/v1", &[key])
}

fn empty_hashes() -> [Hash32; 257] {
    let mut out = [Hash32::ZERO; 257];
    out[0] = state_hash(STATE_EMPTY_DOMAIN, &[&[0u8]]);
    for i in 0..256 {
        out[i + 1] = state_hash(STATE_BRANCH_DOMAIN, &[&out[i].0, &out[i].0]);
    }
    out
}

fn leaf_hash(key_hash: Hash32, value: Hash32) -> Hash32 {
    state_hash(STATE_LEAF_DOMAIN, &[&key_hash.0, &value.0])
}

fn branch_hash(left: Hash32, right: Hash32) -> Hash32 {
    state_hash(STATE_BRANCH_DOMAIN, &[&left.0, &right.0])
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct StateUpdate {
    pub key: Vec<u8>,
    pub old_value: Hash32,
    pub new_value: Hash32,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct StateUpdateProof {
    pub key_hash: Hash32,
    pub old_root: Hash32,
    pub new_root: Hash32,
    pub old_value: Hash32,
    pub new_value: Hash32,
    /// Siblings are ordered from leaf level to root level (256 entries).
    pub siblings: Vec<Hash32>,
}

impl StateUpdateProof {
    pub fn from_update(update: &StateUpdate, siblings: Vec<Hash32>) -> Result<Self, String> {
        if siblings.len() != 256 {
            return Err("state proof must contain exactly 256 siblings".into());
        }
        let key_hash = state_key(&update.key);
        let root = |value: Hash32| {
            let mut cur = leaf_hash(key_hash, value);
            for (level, sibling) in siblings.iter().enumerate() {
                let bit = (key_hash.0[level / 8] >> (level % 8)) & 1;
                cur = if bit == 0 { branch_hash(cur, *sibling) } else { branch_hash(*sibling, cur) };
            }
            cur
        };
        Ok(Self {
            key_hash,
            old_root: root(update.old_value),
            new_root: root(update.new_value),
            old_value: update.old_value,
            new_value: update.new_value,
            siblings,
        })
    }

    #[doc(hidden)]
    pub(crate) fn root_for_for_test(&self, value: Hash32) -> Hash32 { self.root_for(value) }

    fn root_for(&self, value: Hash32) -> Hash32 {
        let mut cur = leaf_hash(self.key_hash, value);
        for (level, sibling) in self.siblings.iter().enumerate() {
            let bit = (self.key_hash.0[level / 8] >> (level % 8)) & 1;
            cur = if bit == 0 { branch_hash(cur, *sibling) } else { branch_hash(*sibling, cur) };
        }
        cur
    }

    pub fn verify_against(&self, old_root: Hash32, new_root: Hash32) -> Result<(), String> {
        if self.siblings.len() != 256 {
            return Err("invalid state proof depth".into());
        }
        if self.old_root != old_root || self.root_for(self.old_value) != self.old_root {
            return Err("old state root does not match update proof".into());
        }
        if self.new_root != new_root || self.root_for(self.new_value) != self.new_root {
            return Err("new state root does not match update proof".into());
        }
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct StateTransitionProof {
    pub protocol_version: u32,
    pub from_root: Hash32,
    pub to_root: Hash32,
    pub updates: Vec<StateUpdateProof>,
    pub transition_root: Hash32,
}

impl StateTransitionProof {
    pub fn derive(from_root: Hash32, to_root: Hash32, updates: Vec<StateUpdateProof>) -> Result<Self, String> {
        if updates.is_empty() {
            return Err("state transition must contain at least one update".into());
        }
        if updates.len() > 4096 {
            return Err("too many state updates".into());
        }
        for u in &updates {
            if u.siblings.len() != 256 { return Err("invalid state proof depth".into()); }
        }
        let mut h = Sha256::new();
        h.update(STATE_TRANSITION_DOMAIN);
        h.update(PROTOCOL_VERSION.to_le_bytes());
        h.update(from_root.0);
        h.update(to_root.0);
        for u in &updates {
            h.update(u.key_hash.0);
            h.update(u.old_value.0);
            h.update(u.new_value.0);
        }
        Ok(Self {
            protocol_version: PROTOCOL_VERSION,
            from_root,
            to_root,
            updates,
            transition_root: Hash32(h.finalize().into()),
        })
    }

    pub fn verify(&self) -> Result<(), String> {
        if self.protocol_version != PROTOCOL_VERSION {
            return Err("unsupported state-transition version".into());
        }
        if self.updates.is_empty() || self.updates.len() > 4096 {
            return Err("invalid state-transition update count".into());
        }
        let mut h = Sha256::new();
        h.update(STATE_TRANSITION_DOMAIN);
        h.update(self.protocol_version.to_le_bytes());
        h.update(self.from_root.0);
        h.update(self.to_root.0);
        let mut current = self.from_root;
        for u in &self.updates {
            u.verify_against(u.old_root, u.new_root)?;
            if u.old_root != current {
                return Err("state transition proofs are not sequentially chained".into());
            }
            current = u.new_root;
            h.update(u.key_hash.0);
            h.update(u.old_value.0);
            h.update(u.new_value.0);
        }
        if current != self.to_root {
            return Err("state transition does not reach destination root".into());
        }
        let expected = Hash32(h.finalize().into());
        if expected != self.transition_root {
            return Err("state transition root mismatch".into());
        }
        Ok(())
    }
}

/// Build a sparse-Merkle root from key/value hashes. This helper is intended
/// for tests, deterministic fixtures, and local wallet-state indexing.
pub fn state_root(entries: &[(Vec<u8>, Hash32)]) -> Result<Hash32, String> {
    use std::collections::BTreeMap;
    let empty = empty_hashes();
    let mut nodes = BTreeMap::<Hash32, Hash32>::new();
    for (key, value) in entries {
        let k = state_key(key);
        if nodes.insert(k, leaf_hash(k, *value)).is_some() {
            return Err("duplicate state key".into());
        }
    }
    for level in 0..256 {
        let mut parents = BTreeMap::<Hash32, (Hash32, Hash32)>::new();
        for (k, v) in nodes.iter() {
            let mut parent = k.0;
            parent[level / 8] &= !(1u8 << (level % 8));
            let parent = Hash32(parent);
            let bit = (k.0[level / 8] >> (level % 8)) & 1;
            let e = parents.entry(parent).or_insert((empty[level], empty[level]));
            if bit == 0 { e.0 = *v; } else { e.1 = *v; }
        }
        nodes = parents.into_iter().map(|(k, (l, r))| (k, branch_hash(l, r))).collect();
    }
    Ok(nodes.values().next().copied().unwrap_or(empty[256]))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn anchor(height: u64, byte: u8) -> ChainAnchor {
        ChainAnchor {
            network: "ycash-mainnet".into(),
            height,
            block_hash: Hash32([byte; 32]),
            consensus_validated: true,
        }
    }

    #[test]
    fn chain_root_is_deterministic_and_fail_closed() {
        let first = ChainCheckpoint::derive(anchor(1, 7), Hash32::ZERO).unwrap();
        let second = ChainCheckpoint::derive(anchor(1, 7), Hash32::ZERO).unwrap();
        assert_eq!(first.chain_root, second.chain_root);
        assert!(first.verify(Hash32::ZERO).is_ok());

        let mut bad = first.clone();
        bad.chain_root.0[0] ^= 1;
        assert!(bad.verify(Hash32::ZERO).is_err());
    }

    #[test]
    fn unvalidated_anchor_cannot_be_checkpointed() {
        let mut a = anchor(1, 1);
        a.consensus_validated = false;
        assert!(ChainCheckpoint::derive(a, Hash32::ZERO).is_err());
    }

    #[test]
    fn transition_is_deterministic_and_rejects_regression() {
        let a = ChainCheckpoint::derive(anchor(10, 1), Hash32::ZERO).unwrap();
        let b = ChainCheckpoint::derive(anchor(20, 2), a.chain_root).unwrap();
        let t = StateTransitionEnvelope::derive(a.clone(), b, Hash32([3; 32])).unwrap();
        assert!(t.verify_envelope(Hash32::ZERO).is_ok());

        let err = StateTransitionEnvelope::derive(a.clone(), a, Hash32::ZERO);
        assert!(err.is_err());
    }

    #[test]
    fn invalid_proof_bans_peer() {
        let mut p = PeerRecord::new("127.0.0.1".into(), 8333);
        p.reject_invalid_proof();
        assert_eq!(p.state, PeerState::Banned);
        assert_eq!(p.score, -100);
    }

    #[test]
    fn ycash_v45_transport_parameters_match_source() {
        assert_eq!(YT_P2P_PROTOCOL_VERSION, 270013);
        assert_eq!(YT_INIT_PROTO_VERSION, 209);
        assert_eq!(YcashNetwork::Mainnet.default_port(), 8833);
        assert_eq!(YcashNetwork::Testnet.default_port(), 18833);
        assert_eq!(YcashNetwork::Mainnet.magic(), [0x24, 0xe9, 0x27, 0x64]);
        assert_eq!(YcashNetwork::Testnet.magic(), [0xfa, 0x1a, 0xf9, 0xbf]);
    }

    #[test]
    fn message_checksum_is_verified() {
        let msg = encode_message(YCASH_MAINNET_MAGIC, "ping", &[1,2,3,4]).unwrap();
        assert_eq!(&msg[..4], &YCASH_MAINNET_MAGIC);
        let checksum = &msg[20..24];
        assert_eq!(checksum, &sha256d(&[1,2,3,4])[..4]);
    }

    #[test]
    fn addr_parser_is_fail_closed() {
        assert!(parse_addr(&[1]).is_err());
        let mut payload = vec![1u8];
        payload.extend_from_slice(&0u32.to_le_bytes());
        payload.extend_from_slice(&0u64.to_le_bytes());
        payload.extend_from_slice(&[0; 16]);
        payload.extend_from_slice(&8833u16.to_be_bytes());
        let peers = parse_addr(&payload).unwrap();
        assert_eq!(peers.len(), 1);
        assert_eq!(peers[0].address.port(), 8833);
    }

    #[test]
    fn peer_manager_orders_ready_peers() {
        let mut m = PeerManager::default();
        let mut a = PeerRecord::new("a".into(), 1);
        a.reward_success(20);
        let mut b = PeerRecord::new("b".into(), 1);
        b.reward_success(5);
        m.upsert(a);
        m.upsert(b);
        assert_eq!(m.ready_peers(2)[0].address, "b");
    }

    #[test]
    fn state_update_proof_roundtrip() {
        let key = b"wallet/note/1".to_vec();
        let old = Hash32([7; 32]);
        let new = Hash32([8; 32]);
        let siblings = vec![Hash32([9; 32]); 256];
        let u = StateUpdateProof::from_update(&StateUpdate { key, old_value: old, new_value: new }, siblings).unwrap();
        let old_root = u.root_for(old);
        let new_root = u.root_for(new);
        u.verify_against(old_root, new_root).unwrap();
        assert!(u.verify_against(old_root, Hash32::ZERO).is_err());
    }

    #[test]
    fn state_transition_proof_roundtrip_and_tamper_rejection() {
        let key = b"wallet/note/2".to_vec();
        let siblings = vec![Hash32([3; 32]); 256];
        let u = StateUpdateProof::from_update(&StateUpdate { key, old_value: Hash32([1;32]), new_value: Hash32([2;32]) }, siblings).unwrap();
        let p = StateTransitionProof::derive(u.root_for(Hash32([1;32])), u.root_for(Hash32([2;32])), vec![u]).unwrap();
        p.verify().unwrap();
        let mut bad = p.clone();
        bad.updates[0].new_value.0[0] ^= 1;
        assert!(bad.verify().is_err());
    }

    #[test]
    fn state_transition_rejects_wrong_root() {
        let u = StateUpdateProof::from_update(&StateUpdate {
            key: b"k".to_vec(), old_value: Hash32([1;32]), new_value: Hash32([2;32])
        }, vec![Hash32([4;32]); 256]).unwrap();
        let p = StateTransitionProof::derive(u.root_for(Hash32([1;32])), Hash32::ZERO, vec![u]).unwrap();
        assert!(p.verify().is_err());
    }

}
