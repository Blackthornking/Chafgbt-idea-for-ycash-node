//! Sync validation gates. These are intentionally separate from networking so
//! tests can run against recorded compact-block fixtures.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ValidationGate {
    BackendPinned,
    KeyVector,
    AddressVector,
    TrialDecryption,
    NoteDetection,
    NullifierDetection,
    BalanceAccounting,
}

#[derive(Debug, Clone, Default)]
pub struct ValidationReport {
    pub backend_pinned: bool,
    pub key_vector: bool,
    pub address_vector: bool,
    pub trial_decryption: bool,
    pub note_detection: bool,
    pub nullifier_detection: bool,
    pub balance_accounting: bool,
}

impl ValidationReport {
    pub fn read_only_ready(&self) -> bool {
        self.backend_pinned
            && self.key_vector
            && self.address_vector
            && self.trial_decryption
            && self.note_detection
            && self.nullifier_detection
            && self.balance_accounting
    }

    pub fn spending_ready(&self) -> bool {
        // Phase 21 never authorizes spending. Transaction/proving vectors belong
        // to a later dedicated phase.
        false
    }
}
