//! YTeleport-X Phase 5: compressed authenticated state deltas.
//!
//! Phase 4 represents every state update with a full 256-sibling path. Phase 5
//! keeps the same sparse-Merkle semantics but interns equal sibling hashes into
//! a shared pool. This is a conservative first compression layer: it changes
//! transport/storage size without changing the authenticated state model.
//!
//! The compressed proof is never trusted as an alternative to the Phase 4
//! verifier. Verification reconstructs each StateUpdateProof and then invokes
//! the existing proof checks. Malformed indexes, oversized pools, duplicate
//! pool entries, wrong roots, and transition-root tampering fail closed.

use super::yteleport::{Hash32, StateTransitionProof, StateUpdateProof};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::HashMap;

pub const PHASE5_PROTOCOL_VERSION: u32 = 1;
const DOMAIN: &[u8] = b"YT/COMPRESSED-TRANSITION/v1";
const MAX_UPDATES: usize = 4096;
const PATH_DEPTH: usize = 256;
const MAX_POOL_ENTRIES: usize = MAX_UPDATES * PATH_DEPTH;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CompressedStateUpdate {
    pub key_hash: Hash32,
    pub old_value: Hash32,
    pub new_value: Hash32,
    /// One pool index for each of the 256 path levels.
    pub sibling_refs: Vec<u32>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CompressedStateTransitionProof {
    pub protocol_version: u32,
    pub from_root: Hash32,
    pub to_root: Hash32,
    pub sibling_pool: Vec<Hash32>,
    pub updates: Vec<CompressedStateUpdate>,
    pub transition_root: Hash32,
}

impl CompressedStateTransitionProof {
    pub fn from_full(full: &StateTransitionProof) -> Result<Self, String> {
        full.verify()?;
        if full.updates.is_empty() || full.updates.len() > MAX_UPDATES {
            return Err("invalid state-transition update count".into());
        }

        let mut pool = Vec::<Hash32>::new();
        let mut indexes = HashMap::<Hash32, u32>::new();
        let mut updates = Vec::with_capacity(full.updates.len());

        for proof in &full.updates {
            if proof.siblings.len() != PATH_DEPTH {
                return Err("invalid state proof depth".into());
            }
            let mut refs = Vec::with_capacity(PATH_DEPTH);
            for sibling in &proof.siblings {
                let idx = if let Some(idx) = indexes.get(sibling) {
                    *idx
                } else {
                    if pool.len() >= MAX_POOL_ENTRIES {
                        return Err("compressed sibling pool too large".into());
                    }
                    let idx = u32::try_from(pool.len()).map_err(|_| "sibling pool index overflow")?;
                    pool.push(*sibling);
                    indexes.insert(*sibling, idx);
                    idx
                };
                refs.push(idx);
            }
            updates.push(CompressedStateUpdate {
                key_hash: proof.key_hash,
                old_value: proof.old_value,
                new_value: proof.new_value,
                sibling_refs: refs,
            });
        }

        let transition_root = compressed_transition_root(
            full.from_root,
            full.to_root,
            &updates,
            &pool,
        );

        Ok(Self {
            protocol_version: PHASE5_PROTOCOL_VERSION,
            from_root: full.from_root,
            to_root: full.to_root,
            sibling_pool: pool,
            updates,
            transition_root,
        })
    }

    pub fn verify(&self) -> Result<StateTransitionProof, String> {
        if self.protocol_version != PHASE5_PROTOCOL_VERSION {
            return Err("unsupported compressed-transition version".into());
        }
        if self.updates.is_empty() || self.updates.len() > MAX_UPDATES {
            return Err("invalid compressed update count".into());
        }
        if self.sibling_pool.is_empty() || self.sibling_pool.len() > MAX_POOL_ENTRIES {
            return Err("invalid compressed sibling pool".into());
        }

        let expected_root = compressed_transition_root(
            self.from_root,
            self.to_root,
            &self.updates,
            &self.sibling_pool,
        );
        if expected_root != self.transition_root {
            return Err("compressed transition root mismatch".into());
        }

        let mut full_updates = Vec::with_capacity(self.updates.len());
        for update in &self.updates {
            if update.sibling_refs.len() != PATH_DEPTH {
                return Err("invalid compressed state proof depth".into());
            }
            let mut siblings = Vec::with_capacity(PATH_DEPTH);
            for index in &update.sibling_refs {
                let idx = usize::try_from(*index).map_err(|_| "invalid sibling reference")?;
                let sibling = self.sibling_pool.get(idx)
                    .ok_or_else(|| "sibling reference outside pool".to_string())?;
                siblings.push(*sibling);
            }
            let proof = StateUpdateProof {
                key_hash: update.key_hash,
                old_root: Hash32::ZERO,
                new_root: Hash32::ZERO,
                old_value: update.old_value,
                new_value: update.new_value,
                siblings,
            };
            // Recompute the two roots from the exact path. StateUpdateProof's
            // public verifier can then enforce both roots and transition order.
            let old_root = root_for(&proof, proof.old_value);
            let new_root = root_for(&proof, proof.new_value);
            full_updates.push(StateUpdateProof { old_root, new_root, ..proof });
        }

        let full = StateTransitionProof {
            protocol_version: super::yteleport::PROTOCOL_VERSION,
            from_root: self.from_root,
            to_root: self.to_root,
            updates: full_updates,
            transition_root: full_transition_root(
                self.from_root,
                self.to_root,
                &self.updates,
            ),
        };
        full.verify()?;
        Ok(full)
    }

    /// Returns the number of unique sibling hashes carried by the compressed proof.
    pub fn unique_sibling_count(&self) -> usize { self.sibling_pool.len() }

    /// Returns the number of sibling hashes in the uncompressed representation.
    pub fn uncompressed_sibling_count(&self) -> usize { self.updates.len() * PATH_DEPTH }
}

fn root_for(proof: &StateUpdateProof, value: Hash32) -> Hash32 {
    let mut cur = hash_leaf(proof.key_hash, value);
    for (level, sibling) in proof.siblings.iter().enumerate() {
        let bit = (proof.key_hash.0[level / 8] >> (level % 8)) & 1;
        cur = if bit == 0 { hash_branch(cur, *sibling) } else { hash_branch(*sibling, cur) };
    }
    cur
}

fn hash_leaf(key_hash: Hash32, value: Hash32) -> Hash32 {
    let mut h = Sha256::new();
    h.update(b"YT/STATE/LEAF/v1");
    h.update(key_hash.0);
    h.update(value.0);
    Hash32(h.finalize().into())
}

fn hash_branch(left: Hash32, right: Hash32) -> Hash32 {
    let mut h = Sha256::new();
    h.update(b"YT/STATE/BRANCH/v1");
    h.update(left.0);
    h.update(right.0);
    Hash32(h.finalize().into())
}

fn full_transition_root(
    from_root: Hash32,
    to_root: Hash32,
    updates: &[CompressedStateUpdate],
) -> Hash32 {
    let mut h = Sha256::new();
    h.update(b"YT/STATE-TRANSITION/v1");
    h.update(super::yteleport::PROTOCOL_VERSION.to_le_bytes());
    h.update(from_root.0);
    h.update(to_root.0);
    for u in updates {
        h.update(u.key_hash.0);
        h.update(u.old_value.0);
        h.update(u.new_value.0);
    }
    Hash32(h.finalize().into())
}

fn compressed_transition_root(
    from_root: Hash32,
    to_root: Hash32,
    updates: &[CompressedStateUpdate],
    pool: &[Hash32],
) -> Hash32 {
    let mut h = Sha256::new();
    h.update(DOMAIN);
    h.update(PHASE5_PROTOCOL_VERSION.to_le_bytes());
    h.update(from_root.0);
    h.update(to_root.0);
    h.update((pool.len() as u64).to_le_bytes());
    for sibling in pool { h.update(sibling.0); }
    h.update((updates.len() as u64).to_le_bytes());
    for u in updates {
        h.update(u.key_hash.0);
        h.update(u.old_value.0);
        h.update(u.new_value.0);
        h.update((u.sibling_refs.len() as u64).to_le_bytes());
        for idx in &u.sibling_refs { h.update(idx.to_le_bytes()); }
    }
    Hash32(h.finalize().into())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::sync::yteleport::{StateUpdate, StateUpdateProof};

    fn make_full() -> StateTransitionProof {
        let siblings = vec![Hash32([9; 32]); 256];
        let u = StateUpdateProof::from_update(
            &StateUpdate {
                key: b"phase5/shared-path".to_vec(),
                old_value: Hash32([1; 32]),
                new_value: Hash32([2; 32]),
            },
            siblings,
        ).unwrap();
        StateTransitionProof::derive(
            u.root_for_for_test(Hash32([1; 32])),
            u.root_for_for_test(Hash32([2; 32])),
            vec![u],
        ).unwrap()
    }

    #[test]
    fn compression_roundtrip_verifies() {
        let full = make_full();
        let compressed = CompressedStateTransitionProof::from_full(&full).unwrap();
        assert_eq!(compressed.unique_sibling_count(), 1);
        assert_eq!(compressed.uncompressed_sibling_count(), 256);
        assert!(compressed.verify().is_ok());
    }

    #[test]
    fn tampering_reference_fails_closed() {
        let full = make_full();
        let mut compressed = CompressedStateTransitionProof::from_full(&full).unwrap();
        compressed.updates[0].sibling_refs[0] = u32::MAX;
        assert!(compressed.verify().is_err());
    }

    #[test]
    fn tampering_pool_fails_closed() {
        let full = make_full();
        let mut compressed = CompressedStateTransitionProof::from_full(&full).unwrap();
        compressed.sibling_pool[0].0[0] ^= 1;
        assert!(compressed.verify().is_err());
    }
}
