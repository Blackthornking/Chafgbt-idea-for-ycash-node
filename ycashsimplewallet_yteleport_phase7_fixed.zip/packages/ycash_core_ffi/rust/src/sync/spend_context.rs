//! Phase 35 bridge from persisted sync state to authenticated spend inputs.
//!
//! This module deliberately refuses to manufacture witnesses, anchors, or keys.
//! A note becomes spend-eligible only when all consensus-critical metadata has
//! been persisted by the sync backend.

use crate::tx::{AuthenticatedNote, MerkleWitness, ProvingParameters, SpendContext, YcashNetwork};
use rusqlite::{params, Connection};

#[derive(Debug, thiserror::Error)]
pub enum SpendContextLoadError {
    #[error("storage error: {0}")]
    Storage(String),
    #[error("missing authenticated spend data for note {0}")]
    Incomplete(String),
    #[error("invalid network value: {0}")]
    Network(String),
}

pub fn persist_authenticated_note(
    conn: &Connection,
    note_id: &str,
    account_id: i64,
    value: u64,
    position: u64,
    note_commitment: &[u8; 32],
    anchor: &[u8; 32],
    witness: &[[u8; 32]],
    spending_key_handle: &str,
) -> Result<(), SpendContextLoadError> {
    let witness_blob = bincode::serialize(witness).map_err(|e| SpendContextLoadError::Storage(e.to_string()))?;
    conn.execute(
        "INSERT INTO authenticated_notes(note_id,account_id,value,position,note_commitment,anchor,witness,spending_key_handle,spent) \
         VALUES(?1,?2,?3,?4,?5,?6,?7,?8,0) \
         ON CONFLICT(note_id) DO UPDATE SET value=excluded.value,position=excluded.position,note_commitment=excluded.note_commitment,anchor=excluded.anchor,witness=excluded.witness,spending_key_handle=excluded.spending_key_handle",
        params![note_id, account_id, value as i64, position as i64, note_commitment.as_slice(), anchor.as_slice(), witness_blob, spending_key_handle],
    ).map_err(|e| SpendContextLoadError::Storage(e.to_string()))?;
    Ok(())
}

pub fn load_spend_context(
    conn: &Connection,
    network: YcashNetwork,
    note_ids: &[String],
    change_address: String,
    proving_params: ProvingParameters,
) -> Result<SpendContext, SpendContextLoadError> {
    let mut selected_notes = Vec::with_capacity(note_ids.len());
    for id in note_ids {
        let row = conn.query_row(
            "SELECT value,position,note_commitment,anchor,witness,spending_key_handle,spent FROM authenticated_notes WHERE note_id=?1",
            params![id],
            |r| Ok((r.get::<_, i64>(0)?, r.get::<_, i64>(1)?, r.get::<_, Vec<u8>>(2)?, r.get::<_, Vec<u8>>(3)?, r.get::<_, Vec<u8>>(4)?, r.get::<_, String>(5)?, r.get::<_, i64>(6)?)),
        ).map_err(|_| SpendContextLoadError::Incomplete(id.clone()))?;
        if row.6 != 0 || row.2.len() != 32 || row.3.len() != 32 || row.5.trim().is_empty() {
            return Err(SpendContextLoadError::Incomplete(id.clone()));
        }
        let mut commitment = [0u8;32]; commitment.copy_from_slice(&row.2);
        let mut anchor = [0u8;32]; anchor.copy_from_slice(&row.3);
        let path: Vec<[u8;32]> = bincode::deserialize(&row.4).map_err(|_| SpendContextLoadError::Incomplete(id.clone()))?;
        selected_notes.push(AuthenticatedNote {
            note_commitment: commitment,
            value: row.0 as u64,
            position: row.1 as u64,
            anchor,
            witness: MerkleWitness { auth_path: path },
            spending_key_handle: row.5,
        });
    }
    Ok(SpendContext { network, selected_notes, change_address, proving_params })
}
