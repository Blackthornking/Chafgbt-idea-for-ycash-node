//! Phase 37: source-verified transaction integration boundary.
//!
//! This module records the exact `sapling-crypto-ycash` Builder contract used by
//! this project. It intentionally does not deserialize opaque wallet bytes by
//! guessing an encoding: database bytes must first be tied to the exact upstream
//! serialization/consensus format that produced them.

use super::{SpendContext, TransactionPlan};

#[derive(Debug, thiserror::Error)]
pub enum Phase37Error {
    #[error("transaction plan has no recipient")]
    EmptyRecipient,
    #[error("transaction amount must be non-zero")]
    ZeroAmount,
    #[error("no authenticated Sapling notes selected")]
    NoNotes,
    #[error("selected notes do not share one anchor")]
    AnchorMismatch,
    #[error("opaque spending-key handles cannot be converted without the wallet key vault")]
    KeyResolutionUnavailable,
    #[error("Phase 37 requires the Ycash transaction layer in addition to sapling-crypto")]
    TransactionLayerUnavailable,
}

pub fn validate_source_verified_inputs(plan: &TransactionPlan, context: &SpendContext) -> Result<(), Phase37Error> {
    if plan.recipient.trim().is_empty() { return Err(Phase37Error::EmptyRecipient); }
    if plan.amount == 0 { return Err(Phase37Error::ZeroAmount); }
    if context.selected_notes.is_empty() { return Err(Phase37Error::NoNotes); }
    let anchor = context.selected_notes[0].anchor;
    if context.selected_notes.iter().any(|n| n.anchor != anchor) {
        return Err(Phase37Error::AnchorMismatch);
    }
    Ok(())
}

/// Exact upstream integration checklist.
///
/// The vendored `sapling-crypto-ycash` API requires:
/// - Builder::new(zip212_enforcement, BundleType, Anchor)
/// - FullViewingKey + Note + MerklePath for each spend
/// - PaymentAddress + NoteValue + 512-byte memo for outputs
/// - matching ExtendedSpendingKey entries when building
/// - concrete SpendProver/OutputProver implementations
///
/// Transaction-wide authorization/binding signatures and Ycash serialization are
/// deliberately delegated to the Ycash-patched transaction layer; they must not
/// be hand-rolled here.
pub const VERIFIED_UPSTREAM_BUILDER_API: &str = "Builder::new/add_spend/add_output/build";

#[cfg(test)]
mod tests {
    use super::*;
    use crate::tx::{AuthenticatedNote, MerkleWitness, ProvingParameters, YcashNetwork};

    #[test]
    fn rejects_mixed_anchors_before_builder() {
        let mut a = AuthenticatedNote { note_commitment:[0;32], value:5, position:0, anchor:[1;32], witness:MerkleWitness{auth_path:vec![]}, spending_key_handle:"k".into() };
        let mut b = a.clone(); b.anchor = [2;32];
        let ctx = SpendContext { network:YcashNetwork::Regtest, selected_notes:vec![a,b], change_address:"x".into(), proving_params:ProvingParameters{spend_params_path:"s".into(), output_params_path:"o".into()} };
        let plan = TransactionPlan { recipient:"ys1test".into(), amount:1, memo:None };
        assert!(matches!(validate_source_verified_inputs(&plan,&ctx), Err(Phase37Error::AnchorMismatch)));
    }
}
