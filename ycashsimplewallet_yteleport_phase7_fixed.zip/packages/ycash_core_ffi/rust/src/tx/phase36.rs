//! Phase 36: source-verified Sapling proving adapter.
//!
//! This module is intentionally *not* a fake transaction signer. It binds the
//! exact vendored Ycash Sapling API into the wallet and validates that the
//! wallet has the information the real builder requires. Secret key decoding,
//! address decoding, transaction-wide authorization and Ycash serialization are
//! kept outside this adapter until their exact Ycash types are wired end-to-end.

#[cfg(feature = "ycash-sapling")]
pub mod api {
    pub use sapling_crypto_ycash::builder::{Builder, BundleType};
    pub use sapling_crypto_ycash::prover::{OutputProver, SpendProver};
    pub use sapling_crypto_ycash::{Anchor, MerklePath, Note, PaymentAddress};
}

use super::{SpendContext, TransactionPlan};

#[derive(Debug, thiserror::Error)]
pub enum Phase36Error {
    #[error("no authenticated notes selected")]
    NoNotes,
    #[error("missing proving parameters")]
    MissingParams,
    #[error("selected notes do not share a single anchor")]
    AnchorMismatch,
    #[error("recipient or change address is not yet decoded into a Ycash Sapling PaymentAddress")]
    AddressNotDecoded,
    #[error("opaque key handles have not been resolved into Ycash ExtendedSpendingKey values")]
    KeyNotResolved,
}

/// Checks prerequisites that must hold before calling the real Sapling builder.
pub fn validate_builder_inputs(plan: &TransactionPlan, context: &SpendContext) -> Result<(), Phase36Error> {
    if context.selected_notes.is_empty() { return Err(Phase36Error::NoNotes); }
    if context.proving_params.spend_params_path.trim().is_empty() || context.proving_params.output_params_path.trim().is_empty() {
        return Err(Phase36Error::MissingParams);
    }
    let anchor = context.selected_notes[0].anchor;
    if context.selected_notes.iter().any(|n| n.anchor != anchor) { return Err(Phase36Error::AnchorMismatch); }
    if plan.recipient.trim().is_empty() || context.change_address.trim().is_empty() { return Err(Phase36Error::AddressNotDecoded); }
    if context.selected_notes.iter().any(|n| n.spending_key_handle.trim().is_empty()) { return Err(Phase36Error::KeyNotResolved); }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::tx::{AuthenticatedNote, MerkleWitness, ProvingParameters, YcashNetwork};
    #[test]
    fn rejects_mixed_anchors() {
        let c = SpendContext { network:YcashNetwork::Regtest, selected_notes: vec![
            AuthenticatedNote{note_commitment:[0;32],value:1,position:0,anchor:[1;32],witness:MerkleWitness{auth_path:vec![]},spending_key_handle:"k".into()},
            AuthenticatedNote{note_commitment:[0;32],value:1,position:1,anchor:[2;32],witness:MerkleWitness{auth_path:vec![]},spending_key_handle:"k".into()},
        ], change_address:"ys1x".into(), proving_params:ProvingParameters{spend_params_path:"a".into(),output_params_path:"b".into()} };
        let p=TransactionPlan{recipient:"ys1y".into(),amount:1,memo:None};
        assert!(matches!(validate_builder_inputs(&p,&c),Err(Phase36Error::AnchorMismatch)));
    }
}
