//! Phase 23 backend compile boundary.
//!
//! This module is intentionally small: it proves the pinned Ycash Sapling
//! crate is present without claiming transaction or proving compatibility.

#[cfg(feature = "ycash-sapling")]
pub fn pinned_sapling_crate_present() -> bool {
    let _ = core::any::TypeId::of::<sapling_crypto_ycash::value::NoteValue>();
    true
}

#[cfg(not(feature = "ycash-sapling"))]
pub fn pinned_sapling_crate_present() -> bool { false }

pub fn orchard_is_not_part_of_core() -> bool { true }

pub mod status;
