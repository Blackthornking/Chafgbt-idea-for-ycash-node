# Ycash Native Compatibility Layer

This build removes the old `yecshell` application crate name and replaces it
with the internally owned `ycash-compat-engine` compatibility layer.

## Boundary

Flutter keeps the existing `ycash_yecshell_*` C ABI symbols for backward
compatibility, but the Rust implementation is now owned by Yodl under
`packages/ycash_core_ffi/rust/vendor/ycash-compat-engine/` and exposed through
`src/ycash_compat.rs`.

The compatibility engine is not the native cryptographic scanner. The scanner
remains the Ycash-native production path and the compatibility layer only
provides wallet lifecycle, persistence, transaction planning, broadcast, and
legacy API adaptation needed by the current UI.

## What was removed

- Direct Rust dependency on the old `yecshell` crate/package name.
- Internal references to `zecwalletlitelib` as the application engine.
- Old `yecshell` source-tree naming for the compatibility engine.

## What remains intentionally

The vendored `libyec` tree is retained as a pinned protocol/cryptographic
compatibility stack. It is not treated as the Yodl application architecture.
Replacing those consensus-sensitive primitives is a separate compatibility
project and must be vector-tested before removal.

## ABI compatibility

The existing `ycash_yecshell_*` exported symbols are intentionally retained so
existing Flutter releases do not break. They are compatibility ABI names, not
a statement that the old wallet engine remains the architecture.
