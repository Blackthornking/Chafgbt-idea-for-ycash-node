# YTeleport-X Phase 3 — Authenticated Chain-Anchor Acquisition

Implemented on top of Phase 2.

## Added

- Ycash `getheaders` request generation using the negotiated protocol version.
- Strict `headers` message parsing for Ycash's block-header layout:
  - version
  - previous block hash
  - Merkle root
  - light-client root
  - time
  - nBits
  - 256-bit nonce
  - compact-size Equihash solution
  - mandatory zero transaction count
- Header-chain continuity interface through `YcashHeaderConsensus`.
- Explicit consensus adapter boundary: YTeleport-X does **not** substitute SHA256d for Ycash's real block-hash/Equihash rules.
- Multi-peer candidate collection types.
- Cryptographic quorum selection for a chain anchor.
- Fail-closed behavior for empty chains, malformed headers, excessive solutions, trailing bytes, invalid consensus results, and insufficient quorum.
- Corrected the wallet's Ycash mainnet P2P default port from 8333 to 8833.

## Security model

Peer data remains untrusted. A peer can only contribute a candidate. The exact Ycash consensus implementation must validate each header and calculate the real block hash before the candidate can contribute to an anchor quorum.

Quorum is an availability/cross-check mechanism, not a replacement for consensus.

## Compatibility

The existing transaction/signing path and 1140-byte signature format are untouched.
