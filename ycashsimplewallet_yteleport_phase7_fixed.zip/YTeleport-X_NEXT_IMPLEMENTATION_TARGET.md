# YTeleport-X Next Implementation Target — Phase 3

## Phase 2 completed

The wallet now contains a Ycash v4.5.0 P2P transport foundation:

- exact v4.5.0 P2P version 270013
- initial protocol version 209
- mainnet/testnet network magic
- mainnet/testnet P2P ports
- DNS bootstrap
- version/verack
- getaddr/addr discovery
- message checksum and size validation
- peer scoring and banning integration

## Phase 3 target — authenticated chain-anchor acquisition

The next implementation must NOT trust the peer's reported height or block hash.

Implement:

1. `getheaders` request/response framing.
2. Strict block-header parsing.
3. Header-chain continuity checks.
4. Per-peer candidate-tip collection.
5. Cross-peer candidate comparison.
6. A consensus-validation adapter behind `ChainAnchorVerifier`.
7. Checkpoint selection only after independent validation.
8. Fail-closed behavior for conflicting or incomplete header chains.
9. Persistent peer table.
10. Integration tests using deterministic synthetic P2P frames.

Only after this phase succeeds should YTeleport-X start transporting
StateRoot/StateTransitionProof objects.
