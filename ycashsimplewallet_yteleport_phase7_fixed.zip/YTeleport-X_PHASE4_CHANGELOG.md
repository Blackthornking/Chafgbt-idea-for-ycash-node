# YTeleport-X Phase 4 — Authenticated State Root + StateTransitionProof

## Implemented

- 256-level sparse Merkle state commitment using SHA-256 and domain-separated hashes.
- Deterministic `state_root()` construction with duplicate-key rejection.
- `StateUpdate` and `StateUpdateProof` structures.
- 256-sibling authentication paths.
- Verification that an update transforms a specific old state root into a specific new state root.
- Sequentially chained update proofs for multi-update transitions.
- `StateTransitionProof` with deterministic transition commitment.
- Fail-closed validation for protocol version, proof depth, update count, root continuity, and transition-root tampering.
- Unit tests for update proofs, transition proofs, tampering, and wrong-root rejection.

## Security boundary

This is an application-layer authenticated state commitment. It does not replace Ycash consensus validation.

A state transition is accepted only when:

1. The source chain anchor has already passed the Ycash consensus adapter.
2. The source state root is trusted locally.
3. Every update proof validates against its claimed old/new roots.
4. The proofs form one continuous root chain.
5. The final root equals the claimed destination root.
6. The transition commitment verifies.

## Important limitation

The proof format is intentionally conservative: each update carries a full 256-level authentication path, and updates are chained sequentially. This is a correctness-first Phase 4 design, not yet the final bandwidth-optimized multiproof format.

The next optimization should introduce authenticated delta/multiproof compression without weakening verification or changing existing Ycash transaction/signature serialization.
