# YTeleport-X Phase 2 — Ycash v4.5.0 P2P Transport

Implemented in `packages/ycash_core_ffi/rust/src/sync/yteleport.rs`.

## Implemented

- Exact Ycash v4.5.0 P2P protocol version: `270013`.
- Exact initial protocol version: `209`.
- Mainnet magic: `24 e9 27 64`.
- Testnet magic: `fa 1a f9 bf`.
- Mainnet P2P port: `8833`.
- Testnet P2P port: `18833`.
- Ycash DNS bootstrap: `seed.ycash.xyz` / `testseed.ycash.xyz`.
- P2P message framing and double-SHA256 checksum verification.
- `version` / `verack` handshake.
- `getaddr` address discovery.
- Legacy `addr` parsing with strict bounds.
- Ping/pong liveness handling.
- Connect/read/write timeouts.
- Oversized-message rejection.
- Network-magic rejection.
- Unsupported-peer-version rejection.
- Discovered peer insertion into `PeerManager`.
- Transport constants and parser tests.

## Security boundary

This phase does NOT treat peer advertisements as consensus truth.

A peer's reported height is an untrusted advertisement. The next consensus
phase must obtain and independently validate chain headers/blocks before a
checkpoint can become a `ChainCheckpoint`.

`ChainAnchorVerifier` remains the trust boundary.

## Deliberately not implemented yet

- Full Ycash block-header consensus validation in the wallet.
- Equihash validation in the mobile transport layer.
- Authenticated StateRoot transport.
- StateTransitionProof transport.
- BridgeSkip-X transport messages.
- ProofSkip-X transport messages.
- ReorgProof transport.
- `addrv2` support.

Those are kept behind the existing fail-closed boundary rather than being
faked by trusting peer claims.
