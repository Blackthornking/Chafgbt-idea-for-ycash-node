# YWallet / lightwalletd connection test — v0.19.1

The Android tester now goes beyond the transport handshake.

It tests:
1. DNS/host resolution (via the socket connect)
2. TCP
3. TLS when enabled
4. ALPN `h2` when Android exposes it
5. HTTP/2 SETTINGS
6. HTTP/2 gRPC HEADERS
7. A real unary `CompactTxStreamer.GetLatestBlock` request
8. gRPC DATA and a basic Ycash/Zcash `BlockID` protobuf response check

The endpoint remains manually editable and is saved across launches.

Examples:
- `127.0.0.1:9067`
- `192.168.1.50:9067`
- `lite.ycash.xyz:9067`
- `lightwalletd.ycash.xyz:443`

TLS is independently selectable.

Important: this is a client-side diagnostic. It does not turn the Android node into a lightwalletd server. A local `127.0.0.1:9067` test will only pass if a CompactTxStreamer-compatible service is actually listening there.
