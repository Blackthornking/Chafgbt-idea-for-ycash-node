#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
P="$ROOT/crates/ycash-android-node/src/pipeline_sync.rs"
E="$ROOT/crates/state/src/pipeline/mod.rs"
A="$ROOT/crates/state/src/pipeline/adaptive.rs"
S="$ROOT/crates/state/src/chainstate.rs"
R="$ROOT/crates/ycash-android-node/src/runtime.rs"
M="$ROOT/crates/ycash-android-node/src/main.rs"
J="$ROOT/android-app/app/src/main/java/com/ycash/androidnode/MainActivity.java"
X="$ROOT/android-app/app/src/main/res/layout/activity_main.xml"
C="$ROOT/config/pipeline.toml"

grep -q 'start_adaptive_sampler' "$P"
grep -q 'TryRecvError::Empty' "$P"
grep -q 'active_range_len' "$E"
# Signal separation: throttling pressure, workload demand and the network
# growth gate must stay distinct. Folding them into one max() is what drove the
# window to min_window whenever the validation queue filled up.
grep -q 'fn throttle_pressure' "$A"
grep -q 'fn network_stalled' "$A"
grep -q 'fn demand' "$A"
! grep -q 'max(s.validation_queue_ratio)' "$A"
! grep -q 'max(s.network_ratio)' "$A"
# Lookahead is the window; in-flight ranges partition it, never multiply it.
! grep -q 'saturating_mul(self.adaptive.current_inflight())' "$E"
# Pressure sensors must measure stalls, not utilisation.
grep -q 'read_psi_some_avg10' "$P"
grep -q 'MEMORY_PRESSURE_KNEE' "$P"
grep -q 'set_script_worker_budget' "$S"
grep -q 'commit_active' "$P" || { echo "ERROR: stage-aware commit CPU gate missing" >&2; exit 1; }
grep -q 'update_commit_cpu_budget' "$P" || { echo "ERROR: commit CPU rebalance missing" >&2; exit 1; }
grep -q 'DB_PRESSURE_TARGET_US' "$P" || { echo "ERROR: DB pressure is not isolated to SQLite write/COMMIT" >&2; exit 1; }
! grep -q 'let db_ratio = (commit_ms as f64 / 500.0)' "$P" || { echo "ERROR: full commit latency still feeds DB pressure" >&2; exit 1; }
grep -q 'const COMMIT_LINGER: Duration = Duration::from_millis(50)' "$P" || { echo "ERROR: commit linger was not reduced to 50 ms default" >&2; exit 1; }
grep -q 'pipeline_bottleneck' "$R"
grep -q 'pipeline_bottleneck' "$M"
grep -q 'pipelineBottleneck' "$J"
grep -q 'pipelinePressure' "$X"
grep -Eq '^max_range_len[[:space:]]*=[[:space:]]*100([[:space:]]*(#.*)?)?$' "$C"
grep -Eq '^max_validation_workers[[:space:]]*=[[:space:]]*0' "$C"
grep -Eq '^max_inflight_ranges[[:space:]]*=[[:space:]]*0' "$C"
! grep -q 'network_ratio = 0.0' "$P"
! grep -q 'let max_blocks = { let g = self.inner.lock' "$P"

echo 'PASS: fully adaptive Android pipeline scheduling, shared CPU budget, and bottleneck telemetry checks'
