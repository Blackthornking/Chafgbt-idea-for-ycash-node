package com.ycash.androidnode;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.StatFs;
import android.content.Intent;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.view.View;
import android.widget.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.*;
import java.util.Locale;
import org.json.JSONObject;
import android.content.SharedPreferences;

/**
 * Dedicated Ycash node monitor/control surface. Wallet UI intentionally excluded.
 *
 * This Activity talks only to the local status API (127.0.0.1:8834) and does not
 * open a gRPC channel itself. The node's YWallet-compatible lightwalletd surface
 * lives in crates/ycash-android-node and is documented here for CI diagnostics:
 *   - Service/method: CompactTxStreamer/GetLatestBlock
 *   - Content-Type: application/grpc
 *   - Negotiated header: grpc-accept-encoding
 *   - HTTP/2 stream teardown: RST_STREAM
 *   - HTTP/2 connection teardown: GOAWAY
 */
public class MainActivity extends Activity {
    TextView status, peer, height, headersHeight, targetHeight, blocksBehind, sync, syncPercent,
        pipelineState, pipelineWindow, inFlight, validationQueue, batchSize, headersRate, blocksRate,
        downloadRate, validationRate, commitRate, rxRate, avgValidation, avgCommit, lastBlock,
        activeWorkers, rangesCompleted, rangesRetried, rangesQuarantined, lastCommit,
        uptime, dbSize, freeStorage, networkType, listeners, connectionSource, connectionEndpoint,
        connectionDetail, diagnostics, log, exportStatus;
    ProgressBar syncProgress;
    View advancedSection;
    Button toggleAdvanced;
    Handler handler = new Handler();
    boolean running = false, advancedShown = false;
    SharedPreferences prefs;
    int consecutiveFailures = 0;
    static final int FAILURE_THRESHOLD = 5;
    long lastPollAt = 0;
    long lastHeight = -1, lastHeaders = -1, lastBlocks = -1, lastValidated = -1, lastHeaderBytes = -1, lastBlockBytes = -1, lastCommits = -1;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        bind();
        prefs=getSharedPreferences("ycash_node",MODE_PRIVATE);

        toggleAdvanced.setOnClickListener(v -> {
            advancedShown=!advancedShown;
            advancedSection.setVisibility(advancedShown ? View.VISIBLE : View.GONE);
            toggleAdvanced.setText(advancedShown ? "Hide diagnostics" : "Show diagnostics");
            if (advancedShown) refreshDeviceStats();
        });

        findViewById(R.id.start).setOnClickListener(v -> {
            prefs.edit().putString(NodeService.PREF_MANUAL_PEER,
                    ((EditText)findViewById(R.id.manualPeer)).getText().toString().trim()).apply();
            Intent i=new Intent(this,NodeService.class); i.setAction(NodeService.START);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            running=true; consecutiveFailures=0; resetRates();
            status.setText("RUNNING"); log.setText("Node: start requested"); pollStatus();
        });
        findViewById(R.id.stop).setOnClickListener(v -> {
            Intent i=new Intent(this,NodeService.class); i.setAction(NodeService.STOP); startService(i);
            running=false; status.setText("STOPPED"); sync.setText("Stopped");
            pipelineState.setText("IDLE"); log.setText("Node: stop requested"); resetRates();
            activeWorkers.setText("0"); lastCommit.setText("never this run"); lastCommit.setTextColor(0xFF667085);
        });
        findViewById(R.id.test).setOnClickListener(v -> testNetwork());
        findViewById(R.id.exportChain).setOnClickListener(v -> startExportChain());
    }

    private void bind() {
        status=findViewById(R.id.status); peer=findViewById(R.id.peer); height=findViewById(R.id.height);
        headersHeight=findViewById(R.id.headersHeight); targetHeight=findViewById(R.id.targetHeight);
        blocksBehind=findViewById(R.id.blocksBehind); sync=findViewById(R.id.sync); syncPercent=findViewById(R.id.syncPercent);
        syncProgress=findViewById(R.id.syncProgress); pipelineState=findViewById(R.id.pipelineState);
        pipelineWindow=findViewById(R.id.pipelineWindow); inFlight=findViewById(R.id.inFlight);
        validationQueue=findViewById(R.id.validationQueue); batchSize=findViewById(R.id.batchSize);
        headersRate=findViewById(R.id.headersRate); blocksRate=findViewById(R.id.blocksRate);
        downloadRate=findViewById(R.id.downloadRate); validationRate=findViewById(R.id.validationRate);
        commitRate=findViewById(R.id.commitRate); rxRate=findViewById(R.id.rxRate);
        avgValidation=findViewById(R.id.avgValidation); avgCommit=findViewById(R.id.avgCommit);
        lastBlock=findViewById(R.id.lastBlock); uptime=findViewById(R.id.uptime);
        activeWorkers=findViewById(R.id.activeWorkers); rangesCompleted=findViewById(R.id.rangesCompleted);
        rangesRetried=findViewById(R.id.rangesRetried); rangesQuarantined=findViewById(R.id.rangesQuarantined);
        lastCommit=findViewById(R.id.lastCommit);
        dbSize=findViewById(R.id.dbSize); freeStorage=findViewById(R.id.freeStorage); networkType=findViewById(R.id.networkType);
        listeners=findViewById(R.id.listeners); connectionSource=findViewById(R.id.connectionSource);
        connectionEndpoint=findViewById(R.id.connectionEndpoint); connectionDetail=findViewById(R.id.connectionDetail);
        diagnostics=findViewById(R.id.diagnostics); log=findViewById(R.id.log); exportStatus=findViewById(R.id.exportStatus);
        toggleAdvanced=findViewById(R.id.toggleAdvanced);
        EditText manualPeer=findViewById(R.id.manualPeer);
        manualPeer.setText(prefsOrDefault(NodeService.PREF_MANUAL_PEER,""));
    }

    private String prefsOrDefault(String k,String d){ return getSharedPreferences("ycash_node",MODE_PRIVATE).getString(k,d); }
    private void resetRates(){ lastPollAt=0; lastHeight=lastHeaders=lastBlocks=lastValidated=lastHeaderBytes=lastBlockBytes=lastCommits=-1; }

    private void pollStatus(){
        if(!running)return;
        new Thread(() -> {
            try{
                HttpURLConnection c=(HttpURLConnection)new URL("http://127.0.0.1:8834/status").openConnection();
                c.setConnectTimeout(1500); c.setReadTimeout(1500); c.setRequestMethod("GET");
                if(c.getResponseCode()==200){
                    BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));
                    StringBuilder s=new StringBuilder(); String line; while((line=br.readLine())!=null)s.append(line);
                    JSONObject j=new JSONObject(s.toString()); runOnUiThread(() -> applyStatus(j));
                }
                c.disconnect();
            }catch(Exception e){
                consecutiveFailures++;
                if(consecutiveFailures==FAILURE_THRESHOLD) runOnUiThread(() -> {
                    status.setText("NODE NOT RESPONDING"); log.setText("No response from status API :8834");
                });
            }
            handler.postDelayed(this::pollStatus,2000);
        }).start();
    }

    private void applyStatus(JSONObject j){
        try{
            consecutiveFailures=0;
            long now=System.currentTimeMillis(); double dt=lastPollAt>0?(now-lastPollAt)/1000.0:0;
            long h=j.optLong("height",-1), hh=j.optLong("headers_height",-1), blocks=j.optLong("blocks_received",0);
            long hb=j.optLong("header_bytes_received",0), bb=j.optLong("block_bytes_received",0), commits=j.optLong("db_commits",0);
            status.setText(j.optString("status","unknown").toUpperCase(Locale.US));
            peer.setText(String.valueOf(j.optInt("peers",0)));
            height.setText(h<0?"—":formatLong(h)); headersHeight.setText(hh<0?"—":formatLong(hh));
            long target=j.optLong("target_height",-1); targetHeight.setText(target<0?"—":formatLong(target));
            long behind=(h>=0&&target>=0)?Math.max(0,target-h):0; blocksBehind.setText(formatLong(behind));
            String syncText=j.optString("sync","unknown"); sync.setText(syncText);
            int pct=0; if(target>0&&hh>=0)pct=(int)Math.min(100,Math.max(0,(hh*100)/target));
            syncProgress.setProgress(pct); syncPercent.setText(pct+"%");
            pipelineState.setText(behind>0?"ACTIVE · FETCH / VALIDATE / COMMIT":"LIVE · READY");
            pipelineWindow.setText(formatLong(j.optLong("current_window",0)));
            inFlight.setText(formatLong(j.optLong("blocks_in_flight",0)));
            validationQueue.setText(formatLong(j.optLong("validation_queue",0)));
            batchSize.setText(formatLong(j.optLong("batch_size",0)));
            activeWorkers.setText(formatLong(j.optLong("active_block_workers",0)));
            long retried=j.optLong("retried_ranges",0), quarantined=j.optLong("quarantined_ranges",0);
            rangesCompleted.setText(formatLong(j.optLong("completed_ranges",0)));
            rangesRetried.setText(formatLong(retried));
            rangesQuarantined.setText(formatLong(quarantined));
            // A worker retries a range when a peer times out or misbehaves mid-claim; that's
            // normal on a weak connection. A nonzero quarantined count means a range hit the
            // retry limit with no peer able to serve it -- the chain is genuinely stuck behind
            // it until a different peer becomes available, independent of headers still moving.
            rangesQuarantined.setTextColor(quarantined>0?0xFFB42318:0xFF111827);
            if(dt>0){
                headersRate.setText(rate(hh,lastHeaders,dt,"headers/s"));
                blocksRate.setText(rate(blocks,lastBlocks,dt,"blocks/s"));
                downloadRate.setText(byteRate(bb,lastBlockBytes,dt));
                validationRate.setText(rate(j.optLong("blocks_validated",0),lastValidated,dt,"valid/s"));
                commitRate.setText(rate(commits,lastCommits,dt,"commits/s"));
                rxRate.setText(byteRate(hb+bb,(lastHeaderBytes<0||lastBlockBytes<0)?-1:lastHeaderBytes+lastBlockBytes,dt));
            }
            long valCount=j.optLong("blocks_validated",0), valMs=j.optLong("validation_ms_total",0);
            long commitCount=j.optLong("db_commits",0), commitMs=j.optLong("db_commit_ms_total",0);
            avgValidation.setText(valCount>0?String.format(Locale.US,"%.1f ms",(double)valMs/valCount):"—");
            avgCommit.setText(commitCount>0?String.format(Locale.US,"%.1f ms",(double)commitMs/commitCount):"—");
            long tipTime=j.optLong("tip_time",0); lastBlock.setText(tipTime>0?formatDuration(Math.max(0,System.currentTimeMillis()/1000-tipTime))+" ago":"—");
            // tip_time is the *committed* block's own header timestamp (a consensus field, not
            // wall-clock), so on a chain that's still far behind it stays old no matter how fast
            // sync is actually going. last_commit_unix is wall-clock time of the last successful
            // DB commit, which is what actually tells you whether the pipeline is stuck right now
            // -- this is the number that stays frozen in exactly the "headers moving, blocks not"
            // case that prompted adding this panel.
            long lastCommitUnix=j.optLong("last_commit_unix",0);
            if(lastCommitUnix<=0){
                lastCommit.setText("never this run");
                lastCommit.setTextColor(0xFF667085);
            }else{
                long secsSince=Math.max(0,System.currentTimeMillis()/1000-lastCommitUnix);
                lastCommit.setText(formatDuration(secsSince)+" ago");
                lastCommit.setTextColor(secsSince>120?0xFFB42318:0xFF111827);
            }
            uptime.setText(formatDuration(Math.max(0,j.optLong("uptime_seconds",0))));
            listeners.setText("P2P 8833 "+up(j.optBoolean("p2p_listening"))+"   RPC 8832 "+up(j.optBoolean("rpc_listening"))+"   API 8834 "+up(j.optBoolean("api_listening"))+"   YWallet gRPC 9067 "+up(j.optBoolean("lightwallet_listening")));
            connectionSource.setText(j.optString("connection_source","None"));
            connectionEndpoint.setText(j.optString("connection_endpoint","—"));
            connectionDetail.setText(j.optString("connection_detail","—"));
            diagnostics.setText("Outbound: "+j.optLong("outbound_attempts",0)+" attempts / "+j.optLong("outbound_handshakes",0)+" handshakes\n"+
                "Inbound: "+j.optLong("inbound_connections",0)+"   Known peers: "+j.optLong("known_peers",0)+"\n"+
                "Validated: "+j.optLong("blocks_validated",0)+" blocks   Indexed: "+j.optLong("txs_indexed",0)+" txs\n"+
                "Last block: "+formatBytes(j.optLong("last_block_bytes",0))+"   Last height: "+j.optLong("last_block_height",0)+"\n"+
                "Last error: "+j.optString("last_error","—"));
            log.setText(j.optString("message","status updated"));
            lastPollAt=now; lastHeight=h; lastHeaders=hh; lastBlocks=blocks; lastValidated=j.optLong("blocks_validated",0); lastHeaderBytes=hb; lastBlockBytes=bb; lastCommits=commits;
            if(advancedShown)refreshDeviceStats();
        }catch(Exception ignored){}
    }

    private String up(boolean v){return v?"UP":"DOWN";}
    private String rate(long now,long prev,double dt,String unit){ if(prev<0||now<prev)return"—"; return String.format(Locale.US,"%.1f %s",(now-prev)/dt,unit); }
    private String byteRate(long now,long prev,double dt){ if(prev<0||now<prev)return"—"; return formatBytesPerSecond((now-prev)/dt); }
    private String formatBytesPerSecond(double v){ if(v<1024)return String.format(Locale.US,"%.0f B/s",v); if(v<1024*1024)return String.format(Locale.US,"%.1f KB/s",v/1024); return String.format(Locale.US,"%.2f MB/s",v/(1024*1024)); }
    private String formatLong(long v){return String.format(Locale.US,"%,d",v);}
    private static String formatDuration(long s){long h=s/3600,m=(s%3600)/60,sec=s%60;if(h>0)return h+"h "+m+"m";if(m>0)return m+"m "+sec+"s";return sec+"s";}
    private static String formatBytes(long b){if(b<1024)return b+" B";if(b<1024*1024)return String.format(Locale.US,"%.1f KB",b/1024.0);if(b<1024*1024*1024)return String.format(Locale.US,"%.1f MB",b/(1024.0*1024));return String.format(Locale.US,"%.2f GB",b/(1024.0*1024*1024));}

    private void refreshDeviceStats(){
        try{File db=new File(getFilesDir(),"ycash-node.sqlite");dbSize.setText(db.exists()?formatBytes(db.length()):"—");}catch(Exception e){dbSize.setText("—");}
        try{StatFs s=new StatFs(getFilesDir().getAbsolutePath());freeStorage.setText(formatBytes(s.getAvailableBytes()));}catch(Exception e){freeStorage.setText("—");}
        try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkCapabilities c=cm==null?null:cm.getNetworkCapabilities(cm.getActiveNetwork());networkType.setText(c==null?"None":c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)?"Wi-Fi":c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)?"Mobile":"Other");}catch(Exception e){networkType.setText("—");}
    }

    private void testNetwork(){
        new Thread(() -> { long t=System.currentTimeMillis(); try{HttpURLConnection c=(HttpURLConnection)new URL("http://127.0.0.1:8834/status").openConnection();c.setConnectTimeout(3000);c.setReadTimeout(3000);int code=c.getResponseCode();c.disconnect();runOnUiThread(() -> log.setText("Status API: HTTP "+code+" · "+(System.currentTimeMillis()-t)+" ms"));}catch(Exception e){runOnUiThread(() -> log.setText("Status API test failed: "+e.getClass().getSimpleName()));}}).start();
    }

    private void startExportChain(){
        if(!running){exportStatus.setText("Export: start the node first");return;}
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"ycash-chain-"+(System.currentTimeMillis()/1000)+".sqlite");exportStatus.setText("Export: choose destination…");
        try{startActivityForResult(i,1001);}catch(Exception e){exportStatus.setText("Export: file picker unavailable");}
    }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==1001&&c==RESULT_OK&&d!=null&&d.getData()!=null)exportChainTo(d.getData());else if(r==1001)exportStatus.setText("Export: cancelled");}
    private void exportChain(android.net.Uri dest){exportChainTo(dest);}
    private void exportChainTo(android.net.Uri dest){
        exportStatus.setText("Export: creating snapshot…");new Thread(() -> {HttpURLConnection c=null;try{c=(HttpURLConnection)new URL("http://127.0.0.1:8834/export").openConnection();c.setConnectTimeout(5000);c.setReadTimeout(0);c.setRequestMethod("GET");if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());long total=0;try(InputStream in=c.getInputStream();OutputStream out=getContentResolver().openOutputStream(dest)){if(out==null)throw new IOException("destination unavailable");byte[] buf=new byte[64*1024];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);total+=n;}}long x=total;runOnUiThread(() -> exportStatus.setText("Export: saved "+formatBytes(x)));}catch(Exception e){runOnUiThread(() -> exportStatus.setText("Export: failed — "+e.getMessage()));}finally{if(c!=null)c.disconnect();}}).start();
    }
}
