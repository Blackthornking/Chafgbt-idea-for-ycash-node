package com.ycash.androidnode;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.StatFs;
import android.content.Intent;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.view.View;
import android.widget.*;
import java.net.*;
import javax.net.ssl.*;
import java.util.LinkedHashSet;
import java.io.*;
import org.json.JSONObject;
// RandomAccessFile is covered by java.io.* above

public class MainActivity extends Activity {
    TextView status, peer, height, sync, log, headersHeight, connectionSource, connectionEndpoint, connectionDetail,
        targetHeight, blocksBehind, syncSpeed, lastBlock, uptime, dbSize, freeStorage, networkType;
    View advancedSection;
    Button toggleAdvanced;
    Handler handler = new Handler();
    boolean running = false;
    boolean advancedShown = false;
    EditText walletEndpoint;
    CheckBox walletTls;
    TextView walletTestResult;
    int consecutiveFailures = 0;
    // 2s poll interval * 5 = ~10s of nothing listening on 8834 before we tell the user, instead of
    // sitting on "STARTING" forever.
    static final int FAILURE_THRESHOLD = 5;
    // For a client-side sync-speed estimate: last height/time we saw, so we can diff across polls
    // instead of asking the node to track a rate itself.
    long lastSpeedHeight = -1;
    long lastSpeedAtMillis = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status=findViewById(R.id.status);
        peer=findViewById(R.id.peer);
        height=findViewById(R.id.height);
        sync=findViewById(R.id.sync);
        log=findViewById(R.id.log);
        headersHeight=findViewById(R.id.headersHeight);
        connectionSource=findViewById(R.id.connectionSource);
        connectionEndpoint=findViewById(R.id.connectionEndpoint);
        connectionDetail=findViewById(R.id.connectionDetail);
        targetHeight=findViewById(R.id.targetHeight);
        blocksBehind=findViewById(R.id.blocksBehind);
        syncSpeed=findViewById(R.id.syncSpeed);
        lastBlock=findViewById(R.id.lastBlock);
        uptime=findViewById(R.id.uptime);
        dbSize=findViewById(R.id.dbSize);
        freeStorage=findViewById(R.id.freeStorage);
        networkType=findViewById(R.id.networkType);
        advancedSection=findViewById(R.id.advancedSection);
        toggleAdvanced=findViewById(R.id.toggleAdvanced);
        walletEndpoint=findViewById(R.id.walletEndpoint);
        walletTls=findViewById(R.id.walletTls);
        walletTestResult=findViewById(R.id.walletTestResult);
        findViewById(R.id.testWallet).setOnClickListener(v -> testWalletEndpoint());

        toggleAdvanced.setOnClickListener(v -> {
            advancedShown=!advancedShown;
            advancedSection.setVisibility(advancedShown ? View.VISIBLE : View.GONE);
            toggleAdvanced.setText(advancedShown ? "Advanced ▾" : "Advanced ▸");
            if (advancedShown) refreshDeviceStats();
        });

        findViewById(R.id.start).setOnClickListener(v -> {
            Intent i = new Intent(this, NodeService.class); i.setAction(NodeService.START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            running=true; consecutiveFailures=0; lastSpeedHeight=-1; status.setText("● STARTING"); log.setText("Log: starting Ycash node process"); pollStatus();
        });

        findViewById(R.id.stop).setOnClickListener(v -> {
            Intent i = new Intent(this, NodeService.class); i.setAction(NodeService.STOP); startService(i);
            running=false; status.setText("● STOPPED"); sync.setText("Sync: stopped");
            connectionSource.setText("Connection source: None");
            connectionEndpoint.setText("Endpoint: —");
            connectionDetail.setText("Details: Node stopped");
            blocksBehind.setText("Blocks behind: —");
            syncSpeed.setText("Sync speed: —");
            lastBlock.setText("Last block: —");
            uptime.setText("Node uptime: —");
            log.setText("Log: node stop requested");
        });

        findViewById(R.id.test).setOnClickListener(v -> testNetwork());
    }

    private void pollStatus() {
        if (!running) return;
        new Thread(() -> {
            try {
                URL u=new URL("http://127.0.0.1:8834/status");
                HttpURLConnection c=(HttpURLConnection)u.openConnection();
                c.setConnectTimeout(1500);
                c.setReadTimeout(1500);
                c.setRequestMethod("GET");
                if(c.getResponseCode()==200) {
                    BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));
                    StringBuilder s=new StringBuilder(); String line;
                    while((line=br.readLine())!=null) s.append(line);
                    JSONObject j=new JSONObject(s.toString());
                    runOnUiThread(() -> applyStatus(j));
                }
                c.disconnect();
            } catch(Exception e) {
                consecutiveFailures++;
                if (consecutiveFailures == FAILURE_THRESHOLD) {
                    String tail = readLogTail();
                    runOnUiThread(() -> {
                        status.setText("● NODE NOT RESPONDING");
                        log.setText("Log: no response from the node on :8834 after "+
                            (FAILURE_THRESHOLD*2)+"s. Last error: "+e.getClass().getSimpleName()+
                            (tail.isEmpty() ? "" : "\n\nnode.log tail:\n"+tail));
                    });
                }
                // Below the threshold, keep showing the last real values -- a couple of missed polls
                // during startup is normal and not worth alarming the user over.
            }
            handler.postDelayed(this::pollStatus, 2000);
        }).start();
    }

    /** Reads the last ~2KB of node.log so a "not responding" status is actually actionable. */
    private String readLogTail() {
        File f = new File(getFilesDir(), "node.log");
        if (!f.exists()) return "";
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            long len = raf.length();
            long start = Math.max(0, len - 2048);
            raf.seek(start);
            byte[] buf = new byte[(int)(len - start)];
            raf.readFully(buf);
            return new String(buf);
        } catch (Exception e) {
            return "";
        }
    }

    private void applyStatus(JSONObject j) {
        try {
            consecutiveFailures = 0;
            status.setText("● "+j.optString("status","UNKNOWN").toUpperCase());
            peer.setText("Peers: "+j.optInt("peers",0));
            long blockHeight=j.optLong("height",-1);
            long headerHeight=j.optLong("headers_height",-1);
            long peerTargetHeight=j.optLong("target_height",-1);
            height.setText("Block height: "+(blockHeight < 0 ? "—" : blockHeight));
            headersHeight.setText("Headers height: "+(headerHeight < 0 ? "—" : headerHeight));
            targetHeight.setText("Target height: "+(peerTargetHeight < 0 ? "—" : peerTargetHeight));
            sync.setText("Sync: "+j.optString("sync","unknown"));
            blocksBehind.setText("Blocks behind: "+
                (blockHeight < 0 || peerTargetHeight < 0 ? "—" : Math.max(0, peerTargetHeight-blockHeight)));

            // Sync speed: diffed client-side across polls. The node doesn't track a rate itself,
            // so this is only as smooth as the 2s poll interval -- fine for a rough reading.
            long now=System.currentTimeMillis();
            if (blockHeight >= 0) {
                if (lastSpeedHeight >= 0 && now > lastSpeedAtMillis) {
                    double blocksPerSec=(blockHeight-lastSpeedHeight)*1000.0/(now-lastSpeedAtMillis);
                    syncSpeed.setText(blocksPerSec <= 0 ? "Sync speed: —" :
                        String.format(java.util.Locale.US, "Sync speed: %.1f blocks/s", blocksPerSec));
                }
                lastSpeedHeight=blockHeight; lastSpeedAtMillis=now;
            }

            long tipTime=j.optLong("tip_time",0);
            if (tipTime > 0) {
                long agoSec=Math.max(0, System.currentTimeMillis()/1000 - tipTime);
                lastBlock.setText("Last block: "+formatDuration(agoSec)+" ago");
            } else {
                lastBlock.setText("Last block: —");
            }

            long uptimeSec=j.optLong("uptime_seconds",-1);
            uptime.setText("Node uptime: "+(uptimeSec < 0 ? "—" : formatDuration(uptimeSec)));

            connectionSource.setText("Connection source: "+j.optString("connection_source","None"));
            connectionEndpoint.setText("Endpoint: "+j.optString("connection_endpoint","—"));
            connectionDetail.setText("Details: "+j.optString("connection_detail","—"));
            log.setText("Log: "+j.optString("message","status updated"));
            if (advancedShown) refreshDeviceStats();
        } catch(Exception ignored) {}
    }

    private static String formatDuration(long totalSeconds) {
        long h=totalSeconds/3600, m=(totalSeconds%3600)/60, s=totalSeconds%60;
        if (h > 0) return h+"h "+m+"m";
        if (m > 0) return m+"m "+s+"s";
        return s+"s";
    }

    /**
     * Real device/OS numbers, not node output -- the node process has no reliable, portable way to
     * report its own CPU/RAM from inside another app's process on modern Android, so rather than ship
     * a reading that silently goes wrong on some devices, this sticks to what Android itself can answer
     * accurately: the node's actual database file size, free space on the device, and network type.
     */
    private void refreshDeviceStats() {
        try {
            File db=new File(getFilesDir(),"ycash-node.sqlite");
            dbSize.setText("Node database size: "+(db.exists() ? formatBytes(db.length()) : "—"));
        } catch (Exception e) { dbSize.setText("Node database size: —"); }
        try {
            StatFs stat=new StatFs(getFilesDir().getAbsolutePath());
            freeStorage.setText("Free device storage: "+formatBytes(stat.getAvailableBytes()));
        } catch (Exception e) { freeStorage.setText("Free device storage: —"); }
        try {
            ConnectivityManager cm=(ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities caps = cm==null ? null : cm.getNetworkCapabilities(cm.getActiveNetwork());
            String kind = caps==null ? "none"
                : caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi"
                : caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "mobile"
                : "other";
            networkType.setText("Device network: "+kind);
        } catch (Exception e) { networkType.setText("Device network: —"); }
    }

    private static String formatBytes(long bytes) {
        if (bytes < 1024*1024) return String.format(java.util.Locale.US, "%.0f KB", bytes/1024.0);
        if (bytes < 1024*1024*1024) return String.format(java.util.Locale.US, "%.1f MB", bytes/(1024.0*1024));
        return String.format(java.util.Locale.US, "%.2f GB", bytes/(1024.0*1024*1024));
    }

    /** Tests a manually entered YWallet/Lightwalletd endpoint.
     *  This deliberately performs a real TCP/TLS + HTTP/2 preface probe.
     *  It does not claim CompactTxStreamer compatibility unless the HTTP/2
     *  server answers the gRPC transport handshake.
     */
    private void testWalletEndpoint() {
        String raw=walletEndpoint.getText().toString().trim();
        boolean tls=walletTls.isChecked();
        if(raw.isEmpty()) { walletTestResult.setText("YWallet test: enter host:port"); return; }
        String host=raw; int port=tls ? 443 : 9067;
        try {
            if(host.contains("://")) host=host.substring(host.indexOf("://")+3);
            int slash=host.indexOf('/'); if(slash>=0) host=host.substring(0,slash);
            if(host.startsWith("[")) {
                int close=host.indexOf(']'); if(close>0) {
                    String h=host.substring(1,close);
                    if(host.length()>close+1 && host.charAt(close+1)==':') port=Integer.parseInt(host.substring(close+2));
                    host=h;
                }
            } else {
                int colon=host.lastIndexOf(':');
                if(colon>0 && host.indexOf(':')==colon) { port=Integer.parseInt(host.substring(colon+1)); host=host.substring(0,colon); }
            }
        } catch(Exception e) { walletTestResult.setText("YWallet test: invalid host:port"); return; }

        final String h=host; final int p=port;
        walletTestResult.setText("YWallet test: testing "+h+":"+p+(tls?" (TLS)":" (plain)")+"…");
        new Thread(() -> {
            long started=System.currentTimeMillis();
            try {
                Socket socket;
                if(tls) {
                    SSLSocketFactory sf=(SSLSocketFactory)SSLSocketFactory.getDefault();
                    SSLSocket ss=(SSLSocket)sf.createSocket();
                    ss.setConnectTimeout(4000); ss.setSoTimeout(4000);
                    ss.connect(new InetSocketAddress(h,p),4000);
                    ss.startHandshake();
                    socket=ss;
                } else {
                    Socket s=new Socket();
                    s.connect(new InetSocketAddress(h,p),4000);
                    s.setSoTimeout(4000);
                    socket=s;
                }
                InputStream in=socket.getInputStream(); OutputStream out=socket.getOutputStream();
                // HTTP/2 client connection preface, followed by an empty SETTINGS frame.
                out.write(new byte[]{'P','R','I',' ','*',' ','H','T','T','P','/','2','\r','\n','\r','\n','S','M','\r','\n','\r','\n'});
                out.write(new byte[]{0,0,0,4,0,0,0,0,0});
                out.flush();
                byte[] hdr=new byte[9]; int got=0;
                while(got<9) { int n=in.read(hdr,got,9-got); if(n<0) break; got+=n; }
                final int bytes=got;
                final boolean settings = got==9 && (hdr[3]&0xff)==4;
                final long ms=System.currentTimeMillis()-started;
                final String result = settings
                    ? "YWallet transport: PASS\n"+h+":"+p+(tls?" TLS":"")+"\n✓ TCP connection\n✓ "+(tls?"TLS handshake\n✓ ":"")+"HTTP/2 SETTINGS received\nNext: CompactTxStreamer RPC test"
                    : "YWallet transport: PARTIAL\n"+h+":"+p+"\n✓ TCP connection"+(tls?"\n✓ TLS handshake":"")+"\n✗ HTTP/2 SETTINGS not received ("+bytes+"/9 bytes)";
                runOnUiThread(() -> walletTestResult.setText(result+"\nLatency: "+ms+" ms"));
                socket.close();
            } catch(Exception e) {
                String msg=e.getClass().getSimpleName()+": "+(e.getMessage()==null?"connection failed":e.getMessage());
                runOnUiThread(() -> walletTestResult.setText("YWallet test: FAIL\n"+h+":"+p+"\n✗ "+msg));
            }
        }).start();
    }

    private void testNetwork() {
        status.setText("● TESTING");
        connectionSource.setText("Connection source: testing all known sources");
        connectionEndpoint.setText("Endpoint: —");
        connectionDetail.setText("Details: DNS seed and fixed seeds will be tested in order");
        log.setText("Log: testing Ycash mainnet connection sources on TCP 8833…");
        new Thread(() -> {
            LinkedHashSet<String> seen = new LinkedHashSet<>();
            java.util.ArrayList<String[]> candidates = new java.util.ArrayList<>();

            try {
                for (InetAddress a : InetAddress.getAllByName("seed.ycash.xyz")) {
                    String endpoint=a.getHostAddress()+":8833";
                    if (seen.add(endpoint)) candidates.add(new String[]{"DNS Seed (seed.ycash.xyz)", endpoint, a.getHostAddress()});
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    connectionSource.setText("Connection source: DNS Seed (seed.ycash.xyz)");
                    connectionEndpoint.setText("Endpoint: —");
                    connectionDetail.setText("Details: DNS resolution failed; testing fixed seeds");
                    log.setText("Log: DNS seed unavailable: "+e.getClass().getSimpleName());
                });
            }

            String[][] fixed = {
                {"Fixed Seed #1", "3.130.144.65", "8833"},
                {"Fixed Seed #2", "13.126.58.237", "8833"}
            };
            for (String[] f : fixed) {
                String endpoint=f[1]+":"+f[2];
                if (seen.add(endpoint)) candidates.add(new String[]{f[0], endpoint, f[1]});
            }

            Exception last=null;
            for (String[] candidate : candidates) {
                final String source=candidate[0];
                final String endpoint=candidate[1];
                runOnUiThread(() -> {
                    connectionSource.setText("Connection source: "+source);
                    connectionEndpoint.setText("Endpoint: "+endpoint);
                    connectionDetail.setText("Details: attempting TCP connection");
                    log.setText("Log: trying "+source+" → "+endpoint);
                });
                try (Socket socket = new Socket()) {
                    socket.connect(new InetSocketAddress(candidate[2], 8833), 7000);
                    runOnUiThread(() -> {
                        status.setText("● NETWORK REACHABLE");
                        connectionSource.setText("Connection source: "+source);
                        connectionEndpoint.setText("Endpoint: "+endpoint);
                        connectionDetail.setText("Details: TCP connection succeeded (P2P handshake is tested by the node)");
                        log.setText("Log: "+source+" succeeded at "+endpoint);
                    });
                    return;
                } catch (Exception e) {
                    last=e;
                    runOnUiThread(() -> log.setText("Log: "+source+" failed at "+endpoint+": "+e.getClass().getSimpleName()));
                }
            }
            Exception failure=last;
            runOnUiThread(() -> {
                status.setText("● CONNECTION FAILED");
                connectionDetail.setText("Details: every known Ycash connection source failed");
                log.setText("Log: all Ycash connection sources failed: "+
                    (failure == null ? "unknown error" : failure.getClass().getSimpleName()+": "+failure.getMessage()));
            });
        }).start();
    }

}
