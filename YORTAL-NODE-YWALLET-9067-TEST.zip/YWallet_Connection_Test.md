# YWallet / Lightwalletd manual connection tester

Added to the Android app.

## UI
Enter a server as `host:port`, for example:
- `127.0.0.1:9067`
- `192.168.1.50:9067`
- `lightwalletd.ycash.xyz:443`

Enable **Use TLS** for TLS endpoints such as port 443.

## What the test verifies
1. DNS/host resolution
2. TCP connection
3. TLS handshake when enabled
4. HTTP/2 connection preface and SETTINGS response

A successful transport test is reported as **YWallet transport: PASS**. This confirms that the endpoint accepts the underlying gRPC/HTTP2 transport. It does not by itself prove that every CompactTxStreamer RPC is implemented; the UI explicitly says that the CompactTxStreamer RPC test is the next layer.

## Build
The supplied project currently does not contain `gradle-wrapper.jar`, so the included `gradlew` cannot execute until a Gradle wrapper JAR/distribution is supplied or generated in a normal Gradle environment.
