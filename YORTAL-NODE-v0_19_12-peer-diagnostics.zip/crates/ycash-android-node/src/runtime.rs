use std::sync::{Arc, RwLock};
use ycash_network::runtime::unix_time;

#[derive(Clone, Debug)]
pub struct LiveNodeState {
    pub running: bool,
    pub peers: u32,
    pub local_height: u64,
    pub target_height: Option<u64>,
    pub headers_height: u64,
    pub connection_source: String,
    pub connection_endpoint: String,
    pub connection_detail: String,
    pub message: String,
    /// Unix time embedded in the most recently validated block's header -- this is a real
    /// consensus field (BlockHeader.time), not a wall-clock timestamp of when we processed it.
    pub tip_time: u32,
    /// Wall-clock unix time this node process started, captured once at state creation.
    pub started_unix: i64,
    pub api_listening: bool,
    pub rpc_listening: bool,
    pub p2p_listening: bool,
    pub lightwallet_listening: bool,
    pub outbound_attempts: u64,
    pub outbound_handshakes: u64,
    pub inbound_connections: u64,
    pub last_error: String,
    /// Last status per outbound peer address (most recent first when rendered).
    pub peer_last: std::collections::BTreeMap<String,(i64,String)>,
    pub active_outbound: u32,
    pub known_peers: u32,
}
impl Default for LiveNodeState {
    fn default() -> Self {
        Self {
            running: false,
            peers: 0,
            local_height: 0,
            target_height: None,
            headers_height: 0,
            connection_source: "None".into(),
            connection_endpoint: "—".into(),
            connection_detail: "No active Ycash P2P connection".into(),
            message: "node ready".into(),
            tip_time: 0,
            started_unix: unix_time(),
            api_listening: false,
            rpc_listening: false,
            p2p_listening: false,
            lightwallet_listening: false,
            outbound_attempts: 0,
            outbound_handshakes: 0,
            inbound_connections: 0,
            last_error: String::new(),
            peer_last: Default::default(),
            active_outbound: 0,
            known_peers: 0,
        }
    }
}
impl LiveNodeState {
    pub fn note(&mut self, addr:&str){
        self.peer_last.insert(addr.to_string(),(unix_time(),self.connection_detail.clone()));
        if self.peer_last.len()>40 { if let Some(k)=self.peer_last.iter().min_by_key(|(_,v)|v.0).map(|(k,_)|k.clone()) { self.peer_last.remove(&k); } }
    }
    pub fn sync_text(&self) -> String {
        match self.target_height {
            Some(t) if t > self.local_height =>
                format!("{}%", ((self.local_height.saturating_mul(100))/t).min(100)),
            Some(_) => "100%".into(),
            None => "waiting for headers".into(),
        }
    }
}
pub type SharedState = Arc<RwLock<LiveNodeState>>;
