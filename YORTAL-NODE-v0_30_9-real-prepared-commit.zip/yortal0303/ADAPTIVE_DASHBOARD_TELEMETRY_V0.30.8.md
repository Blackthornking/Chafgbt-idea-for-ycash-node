# v0.30.8 Adaptive Dashboard Telemetry

The Android dashboard now refreshes the adaptive CPU telemetry with the existing live status poll (2 seconds):

- CPU cores: detected by Android `Runtime.getRuntime().availableProcessors()`.
- Reserved for Android: one logical core whenever the device has more than one.
- Max adaptive workers: the native pipeline verifier ceiling, derived from native available parallelism minus one.
- Current adaptive workers: the live pressure-controlled worker budget.

The native verifier ceiling is now strictly device-derived; `YORTAL_VERIFY_THREADS` can no longer lower the all-cores-minus-one ceiling. The adaptive controller can still reduce the **current** worker count under CPU, memory, DB, or validation pressure.

Consensus behaviour is unchanged: these values only control scheduling/concurrency and do not change block or transaction validation rules or ordered commits.
