use sha2::{Digest, Sha256};
use std::io::{Read, Write};
use std::os::unix::fs::PermissionsExt;
use base64::Engine as _;
use std::net::{IpAddr, SocketAddr, TcpListener, TcpStream, ToSocketAddrs};
use std::path::{Path, PathBuf};
use std::sync::{atomic::{AtomicBool, Ordering}, Arc, RwLock};
use std::thread;
use std::time::{Duration, Instant};
use ycash_chain::{genesis_hash_internal, read_block_at_height, read_header_at, BlockHeader, YCASH_FORK_HEIGHT, MAX_HEADERS_RESULTS};
use ycash_consensus::{validate_header, validate_for_commit, Context, block_proof, add_work, minimum_chain_work};
use ycash_network::runtime::{connect_with_timeout, getdata_payload, getheaders_payload, parse_addr_message, unix_time, version_payload};
use ycash_network::{decode_header, encode_message, Hash256, PROTOCOL_VERSION};
use ycash_state::{State,BlockCommit};

mod runtime;
use runtime::{LiveNodeState, SharedState};

struct DoubleSha;
impl Hash256 for DoubleSha { fn hash256(data: &[u8]) -> [u8;32] { let a=Sha256::digest(data); let b=Sha256::digest(a); let mut out=[0u8;32]; out.copy_from_slice(&b); out } }

fn esc(s:&str)->String{s.replace('\\',"\\\\").replace('"',"\\\"")}
fn json(s:&LiveNodeState)->String{let target_height=match s.target_height{Some(t)=>t.to_string(),None=>"null".into()};let uptime_seconds=(unix_time()-s.started_unix).max(0);format!(r#"{{"status":"{}","peers":{},"height":{},"target_height":{},"headers_height":{},"sync":"{}","connection_source":"{}","connection_endpoint":"{}","connection_detail":"{}","message":"{}","tip_time":{},"uptime_seconds":{},"api_listening":{},"rpc_listening":{},"p2p_listening":{},"lightwallet_listening":{},"outbound_attempts":{},"outbound_handshakes":{},"inbound_connections":{},"last_error":"{}","active_outbound":{},"known_peers":{},"blocks_received":{},"blocks_validated":{},"txs_indexed":{},"last_block_bytes":{},"last_block_height":{},"peer_table":"{}"}}"#,if s.running{"running"}else{"stopped"},s.peers,s.local_height,target_height,s.headers_height,esc(&s.sync_text()),esc(&s.connection_source),esc(&s.connection_endpoint),esc(&s.connection_detail),esc(&s.message),s.tip_time,uptime_seconds,s.api_listening,s.rpc_listening,s.p2p_listening,s.lightwallet_listening,s.outbound_attempts,s.outbound_handshakes,s.inbound_connections,esc(&s.last_error),s.active_outbound,s.known_peers,s.blocks_received,s.blocks_validated,s.txs_indexed,s.last_block_bytes,s.last_block_height,esc(&peer_table(s)))}
fn peer_table(s:&LiveNodeState)->String{let mut v:Vec<_>=s.peer_last.iter().collect();v.sort_by_key(|(_,x)|std::cmp::Reverse(x.0));v.iter().take(20).map(|(k,x)|format!("{} - {}",k,x.1)).collect::<Vec<_>>().join(" | ")}
fn serve(mut stream:TcpStream,state:SharedState,db:Arc<State>,export_dir:PathBuf){
    let mut b=[0u8;2048];let _=stream.read(&mut b);let req=String::from_utf8_lossy(&b);
    let line=req.lines().next().unwrap_or("");
    if line.starts_with("GET /export"){
        let _=stream.write_all(&export_response(&db,&export_dir,state.read().unwrap().local_height));
        return;
    }
    let(code,body)=if line.starts_with("GET /status "){("200 OK",json(&state.read().unwrap()))}else{("404 Not Found",r#"{"error":"not found"}"#.into())};
    let r=format!("HTTP/1.1 {code}\r\nContent-Type: application/json\r\nCache-Control: no-store\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",body.len(),body);
    let _=stream.write_all(r.as_bytes());
}
/// Handles GET /export: writes a fresh VACUUM INTO snapshot of the whole chain database (headers,
/// blocks, transactions -- everything downloaded and validated so far) to a temp file, reads it back,
/// and always cleans the temp file up before returning, whether or not the export succeeded.
fn export_response(db:&State,export_dir:&Path,height:u64)->Vec<u8>{
    let tmp=export_dir.join(format!(".ycash-chain-export-{}.sqlite",unix_time()));
    let _=std::fs::remove_file(&tmp);
    let result=db.export_snapshot(&tmp).and_then(|_|Ok(std::fs::read(&tmp)?));
    let _=std::fs::remove_file(&tmp);
    match result{
        Ok(bytes)=>{
            let filename=format!("ycash-chain-height-{}.sqlite",height);
            let header=format!("HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Disposition: attachment; filename=\"{}\"\r\nCache-Control: no-store\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",filename,bytes.len());
            let mut out=header.into_bytes();out.extend_from_slice(&bytes);out
        }
        Err(e)=>{
            let body=format!(r#"{{"error":"export failed: {}"}}"#,esc(&e.to_string()));
            format!("HTTP/1.1 500 Internal Server Error\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",body.len(),body).into_bytes()
        }
    }
}
fn start_api(state:SharedState,db:Arc<State>,export_dir:PathBuf)->std::io::Result<()> {
    let bind=std::env::var("YCASH_STATUS_BIND").unwrap_or_else(|_|"127.0.0.1".into());
    let port=std::env::var("YCASH_STATUS_PORT").ok().and_then(|x|x.parse().ok()).unwrap_or(8834u16);
    let listener=TcpListener::bind((bind.as_str(),port))?;
    { let mut st=state.write().unwrap(); st.api_listening=true; st.message=format!("status API listening on {}:{}",bind,port); }
    thread::spawn(move||for s in listener.incoming(){if let Ok(s)=s{let st=state.clone();let db=db.clone();let dir=export_dir.clone();thread::spawn(move||serve(s,st,db,dir));}});
    Ok(())
}

fn rpc_config(base:&Path)->(String,String) {
    let user=std::env::var("YCASH_RPC_USER").unwrap_or_else(|_|"ycashrpc".into());
    let path=base.join("rpc_credentials.conf");
    if let Ok(text)=std::fs::read_to_string(&path) {
        let mut u=None; let mut p=None;
        for l in text.lines() {
            if let Some(v)=l.strip_prefix("rpcuser="){u=Some(v.trim().to_string());}
            if let Some(v)=l.strip_prefix("rpcpassword="){p=Some(v.trim().to_string());}
        }
        if let (Some(u),Some(p))=(u,p) { return (u,p); }
    }
    let mut bytes=[0u8;32];
    if let Ok(mut f)=std::fs::File::open("/dev/urandom") { let _=std::io::Read::read_exact(&mut f,&mut bytes); }
    let pass=hex::encode(bytes);
    let _=std::fs::write(&path,format!("rpcuser={}\nrpcpassword={}\nrpcport={}\n",user,pass,
        std::env::var("YCASH_RPC_PORT").unwrap_or_else(|_|"8832".into())));
    let _=std::fs::set_permissions(&path,std::fs::Permissions::from_mode(0o600));
    (user,pass)
}

fn http_basic_ok(req:&str,user:&str,pass:&str)->bool {
    let wanted=base64::engine::general_purpose::STANDARD.encode(format!("{}:{}",user,pass));
    req.lines().any(|l|l.trim().eq_ignore_ascii_case(&format!("Authorization: Basic {}",wanted)))
}
fn rpc_response(body:&str)->String {
    format!("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",body.len(),body)
}
fn serve_rpc(mut stream:TcpStream,state:SharedState,user:String,pass:String){
    let mut b=[0u8;16384]; let n=stream.read(&mut b).unwrap_or(0);
    let req=String::from_utf8_lossy(&b[..n]).to_string();
    if !http_basic_ok(&req,&user,&pass) {
        let r="HTTP/1.1 401 Unauthorized\r\nWWW-Authenticate: Basic realm=\"ycashd\"\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
        let _=stream.write_all(r.as_bytes()); return;
    }
    let body=req.split("\r\n\r\n").nth(1).unwrap_or("");
    let method=if body.contains("\"method\":\"getblockchaininfo\""){"getblockchaininfo"}
        else if body.contains("\"method\":\"getnetworkinfo\""){"getnetworkinfo"}
        else if body.contains("\"method\":\"getpeerinfo\""){"getpeerinfo"}
        else {"unknown"};
    let st=state.read().unwrap();
    let result=match method {
        "getblockchaininfo"=>format!(r#"{{"result":{{"chain":"main","blocks":{},"headers":{},"verificationprogress":0.0}},"error":null,"id":1}}"#,st.local_height,st.headers_height),
        "getnetworkinfo"=>format!(r#"{{"result":{{"version":270013,"subversion":"/YcashAndroid:0.19.17/","protocolversion":270013,"connections":{}}},"error":null,"id":1}}"#,st.peers),
        "getpeerinfo"=>r#"{"result":[],"error":null,"id":1}"#.into(),
        _=>r#"{"result":null,"error":{"code":-32601,"message":"method not implemented"},"id":1}"#.into()
    };
    let _=stream.write_all(rpc_response(&result).as_bytes());
}
fn start_rpc(state:SharedState,base:&Path)->std::io::Result<()> {
    let bind=std::env::var("YCASH_RPC_BIND").unwrap_or_else(|_|"127.0.0.1".into());
    let port=std::env::var("YCASH_RPC_PORT").ok().and_then(|x|x.parse().ok()).unwrap_or(8832u16);
    let (user,pass)=rpc_config(base);
    let listener=TcpListener::bind((bind.as_str(),port))?;
    eprintln!("Ycash JSON-RPC listening on {}:{} (credentials: {})",bind,port,base.join("rpc_credentials.conf").display());
    { let mut st=state.write().unwrap(); st.rpc_listening=true; st.message=format!("JSON-RPC listening on {}:{}",bind,port); }
    thread::spawn(move||for s in listener.incoming(){if let Ok(s)=s{let st=state.clone();let u=user.clone();let p=pass.clone();thread::spawn(move||serve_rpc(s,st,u,p));}}); Ok(())
}
fn start_p2p_listener(state:SharedState)->std::io::Result<()> {
    let bind=std::env::var("YCASH_P2P_BIND").unwrap_or_else(|_|"0.0.0.0".into());
    let port=std::env::var("YCASH_P2P_PORT").ok().and_then(|x|x.parse().ok()).unwrap_or(8833u16);
    let listener=TcpListener::bind((bind.as_str(),port))?;
    { let mut st=state.write().unwrap(); st.p2p_listening=true; st.message=format!("P2P listening on {}:{}",bind,port); }
    thread::spawn(move||for incoming in listener.incoming(){if let Ok(mut s)=incoming{
        let st=state.clone(); thread::spawn(move||{
            let peer=s.peer_addr().ok(); let local=s.local_addr().ok();
            let _=s.set_read_timeout(Some(Duration::from_secs(20))); let _=s.set_write_timeout(Some(Duration::from_secs(20)));
            let remote=match peer { Some(x)=>x, None=>return };
            let local_addr=local.unwrap_or_else(||"0.0.0.0:0".parse().unwrap());
            {
                let mut x=st.write().unwrap();
                x.connection_source="Inbound Peer".into();
                x.connection_endpoint=remote.to_string();
                x.connection_detail="TCP accepted; sending version".into();
                x.message=format!("inbound TCP connection accepted: {}",remote);
            }
            let start=st.read().unwrap().local_height.min(i32::MAX as u64) as i32;
            let nonce=unix_time() as u64 ^ std::process::id() as u64 ^ remote.port() as u64;
            let v=version_payload(ycash_network::runtime::NODE_NETWORK,remote,local_addr,nonce,"/YcashAndroid:0.19.17/",start);
            if let Err(e)=send(&mut s,"version",&v) {
                let mut x=st.write().unwrap(); x.connection_detail=format!("inbound VERSION send failed: {}",e); x.last_error=format!("{} VERSION send: {}",remote,e); return;
            }
            let mut got_version=false; let mut got_verack=false;
            let mut peer_height=None;
            for _ in 0..32 {
                match read_message(&mut s) {
                    Ok((cmd,p)) if cmd=="version" => {
                        if got_version { let mut x=st.write().unwrap(); x.connection_detail="duplicate VERSION received".into(); return; }
                        if p.len()<4 { let mut x=st.write().unwrap(); x.connection_detail=format!("invalid VERSION payload: {} bytes",p.len()); return; }
                        let pv=i32::from_le_bytes(p[0..4].try_into().unwrap());
                        peer_height=parse_version_height(&p);
                        if pv<PROTOCOL_VERSION { let mut x=st.write().unwrap(); x.connection_detail=format!("peer protocol {} below required {}",pv,PROTOCOL_VERSION); return; }
                        got_version=true;
                        if let Err(e)=send(&mut s,"verack",&[]) { let mut x=st.write().unwrap(); x.connection_detail=format!("VERACK send failed: {}",e); x.last_error=format!("{} VERACK send: {}",remote,e); return; }
                        let _=send(&mut s,"getaddr",&[]);
                        let mut x=st.write().unwrap();
                        x.target_height=peer_height;
                        x.connection_detail=format!("VERSION received (protocol {}, peer height {:?}); VERACK sent",pv,peer_height);
                    }
                    Ok((cmd,_)) if cmd=="verack" => {
                        got_verack=true;
                        let mut x=st.write().unwrap(); x.connection_detail="VERACK received; inbound handshake complete".into();
                    }
                    Ok((cmd,p)) if cmd=="ping" => { let _=send(&mut s,"pong",&p); }
                    Ok((cmd,p)) if cmd=="addr" => {
                        if let Ok(addrs)=parse_addr_message(&p,1000) { /* inbound path has no peers.dat here */ let mut x=st.write().unwrap(); x.message=format!("inbound handshake received {} peer addresses",addrs.len()); }
                    }
                    Ok((cmd,p)) if cmd=="reject" => { let mut x=st.write().unwrap(); x.connection_detail=format!("peer rejected inbound message: {}",String::from_utf8_lossy(&p)); }
                    Ok((_cmd,_p)) => {}
                    Err(e) => { let mut x=st.write().unwrap(); x.connection_detail=format!("inbound handshake/session failed: {}",describe_io_error(&e)); x.last_error=format!("{} inbound: {}",remote,e); return; }
                }
                if got_version && got_verack { break; }
            }
            if !(got_version && got_verack) { let mut x=st.write().unwrap(); x.connection_detail=format!("inbound handshake incomplete (version={}, verack={})",got_version,got_verack); return; }
            {
                let mut x=st.write().unwrap();
                x.peers=x.peers.saturating_add(1); x.inbound_connections=x.inbound_connections.saturating_add(1);
                x.connection_source="Inbound Peer".into(); x.connection_endpoint=remote.to_string();
                x.connection_detail=format!("Ycash P2P handshake PASS: {}",remote);
                x.message=format!("inbound peer ready: {} (height {:?})",remote,peer_height);
            }
            loop {
                match read_message(&mut s) {
                    Ok((cmd,p)) if cmd=="ping" => { if send(&mut s,"pong",&p).is_err(){break;} }
                    Ok((cmd,_)) if cmd=="verack" || cmd=="version" => {}
                    Ok((_cmd,_p)) => {}
                    Err(e) => { let mut x=st.write().unwrap(); x.connection_detail=format!("inbound peer {} disconnected: {}",remote,describe_io_error(&e)); break; }
                }
            }
            let mut x=st.write().unwrap(); x.peers=x.peers.saturating_sub(1);
        });
    }}); Ok(())
}

fn describe_io_error(e:&std::io::Error)->String{match e.kind(){std::io::ErrorKind::UnexpectedEof=>"EOF while reading a complete Ycash P2P message (peer closed mid-frame)".into(),std::io::ErrorKind::WouldBlock=>"timed out: peer sent nothing (Android reports read timeout as EAGAIN)".into(),std::io::ErrorKind::TimedOut=>"read timeout waiting for a complete P2P message".into(),std::io::ErrorKind::ConnectionReset=>"connection reset by peer".into(),std::io::ErrorKind::ConnectionAborted=>"connection aborted".into(),std::io::ErrorKind::BrokenPipe=>"broken pipe".into(),_=>format!("{} ({:?})",e,e.kind())}}
fn is_timeout(e:&std::io::Error)->bool{matches!(e.kind(),std::io::ErrorKind::WouldBlock|std::io::ErrorKind::TimedOut)}
fn read_message(stream:&mut TcpStream)->std::io::Result<(String,Vec<u8>)>{
    let mut h=[0u8;24];
    // Wait for the first byte with the socket's normal (short) timeout. A timeout here means the
    // peer is idle and nothing was consumed. Once a message has started, finish it with a long
    // timeout: a short timeout mid-frame (large addr/headers/block messages on mobile data) used to
    // discard half a message, desync the stream and drop the peer.
    loop{match stream.read(&mut h[..1]){Ok(0)=>return Err(std::io::Error::new(std::io::ErrorKind::UnexpectedEof,"peer closed")),Ok(_)=>break,Err(e) if e.kind()==std::io::ErrorKind::Interrupted=>continue,Err(e)=>return Err(e)}}
    let prev=stream.read_timeout().ok().flatten();
    let _=stream.set_read_timeout(Some(Duration::from_secs(120)));
    let r=(||->std::io::Result<(String,Vec<u8>)>{
    stream.read_exact(&mut h[1..])?;
    let(cmd,len,checksum)=decode_header::<DoubleSha>(&h)?;
    if len as usize>2*1024*1024{return Err(std::io::Error::new(std::io::ErrorKind::InvalidData,"message exceeds Ycash 2 MiB limit"))}
    let mut p=vec![0u8;len as usize];
    stream.read_exact(&mut p)?;
    if DoubleSha::hash256(&p)[..4]!=checksum{return Err(std::io::Error::new(std::io::ErrorKind::InvalidData,format!("{} checksum mismatch",cmd)))}
    Ok((cmd,p))
    })();
    let _=stream.set_read_timeout(prev);
    r
}
fn send(stream:&mut TcpStream,cmd:&str,payload:&[u8])->std::io::Result<()>{stream.write_all(&encode_message::<DoubleSha>(cmd,payload)?)}

#[derive(Clone,Debug)]struct PeerCandidate{addr:SocketAddr,source:String}
#[derive(Clone,Debug)]struct PeerRecord{addr:SocketAddr,last_seen:u64,attempts:u32,tried:bool}
fn load_peer_records(path:&Path)->Vec<PeerRecord>{std::fs::read_to_string(path).ok().map(|s|s.lines().filter_map(|l|{let f:Vec<_>=l.split('\t').collect();if f.len()>=4{Some(PeerRecord{addr:f[0].parse().ok()?,last_seen:f[1].parse().unwrap_or(0),attempts:f[2].parse().unwrap_or(0),tried:f[3]=="1"})}else{Some(PeerRecord{addr:l.parse().ok()?,last_seen:0,attempts:0,tried:false})}}).collect()).unwrap_or_default()}
fn save_peer_records(path:&Path,records:&[PeerRecord]){let body=records.iter().take(512).map(|r|format!("{}\t{}\t{}\t{}",r.addr,r.last_seen,r.attempts,if r.tried{"1"}else{"0"})).collect::<Vec<_>>().join("\n");let _=std::fs::write(path,body);}
fn routable(a:&SocketAddr)->bool{if a.port()==0{return false}match a.ip(){IpAddr::V4(v)=>{let o=v.octets();!(v.is_private()||v.is_loopback()||v.is_link_local()||v.is_unspecified()||v.is_broadcast()||v.is_documentation()||(o[0]==100&&(o[1]&0xc0)==64))},IpAddr::V6(v)=>{let o=v.segments();!(v.is_loopback()||v.is_unspecified()||(o[0]&0xfe00)==0xfc00||(o[0]&0xffc0)==0xfe80)}}}
fn learn_peers(path:&Path,addrs:&[SocketAddr])->usize{let _g=PEERS_LOCK.lock().unwrap_or_else(|e|e.into_inner());let mut v=load_peer_records(path);let mut added=0;for a in addrs{if !routable(a){continue}if !v.iter().any(|r|r.addr==*a){v.push(PeerRecord{addr:*a,last_seen:0,attempts:0,tried:false});added+=1;}}v.sort_by_key(|r|std::cmp::Reverse((r.tried,r.last_seen)));save_peer_records(path,&v);added}
static PEERS_LOCK:std::sync::Mutex<()>=std::sync::Mutex::new(());
static PEER_FILE:std::sync::OnceLock<PathBuf>=std::sync::OnceLock::new();
/// ycashd answers our getaddr a moment after the handshake, i.e. while this peer is already inside
/// header/block sync. Those loops used to discard every non-sync message, so the address list was lost
/// and the node never learned any other peers to connect to.
fn learn_from_addr_payload(p:&[u8]){if let (Some(pf),Ok(addrs))=(PEER_FILE.get(),parse_addr_message(p,1000)){let n=learn_peers(pf,&addrs);if n>0{eprintln!("learned {} new peer addresses during sync",n);}}}
fn save_peer(path:&Path,addr:SocketAddr){let _g=PEERS_LOCK.lock().unwrap_or_else(|e|e.into_inner());let mut v=load_peer_records(path);if let Some(r)=v.iter_mut().find(|r|r.addr==addr){r.last_seen=unix_time() as u64;r.tried=true;}else{v.push(PeerRecord{addr,last_seen:unix_time() as u64,attempts:0,tried:true});}v.sort_by_key(|r|std::cmp::Reverse((r.tried,r.last_seen)));save_peer_records(path,&v)}
fn ban_peer(base:&Path,addr:SocketAddr){let p=base.join("banlist.dat");let mut v=std::fs::read_to_string(&p).unwrap_or_default();if !v.lines().any(|x|x.trim()==addr.to_string()){v.push_str(&format!("{}\t{}\n",addr,unix_time()+24*60*60));let _=std::fs::write(p,v);}}
fn is_banned(base:&Path,addr:SocketAddr)->bool{let p=base.join("banlist.dat");let now=unix_time();std::fs::read_to_string(p).ok().map(|s|s.lines().any(|l|{let f:Vec<_>=l.split('\t').collect();f.len()>=2&&f[0]==addr.to_string()&&f[1].parse::<i64>().unwrap_or(0)>now})).unwrap_or(false)}

fn mark_peer_attempt(path:&Path,addr:SocketAddr){let _g=PEERS_LOCK.lock().unwrap_or_else(|e|e.into_inner());let mut v=load_peer_records(path);if let Some(r)=v.iter_mut().find(|r|r.addr==addr){r.attempts=r.attempts.saturating_add(1);}else{v.push(PeerRecord{addr,last_seen:0,attempts:1,tried:false});}save_peer_records(path,&v)}

fn parse_version_height(version:&[u8])->Option<u64>{let mut i=4+8+8+26+26+8;let b=*version.get(i)?;let n=match b{0..=252=>{i+=1;b as usize},253=>{let x=version.get(i+1..i+3)?;i+=3;u16::from_le_bytes([x[0],x[1]]) as usize},254=>{let x=version.get(i+1..i+5)?;i+=5;u32::from_le_bytes(x.try_into().ok()?) as usize},255=>{let x=version.get(i+1..i+9)?;i+=9;u64::from_le_bytes(x.try_into().ok()?) as usize}};i=i.checked_add(n)?;if version.len()<i+4{return None}Some(i32::from_le_bytes(version[i..i+4].try_into().ok()?).max(0) as u64)}

fn header_from_raw(raw:&[u8],height:u64)->std::io::Result<BlockHeader>{let mut c=std::io::Cursor::new(raw);read_header_at(&mut c,height).map_err(|e|std::io::Error::new(std::io::ErrorKind::InvalidData,e.to_string()))}
fn mtp(state:&State,height:u64)->u32{let start=height.saturating_sub(11);let mut times=Vec::new();for h in start..height{if h==0{times.push(ycash_consensus::GENESIS_TIME);continue;}if let Ok(Some(raw))=state.header_by_height(h){if let Ok(x)=header_from_raw(&raw,h){times.push(x.time);}}}if times.is_empty(){0}else{times.sort_unstable();times[times.len()/2]}}

fn load_header_history(state:&State, next_height:u64)->std::io::Result<(u64,Vec<BlockHeader>)>{
    if next_height<=1{return Ok((1,Vec::new()));}
    let end=next_height-1;
    // 17-block window + 11-block median for pindexFirst = 28 headers, including genesis when needed.
    let start=end.saturating_sub(27);
    let mut out=Vec::new();
    for h in start..=end{
        if h==0{out.push(BlockHeader{version:4,prev:[0;32],merkle:[0;32],light_client_root:[0;32],time:ycash_consensus::GENESIS_TIME,bits:ycash_consensus::GENESIS_BITS,nonce:[0;32],solution:Vec::new()});continue;}
        let raw=state.header_by_height(h).map_err(|e|ioe(&e.to_string()))?.ok_or_else(||ioe(&format!("missing header {h}")))?;
        out.push(header_from_raw(&raw,h)?);
    }
    Ok((start,out))
}

fn parse_headers(payload:&[u8],start_height:u64)->std::io::Result<Vec<(u64,BlockHeader,Vec<u8>)>>{
    let mut i=0usize;let count=ycash_network::runtime::read_compact_size(payload,&mut i).map_err(|e|e)? as usize;if count>MAX_HEADERS_RESULTS{return Err(std::io::Error::new(std::io::ErrorKind::InvalidData,"too many headers"))}let mut out=Vec::with_capacity(count);for n in 0..count{let height=start_height+n as u64;let begin=i;let slice=&payload[i..];let mut c=std::io::Cursor::new(slice);let h=read_header_at(&mut c,height).map_err(|e|std::io::Error::new(std::io::ErrorKind::InvalidData,e.to_string()))?;i+=c.position() as usize;let _tx_count=ycash_network::runtime::read_compact_size(payload,&mut i).map_err(|e|e)?;out.push((height,h,payload[begin..i].to_vec()));}Ok(out)}

fn sync_headers(stream:&mut TcpStream,state:Arc<State>,live:&SharedState,source:&str,endpoint:&str)->std::io::Result<u64>{
    let mut next=state.header_height().map_err(|e| ioe(&e.to_string()))?.unwrap_or(0)+1;
    loop{
        let locator=state.locator_hashes().map_err(|e| ioe(&e.to_string()))?;let stop=[0u8;32];send(stream,"getheaders",&getheaders_payload(&locator,&stop))?;
        // Previously every unrelated message (addr, inv, ping...) looped back and re-sent getheaders,
        // flooding the peer. Now: send once, then read until "headers", resending only after idle timeouts.
        let mut idle=0u32;
        let payload=loop{match read_message(stream){
            Ok((cmd,p)) if cmd=="headers"=>break p,
            Ok((cmd,p)) if cmd=="ping"=>{send(stream,"pong",&p)?;}
            Ok((cmd,p)) if cmd=="reject"=>return Err(std::io::Error::new(std::io::ErrorKind::ConnectionAborted,format!("peer rejected getheaders: {}",String::from_utf8_lossy(&p)))),
            Ok((cmd,p)) if cmd=="addr"=>{learn_from_addr_payload(&p);}
            Ok(_)=>{}
            Err(e) if is_timeout(&e)=>{idle+=1;if idle>=6{return Err(std::io::Error::new(std::io::ErrorKind::TimedOut,"peer did not answer getheaders"))}if idle%2==0{send(stream,"getheaders",&getheaders_payload(&locator,&stop))?;}}
            Err(e)=>return Err(e),
        }};
        // Peer answers from the fork point it found in our locator, not necessarily our tip.
        // Derive the start height from the first header's prev hash (ycashd does this via mapBlockIndex).
        let mut pi=0usize;let n_hdr=ycash_network::runtime::read_compact_size(&payload,&mut pi).unwrap_or(0);if n_hdr==0{break;}
        if payload.len()<pi+36{return Err(ioe("headers message truncated"));}
        let mut first_prev=[0u8;32];first_prev.copy_from_slice(&payload[pi+4..pi+36]);
        next=if first_prev==genesis_hash_internal(){1}else{match state.header_height_by_hash(&first_prev).map_err(|e|ioe(&e.to_string()))?{Some(h)=>h+1,None=>return Err(ioe("headers do not connect to our chain (unknown prev hash)"))}};
        let batch=parse_headers(&payload,next)?;if batch.is_empty(){break;}
        for (height,h,raw) in batch.iter(){
            let prev_hash=if *height==1{genesis_hash_internal()}else{state.header_hash_by_height(height-1).map_err(|e| ioe(&e.to_string()))?.ok_or_else(||ioe("missing previous header"))?.try_into().unwrap()};
            if h.prev!=prev_hash{return Err(ioe("header chain discontinuity"));}
            let mtp_time=mtp(&state,*height);if *height>1{let prev_raw=state.header_by_height(height-1).map_err(|e| ioe(&e.to_string()))?.ok_or_else(||ioe("missing previous header"))?;let prev=header_from_raw(&prev_raw,height-1)?;let (hist_start,hist)=load_header_history(&state,*height)?;validate_header(h,*height,&prev,mtp_time,hist_start,&hist).map_err(|e|ioe(&format!("header validation failed at {height}: {e:?}")))?;}else{if h.bits!=ycash_consensus::GENESIS_BITS{return Err(ioe("header validation failed at 1: nBits must be powLimit"));}if h.time<=ycash_consensus::GENESIS_TIME{return Err(ioe("header validation failed at 1: time-too-old"));}ycash_consensus::check_pow(h,*height).map_err(|e|ioe(&format!("genesis successor PoW invalid: {e:?}")))?;}
            let hash=h.hash();let proof=block_proof(h.bits).map_err(|e|ioe(&format!("work calculation failed: {e:?}")))?;let prev_work=if *height<=1{[0u8;32]}else{let w=state.header_work_by_height(height-1).map_err(|e|ioe(&e.to_string()))?.ok_or_else(||ioe("missing previous chain work"))?;w.try_into().map_err(|_|ioe("invalid previous chain work"))?};let chain_work=add_work(&prev_work,&proof);state.put_header(*height,&hash,&h.prev,h.time,h.bits,&chain_work,&h.serialize()).map_err(|e| ioe(&e.to_string()))?;
            let mut ls=live.write().unwrap();ls.headers_height=*height;ls.connection_source=source.into();ls.connection_endpoint=endpoint.into();ls.connection_detail=format!("validated Ycash header {} (Equihash {})",height,if *height>=YCASH_FORK_HEIGHT{"192,7"}else{"200,9"});ls.message=format!("header sync: height {}",height);
        }
        next+=batch.len() as u64;if batch.len()<MAX_HEADERS_RESULTS{break;}
    }
    let tip=next.saturating_sub(1);if let Some(w)=state.header_work_by_height(tip).map_err(|e|ioe(&e.to_string()))?{if w.len()==32{let mut x=[0u8;32];x.copy_from_slice(&w);if x.iter().cmp(minimum_chain_work().iter()).is_lt(){let mut ls=live.write().unwrap();ls.message=format!("header tip {tip} below Ycash minimum chain work");}}}Ok(tip)
}

fn download_blocks(stream:&mut TcpStream,state:Arc<State>,live:&SharedState,target:u64)->std::io::Result<()> {
    let mut h=state.tip_height().map_err(|e|ioe(&e.to_string()))?.unwrap_or(0)+1;
    while h<=target {
        let end=(h+15).min(target);
        let mut requests=Vec::new();
        for x in h..=end { if let Some(raw)=state.header_by_height(x).map_err(|e|ioe(&e.to_string()))? { requests.push((x,header_from_raw(&raw,x)?.hash())); } }
        if requests.is_empty(){break;}
        let hashes:Vec<[u8;32]>=requests.iter().map(|(_,x)|*x).collect();
        send(stream,"getdata",&getdata_payload(&hashes))?;
        let mut completed=0usize;
        let mut done=std::collections::HashSet::<u64>::new();
        let mut pending_commits:Vec<BlockCommit>=Vec::with_capacity(requests.len());
        let mut blk_idle=0u32;
        while completed<requests.len(){
            let(cmd,payload)=match read_message(stream){Ok(x)=>x,Err(e) if is_timeout(&e)=>{blk_idle+=1;if blk_idle>=8{return Err(std::io::Error::new(std::io::ErrorKind::TimedOut,"peer stopped sending blocks"))}continue},Err(e)=>return Err(e)};
            blk_idle=0;
            match cmd.as_str(){
                "block"=>{
                    let mut matched=None;
                    for (height,expected) in &requests{
                        if !done.contains(height){
                            // A block response does not carry its height. Near the Ycash fork
                            // boundary the Equihash solution length changes, so a wrong candidate
                            // height can fail header decoding even though the payload itself is valid.
                            // Treat that as a non-match and try the remaining requested heights.
                            if let Ok(candidate)=read_block_at_height(&payload,*height){
                                if candidate.header.hash()==*expected{matched=Some((*height,candidate));break;}
                            }
                        }
                    }
                    let (height,block)=matched.ok_or_else(||ioe("received block is not one of the requested headers"))?;
                    let expected=requests.iter().find(|(x,_)|*x==height).map(|(_,h)|*h).unwrap();
                    let prev=if height==1{None}else{state.header_by_height(height-1).map_err(|e|ioe(&e.to_string()))?.map(|r|header_from_raw(&r,height-1)).transpose()?};
                    let prev_height=height.saturating_sub(1);
                    let mtp_time=mtp(&state,height);
                    let ctx=Context{height,prev_height,median_time_past:mtp_time};
                    if let Some(prev_header)=prev.as_ref(){if block.header.prev!=prev_header.hash(){return Err(ioe("block previous hash does not match stored header"));}}else if block.header.prev!=genesis_hash_internal(){return Err(ioe("first block does not point to Ycash genesis"));}
                    let validated=validate_for_commit(&payload,ctx).map_err(|e|ioe(&format!("block validation failed at {height}: {e:?}")))?;
                    if validated.txs.is_empty(){return Err(ioe("consensus decoder returned zero transactions"));}
                    let work=state.header_work_by_height(height).map_err(|e|ioe(&e.to_string()))?.ok_or_else(||ioe("missing header chain work"))?;
                    let txs:Vec<([u8;32],Vec<u8>)>=validated.txs.iter().map(|t|(ycash_chain::txid(t),t.clone())).collect();
                    let prev_arr:[u8;32]=block.header.prev;
                    let work_arr:[u8;32]=work.try_into().map_err(|_|ioe("invalid chain work"))?;
                    pending_commits.push(BlockCommit{height,hash:expected,prev:prev_arr,work:work_arr,raw:payload.clone(),txs:txs.clone()});
                    done.insert(height);completed+=1;
                    {let mut ls=live.write().unwrap();ls.blocks_received=ls.blocks_received.saturating_add(1);ls.blocks_validated=ls.blocks_validated.saturating_add(1);ls.txs_indexed=ls.txs_indexed.saturating_add(txs.len() as u64);ls.last_block_bytes=payload.len() as u64;ls.last_block_height=height;ls.connection_detail=format!("validated block {} ({} tx); batch {}/{}",height,txs.len(),completed,requests.len());ls.message=format!("validation pipeline: block {} (batch {}/{})",height,completed,requests.len());}
                },
                "ping"=>{send(stream,"pong",&payload)?;},
                "reject"=>return Err(ioe("peer rejected block request")),
                "addr"=>{learn_from_addr_payload(&payload);},
                _=>{}
            }
        }
        // Commit the fully validated batch in height order in one SQLite transaction.
        // Network receive + consensus validation can stay pipelined while database writes are amortised.
        pending_commits.sort_by_key(|b| b.height);
        state.commit_blocks_batch(&pending_commits).map_err(|e|ioe(&e.to_string()))?;
        for b in &pending_commits {
            if let Some(raw)=state.header_by_height(b.height).map_err(|e|ioe(&e.to_string()))? {
                let bh=header_from_raw(&raw,b.height)?;
                let mut ls=live.write().unwrap();
                ls.local_height=b.height; ls.tip_time=bh.time;
            }
        }
        h=end+1;
    }
    Ok(())
}
fn inv_has_block(payload:&[u8])->bool{let mut i=0usize;let count=match ycash_network::runtime::read_compact_size(payload,&mut i){Ok(x)=>x as usize,Err(_)=>return false};if count>50000{return false}for _ in 0..count{if i+36>payload.len(){return false}let kind=u32::from_le_bytes(payload[i..i+4].try_into().unwrap());if kind==2{return true}i+=36;}false}

fn ioe(s:&str)->std::io::Error{std::io::Error::new(std::io::ErrorKind::InvalidData,s.to_string())}

fn peer_session(candidate:PeerCandidate,live:SharedState,peer_file:PathBuf,db:Arc<State>,sync_owner:Arc<AtomicBool>)->bool{
    let addr=candidate.addr; let source=candidate.source.clone(); if !source.starts_with("Fixed Seed"){mark_peer_attempt(&peer_file,addr);}
    { let mut st=live.write().unwrap(); st.outbound_attempts=st.outbound_attempts.saturating_add(1); st.connection_source=source.clone(); st.connection_endpoint=addr.to_string(); st.connection_detail="TCP CONNECT: starting".into();st.note(&addr.to_string()); st.message=format!("connecting to {} via {}",addr,source); }
    let mut s=match connect_with_timeout(addr,Duration::from_secs(8)){Ok(x)=>{let mut st=live.write().unwrap();st.connection_detail="TCP CONNECT: PASS".into();st.note(&addr.to_string());x},Err(e)=>{let mut st=live.write().unwrap();st.connection_detail=format!("TCP CONNECT: FAIL — {}",describe_io_error(&e));st.note(&addr.to_string());st.last_error=format!("{} TCP: {}",addr,e);return false;}};
    let start_height=db.header_height().ok().flatten().unwrap_or(0).min(i32::MAX as u64) as i32;
    let local="0.0.0.0:0".parse().unwrap();
    let nonce=unix_time() as u64 ^ std::process::id() as u64 ^ addr.port() as u64;
    if let Err(e)=send(&mut s,"version",&version_payload(ycash_network::runtime::NODE_NETWORK,addr,local,nonce,"/YcashAndroid:0.19.17/",start_height)){let mut st=live.write().unwrap();st.connection_detail=format!("VERSION SEND: FAIL — {}",describe_io_error(&e));st.note(&addr.to_string());st.last_error=format!("{} VERSION send: {}",addr,e);return false;}
    {let mut st=live.write().unwrap();st.connection_detail="VERSION SEND: PASS; waiting for peer VERSION/VERACK".into();st.note(&addr.to_string());}
    let mut got_v=false; let mut got_a=false; let mut peer_height=None;
    for _ in 0..64 {
        match read_message(&mut s) {
            Ok((cmd,p)) if cmd=="version" => {
                if got_v {let mut st=live.write().unwrap();st.connection_detail="HANDSHAKE FAIL: duplicate VERSION".into();st.note(&addr.to_string());return false;}
                if p.len()<4 {let mut st=live.write().unwrap();st.connection_detail=format!("HANDSHAKE FAIL: VERSION payload too short ({} bytes)",p.len());st.note(&addr.to_string());return false;}
                let peer_proto=i32::from_le_bytes(p[0..4].try_into().unwrap());
                if peer_proto<PROTOCOL_VERSION {let mut st=live.write().unwrap();st.connection_detail=format!("HANDSHAKE FAIL: peer protocol {} < {}",peer_proto,PROTOCOL_VERSION);st.note(&addr.to_string());return false;}
                got_v=true; peer_height=parse_version_height(&p);
                if let Err(e)=send(&mut s,"verack",&[]){let mut st=live.write().unwrap();st.connection_detail=format!("VERACK SEND: FAIL — {}",describe_io_error(&e));st.note(&addr.to_string());st.last_error=format!("{} VERACK send: {}",addr,e);return false;}
                let _=send(&mut s,"getaddr",&[]);
                let mut st=live.write().unwrap();st.target_height=peer_height;st.connection_detail=format!("VERSION RECV: PASS (protocol {}, peer height {:?}); VERACK SEND: PASS",peer_proto,peer_height);st.note(&addr.to_string());
            }
            Ok((cmd,_)) if cmd=="verack" => {got_a=true;let mut st=live.write().unwrap();st.connection_detail="VERACK RECV: PASS".into();st.note(&addr.to_string());}
            Ok((cmd,p)) if cmd=="ping" => {let _=send(&mut s,"pong",&p);}
            Ok((cmd,p)) if cmd=="addr" => {if let Ok(addrs)=parse_addr_message(&p,1000){let _=learn_peers(&peer_file,&addrs);let mut st=live.write().unwrap();st.message=format!("received {} addresses from {}",addrs.len(),addr);}}
            Ok((cmd,p)) if cmd=="reject" => {let mut st=live.write().unwrap();st.connection_detail=format!("PEER REJECT: {}",String::from_utf8_lossy(&p));st.note(&addr.to_string());}
            Ok((cmd,_)) => {let mut st=live.write().unwrap();st.connection_detail=format!("HANDSHAKE: received {}",cmd);st.note(&addr.to_string());}
            Err(e) => {let mut st=live.write().unwrap();st.connection_detail=format!("HANDSHAKE/SESSION FAIL: {}",describe_io_error(&e));st.note(&addr.to_string());st.last_error=format!("{} handshake: {}",addr,e);return false;}
        }
        if got_v&&got_a {break;}
    }
    if !(got_v&&got_a){let mut st=live.write().unwrap();st.connection_detail=format!("HANDSHAKE INCOMPLETE: version={}, verack={}",got_v,got_a);st.note(&addr.to_string());return false;}
    save_peer(&peer_file,addr);
    {let mut st=live.write().unwrap();st.peers=st.peers.saturating_add(1);st.outbound_handshakes=st.outbound_handshakes.saturating_add(1);st.connection_source=source.clone();st.connection_endpoint=addr.to_string();st.connection_detail="P2P HANDSHAKE PASS: VERSION + VERACK".into();st.note(&addr.to_string());st.message=format!("outbound peer ready: {}",addr);}
    if sync_owner.compare_exchange(false,true,Ordering::AcqRel,Ordering::Acquire).is_ok(){
        let result=sync_headers(&mut s,db.clone(),&live,&source,&addr.to_string()).and_then(|tip|{let peer_tip=peer_height.unwrap_or(tip);download_blocks(&mut s,db.clone(),&live,peer_tip).map(|_|())});
        sync_owner.store(false,Ordering::Release);
        if let Err(e)=result{let detail=e.to_string();if detail.contains("invalid Equihash")||detail.contains("header hash above target")||detail.contains("wrong Equihash solution length"){if let Some(base)=peer_file.parent(){ban_peer(base,addr);}}let mut st=live.write().unwrap();st.connection_detail=format!("SYNC FAIL: {}",detail);st.note(&addr.to_string());st.message=format!("sync peer {} dropped: {}",addr,detail);st.last_error=format!("{} sync: {}",addr,detail);}
    }
    let _=s.set_read_timeout(Some(Duration::from_secs(5)));let _=s.set_write_timeout(Some(Duration::from_secs(30)));
    let mut last_ping_sent=Instant::now(); let mut ping_deadline:Option<Instant>=None; let mut ping_nonce=unix_time() as u64 ^ addr.port() as u64;
    loop{match read_message(&mut s){
        Ok((cmd,p)) if cmd=="ping"=>{if send(&mut s,"pong",&p).is_err(){break}},
        Ok((cmd,p)) if cmd=="pong"=>{ping_deadline=None;let _=p;let mut st=live.write().unwrap();st.connection_detail="P2P SESSION: alive".into();st.note(&addr.to_string());},
        Ok((cmd,p)) if cmd=="addr"=>{if let Ok(addrs)=parse_addr_message(&p,1000){let _=learn_peers(&peer_file,&addrs);}},
        Ok((cmd,p)) if cmd=="inv"=>{if inv_has_block(&p)&&sync_owner.compare_exchange(false,true,Ordering::AcqRel,Ordering::Acquire).is_ok(){let result=sync_headers(&mut s,db.clone(),&live,&source,&addr.to_string()).and_then(|tip|download_blocks(&mut s,db.clone(),&live,peer_height.unwrap_or(tip)).map(|_|()));sync_owner.store(false,Ordering::Release);if let Err(e)=result{let mut st=live.write().unwrap();st.message=format!("live chain update failed: {}",e);}}},
        Ok((cmd,p)) if cmd=="reject"=>{let mut st=live.write().unwrap();st.message=format!("peer reject: {}",String::from_utf8_lossy(&p));},
        Ok((cmd,_))=>{let mut st=live.write().unwrap();st.connection_detail=format!("P2P SESSION: received {}",cmd);st.note(&addr.to_string());},
        Err(e) if is_timeout(&e)=>{if let Some(deadline)=ping_deadline{if deadline.elapsed()>=Duration::from_secs(30){let mut st=live.write().unwrap();st.connection_detail="P2P SESSION FAIL: ping timeout".into();st.note(&addr.to_string());break}}if ping_deadline.is_none()&&last_ping_sent.elapsed()>=Duration::from_secs(120){ping_nonce=ping_nonce.wrapping_add(1);if send(&mut s,"ping",&ping_nonce.to_le_bytes()).is_err(){break}last_ping_sent=Instant::now();ping_deadline=Some(Instant::now());}},
        Err(e)=>{let mut st=live.write().unwrap();st.connection_detail=format!("P2P SESSION END: {}",describe_io_error(&e));st.note(&addr.to_string());break;}
    }}
    let mut st=live.write().unwrap();st.peers=st.peers.saturating_sub(1);false
}

fn peer_candidates(peer_file:&Path)->Vec<PeerCandidate>{
    // Ycash 4.5.0 defines seed.ycash.xyz as the mainnet DNS seed and the two
    // historical fixed seeds below. Prefer DNS discovery and successful peers;
    // keep fixed seeds as an opt-in diagnostic fallback so dead historical
    // addresses cannot starve discovery.
    let mut out=Vec::new();
    if let Ok(v)=std::env::var("YCASH_PEER"){for x in v.split([',',';']).map(str::trim).filter(|x|!x.is_empty()){if let Ok(a)=x.to_socket_addrs(){for addr in a{out.push(PeerCandidate{addr,source:"Manual Peer".into()})}}}}
    if let Ok(v)=std::env::var("YCASH_AUTO_PEER"){for x in v.split([',',';']).map(str::trim).filter(|x|!x.is_empty()){if let Ok(addr)=x.parse::<SocketAddr>(){out.push(PeerCandidate{addr,source:"Auto-discovered".into()})}}}
    match "seed.ycash.xyz:8833".to_socket_addrs(){Ok(a)=>{for addr in a{out.push(PeerCandidate{addr,source:"DNS Seed (seed.ycash.xyz)".into()})}},Err(e)=>{eprintln!("DNS seed seed.ycash.xyz failed: {e}");}}
    let mut peers=load_peer_records(peer_file); peers.sort_by_key(|p|std::cmp::Reverse((p.tried,p.last_seen))); for p in peers{out.push(PeerCandidate{addr:p.addr,source:"peers.dat".into()});}
    // ycashd 4.5.0 falls back to vFixedSeeds (chainparamsseeds.h) when DNS gives nothing.
    // Always keep them at the END of the list so DNS/peers.dat are preferred, but discovery
    // can never be left with zero candidates. Set YCASH_NO_FIXED_SEEDS=1 to disable.
    if std::env::var("YCASH_NO_FIXED_SEEDS").ok().as_deref()!=Some("1"){
        for(label,s)in [("Fixed Seed #1","3.130.144.65:8833"),("Fixed Seed #2","13.126.58.237:8833")]{if let Ok(addr)=s.parse::<SocketAddr>(){out.push(PeerCandidate{addr,source:format!("{} (fallback)",label)})}}
    }
    let base=peer_file.parent().unwrap_or(Path::new("."));let mut unique=Vec::new();for c in out{if is_banned(base,c.addr){continue}if !unique.iter().any(|x:&PeerCandidate|x.addr==c.addr){unique.push(c)}}unique
}
fn peer_supervisor(live:SharedState,db:Arc<State>){
    let base=std::env::var("YCASH_DATA_DIR").map(PathBuf::from).unwrap_or_else(|_|std::env::var("YCASH_NODE_DB").ok().and_then(|p|Path::new(&p).parent().map(Path::to_path_buf)).unwrap_or_else(||std::env::temp_dir().join("ycash-android-node")));
    let _=std::fs::create_dir_all(&base);let peer_file=base.join("peers.dat");let _=PEER_FILE.set(peer_file.clone());let sync_owner=Arc::new(AtomicBool::new(false));
    // ycashd-compatible peer management is retained, while YORTAL allows up to 12 outbound connections for faster peer redundancy. The old supervisor ran
    // one session at a time, so the peer count could never stay above 1. Each session now runs in
    // its own thread; one peer owns header/block sync at a time (sync_owner).
    const MAX_OUTBOUND:usize=12;
    let active=Arc::new(std::sync::Mutex::new(std::collections::HashSet::<SocketAddr>::new()));
    let mut retry_after=std::collections::HashMap::<SocketAddr,Instant>::new();
    loop{
        let candidates=peer_candidates(&peer_file);
        if candidates.is_empty(){let mut st=live.write().unwrap();st.connection_source="DNS Seed".into();st.connection_endpoint="seed.ycash.xyz:8833".into();st.connection_detail="peer discovery: no candidates (DNS failed, peers.dat empty, fixed seeds disabled or banned); retrying".into();drop(st);thread::sleep(Duration::from_secs(5));continue;}
        {let known=load_peer_records(&peer_file).len() as u32;let act=active.lock().unwrap().len() as u32;let mut st=live.write().unwrap();st.known_peers=known;st.active_outbound=act;}
        for c in candidates{
            if active.lock().unwrap().len()>=MAX_OUTBOUND{break}
            if active.lock().unwrap().contains(&c.addr){continue}
            if let Some(t)=retry_after.get(&c.addr){if Instant::now()<*t{continue}}
            // back off 5 minutes before retrying the same address, so dead peers aren't hammered
            retry_after.insert(c.addr,Instant::now()+Duration::from_secs(300));
            active.lock().unwrap().insert(c.addr);
            let (l,pf,d,so,act)=(live.clone(),peer_file.clone(),db.clone(),sync_owner.clone(),active.clone());
            thread::spawn(move||{let addr=c.addr;let _=peer_session(c,l,pf,d,so);act.lock().unwrap().remove(&addr);});
            thread::sleep(Duration::from_millis(300));
        }
        thread::sleep(Duration::from_secs(5));
    }
}


pub mod walletrpc { tonic::include_proto!("cash.z.wallet.sdk.rpc"); }

use walletrpc::compact_tx_streamer_server::{CompactTxStreamer, CompactTxStreamerServer};
use walletrpc::{BlockId, BlockRange, ChainSpec, CompactBlock, Empty, LightdInfo};
use tonic::{Request, Response, Status};
use tonic::transport::Server;
use std::pin::Pin;
use tokio_stream::Stream;
use tokio_stream::wrappers::ReceiverStream;

#[derive(Clone)]
struct LightwalletService { db: Arc<State> }

fn compact_block_from_header(raw: Vec<u8>, height: u64) -> Result<CompactBlock, Status> {
    let header = read_header_at(&mut std::io::Cursor::new(raw.as_slice()), height)
        .map_err(|e| Status::internal(format!("invalid stored header: {e}")))?;
    let hash = header.hash().to_vec();
    Ok(CompactBlock {
        height,
        hash,
        prev_hash: header.prev.to_vec(),
        time: header.time,
        header: raw,
        vtx: Vec::new(),
        chain_metadata: None,
    })
}

#[tonic::async_trait]
impl CompactTxStreamer for LightwalletService {
    async fn get_latest_block(&self, _req: Request<ChainSpec>) -> Result<Response<BlockId>, Status> {
        let height = self.db.header_height().map_err(|e| Status::internal(e.to_string()))?.unwrap_or(0);
        let hash = if let Some(h) = self.db.header_hash_by_height(height).map_err(|e| Status::internal(e.to_string()))? {
            h
        } else {
            genesis_hash_internal().to_vec()
        };
        Ok(Response::new(BlockId { height, hash }))
    }

    async fn get_block(&self, req: Request<BlockId>) -> Result<Response<CompactBlock>, Status> {
        let id = req.into_inner();
        if id.hash.len() != 0 {
            return Err(Status::invalid_argument("hash selection is not supported; use height"));
        }
        let raw = self.db.header_by_height(id.height).map_err(|e| Status::internal(e.to_string()))?
            .ok_or_else(|| Status::not_found(format!("header {} not found", id.height)))?;
        Ok(Response::new(compact_block_from_header(raw, id.height)?))
    }

    type GetBlockRangeStream = ReceiverStream<Result<CompactBlock, Status>>;
    async fn get_block_range(&self, req: Request<BlockRange>) -> Result<Response<Self::GetBlockRangeStream>, Status> {
        let r = req.into_inner();
        let start = r.start.map(|x| x.height).unwrap_or(0);
        let end = r.end.map(|x| x.height).unwrap_or(start);
        let (tx, rx) = tokio::sync::mpsc::channel(8);
        let db = self.db.clone();
        tokio::spawn(async move {
            let step_up = start <= end;
            let mut h = start;
            loop {
                match db.header_by_height(h) {
                    Ok(Some(raw)) => {
                        match compact_block_from_header(raw, h) {
                            Ok(block) => { if tx.send(Ok(block)).await.is_err() { break; } }
                            Err(e) => { let _ = tx.send(Err(e)).await; break; }
                        }
                    }
                    Ok(None) => {
                        let _ = tx.send(Err(Status::not_found(format!("header {} not found", h)))).await;
                        break;
                    }
                    Err(e) => { let _ = tx.send(Err(Status::internal(e.to_string()))).await; break; }
                }
                if h == end { break; }
                if step_up { h = h.saturating_add(1); } else { if h == 0 { break; } h -= 1; }
            }
        });
        Ok(Response::new(ReceiverStream::new(rx)))
    }

    async fn get_lightd_info(&self, _req: Request<Empty>) -> Result<Response<LightdInfo>, Status> {
        let height = self.db.header_height().map_err(|e| Status::internal(e.to_string()))?.unwrap_or(0);
        Ok(Response::new(LightdInfo {
            version: "0.19.17".into(),
            vendor: "Ycash".into(),
            taddr_support: true,
            chain_name: "main".into(),
            sapling_activation_height: 0,
            consensus_branch_id: "".into(),
            block_height: height,
            git_commit: "".into(),
            branch: "".into(),
            build_date: "".into(),
            build_user: "".into(),
            estimated_height: height,
            zcashd_build: "".into(),
            zcashd_subversion: "/YcashAndroid:0.19.17/".into(),
            donation_address: "".into(),
            upgrade_name: "".into(),
            upgrade_height: 0,
            lightwallet_protocol_version: "0.5.0".into(),
        }))
    }
}

fn start_lightwalletd(state: SharedState, db: Arc<State>) {
    let bind = std::env::var("YCASH_LIGHTWALLET_BIND").unwrap_or_else(|_| "127.0.0.1".into());
    let port = std::env::var("YCASH_LIGHTWALLET_PORT")
        .ok()
        .and_then(|x| x.parse().ok())
        .unwrap_or(9067u16);

    let addr: SocketAddr = match format!("{}:{}", bind, port).parse() {
        Ok(a) => a,
        Err(e) => {
            state.write().unwrap().last_error =
                format!("Lightwalletd address invalid: {e}");
            return;
        }
    };

    thread::spawn(move || {
        let rt = match tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .build()
        {
            Ok(rt) => rt,
            Err(e) => {
                state.write().unwrap().last_error =
                    format!("Lightwalletd runtime failed: {e}");
                return;
            }
        };

        rt.block_on(async move {
            // IMPORTANT: bind once and give the already-bound listener to tonic.
            // The previous implementation bound 9067, dropped that socket, and then
            // asked tonic to bind the address again. That created a race/window where
            // the diagnostic could see a listening HTTP/2 endpoint while the actual
            // gRPC server was not yet attached to the socket.
            match tokio::net::TcpListener::bind(addr).await {
                Ok(listener) => {
                    state.write().unwrap().lightwallet_listening = true;
                    state.write().unwrap().message =
                        format!("YWallet gRPC listening on {}:{}", bind, port);

                    let incoming = tokio_stream::wrappers::TcpListenerStream::new(listener);
                    if let Err(e) = Server::builder()
                        .add_service(CompactTxStreamerServer::new(LightwalletService { db }))
                        .serve_with_incoming(incoming)
                        .await
                    {
                        let mut st = state.write().unwrap();
                        st.lightwallet_listening = false;
                        st.last_error = format!("YWallet gRPC failed: {e}");
                    }
                }
                Err(e) => {
                    state.write().unwrap().last_error =
                        format!("YWallet gRPC bind {}:{} failed: {e}", bind, port);
                }
            }
        });
    });
}

fn main(){let state=Arc::new(RwLock::new(LiveNodeState{running:true,..Default::default()}));let db_path=std::env::var("YCASH_NODE_DB").map(PathBuf::from).unwrap_or_else(|_|std::env::var("YCASH_DATA_DIR").map(|p|PathBuf::from(p).join("ycash-node.sqlite")).unwrap_or_else(|_|PathBuf::from("ycash-node.sqlite")));if let Some(p)=db_path.parent(){let _=std::fs::create_dir_all(p);}let db=match State::open(&db_path){Ok(x)=>Arc::new(x),Err(e)=>{eprintln!("database open failed: {e}");return}};if let Ok(h)=db.header_height(){let mut s=state.write().unwrap();s.headers_height=h.unwrap_or(0);s.local_height=db.tip_height().ok().flatten().unwrap_or(0);}if let Err(e)=start_api(state.clone(),db.clone(),db_path.parent().map(|p|p.to_path_buf()).unwrap_or_else(||PathBuf::from("."))){eprintln!("Status API failed: {e}");return}if let Some(base)=db_path.parent(){if let Err(e)=start_rpc(state.clone(),base){eprintln!("RPC failed: {e}");return}}start_lightwalletd(state.clone(), db.clone());if let Err(e)=start_p2p_listener(state.clone()){eprintln!("P2P listener failed: {e}");return}println!("Ycash Android Rust full P2P node v0.19.17");println!("Ycash mainnet magic 24e92764, port 8833, protocol 270014");let st=state.clone();let d=db.clone();thread::spawn(move||peer_supervisor(st,d));loop{thread::park()}}
