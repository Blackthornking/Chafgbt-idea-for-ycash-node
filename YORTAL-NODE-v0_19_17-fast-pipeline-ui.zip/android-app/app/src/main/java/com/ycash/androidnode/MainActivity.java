package com.ycash.androidnode;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.StatFs;
import android.content.Intent;
import android.content.Context;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.view.View;
import android.widget.*;
import java.net.*;
import javax.net.ssl.*;
import java.util.LinkedHashSet;
import java.io.*;
import java.security.MessageDigest;
import org.json.JSONObject;
import android.content.SharedPreferences;
// RandomAccessFile is covered by java.io.* above

public class MainActivity extends Activity {
    TextView status, peer, height, sync, log, headersHeight, connectionSource, connectionEndpoint, connectionDetail,
        targetHeight, blocksBehind, syncSpeed, lastBlock, uptime, dbSize, freeStorage, networkType, diagnostics,
        exportStatus, pipeline, peerPool, blocksStats;
    ProgressBar syncProgress;
    View advancedSection;
    Button toggleAdvanced;
    static final int REQUEST_EXPORT_CHAIN = 1001;
    Handler handler = new Handler();
    boolean running = false;
    boolean advancedShown = false;
    EditText walletEndpoint;
    EditText manualPeer;
    CheckBox walletTls;
    TextView walletTestResult;
    SharedPreferences prefs;
    int consecutiveFailures = 0;
    // 2s poll interval * 5 = ~10s of nothing listening on 8834 before we tell the user, instead of
    // sitting on "STARTING" forever.
    static final int FAILURE_THRESHOLD = 5;
    // For a client-side sync-speed estimate: last height/time we saw, so we can diff across polls
    // instead of asking the node to track a rate itself.
    long lastSpeedHeight = -1;
    long lastSpeedAtMillis = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status=findViewById(R.id.status);
        peer=findViewById(R.id.peer);
        height=findViewById(R.id.height);
        sync=findViewById(R.id.sync);
        log=findViewById(R.id.log);
        headersHeight=findViewById(R.id.headersHeight);
        connectionSource=findViewById(R.id.connectionSource);
        connectionEndpoint=findViewById(R.id.connectionEndpoint);
        connectionDetail=findViewById(R.id.connectionDetail);
        targetHeight=findViewById(R.id.targetHeight);
        blocksBehind=findViewById(R.id.blocksBehind);
        syncSpeed=findViewById(R.id.syncSpeed);
        syncProgress=findViewById(R.id.syncProgress);
        pipeline=findViewById(R.id.pipeline);
        peerPool=findViewById(R.id.peerPool);
        blocksStats=findViewById(R.id.blocksStats);
        lastBlock=findViewById(R.id.lastBlock);
        uptime=findViewById(R.id.uptime);
        dbSize=findViewById(R.id.dbSize);
        freeStorage=findViewById(R.id.freeStorage);
        networkType=findViewById(R.id.networkType);
        diagnostics=findViewById(R.id.diagnostics);
        exportStatus=findViewById(R.id.exportStatus);
        advancedSection=findViewById(R.id.advancedSection);
        toggleAdvanced=findViewById(R.id.toggleAdvanced);
        walletEndpoint=findViewById(R.id.walletEndpoint);
        walletTls=findViewById(R.id.walletTls);
        walletTestResult=findViewById(R.id.walletTestResult);
        prefs=getSharedPreferences("ycash_node",MODE_PRIVATE);
        walletEndpoint.setText(prefs.getString("wallet_endpoint","127.0.0.1:9067"));
        walletTls.setChecked(prefs.getBoolean("wallet_tls",false));
        manualPeer=findViewById(R.id.manualPeer);
        manualPeer.setText(prefs.getString(NodeService.PREF_MANUAL_PEER,""));
        findViewById(R.id.testWallet).setOnClickListener(v -> testWalletEndpoint());

        toggleAdvanced.setOnClickListener(v -> {
            advancedShown=!advancedShown;
            advancedSection.setVisibility(advancedShown ? View.VISIBLE : View.GONE);
            toggleAdvanced.setText(advancedShown ? "Advanced ▾" : "Advanced ▸");
            if (advancedShown) refreshDeviceStats();
        });

        findViewById(R.id.start).setOnClickListener(v -> {
            prefs.edit().putString(NodeService.PREF_MANUAL_PEER, manualPeer.getText().toString().trim()).apply();
            Intent i = new Intent(this, NodeService.class); i.setAction(NodeService.START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            running=true; consecutiveFailures=0; lastSpeedHeight=-1; status.setText("● STARTING"); log.setText("Log: starting Ycash node process"); pollStatus();
        });

        findViewById(R.id.stop).setOnClickListener(v -> {
            Intent i = new Intent(this, NodeService.class); i.setAction(NodeService.STOP); startService(i);
            running=false; status.setText("● STOPPED"); sync.setText("Sync: stopped");
            connectionSource.setText("Connection source: None");
            connectionEndpoint.setText("Endpoint: —");
            connectionDetail.setText("Details: Node stopped");
            blocksBehind.setText("Blocks behind: —");
            syncSpeed.setText("Sync speed: —");
            lastBlock.setText("Last block: —");
            uptime.setText("Node uptime: —");
            log.setText("Log: node stop requested");
        });

        findViewById(R.id.test).setOnClickListener(v -> testNetwork());
        findViewById(R.id.exportChain).setOnClickListener(v -> startExportChain());
    }

    /**
     * Kicks off the "Save blockchain data" flow: opens Android's document picker so the user chooses
     * where the file goes (no storage permission needed for this), then streams the node's /export
     * response straight into it once a destination comes back in onActivityResult.
     */
    private void startExportChain() {
        if (!running) { exportStatus.setText("Export: start the node first"); return; }
        String filename = "ycash-chain-" + (System.currentTimeMillis()/1000) + ".sqlite";
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/octet-stream");
        intent.putExtra(Intent.EXTRA_TITLE, filename);
        exportStatus.setText("Export: choose where to save…");
        try {
            startActivityForResult(intent, REQUEST_EXPORT_CHAIN);
        } catch (Exception e) {
            exportStatus.setText("Export: no file picker available on this device");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_EXPORT_CHAIN) return;
        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            exportChainTo(data.getData());
        } else {
            exportStatus.setText("Export: cancelled");
        }
    }

    /**
     * Streams GET /export straight into the user-chosen destination, buffer to buffer, so the copy
     * never has to hold the whole chain database in memory regardless of how large it's grown. The
     * node performs a VACUUM INTO snapshot server-side, so this is a consistent, point-in-time copy of
     * every header and block downloaded so far, not a live-editing view of the running database.
     */
    private void exportChainTo(Uri dest) {
        exportStatus.setText("Export: requesting snapshot from node…");
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                URL u = new URL("http://127.0.0.1:8834/export");
                c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(5000);
                // A full chain snapshot can take a while once the database is large; don't time out
                // mid-copy the way the 2s status poll does.
                c.setReadTimeout(0);
                c.setRequestMethod("GET");
                int code = c.getResponseCode();
                if (code != 200) {
                    final int fc = code;
                    runOnUiThread(() -> exportStatus.setText("Export: node returned HTTP " + fc));
                    return;
                }
                long total = 0;
                try (InputStream in = c.getInputStream();
                     OutputStream out = getContentResolver().openOutputStream(dest)) {
                    if (out == null) throw new IOException("could not open destination file");
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) != -1) { out.write(buf, 0, n); total += n; }
                }
                final long bytes = total;
                runOnUiThread(() -> exportStatus.setText("Export: saved " + formatBytes(bytes)));
            } catch (Exception e) {
                final String msg = e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
                runOnUiThread(() -> exportStatus.setText("Export: failed — " + msg));
            } finally {
                if (c != null) c.disconnect();
            }
        }).start();
    }

    private void pollStatus() {
        if (!running) return;
        new Thread(() -> {
            try {
                URL u=new URL("http://127.0.0.1:8834/status");
                HttpURLConnection c=(HttpURLConnection)u.openConnection();
                c.setConnectTimeout(1500);
                c.setReadTimeout(1500);
                c.setRequestMethod("GET");
                if(c.getResponseCode()==200) {
                    BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));
                    StringBuilder s=new StringBuilder(); String line;
                    while((line=br.readLine())!=null) s.append(line);
                    JSONObject j=new JSONObject(s.toString());
                    runOnUiThread(() -> applyStatus(j));
                }
                c.disconnect();
            } catch(Exception e) {
                consecutiveFailures++;
                if (consecutiveFailures == FAILURE_THRESHOLD) {
                    String tail = readLogTail();
                    runOnUiThread(() -> {
                        status.setText("● NODE NOT RESPONDING");
                        log.setText("Log: no response from the node on :8834 after "+
                            (FAILURE_THRESHOLD*2)+"s. Last error: "+e.getClass().getSimpleName()+
                            (tail.isEmpty() ? "" : "\n\nnode.log tail:\n"+tail));
                    });
                }
                // Below the threshold, keep showing the last real values -- a couple of missed polls
                // during startup is normal and not worth alarming the user over.
            }
            handler.postDelayed(this::pollStatus, 2000);
        }).start();
    }

    /** Reads the last ~2KB of node.log so a "not responding" status is actually actionable. */
    private String readLogTail() {
        File f = new File(getFilesDir(), "node.log");
        if (!f.exists()) return "";
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            long len = raf.length();
            long start = Math.max(0, len - 2048);
            raf.seek(start);
            byte[] buf = new byte[(int)(len - start)];
            raf.readFully(buf);
            return new String(buf);
        } catch (Exception e) {
            return "";
        }
    }

    private void applyStatus(JSONObject j) {
        try {
            consecutiveFailures = 0;
            status.setText("● "+j.optString("status","UNKNOWN").toUpperCase());
            peer.setText("Peers: "+j.optInt("peers",0));
            long blockHeight=j.optLong("height",-1);
            long headerHeight=j.optLong("headers_height",-1);
            long peerTargetHeight=j.optLong("target_height",-1);
            height.setText("Block height: "+(blockHeight < 0 ? "—" : blockHeight));
            headersHeight.setText("Headers height: "+(headerHeight < 0 ? "—" : headerHeight));
            targetHeight.setText("Target height: "+(peerTargetHeight < 0 ? "—" : peerTargetHeight));
            String syncText=j.optString("sync","unknown");
            sync.setText("Sync: "+syncText);
            long behind=(blockHeight < 0 || peerTargetHeight < 0 ? -1 : Math.max(0, peerTargetHeight-blockHeight));
            blocksBehind.setText("Blocks behind: "+(behind < 0 ? "—" : behind));
            long active=j.optLong("active_outbound",0), known=j.optLong("known_peers",0);
            peerPool.setText("Peer pool: "+active+" active / "+known+" known");
            long validated=j.optLong("blocks_validated",0), txs=j.optLong("txs_indexed",0);
            blocksStats.setText("Validated: "+validated+" • Transactions: "+txs);
            boolean syncing=behind>0 || syncText.contains("headers");
            pipeline.setText("Pipeline: "+(syncing ? "FETCH → VALIDATE → BATCH COMMIT" : "LIVE / READY"));
            pipeline.setTextColor(syncing ? 0xFFFF9800 : 0xFF66BB6A);
            if (peerTargetHeight >= 0 && headerHeight >= 0 && peerTargetHeight > 0) {
                int pct=(int)Math.min(100,Math.max(0,(headerHeight*100)/peerTargetHeight));
                syncProgress.setProgress(pct);
            } else syncProgress.setProgress(0);

            // Sync speed: diffed client-side across polls. The node doesn't track a rate itself,
            // so this is only as smooth as the 2s poll interval -- fine for a rough reading.
            long now=System.currentTimeMillis();
            if (blockHeight >= 0) {
                if (lastSpeedHeight >= 0 && now > lastSpeedAtMillis) {
                    double blocksPerSec=(blockHeight-lastSpeedHeight)*1000.0/(now-lastSpeedAtMillis);
                    syncSpeed.setText(blocksPerSec <= 0 ? "Sync speed: —" :
                        String.format(java.util.Locale.US, "Sync speed: %.1f blocks/s", blocksPerSec));
                }
                lastSpeedHeight=blockHeight; lastSpeedAtMillis=now;
            }

            long tipTime=j.optLong("tip_time",0);
            if (tipTime > 0) {
                long agoSec=Math.max(0, System.currentTimeMillis()/1000 - tipTime);
                lastBlock.setText("Last block: "+formatDuration(agoSec)+" ago");
            } else {
                lastBlock.setText("Last block: —");
            }

            long uptimeSec=j.optLong("uptime_seconds",-1);
            uptime.setText("Node uptime: "+(uptimeSec < 0 ? "—" : formatDuration(uptimeSec)));

            connectionSource.setText("Connection source: "+j.optString("connection_source","None"));
            connectionEndpoint.setText("Endpoint: "+j.optString("connection_endpoint","—"));
            connectionDetail.setText("Details: "+j.optString("connection_detail","—"));
            log.setText("Log: "+j.optString("message","status updated"));
            if (diagnostics != null) diagnostics.setText(
                "Listeners — P2P 8833: "+(j.optBoolean("p2p_listening",false)?"LISTENING":"DOWN")+
                "  RPC 8832: "+(j.optBoolean("rpc_listening",false)?"LISTENING":"DOWN")+
                "  Status 8834: "+(j.optBoolean("api_listening",false)?"LISTENING":"DOWN")+
                "  YWallet gRPC 9067: "+(j.optBoolean("lightwallet_listening",false)?"LISTENING":"DOWN")+
                "\nOutbound attempts: "+j.optLong("outbound_attempts",0)+
                "  handshakes: "+j.optLong("outbound_handshakes",0)+
                "\nInbound connections: "+j.optLong("inbound_connections",0)+
                "\nBlocks received: "+j.optLong("blocks_received",0)+"  validated: "+j.optLong("blocks_validated",0)+
                "\nTransactions indexed: "+j.optLong("txs_indexed",0)+"  Last block bytes: "+j.optLong("last_block_bytes",0)+
                "\nLast validated height: "+j.optLong("last_block_height",0)+
                "\nLast node error: "+j.optString("last_error","—")+
                "\nOutbound slots in use: "+j.optInt("active_outbound",0)+"/8  Known addresses: "+j.optInt("known_peers",0)+
                "\n\nPeer attempts (newest first):\n"+j.optString("peer_table","—").replace(" | ","\n"));
            if (advancedShown) refreshDeviceStats();
        } catch(Exception ignored) {}
    }

    private static String formatDuration(long totalSeconds) {
        long h=totalSeconds/3600, m=(totalSeconds%3600)/60, s=totalSeconds%60;
        if (h > 0) return h+"h "+m+"m";
        if (m > 0) return m+"m "+s+"s";
        return s+"s";
    }

    /**
     * Real device/OS numbers, not node output -- the node process has no reliable, portable way to
     * report its own CPU/RAM from inside another app's process on modern Android, so rather than ship
     * a reading that silently goes wrong on some devices, this sticks to what Android itself can answer
     * accurately: the node's actual database file size, free space on the device, and network type.
     */
    private void refreshDeviceStats() {
        try {
            File db=new File(getFilesDir(),"ycash-node.sqlite");
            dbSize.setText("Node database size: "+(db.exists() ? formatBytes(db.length()) : "—"));
        } catch (Exception e) { dbSize.setText("Node database size: —"); }
        try {
            StatFs stat=new StatFs(getFilesDir().getAbsolutePath());
            freeStorage.setText("Free device storage: "+formatBytes(stat.getAvailableBytes()));
        } catch (Exception e) { freeStorage.setText("Free device storage: —"); }
        try {
            ConnectivityManager cm=(ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities caps = cm==null ? null : cm.getNetworkCapabilities(cm.getActiveNetwork());
            String kind = caps==null ? "none"
                : caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi"
                : caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "mobile"
                : "other";
            networkType.setText("Device network: "+kind);
        } catch (Exception e) { networkType.setText("Device network: —"); }
    }

    private static String formatBytes(long bytes) {
        if (bytes < 1024*1024) return String.format(java.util.Locale.US, "%.0f KB", bytes/1024.0);
        if (bytes < 1024*1024*1024) return String.format(java.util.Locale.US, "%.1f MB", bytes/(1024.0*1024));
        return String.format(java.util.Locale.US, "%.2f GB", bytes/(1024.0*1024*1024));
    }

    /**
     * YWallet/lightwalletd diagnostic probe.
     *
     * Keep the actual wire test small and deterministic, but expose enough
     * information to distinguish DNS, TCP, TLS/ALPN, HTTP/2 and gRPC failures.
     */
    private void testWalletEndpoint() {
        String raw=walletEndpoint.getText().toString().trim();
        boolean tls=walletTls.isChecked();
        prefs.edit().putString("wallet_endpoint",raw).putBoolean("wallet_tls",tls).apply();
        if(raw.isEmpty()) { walletTestResult.setText("YWallet test: enter host:port"); return; }

        String host; int port;
        try {
            String n=raw;
            if(n.startsWith("http://")) n=n.substring(7);
            if(n.startsWith("https://")) n=n.substring(8);
            int slash=n.indexOf('/'); if(slash>=0) n=n.substring(0,slash);
            if(n.startsWith("[")) {
                int close=n.indexOf(']');
                if(close<1) throw new IllegalArgumentException();
                host=n.substring(1,close);
                port=(close+1<n.length() && n.charAt(close+1)==':')
                    ? Integer.parseInt(n.substring(close+2)) : (tls?443:9067);
            } else {
                int colon=n.lastIndexOf(':');
                if(colon>0 && n.indexOf(':')==colon) {
                    host=n.substring(0,colon); port=Integer.parseInt(n.substring(colon+1));
                } else { host=n; port=tls?443:9067; }
            }
            if(host.isEmpty() || port<1 || port>65535) throw new IllegalArgumentException();
        } catch(Exception e) {
            walletTestResult.setText("YWallet test: invalid host:port");
            return;
        }

        final String h=host; final int p=port;
        walletTestResult.setText("YWallet test: testing "+h+":"+p+(tls?" (TLS)":" (plain)")+"…");
        new Thread(() -> {
            long started=System.currentTimeMillis();
            StringBuilder d=new StringBuilder();
            Socket socket=null;
            try {
                // Stage 1: DNS, explicitly shown instead of being hidden in Socket.connect().
                InetAddress[] addrs=InetAddress.getAllByName(h);
                if(addrs.length==0) throw new IOException("DNS returned no addresses");
                d.append("DNS PASS: ").append(addrs[0].getHostAddress());
                if(addrs.length>1) d.append(" (+").append(addrs.length-1).append(")");

                // Stage 2: TCP.
                Socket tcp=new Socket();
                tcp.setSoTimeout(8000);
                tcp.connect(new InetSocketAddress(h,p),6000);
                d.append("\nTCP PASS: ").append(tcp.getRemoteSocketAddress());

                boolean alpn=false;
                String tlsVersion="", cipher="";
                if(tls) {
                    // Wrap the already-connected socket so hostname verification/SNI are tied to h.
                    SSLSocketFactory sf=(SSLSocketFactory)SSLSocketFactory.getDefault();
                    SSLSocket ss=(SSLSocket)sf.createSocket(tcp,h,p,true);
                    if(Build.VERSION.SDK_INT>=29) {
                        try {
                            SSLParameters sp=ss.getSSLParameters();
                            sp.setApplicationProtocols(new String[]{"h2"});
                            ss.setSSLParameters(sp);
                        } catch(Throwable ignored) {}
                    }
                    ss.startHandshake();
                    tlsVersion=ss.getSession().getProtocol();
                    cipher=ss.getSession().getCipherSuite();
                    if(Build.VERSION.SDK_INT>=29) {
                        try { alpn="h2".equals(ss.getApplicationProtocol()); } catch(Throwable ignored) {}
                    }
                    d.append("\nTLS PASS: ").append(tlsVersion).append(" / ").append(cipher);
                    d.append("\nALPN: ").append(alpn?"h2 PASS":"h2 NOT NEGOTIATED");
                    socket=ss;
                } else {
                    socket=tcp;
                    d.append("\nTLS: not requested");
                }

                InputStream in=socket.getInputStream();
                OutputStream out=socket.getOutputStream();

                // HTTP/2 connection preface + client SETTINGS.
                out.write("PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n".getBytes("US-ASCII")); // RFC 7540 3.5: exactly 24 bytes (old code omitted ".0")
                out.write(new byte[]{0,0,0,4,0,0,0,0,0});
                out.flush();

                H2Frame sf=readH2Frame(in);
                if(sf==null) throw new IOException("HTTP/2: server closed connection before SETTINGS");
                if(sf.type!=4) {
                    d.append("\nHTTP/2 FAIL: first frame type ").append(sf.type);
                    finishWalletDiagnostic(h,p,tls,alpn,false,false,d.toString(),started);
                    return;
                }
                d.append("\nHTTP/2 SETTINGS PASS ("+sf.len+" bytes)");
                if((sf.flags&1)==0) {
                    out.write(new byte[]{0,0,0,4,1,0,0,0,0});
                    out.flush();
                }

                // Real unary lightwalletd RPC.
                byte[] headers=hpackRequestHeaders(h,p,tls);
                writeH2Frame(out,1,0x4,1,headers); // HEADERS | END_HEADERS
                byte[] grpcEmpty=new byte[]{0,0,0,0,0};
                writeH2Frame(out,0,0x1,1,grpcEmpty); // DATA | END_STREAM
                out.flush();
                d.append("\ngRPC request sent: POST /cash.z.wallet.sdk.rpc.CompactTxStreamer/GetLatestBlock");
                d.append("\ngRPC framing: 5-byte empty protobuf message, END_STREAM");

                boolean gotHeaders=false, gotData=false, gotTrailers=false, latest=false;
                byte[] responseData=new byte[0];
                int rstCode=-1, goAwayCode=-1;
                long deadline=System.currentTimeMillis()+8000;
                while(System.currentTimeMillis()<deadline) {
                    H2Frame f=readH2Frame(in);
                    if(f==null) { d.append("\nHTTP/2 EOF: server closed connection before a complete gRPC response"); break; }
                    d.append("\nHTTP/2 frame: type=").append(f.type)
                      .append(" flags=0x").append(Integer.toHexString(f.flags))
                      .append(" stream=").append(f.stream).append(" len=").append(f.len);
                    if(f.type==4) {
                        if((f.flags&1)==0) {
                            out.write(new byte[]{0,0,0,4,1,0,0,0,0}); out.flush();
                        }
                    } else if(f.type==1) {
                        if(f.stream==1) {
                            gotHeaders=true;
                            if((f.flags&1)!=0) gotTrailers=true;
                        }
                    } else if(f.type==0 && f.stream==1) {
                        gotData=true;
                        if(f.payload.length>=5) {
                            int off=0;
                            while(off+5<=f.payload.length) {
                                int len=((f.payload[off+1]&255)<<24)|((f.payload[off+2]&255)<<16)|
                                    ((f.payload[off+3]&255)<<8)|(f.payload[off+4]&255);
                                int total=5+len;
                                if(len<0 || off+total>f.payload.length) break;
                                byte[] msg=java.util.Arrays.copyOfRange(f.payload,off+5,off+total);
                                responseData=concat(responseData,msg);
                                off+=total;
                            }
                        }
                        if((f.flags&1)!=0) break;
                    } else if(f.type==3 && f.stream==1) {
                        rstCode=f.payload.length>=4 ? ((f.payload[0]&255)<<24)|((f.payload[1]&255)<<16)|
                            ((f.payload[2]&255)<<8)|(f.payload[3]&255) : -1;
                        d.append("\nRST_STREAM code=").append(h2ErrorName(rstCode));
                        break;
                    } else if(f.type==7) {
                        goAwayCode=f.payload.length>=8 ? ((f.payload[4]&255)<<24)|((f.payload[5]&255)<<16)|
                            ((f.payload[6]&255)<<8)|(f.payload[7]&255) : -1;
                        d.append("\nGOAWAY code=").append(h2ErrorName(goAwayCode));
                        break;
                    }
                    if(f.type==1 && f.stream==1 && (f.flags&1)!=0) { gotTrailers=true; break; } // trailers + END_STREAM = RPC complete
                }
                if(responseData.length>0) latest=looksLikeBlockId(responseData);
                d.append("\ngRPC response bytes: ").append(responseData.length);
                d.append("\nBlockID decode: ").append(latest?"PASS":"not confirmed");
                if(rstCode>=0) d.append("\nRPC reset: ").append(h2ErrorName(rstCode));
                if(goAwayCode>=0) d.append("\nGOAWAY: ").append(h2ErrorName(goAwayCode));
                d.append("\nResult: ").append(latest?"YWallet RPC PASS":
                    gotData?"gRPC DATA received (response protobuf not decoded)":
                    gotTrailers?"gRPC trailers received (grpc-status not decoded)":
                    gotHeaders?"RPC response headers received but no DATA":"HTTP/2 transport connected but server returned no gRPC response");
                d.append("\nLatency: ").append(System.currentTimeMillis()-started).append(" ms");
                final String msg=d.toString();
                runOnUiThread(() -> walletTestResult.setText(msg));
            } catch(Exception e) {
                d.append("\nFAIL: ").append(e.getClass().getSimpleName()).append(": ")
                  .append(e.getMessage()==null?"connection failed":e.getMessage());
                d.append("\nLatency: ").append(System.currentTimeMillis()-started).append(" ms");
                final String msg=d.toString();
                runOnUiThread(() -> walletTestResult.setText(msg));
            } finally {
                if(socket!=null) try { socket.close(); } catch(Exception ignored) {}
            }
        }).start();
    }

    private void finishWalletDiagnostic(String h,int p,boolean tls,boolean alpn,boolean h2,boolean rpc,String detail,long started) {
        runOnUiThread(() -> walletTestResult.setText(detail+"\nLatency: "+(System.currentTimeMillis()-started)+" ms"));
    }

    private static String h2ErrorName(int code) {
        switch(code) {
            case 0: return "NO_ERROR(0)";
            case 1: return "PROTOCOL_ERROR(1)";
            case 2: return "INTERNAL_ERROR(2)";
            case 3: return "FLOW_CONTROL_ERROR(3)";
            case 4: return "SETTINGS_TIMEOUT(4)";
            case 5: return "STREAM_CLOSED(5)";
            case 6: return "FRAME_SIZE_ERROR(6)";
            case 7: return "REFUSED_STREAM(7)";
            case 8: return "CANCEL(8)";
            case 9: return "COMPRESSION_ERROR(9)";
            case 10: return "CONNECT_ERROR(10)";
            case 11: return "ENHANCE_YOUR_CALM(11)";
            case 12: return "INADEQUATE_SECURITY(12)";
            case 13: return "HTTP_1_1_REQUIRED(13)";
            default: return "UNKNOWN("+code+")";
        }
    }

    private static class H2Frame {
        int len,type,flags,stream; byte[] payload;
    }

    private static H2Frame readH2Frame(InputStream in) throws IOException {
        byte[] h=new byte[9]; readFully(in,h);
        H2Frame f=new H2Frame();
        f.len=((h[0]&255)<<16)|((h[1]&255)<<8)|(h[2]&255);
        f.type=h[3]&255; f.flags=h[4]&255;
        f.stream=((h[5]&127)<<24)|((h[6]&255)<<16)|((h[7]&255)<<8)|(h[8]&255);
        f.payload=new byte[f.len]; if(f.len>0) readFully(in,f.payload);
        return f;
    }

    private static void readFully(InputStream in,byte[] b) throws IOException {
        int off=0; while(off<b.length) { int n=in.read(b,off,b.length-off); if(n<0) throw new EOFException(); off+=n; }
    }

    private static void writeH2Frame(OutputStream out,int type,int flags,int stream,byte[] p) throws IOException {
        int n=p.length;
        out.write(new byte[]{(byte)(n>>>16),(byte)(n>>>8),(byte)n,(byte)type,(byte)flags,
            (byte)(stream>>>24),(byte)(stream>>>16),(byte)(stream>>>8),(byte)stream});
        out.write(p);
    }

    /* HPACK request block using only RFC 7541 static-table entries plus literal
       values. No dynamic table is needed for this request. */
    private static byte[] hpackRequestHeaders(String host,int port,boolean tls) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();
        // :method POST = static index 3; :scheme = 6(http) or 7(https)
        b.write(0x83); b.write(tls?0x87:0x86);
        hpackLiteralIndexedName(b,":path","/cash.z.wallet.sdk.rpc.CompactTxStreamer/GetLatestBlock",4);
        hpackLiteralIndexedName(b,":authority",host+":"+port,1);
        // gRPC requires its timeout immediately after the reserved HTTP/2 headers.
        hpackLiteralIndexedName(b,"grpc-timeout","10S",-1);
        // content-type: application/grpc = static name index 31.
        // Literal without indexing uses a 4-bit prefix: index 31 => 0x0f, then 0x10.
        b.write(0x0f); b.write(0x10);
        byte[] ct="application/grpc".getBytes("UTF-8");
        b.write(ct.length); b.write(ct);
        hpackLiteralIndexedName(b,"te","trailers",-1);
        hpackLiteralIndexedName(b,"grpc-encoding","identity",-1);
        hpackLiteralIndexedName(b,"grpc-accept-encoding","identity,gzip",-1);
        hpackLiteralIndexedName(b,"user-agent","grpc-java-android/diagnostic-ycash-0.19.17",-1);
        return b.toByteArray();
    }

    private static void hpackLiteralIndexedName(ByteArrayOutputStream b,String name,String value,int staticIndex) throws IOException {
        byte[] v=value.getBytes("UTF-8");
        if(staticIndex>0) {
            // literal without indexing, 0000xxxx prefix
            writeHpackInt(b,0x00,4,staticIndex);
        } else {
            byte[] n=name.getBytes("UTF-8"); b.write(0x00); writeHpackInt(b,0,7,n.length); b.write(n);
        }
        writeHpackInt(b,0,7,v.length); b.write(v);
    }

    private static void writeHpackInt(ByteArrayOutputStream b,int prefix,int bits,int value) {
        int max=(1<<bits)-1;
        if(value<max){ b.write(prefix|value); return; }
        b.write(prefix|max); value-=max;
        while(value>=128){ b.write((value&127)|128); value>>>=7; }
        b.write(value);
    }

    private static byte[] concat(byte[] a,byte[] c) {
        byte[] r=java.util.Arrays.copyOf(a,a.length+c.length);
        System.arraycopy(c,0,r,a.length,c.length); return r;
    }

    /* Standard lightwalletd BlockID protobuf:
       field 1 = height (varint), field 2 = hash (bytes).
       Require both fields so the diagnostic only reports a real GetLatestBlock response. */
    private static boolean looksLikeBlockId(byte[] p) {
        try {
            int i=0; boolean hash=false,height=false;
            while(i<p.length) {
                long tag=readVarint(p,i); int consumed=varintLen(p,i);
                if(consumed<1) return false;
                i+=consumed;
                int field=(int)(tag>>>3), wire=(int)(tag&7);

                // BlockID.height = field 1, uint64/varint.
                if(field==1 && wire==0) {
                    int l=varintLen(p,i);
                    if(l<1) return false;
                    i+=l;
                    height=true;

                // BlockID.hash = field 2, bytes.
                } else if(field==2 && wire==2) {
                    long n=readVarint(p,i); int l=varintLen(p,i);
                    if(l<1 || n<1 || n>64) return false;
                    i+=l;
                    if(i+n>p.length) return false;
                    i+=(int)n;
                    hash=true;
                } else {
                    return false;
                }
            }
            return hash; // proto3 omits height when it is 0 (node has no headers yet)
        } catch(Exception e){ return false; }
    }
    private static long readVarint(byte[] p,int i) {
        long v=0; int s=0; for(int n=0;n<10 && i+n<p.length;n++){ int c=p[i+n]&255; v|=(long)(c&127)<<s; if((c&128)==0)return v; s+=7; } return -1;
    }
    private static int varintLen(byte[] p,int i) {
        for(int n=0;n<10 && i+n<p.length;n++) if((p[i+n]&128)==0)return n+1;
        return -1;
    }

    private void testNetwork() {
        status.setText("● TESTING");
        connectionSource.setText("Connection source: testing Ycash peer discovery");
        connectionEndpoint.setText("Endpoint: —");
        connectionDetail.setText("Details: DNS seed → TCP → VERSION → VERACK; historical fixed seeds are fallback");
        log.setText("Log: testing Ycash mainnet discovery and P2P handshake on TCP 8833…");
        new Thread(() -> {
            LinkedHashSet<String> seen = new LinkedHashSet<>();
            java.util.ArrayList<String[]> candidates = new java.util.ArrayList<>();
            try {
                for (InetAddress a : InetAddress.getAllByName("seed.ycash.xyz")) {
                    String endpoint=a.getHostAddress()+":8833";
                    if (seen.add(endpoint)) candidates.add(new String[]{"DNS Seed (seed.ycash.xyz)", endpoint, a.getHostAddress()});
                }
            } catch (Exception e) {
                final String err=e.getClass().getSimpleName()+": "+(e.getMessage()==null?"DNS lookup failed":e.getMessage());
                runOnUiThread(() -> log.setText("Log: DNS seed lookup failed — "+err+"; trying historical fixed seeds as fallback"));
            }
            // These are the two fixed seeds shipped by Ycash 4.5.0. They are deliberately
            // fallback-only so an unavailable historical seed cannot block DNS discovery.
            String[][] fixed={{"Fixed Seed #1 (fallback)","3.130.144.65","8833"},{"Fixed Seed #2 (fallback)","13.126.58.237","8833"}};
            for(String[] f:fixed){String endpoint=f[1]+":"+f[2];if(seen.add(endpoint))candidates.add(new String[]{f[0],endpoint,f[1]});}
            Exception last=null;
            for(String[] c:candidates){
                final String source=c[0], endpoint=c[1], host=c[2];
                runOnUiThread(() -> {connectionSource.setText("Connection source: "+source);connectionEndpoint.setText("Endpoint: "+endpoint);connectionDetail.setText("Details: TCP CONNECT testing…");log.setText("Log: trying "+source+" → "+endpoint);});
                try(Socket socket=new Socket()){
                    socket.setSoTimeout(8000);socket.connect(new InetSocketAddress(host,8833),7000);
                    runOnUiThread(() -> {connectionDetail.setText("Details: TCP CONNECT PASS; sending VERSION");log.setText("Log: TCP PASS "+endpoint+"; sending Ycash VERSION…");});
                    sendP2PVersion(socket, InetAddress.getByName(host));
                    String handshake=readP2PHandshake(socket);
                    final String result=handshake;
                    runOnUiThread(() -> {status.setText("● P2P HANDSHAKE PASS");connectionSource.setText("Connection source: "+source);connectionEndpoint.setText("Endpoint: "+endpoint);connectionDetail.setText("Details: TCP PASS → VERSION PASS → VERACK PASS");log.setText("Log: "+source+" completed Ycash P2P handshake at "+endpoint+" ("+result+")");});
                    return;
                }catch(Exception e){last=e;final String msg=source+" failed at "+endpoint+": "+e.getClass().getSimpleName()+" — "+(e.getMessage()==null?"connection failed":e.getMessage());runOnUiThread(() -> {connectionDetail.setText("Details: "+msg);log.setText("Log: "+msg);});}
            }
            Exception failure=last;
            runOnUiThread(() -> {status.setText("● CONNECTION FAILED");connectionDetail.setText("Details: every discovered/fallback Ycash peer failed TCP/P2P handshake");log.setText("Log: all Ycash connection sources failed: "+(failure==null?"DNS returned no peers":failure.getClass().getSimpleName()+": "+failure.getMessage()));});
        }).start();
    }

    private static void sendP2PVersion(Socket socket, InetAddress peer) throws Exception {
        ByteArrayOutputStream p=new ByteArrayOutputStream();
        writeIntLE(p,270014);writeLongLE(p,1);writeLongLE(p,System.currentTimeMillis()/1000);
        p.write(new byte[8]);p.write(ipv6Mapped(peer));writeShortBE(p,8833);p.write(new byte[8]);p.write(new byte[16]);writeShortBE(p,0);
        writeLongLE(p,System.currentTimeMillis() ^ android.os.Process.myPid());byte[] ua="/YcashAndroid:0.19.17/".getBytes("UTF-8");writeCompactSize(p,ua.length);p.write(ua);writeIntLE(p,0);p.write(1);
        writeYcashMessage(socket.getOutputStream(),"version",p.toByteArray());socket.getOutputStream().flush();
    }
    private static String readP2PHandshake(Socket socket) throws Exception {
        boolean version=false,verack=false;long deadline=System.currentTimeMillis()+8000;
        while(System.currentTimeMillis()<deadline){
            P2PFrame f=readP2PFrame(socket.getInputStream());
            if("version".equals(f.command)){version=true;writeYcashMessage(socket.getOutputStream(),"verack",new byte[0]);socket.getOutputStream().flush();}
            else if("verack".equals(f.command)){verack=true;}
            else if("ping".equals(f.command)){writeYcashMessage(socket.getOutputStream(),"pong",f.payload);socket.getOutputStream().flush();}
            if(version&&verack)return "version + verack handshake complete";
        }
        if(!version && !verack) throw new EOFException("no VERSION/VERACK received");
        if(!version) throw new EOFException("peer never sent VERSION");
        throw new EOFException("peer never sent VERACK");
    }
    private static class P2PFrame { String command; byte[] payload; }
    private static P2PFrame readP2PFrame(InputStream in) throws Exception {
        byte[] h=new byte[24];readFully(in,h);if(h[0]!=0x24||h[1]!=(byte)0xe9||h[2]!=0x27||h[3]!=0x64)throw new IOException("bad Ycash network magic");
        String cmd=new String(h,4,12,"US-ASCII").trim();int len=(h[16]&255)|((h[17]&255)<<8)|((h[18]&255)<<16)|((h[19]&255)<<24);if(len<0||len>2*1024*1024)throw new IOException("invalid P2P payload length");byte[] p=new byte[len];readFully(in,p);byte[] sum=sha256d(p);for(int i=0;i<4;i++)if(sum[i]!=h[20+i])throw new IOException("P2P checksum mismatch");P2PFrame f=new P2PFrame();f.command=cmd;f.payload=p;return f;
    }
    private static void writeYcashMessage(OutputStream out,String command,byte[] payload) throws Exception {byte[] h=new byte[24];h[0]=0x24;h[1]=(byte)0xe9;h[2]=0x27;h[3]=0x64;byte[] c=command.getBytes("US-ASCII");System.arraycopy(c,0,h,4,Math.min(12,c.length));int n=payload.length;h[16]=(byte)n;h[17]=(byte)(n>>>8);h[18]=(byte)(n>>>16);h[19]=(byte)(n>>>24);byte[] sum=sha256d(payload);System.arraycopy(sum,0,h,20,4);out.write(h);out.write(payload);}
    private static byte[] sha256d(byte[] x) throws Exception {MessageDigest d=MessageDigest.getInstance("SHA-256");return d.digest(d.digest(x));}
    private static byte[] ipv6Mapped(InetAddress a){byte[] out=new byte[16];byte[] v=a.getAddress();if(v.length==4){out[10]=(byte)0xff;out[11]=(byte)0xff;System.arraycopy(v,0,out,12,4);}else System.arraycopy(v,0,out,0,16);return out;}
    private static void writeIntLE(OutputStream o,int v)throws IOException{o.write(v);o.write(v>>>8);o.write(v>>>16);o.write(v>>>24);}
    private static void writeLongLE(OutputStream o,long v)throws IOException{for(int i=0;i<8;i++)o.write((int)(v>>>(8*i)));}
    private static void writeShortBE(OutputStream o,int v)throws IOException{o.write(v>>>8);o.write(v);}
    private static void writeCompactSize(OutputStream o,long n)throws IOException{if(n<=252)o.write((int)n);else throw new IOException("test user-agent too long");}


}
