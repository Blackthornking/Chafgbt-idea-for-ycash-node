# YORTAL v0.31 deep sync-stall fix

## Root cause traced

The state path had a canonical UTXO RAM cache, but positive UTXOs loaded from SQLite were **not promoted into that cache**. The cache therefore learned mostly newly-created outputs and repeatedly fell back to SQLite as the chain/working set grew. This matches the observed degradation in UTXO cache hit rate and rising TX-connect time.

BIP30 used `COUNT(*)` for a hot-path existence check. It was replaced with an indexed, short-circuiting row-existence scan while preserving the required ordered-batch semantics for outputs spent earlier in the same batch.

The script verifier already used one job per input, but Rayon scheduling could produce highly uneven worker assignment for heterogeneous verification costs. It now uses exactly the active script-worker count with an atomic input cursor; each worker pulls the next input after finishing the previous one.

The ordered canonical committer remains a single permanent worker. No consensus state mutation is moved into the parallel script workers.

## Changes

### UTXO cache
- Promote positive SQLite UTXO reads at commit publication.
- Do not promote entries that were spent later in the same ordered batch.
- Preserve exact-parent cache invalidation/reorg safety.
- Added a regression test proving a DB UTXO hit becomes a later RAM hit.

### BIP30
- Replace `COUNT(*)` with an existence-oriented indexed query.
- Added `utxos_txid_spent_height_height(txid, spent_height, height)`.
- Preserve the special case where an output was spent by an earlier transaction in the same canonical batch.

### Script distribution
- Keep one shared script CPU budget.
- Use `worker_count` persistent Rayon tasks plus `AtomicUsize::fetch_add(1)` work distribution.
- Each task holds one script permit while pulling inputs, reducing gate/scheduler overhead.
- Preserve deterministic error selection by sorting results by input index.
- Fixed the small-transaction path so it verifies **all** inputs, not only input 0 when the threshold is raised.
- Fixed state-level telemetry aggregation to retain all 32 worker slots instead of only the first four.

### SQLite / commit path
- Keep WAL + `synchronous=NORMAL`.
- Increase SQLite page cache defaults for the writer/reader to 64 MiB / 32 MiB.
- Raise WAL autocheckpoint to 10,000 pages to reduce frequent checkpoint-induced commit spikes.
- Keep expensive consensus preparation outside the canonical write transaction.
- Keep exactly one ordered canonical state committer and re-check the prepared parent/tip before mutation.

### CI
- Updated `tools/verify-script-pool.sh` to accept the new atomic-cursor dynamic scheduler and explicitly verify `fetch_add(1, Ordering::Relaxed)`.

## Consensus boundary

The following remain ordered and canonical:

`UTXO state -> BIP30 -> value/fee checks -> state mutation -> Sapling/Sprout state -> SQLite commit`

Only independent transparent script verification is parallelized. The database remains authoritative; the RAM cache is an acceleration layer only.

## Expected telemetry after the fix

The most important signs are:

1. `utxo_cache_hits` should rise substantially after the first cache-warming batches.
2. `utxo_cache_misses` should stop growing in proportion to every historical spend.
3. BIP30 time should fall relative to the old `COUNT(*)` implementation.
4. Script `worker_inputs` should be substantially more evenly distributed by count; actual wall balance should also improve for heterogeneous inputs.
5. `script_pool_overhead_us` and `parallel wall gap` should decrease.
6. `state_validation_ms` should scale more gently as height increases.
7. `db_write_ms` / `sqlite_commit_ms` should remain short while long preparation time stays outside the write transaction.
8. There must still be exactly one permanent ordered commit worker.

## Verification limitation

The supplied environment does not contain `cargo`/`rustc`, so a full Rust compile/test run could not be executed here. Static brace/parenthesis checks and the repository's shell verification scripts were run successfully.
