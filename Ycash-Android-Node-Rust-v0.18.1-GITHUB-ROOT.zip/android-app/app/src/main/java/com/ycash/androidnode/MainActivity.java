package com.ycash.androidnode;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.os.Build;
import android.widget.*;
import java.net.*;
import java.util.LinkedHashSet;
import java.io.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
    TextView status, peer, height, sync, log, headersHeight, connectionSource, connectionEndpoint, connectionDetail;
    Handler handler = new Handler();
    boolean running = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status=findViewById(R.id.status);
        peer=findViewById(R.id.peer);
        height=findViewById(R.id.height);
        sync=findViewById(R.id.sync);
        log=findViewById(R.id.log);
        headersHeight=findViewById(R.id.headers_height);
        connectionSource=findViewById(R.id.connectionSource);
        connectionEndpoint=findViewById(R.id.connectionEndpoint);
        connectionDetail=findViewById(R.id.connectionDetail);

        findViewById(R.id.start).setOnClickListener(v -> {
            Intent i = new Intent(this, NodeService.class); i.setAction(NodeService.START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            running=true; status.setText("● STARTING"); log.setText("Log: starting Ycash node process"); pollStatus();
        });

        findViewById(R.id.stop).setOnClickListener(v -> {
            Intent i = new Intent(this, NodeService.class); i.setAction(NodeService.STOP); startService(i);
            running=false; status.setText("● STOPPED"); sync.setText("Sync: stopped");
            connectionSource.setText("Connection source: None");
            connectionEndpoint.setText("Endpoint: —");
            connectionDetail.setText("Details: Node stopped");
            log.setText("Log: node stop requested");
        });

        findViewById(R.id.test).setOnClickListener(v -> testNetwork());
    }

    private void pollStatus() {
        if (!running) return;
        new Thread(() -> {
            try {
                URL u=new URL("http://127.0.0.1:8834/status");
                HttpURLConnection c=(HttpURLConnection)u.openConnection();
                c.setConnectTimeout(1500);
                c.setReadTimeout(1500);
                c.setRequestMethod("GET");
                if(c.getResponseCode()==200) {
                    BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));
                    StringBuilder s=new StringBuilder(); String line;
                    while((line=br.readLine())!=null) s.append(line);
                    JSONObject j=new JSONObject(s.toString());
                    runOnUiThread(() -> applyStatus(j));
                }
                c.disconnect();
            } catch(Exception ignored) {
                // Keep the last real values when the local API is temporarily unavailable.
            }
            handler.postDelayed(this::pollStatus, 2000);
        }).start();
    }

    private void applyStatus(JSONObject j) {
        try {
            status.setText("● "+j.optString("status","UNKNOWN").toUpperCase());
            peer.setText("Peers: "+j.optInt("peers",0));
            long blockHeight=j.optLong("height",-1);
            long headerHeight=j.optLong("headers_height",-1);
            height.setText("Block height: "+(blockHeight < 0 ? "—" : blockHeight));
            headersHeight.setText("Headers height: "+(headerHeight < 0 ? "—" : headerHeight));
            sync.setText("Sync: "+j.optString("sync","unknown"));
            connectionSource.setText("Connection source: "+j.optString("connection_source","None"));
            connectionEndpoint.setText("Endpoint: "+j.optString("connection_endpoint","—"));
            connectionDetail.setText("Details: "+j.optString("connection_detail","—"));
            log.setText("Log: "+j.optString("message","status updated"));
        } catch(Exception ignored) {}
    }

    private void testNetwork() {
        status.setText("● TESTING");
        connectionSource.setText("Connection source: testing all known sources");
        connectionEndpoint.setText("Endpoint: —");
        connectionDetail.setText("Details: DNS seed and fixed seeds will be tested in order");
        log.setText("Log: testing Ycash mainnet connection sources on TCP 8833…");
        new Thread(() -> {
            LinkedHashSet<String> seen = new LinkedHashSet<>();
            java.util.ArrayList<String[]> candidates = new java.util.ArrayList<>();

            try {
                for (InetAddress a : InetAddress.getAllByName("seed.ycash.xyz")) {
                    String endpoint=a.getHostAddress()+":8833";
                    if (seen.add(endpoint)) candidates.add(new String[]{"DNS Seed (seed.ycash.xyz)", endpoint, a.getHostAddress()});
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    connectionSource.setText("Connection source: DNS Seed (seed.ycash.xyz)");
                    connectionEndpoint.setText("Endpoint: —");
                    connectionDetail.setText("Details: DNS resolution failed; testing fixed seeds");
                    log.setText("Log: DNS seed unavailable: "+e.getClass().getSimpleName());
                });
            }

            String[][] fixed = {
                {"Fixed Seed #1", "3.130.144.65", "8833"},
                {"Fixed Seed #2", "13.126.58.237", "8833"}
            };
            for (String[] f : fixed) {
                String endpoint=f[1]+":"+f[2];
                if (seen.add(endpoint)) candidates.add(new String[]{f[0], endpoint, f[1]});
            }

            Exception last=null;
            for (String[] candidate : candidates) {
                final String source=candidate[0];
                final String endpoint=candidate[1];
                runOnUiThread(() -> {
                    connectionSource.setText("Connection source: "+source);
                    connectionEndpoint.setText("Endpoint: "+endpoint);
                    connectionDetail.setText("Details: attempting TCP connection");
                    log.setText("Log: trying "+source+" → "+endpoint);
                });
                try (Socket socket = new Socket()) {
                    socket.connect(new InetSocketAddress(candidate[2], 8833), 7000);
                    runOnUiThread(() -> {
                        status.setText("● NETWORK REACHABLE");
                        connectionSource.setText("Connection source: "+source);
                        connectionEndpoint.setText("Endpoint: "+endpoint);
                        connectionDetail.setText("Details: TCP connection succeeded (P2P handshake is tested by the node)");
                        log.setText("Log: "+source+" succeeded at "+endpoint);
                    });
                    return;
                } catch (Exception e) {
                    last=e;
                    runOnUiThread(() -> log.setText("Log: "+source+" failed at "+endpoint+": "+e.getClass().getSimpleName()));
                }
            }
            Exception failure=last;
            runOnUiThread(() -> {
                status.setText("● CONNECTION FAILED");
                connectionDetail.setText("Details: every known Ycash connection source failed");
                log.setText("Log: all Ycash connection sources failed: "+
                    (failure == null ? "unknown error" : failure.getClass().getSimpleName()+": "+failure.getMessage()));
            });
        }).start();
    }

}
