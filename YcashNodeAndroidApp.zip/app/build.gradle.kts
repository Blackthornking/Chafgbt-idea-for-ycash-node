plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "org.ycash.node"
    compileSdk = 35

    defaultConfig {
        applicationId = "org.ycash.node"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-node"

        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildFeatures { buildConfig = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    // ycashd is packaged as app/src/main/jniLibs/arm64-v8a/libycashd.so (a renamed
    // ELF executable, not a real .so) instead of as an asset. Files under jniLibs/
    // are installed by PackageManager into applicationInfo.nativeLibraryDir, which
    // is executable but not writable by the app -- required for Android 10+ (W^X)
    // to allow running it at all. See MainActivity.installDaemon()/startNode().
    packaging {
        jniLibs {
            useLegacyPackaging = true // store uncompressed so extraction is reliable
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
