package org.ycash.node

import android.graphics.Color
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var dashboard: TextView
    private lateinit var logs: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var saveIndexButton: Button

    private var daemon: Process? = null
    private var monitorJob: Job? = null
    private lateinit var dataDir: File
    private lateinit var indexDb: YTeleportIndexDb
    private var indexBuilding = false
    private var indexedTip = -1L
    private val checkpointStride = 1000L

    private val rpcUrl = "http://127.0.0.1:8832/"

    // ycashd will not start without the zk proving parameters. It looks for
    // them in $HOME/.zcash-params, and an Android app process has no HOME, so
    // it looked in /.zcash-params, found nothing, printed "Cannot find the
    // Ycash network parameters" and exited -- before RPC ever opened. That is
    // the "node not responding" state. The app now fetches them itself and
    // points ycashd at them with -paramsdir.
    //
    // Names and SHA-256 hashes are copied from zcutil/fetch-params.sh in the
    // bundled ycashd 4.5.0 source; Ycash uses the same parameters as Zcash.
    private val paramsBaseUrl = "https://download.z.cash/downloads"
    private val requiredParams = listOf(
        "sapling-spend.params" to "8e48ffd23abb3a5fd9c5589204f32d9c31285a04b78096ba40a79b75677efc13",
        "sapling-output.params" to "2f0ebbcbb9bb0bcffe95a397e7eba89c29eb4dde6191c339db88570e3f3fb0e4",
        "sprout-groth16.params" to "b685d700c60328498fbde589c8c7c484c722b788b265b72af448a5bf0ee55b50"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        dataDir = File(filesDir, "ycash")
        dataDir.mkdirs()
        ensureConfig()
        indexDb = YTeleportIndexDb(this, File(dataDir, "yteleport_index.db").absolutePath)

        buildUi()
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val c = indexDb.readableDatabase.rawQuery("SELECT value FROM metadata WHERE key = ?", arrayOf("indexed_tip"))
                c.use { if (it.moveToFirst()) indexedTip = it.getString(0).toLongOrNull() ?: -1L }
            } catch (_: Exception) {}
        }

        lifecycleScope.launch(Dispatchers.IO) {
            val bin = daemonBinary()
            runOnUiThread {
                if (daemonAvailable()) {
                    status.text = "READY"
                    dashboard.text = "Daemon: packaged\nExecutable: ${bin.absolutePath}\nData: ${dataDir.absolutePath}\nRPC: 127.0.0.1:8832 (local only)"
                    startButton.isEnabled = true
                } else {
                    status.text = "DAEMON NOT INSTALLED"
                    dashboard.text = "ycashd was not packaged into the native library directory.\nExpected: ${bin.absolutePath}"
                    startButton.isEnabled = false
                }
            }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val title = TextView(this).apply {
            text = "Ycash Node"
            textSize = 30f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.BLACK)
            setPadding(20, 20, 20, 20)
            gravity = Gravity.CENTER_VERTICAL
        }

        status = TextView(this).apply {
            text = "STARTING"
            textSize = 18f
            setPadding(0, 20, 0, 8)
        }

        dashboard = TextView(this).apply {
            textSize = 16f
            setPadding(0, 8, 0, 16)
        }

        startButton = Button(this).apply {
            text = "START NODE"
            isEnabled = false
            setOnClickListener { startNode() }
        }

        saveIndexButton = Button(this).apply {
            text = "SAVE YTELEPORT INDEX AS TEXT"
            isEnabled = false
            setOnClickListener { saveIndexAsText() }
        }

        stopButton = Button(this).apply {
            text = "STOP NODE"
            setOnClickListener { stopNode() }
        }

        val logTitle = TextView(this).apply {
            text = "Node log"
            textSize = 18f
            setPadding(0, 16, 0, 8)
        }

        logs = TextView(this).apply {
            textSize = 12f
            setPadding(0, 0, 0, 16)
        }

        val scroll = ScrollView(this).apply {
            addView(logs)
        }

        root.addView(title)
        root.addView(status)
        root.addView(dashboard)
        root.addView(startButton)
        root.addView(saveIndexButton)
        root.addView(stopButton)
        root.addView(logTitle)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    // The daemon is packaged by the CI workflow as:
    //   app/src/main/jniLibs/arm64-v8a/libycashd.so
    //
    // Android installs that file into applicationInfo.nativeLibraryDir.
    // Do NOT copy the executable into filesDir/cacheDir/codeCacheDir and try
    // to chmod/execute it there: Android 10+ W^X prevents executing binaries
    // from app-writable storage and that produces error=13 (EACCES).
    private fun daemonBinary(): File {
        return File(applicationInfo.nativeLibraryDir, "libycashd.so")
    }

    // ycashd refuses to start without a configuration file, by design.
    //
    // Its own message explains why: an empty file is a positive statement
    // that you accept the defaults, rather than a default being applied
    // silently to something privacy-sensitive. On a desktop you would write
    // it yourself; here the app has to, because there is no shell.
    //
    // Written once and never overwritten, so anything added by hand
    // survives an app update.
    private fun ensureConfig() {
        val conf = File(dataDir, "ycash.conf")
        if (conf.exists()) return
        conf.writeText(
            """
# Created by the Ycash Node app on first run.
# ycashd requires this file to exist; an empty one would also be valid
# and would mean that the defaults are fine.
#
# These mirror the flags the app passes on the command line, so the node
# behaves the same however it is started.

# Keep the whole chain. Pruning would break the YTeleport index, which
# needs historical blocks to build checkpoints from.
prune=0

# RPC is bound to loopback only and never exposed off the device.
# Authentication uses the .cookie file ycashd writes beside this one,
# so no password is stored here.
rpcbind=127.0.0.1
rpcallowip=127.0.0.1
rpcport=8832

# Accept inbound connections and discover peers normally.
listen=1
discover=1

# Initial block download tuning. These mirror the command line; change them
# here and they apply however the node is started.
#
# fastsync: skip transaction verification below the last built-in checkpoint
# (block 2,250,000 of roughly 3,030,000). Proof-of-work is still checked on
# every block and everything above the checkpoint is fully validated. This is
# ycashd's own option; the trust it asks for is in the checkpoints compiled
# into the binary, not in any peer or server.
fastsync=1

# UTXO cache in MB. Every miss is a random read from flash, so this is the
# biggest remaining win after fastsync. Deliberately below what the phone
# could afford: it is native memory, and Android's low-memory killer will
# take the process without regard for what it is doing.
dbcache=512

# No loose transaction relay while syncing -- pure overhead during catch-up.
blocksonly=1

# Do not serve the chain to others while still downloading it, in MB.
maxuploadtarget=100

# More peers means more blocks in flight: up to 16 are requested from each
# peer at once.
maxconnections=32
            """.trimIndent()
        )
    }

    private fun paramsDir(): File = File(filesDir, "ycash-params").apply { mkdirs() }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(1 shl 16)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun setProgress(state: String, detail: String) {
        runOnUiThread {
            status.text = state
            dashboard.text = detail
        }
    }

    // Downloads one part, resuming from whatever is already on disk.
    private fun downloadPart(url: String, dest: File, label: String) {
        var attempt = 0
        while (true) {
            attempt++
            val have = if (dest.exists()) dest.length() else 0L
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000
                readTimeout = 30000
                instanceFollowRedirects = true
                if (have > 0) setRequestProperty("Range", "bytes=$have-")
            }
            try {
                val code = conn.responseCode
                if (code == 416) return // already complete
                if (code != 200 && code != 206) throw IllegalStateException("HTTP $code for $url")
                val append = code == 206
                val total = if (append) have + conn.contentLengthLong else conn.contentLengthLong
                var done = if (append) have else 0L
                var lastUi = 0L
                conn.inputStream.use { input ->
                    java.io.FileOutputStream(dest, append).use { out ->
                        val buf = ByteArray(1 shl 16)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (now - lastUi > 500) {
                                lastUi = now
                                val pct = if (total > 0) " (${done * 100 / total}%)" else ""
                                setProgress(
                                    "DOWNLOADING PARAMETERS",
                                    "$label\n${formatBytes(done)} of ${if (total > 0) formatBytes(total) else "?"}$pct\n\n" +
                                        "ycashd needs these zk parameter files before it can start.\n" +
                                        "About 780 MB in total, downloaded once. Wi-Fi recommended."
                                )
                            }
                        }
                    }
                }
                return
            } catch (e: Exception) {
                if (attempt >= 5) throw e
                Thread.sleep(3000L * attempt)
            } finally {
                conn.disconnect()
            }
        }
    }

    private fun ensureParams() {
        val dir = paramsDir()
        for ((name, hash) in requiredParams) {
            val out = File(dir, name)
            if (out.isFile && out.length() > 0) continue

            val dl = File(dir, "$name.dl")
            for (i in 1..2) {
                downloadPart("$paramsBaseUrl/$name.part.$i", File(dir, "$name.dl.part.$i"), "$name, part $i of 2")
            }

            setProgress("VERIFYING PARAMETERS", "Checking SHA-256 of $name…")
            dl.outputStream().use { o ->
                for (i in 1..2) File(dir, "$name.dl.part.$i").inputStream().use { it.copyTo(o) }
            }
            val actual = sha256(dl)
            if (actual != hash) {
                dl.delete()
                for (i in 1..2) File(dir, "$name.dl.part.$i").delete()
                throw IllegalStateException("$name failed its checksum and was deleted. Tap START NODE to download it again.")
            }
            for (i in 1..2) File(dir, "$name.dl.part.$i").delete()
            if (!dl.renameTo(out)) throw IllegalStateException("Could not move $name into place")
        }
    }

    private fun daemonAvailable(): Boolean {
        val bin = daemonBinary()
        return bin.isFile && bin.length() > 0L && bin.canExecute()
    }

    private fun startNode() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val bin = daemonBinary()
                if (!daemonAvailable()) {
                    throw IllegalStateException("ycashd is not executable from nativeLibraryDir: ${bin.absolutePath}")
                }
                if (daemon?.isAlive == true) return@launch

                // Report what is actually on disk before launching.
                //
                // "cannot locate symbol ..." has now been chased twice on
                // theory alone -- first the library was missing, then the
                // linker was not told where to look. Rather than guess a
                // third time, list nativeLibraryDir and the environment the
                // process will get. One run then answers whether
                // libc++_shared.so is present at all, which distinguishes a
                // packaging problem from a lookup problem.
                val libDirPath = applicationInfo.nativeLibraryDir
                val libDirFile = File(libDirPath)
                val listing = (libDirFile.listFiles() ?: emptyArray())
                    .sortedBy { it.name }
                    .joinToString("\n") { f ->
                        "  ${f.name}  ${f.length()} bytes  exec=${f.canExecute()}"
                    }
                    .ifEmpty { "  (empty or unreadable)" }

                // Which build is this, really.
                //
                // Three consecutive launches produced a byte-identical
                // daemon, which only showed up by comparing sizes across
                // screenshots. The fingerprint is written by CI at package
                // time, so a stale install is obvious immediately rather
                // than after another round of theorising.
                val fingerprint = try {
                    assets.open("ycashd-build.txt").bufferedReader().readText().trim()
                } catch (_: Exception) {
                    "(no build fingerprint — built before this was added)"
                }

                val diagnostics = buildString {
                    appendLine("ycashd build:")
                    appendLine(fingerprint.prependIndent("  "))
                    appendLine()
                    appendLine("nativeLibraryDir: $libDirPath")
                    appendLine(listing)
                    // Not an error any more: the C++ runtime is linked into
                    // the daemon, so this file is optional.
                    appendLine("libc++_shared.so present (optional): " +
                        File(libDirFile, "libc++_shared.so").isFile)
                }

                runOnUiThread {
                    status.text = "STARTING NODE…"
                    startButton.isEnabled = false
                    logs.text = diagnostics
                }

                ensureParams()
                appendLog("zk parameters: present in ${paramsDir().absolutePath}")

                val builder = ProcessBuilder(
                    bin.absolutePath,
                    "-datadir=${dataDir.absolutePath}",
                    "-paramsdir=${paramsDir().absolutePath}",
                    "-daemon=0",
                    "-listen=1",
                    "-discover=1",
                    // Keep the complete blockchain on disk. Do not enable pruning.
                    "-prune=0",
                    "-rpcbind=127.0.0.1",
                    "-rpcallowip=127.0.0.1",
                    "-rpcport=8832",
                    "-printtoconsole=1",

                    // ---- initial block download tuning ----
                    //
                    // Skip transaction verification for blocks below the last
                    // built-in checkpoint (2,250,000 of roughly 3,030,000, so
                    // about three quarters of the chain). Proof-of-work is
                    // still verified on every block, and everything above the
                    // checkpoint is validated in full.
                    //
                    // This is the single largest saving available and it is
                    // ycashd's own feature, not a shortcut around it. The
                    // trust it asks for is in the checkpoints compiled into
                    // the binary you are already running -- not in a peer or
                    // a server. Zero-knowledge proof verification below
                    // checkpoints is skipped by ycashd regardless.
                    "-fastsync=1",

                    // The UTXO cache. Every miss is a random read from flash.
                    // The 450 MB default is tuned for desktops; raising it is
                    // the biggest remaining IBD win after -fastsync. Held
                    // deliberately below what the phone could afford, because
                    // this is native memory and Android's low-memory killer
                    // does not care that the app is busy.
                    "-dbcache=512",

                    // Do not relay or accept loose transactions while syncing.
                    // Mempool traffic is pure overhead during a catch-up and
                    // costs mobile data for nothing.
                    "-blocksonly=1",

                    // Cap what this node uploads to others. A phone on a
                    // metered connection should not be serving the chain to
                    // the network while it is still downloading it.
                    "-maxuploadtarget=100",

                    // More peers means more blocks in flight: ycashd requests
                    // up to 16 blocks from each peer concurrently, so the
                    // download rate scales with peer count until bandwidth
                    // saturates. Kept modest -- Ycash is a small network and
                    // there may not be many peers to find.
                    "-maxconnections=32"
                ).redirectErrorStream(true)

                // Tell the dynamic linker where ycashd's own libraries live.
                //
                // ycashd links against the NDK's shared libc++, and that
                // library ships in nativeLibraryDir right next to the binary.
                // But a process started with ProcessBuilder inherits no
                // LD_LIBRARY_PATH, and the linker does not search a binary's
                // own directory by default -- so it never looked there and
                // failed with:
                //
                //   cannot locate symbol "_ZTVNSt6__ndk119basic_ostringstream..."
                //
                // which is a libc++ vtable. The library was present the whole
                // time; nothing was looking for it in the right place.
                val existing = System.getenv("LD_LIBRARY_PATH")
                val ldPath =
                    if (existing.isNullOrEmpty()) libDirPath else "$libDirPath:$existing"
                builder.environment()["LD_LIBRARY_PATH"] = ldPath
                // Android gives app processes no HOME. Anything in ycashd that
                // falls back to $HOME would otherwise resolve to "/".
                builder.environment()["HOME"] = filesDir.absolutePath

                runOnUiThread {
                    logs.append("LD_LIBRARY_PATH=$ldPath\n\n")
                }

                val proc = builder.start()

                daemon = proc

                runOnUiThread {
                    status.text = "RUNNING — FULL BLOCKCHAIN SYNC"
                    startButton.isEnabled = false
                }

                startMonitoring()

                proc.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { line ->
                        appendLog(line)
                    }
                }

                val exitCode = proc.waitFor()
                monitorJob?.cancel()
                daemon = null
                runOnUiThread {
                    // Say that the daemon died, and how, instead of leaving the
                    // screen to guess "not responding". The reason is in the log.
                    status.text = if (exitCode == 0) "STOPPED" else "NODE EXITED (code $exitCode)"
                    dashboard.text = "ycashd is no longer running. Its last messages are in the node log below."
                    startButton.isEnabled = true
                }
            } catch (e: Exception) {
                monitorJob?.cancel()
                runOnUiThread {
                    status.text = "START FAILED"
                    dashboard.text = e.message ?: "Unknown error"
                    startButton.isEnabled = true
                }
            }
        }
    }

    private fun startMonitoring() {
        monitorJob?.cancel()
        monitorJob = lifecycleScope.launch(Dispatchers.IO) {
            while (isActive && daemon?.isAlive == true) {
                updateDashboard()
                delay(2000)
            }
        }
    }

    private fun updateDashboard() {
        try {
            val chain = rpc("getblockchaininfo")
            val network = rpc("getnetworkinfo")
            val peers = rpc("getpeerinfo")

            val chainName = chain.optString("chain", "unknown")
            val blocks = chain.optLong("blocks", 0L)
            val headers = chain.optLong("headers", blocks)
            val progress = chain.optDouble("verificationprogress", 0.0)
            val initialDownload = chain.optBoolean("initial_block_download", false)
            val diskBytes = chain.optLong("size_on_disk", calculateDataSize(dataDir))

            val connections = network.optInt("connections", peers.length())
            val version = network.optString("subversion", "unknown")
            val protocol = network.optInt("protocolversion", 0)

            val percent = (progress * 100.0).coerceIn(0.0, 100.0)
            val syncState = when {
                initialDownload -> "SYNCING"
                headers > blocks -> "CATCHING UP"
                else -> "SYNCHRONIZED"
            }

            if (!initialDownload && headers <= blocks && blocks >= 0) {
                buildIndexIfNeeded(blocks, chainName)
            }

            val text = buildString {
                appendLine("$syncState")
                appendLine()
                appendLine("Block height       $blocks")
                appendLine("Network headers    $headers")
                appendLine(String.format(Locale.US, "Verification        %.2f%%", percent))
                appendLine("Peers              $connections")
                appendLine("Chain              $chainName")
                appendLine("Node version       $version")
                appendLine("Protocol           $protocol")
                appendLine("Blockchain data    ${formatBytes(diskBytes)}")
                appendLine("RPC                LOCAL ONLY (127.0.0.1:8832)")
                appendLine()
                appendLine("YTeleport Index    ${if (indexedTip >= blocks && blocks > 0) "READY" else if (indexBuilding) "BUILDING" else "NOT BUILT"}")
                appendLine("Index database     ${File(dataDir, "yteleport_index.db").absolutePath}")
                appendLine("Checkpoint stride  $checkpointStride blocks")
                appendLine("ProofSkip           NOT IMPLEMENTED")
                appendLine("BridgeSkip          NOT IMPLEMENTED")
            }

            runOnUiThread {
                status.text = syncState
                dashboard.text = text
            }
        } catch (e: Exception) {
            runOnUiThread {
                if (daemon?.isAlive == true) {
                    status.text = "RUNNING — RPC WAITING"
                    dashboard.text = "Node process is running, but RPC status is not available yet.\n\nRPC: 127.0.0.1:8832 (local only)\n${e.message ?: "Waiting for daemon RPC…"}"
                }
            }
        }
    }

    private fun buildIndexIfNeeded(tipHeight: Long, chainName: String) {
        if (indexBuilding || tipHeight <= 0L) return
        if (indexedTip >= tipHeight) {
            runOnUiThread { saveIndexButton.isEnabled = true }
            return
        }
        indexBuilding = true
        runOnUiThread {
            saveIndexButton.isEnabled = false
            dashboard.text = dashboard.text.toString() + "\n\nBuilding YTeleport checkpoint index…"
        }
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                indexDb.putMetadata("chain", chainName)
                indexDb.putMetadata("tip_height", tipHeight.toString())
                indexDb.putMetadata("checkpoint_stride", checkpointStride.toString())
                indexDb.putMetadata("format_version", "1")
                indexDb.putMetadata("created_or_updated", System.currentTimeMillis().toString())

                var height = 0L
                while (height <= tipHeight) {
                    addBlockCheckpoint(height)
                    height += checkpointStride
                }
                if (tipHeight % checkpointStride != 0L) addBlockCheckpoint(tipHeight)
                indexedTip = tipHeight
                indexDb.putMetadata("indexed_tip", tipHeight.toString())
                runOnUiThread {
                    saveIndexButton.isEnabled = true
                    dashboard.text = dashboard.text.toString().replace("Building YTeleport checkpoint index…", "YTeleport checkpoint index READY")
                }
            } catch (e: Exception) {
                appendLog("YTeleport index build failed: ${e.message ?: "unknown error"}")
            } finally {
                indexBuilding = false
            }
        }
    }

    private fun addBlockCheckpoint(height: Long) {
        val hashResult = rpcWithParams("getblockhash", JSONArray().put(height))
        val hash = hashResult.optString("result", "")
        if (hash.isEmpty()) throw IllegalStateException("No block hash for height $height")
        val header = rpcWithParams("getblockheader", JSONArray().put(hash))
        indexDb.addCheckpoint(
            height = height,
            hash = header.optString("hash", hash),
            previousHash = header.optString("previousblockhash", null),
            time = if (header.has("time")) header.optLong("time") else null,
            medianTime = if (header.has("mediantime")) header.optLong("mediantime") else null,
            nTx = if (header.has("nTx")) header.optLong("nTx") else null,
            chainwork = header.optString("chainwork", null)
        )
    }

    private fun rpcWithParams(method: String, params: JSONArray): JSONObject {
        val cookieFile = File(dataDir, ".cookie")
        if (!cookieFile.exists()) throw IllegalStateException("RPC cookie not available yet")
        val cookie = cookieFile.readText().trim()
        val connection = (URL(rpcUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 3000
            readTimeout = 8000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Basic " + android.util.Base64.encodeToString(cookie.toByteArray(), android.util.Base64.NO_WRAP))
        }
        try {
            val request = JSONObject().apply {
                put("jsonrpc", "1.0")
                put("id", "ycash-node-index")
                put("method", method)
                put("params", params)
            }
            connection.outputStream.use { it.write(request.toString().toByteArray()) }
            val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            val error = json.opt("error")
            if (error != null && error != JSONObject.NULL) throw IllegalStateException(error.toString())
            return json
        } finally { connection.disconnect() }
    }

    private fun saveIndexAsText() {
        if (indexedTip <= 0L || indexBuilding) return
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "ycash_yteleport_checkpoint_index.txt")
        }
        startActivityForResult(intent, 4101)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 4101 || resultCode != RESULT_OK || data?.data == null) return
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter()?.use { it.write(indexDb.exportText()) }
                runOnUiThread { appendLog("YTeleport index saved as text file") }
            } catch (e: Exception) {
                appendLog("Could not save index: ${e.message ?: "unknown error"}")
            }
        }
    }

    private fun rpc(method: String): JSONObject {
        val cookieFile = File(dataDir, ".cookie")
        if (!cookieFile.exists()) {
            throw IllegalStateException("RPC cookie not available yet")
        }

        val cookie = cookieFile.readText().trim()
        val connection = (URL(rpcUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 1500
            readTimeout = 2500
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Basic " + android.util.Base64.encodeToString(cookie.toByteArray(), android.util.Base64.NO_WRAP))
        }

        try {
            val request = JSONObject().apply {
                put("jsonrpc", "1.0")
                put("id", "ycash-node-dashboard")
                put("method", method)
                put("params", JSONArray())
            }

            connection.outputStream.use { it.write(request.toString().toByteArray()) }
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(response)
            val error = json.opt("error")
            if (error != null && error != JSONObject.NULL) {
                throw IllegalStateException(error.toString())
            }
            return json.optJSONObject("result") ?: throw IllegalStateException("Invalid RPC response")
        } finally {
            connection.disconnect()
        }
    }

    private fun appendLog(line: String) {
        runOnUiThread {
            val current = logs.text.toString()
            val updated = (current + line + "\n").takeLast(12000)
            logs.text = updated
        }
    }

    private fun calculateDataSize(dir: File): Long {
        if (!dir.exists()) return 0L
        return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var index = -1
        while (value >= 1024 && index < units.lastIndex) {
            value /= 1024.0
            index++
        }
        return String.format(Locale.US, "%.2f %s", value, units[index])
    }

    private fun stopNode() {
        monitorJob?.cancel()
        daemon?.destroy()
        daemon = null
        status.text = "STOPPED"
        dashboard.text = "Node stopped\nData: ${dataDir.absolutePath}\nRPC: local only"
        startButton.isEnabled = daemonAvailable()
    }

    override fun onDestroy() {
        monitorJob?.cancel()
        daemon?.destroy()
        daemon = null
        super.onDestroy()
    }
}
