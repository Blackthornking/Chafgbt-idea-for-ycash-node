package org.ycash.node

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class YTeleportIndexDb(context: Context, dbFile: String) : SQLiteOpenHelper(context, dbFile, null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        db.execSQL("""
            CREATE TABLE checkpoints (
                height INTEGER PRIMARY KEY,
                hash TEXT NOT NULL,
                previous_hash TEXT,
                time INTEGER,
                mediantime INTEGER,
                n_tx INTEGER,
                chainwork TEXT,
                indexed_at INTEGER NOT NULL
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_checkpoints_hash ON checkpoints(hash)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS checkpoints")
        db.execSQL("DROP TABLE IF EXISTS metadata")
        onCreate(db)
    }

    fun putMetadata(key: String, value: String) {
        writableDatabase.insertWithOnConflict(
            "metadata", null,
            ContentValues().apply { put("key", key); put("value", value) },
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun addCheckpoint(
        height: Long,
        hash: String,
        previousHash: String?,
        time: Long?,
        medianTime: Long?,
        nTx: Long?,
        chainwork: String?
    ) {
        writableDatabase.insertWithOnConflict(
            "checkpoints", null,
            ContentValues().apply {
                put("height", height)
                put("hash", hash)
                if (previousHash == null) putNull("previous_hash") else put("previous_hash", previousHash)
                if (time == null) putNull("time") else put("time", time)
                if (medianTime == null) putNull("mediantime") else put("mediantime", medianTime)
                if (nTx == null) putNull("n_tx") else put("n_tx", nTx)
                if (chainwork == null) putNull("chainwork") else put("chainwork", chainwork)
                put("indexed_at", System.currentTimeMillis() / 1000L)
            },
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun exportText(): String {
        val out = StringBuilder()
        out.appendLine("# Ycash YTeleport checkpoint index")
        out.appendLine("# Generated locally by Ycash Node Android")
        out.appendLine("# This is a checkpoint/index export, not a standalone proof.")
        out.appendLine()
        out.appendLine("[metadata]")
        readableQuery("SELECT key, value FROM metadata ORDER BY key").use { c ->
            while (c.moveToNext()) out.appendLine("${c.getString(0)}=${c.getString(1)}")
        }
        out.appendLine()
        out.appendLine("[checkpoints]")
        out.appendLine("height\thash\tprevious_hash\ttime\tmediantime\tn_tx\tchainwork\tindexed_at")
        readableQuery("SELECT height, hash, previous_hash, time, mediantime, n_tx, chainwork, indexed_at FROM checkpoints ORDER BY height").use { c ->
            while (c.moveToNext()) {
                fun s(i: Int): String = if (c.isNull(i)) "" else c.getString(i)
                out.appendLine(listOf(s(0), s(1), s(2), s(3), s(4), s(5), s(6), s(7)).joinToString("\t"))
            }
        }
        return out.toString()
    }

    private fun readableQuery(sql: String) = readableDatabase.rawQuery(sql, null)
}
