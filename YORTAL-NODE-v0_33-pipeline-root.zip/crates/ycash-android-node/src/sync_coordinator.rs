//! Android sync coordinator.
//!
//! Each peer runs on its own thread with a blocking socket, which suits the
//! streaming downloader exactly: the thread asks for up to 48 blocks, then
//! services whatever arrives, handing each block to the verifier pool and
//! immediately refilling the freed slot. No peer waits for another peer, and no
//! block waits for 47 siblings.
//!
//! This module owns none of the consensus logic. It is the glue between the
//! app's existing P2P session loop and [`ycash_node::SyncEngine`].

use std::net::TcpStream;
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::time::{Duration, Instant};

use ycash_node::{PeerDownloadSession, SyncConfig, SyncEngine};
use ycash_state::State;

use crate::runtime::SharedState;
use crate::{read_message, send};

pub use ycash_node::{ASSUME_VALID_HASH_DISPLAY, ASSUME_VALID_HEIGHT, MAX_BLOCKS_IN_TRANSIT_PER_PEER};

/// How often a peer thread republishes pipeline telemetry.
const TELEMETRY_INTERVAL: Duration = Duration::from_millis(500);

#[derive(Clone)]
pub struct SyncCoordinator {
    engine: SyncEngine,
}

impl SyncCoordinator {
    pub fn start(state: Arc<State>) -> std::io::Result<Self> {
        let engine = SyncEngine::start(state, SyncConfig::from_env())
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))?;
        Ok(Self { engine })
    }

    pub fn verify_threads(&self) -> usize {
        self.engine.config.verifier_workers
    }

    pub fn session(&self, peer: &str) -> PeerDownloadSession {
        self.engine.session(peer)
    }

    /// Reconsider the candidate tree after the header chain moved.
    pub fn headers_advanced(&self) {
        let _ = self.engine.assigner.rewind_to_canonical();
        self.engine.poke();
    }

    /// Ask this peer for more blocks, if its window has room and the header
    /// chain has something to offer. Returns the number of blocks requested.
    pub fn request_more(&self, stream: &mut TcpStream, session: &mut PeerDownloadSession) -> std::io::Result<usize> {
        let hashes = self
            .engine
            .next_requests(session)
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))?;
        if hashes.is_empty() {
            return Ok(0);
        }
        send(stream, "getdata", &ycash_network::runtime::getdata_payload(&hashes))?;
        Ok(hashes.len())
    }

    /// Feed one `block` message into the pipeline.
    pub fn on_block(&self, session: &mut PeerDownloadSession, raw: Vec<u8>) -> bool {
        match self.engine.on_block_message(session, raw) {
            Ok(accepted) => accepted,
            Err(e) => {
                eprintln!("[SYNC] verifier submit failed: {e}");
                false
            }
        }
    }

    /// Copy the live counters into the dashboard's shared state.
    pub fn publish_telemetry(&self, live: &SharedState) {
        let m = &self.engine.metrics;
        let canonical = m.canonical_height.load(Ordering::Relaxed);
        let mut st = live.write().unwrap();
        if canonical > 0 {
            st.local_height = canonical;
        }
        st.pipeline_inflight_ranges = m.blocks_in_flight_total.load(Ordering::Relaxed);
        st.pipeline_pending_ranges = m.prospective_blocks.load(Ordering::Relaxed);
        st.pipeline_verify_threads = m.verifier_workers.load(Ordering::Relaxed);
        st.pipeline_commit_batch = m.last_publication_blocks.load(Ordering::Relaxed);
        st.pipeline_active_range_len = self.engine.config.blocks_in_transit_per_peer as u64;
        st.pipeline_max_range_len = self.engine.config.blocks_in_transit_per_peer as u64;
        st.pipeline_lookahead = self.engine.config.max_blocks_in_flight as u64;
        st.blocks_received = m.blocks_downloaded.load(Ordering::Relaxed);
        st.block_bytes_received = m.bytes_downloaded.load(Ordering::Relaxed);
        st.blocks_validated = m.committed_blocks.load(Ordering::Relaxed);
        st.blocks_in_flight = m.blocks_in_flight_total.load(Ordering::Relaxed);
        st.validation_queue = m.semantic_queue.load(Ordering::Relaxed);
        st.buffered_ranges = m.prospective_blocks.load(Ordering::Relaxed);
        st.completed_ranges = m.committed_blocks.load(Ordering::Relaxed);
        st.batch_size = m.last_publication_blocks.load(Ordering::Relaxed);
    }

    pub fn canonical_height(&self) -> u64 {
        self.engine.metrics.canonical_height.load(Ordering::Relaxed)
    }
}

/// Drive one peer's block streaming for a single pass of its session loop.
///
/// Returns true when the peer did block work, so the caller can keep looping
/// without falling through to its idle handling.
pub fn drive_peer(
    coordinator: &SyncCoordinator,
    stream: &mut TcpStream,
    session: &mut PeerDownloadSession,
    live: &SharedState,
    last_telemetry: &mut Instant,
) -> std::io::Result<bool> {
    let requested = coordinator.request_more(stream, session)?;
    if last_telemetry.elapsed() >= TELEMETRY_INTERVAL {
        coordinator.publish_telemetry(live);
        *last_telemetry = Instant::now();
    }
    if session.in_flight() == 0 {
        return Ok(requested > 0);
    }

    // Service whatever the peer has sent. One arrival frees one slot, which the
    // next call refills: there is no "wait for the batch" state.
    match read_message(stream) {
        Ok((cmd, payload)) => match cmd.as_str() {
            "block" => {
                coordinator.on_block(session, payload);
                Ok(true)
            }
            "ping" => {
                send(stream, "pong", &payload)?;
                Ok(true)
            }
            "notfound" => {
                // The peer does not have what it was asked for. Release the
                // claims so another peer can supply them; the hashes are not
                // blamed for the peer's answer.
                session.expire_stale(Duration::from_secs(0));
                Ok(true)
            }
            _ => Ok(false),
        },
        Err(e) if crate::is_timeout(&e) => {
            session.expire_stale(ycash_node::REQUEST_TIMEOUT);
            Ok(false)
        }
        Err(e) => Err(e),
    }
}
