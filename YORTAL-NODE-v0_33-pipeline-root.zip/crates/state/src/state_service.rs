//! The ordered canonical gate.
//!
//! Everything upstream of this module is allowed to run out of order and in
//! parallel: downloading, parsing, semantic verification. Everything from here
//! on is strictly ordered by ancestry, because that is what Ycash consensus
//! requires and the only thing that must not be parallelised.
//!
//! The service owns:
//!   * the prospective candidate tree,
//!   * chain selection (most cumulative work, deterministic tie-break),
//!   * contextual consensus validation, via the unchanged
//!     [`State::prepare_commit_batch`],
//!   * and the single [`BlockWriteWorker`] that publishes the result.
//!
//! What it never does is decide what a valid block is. Contextual rules live
//! where they already lived; this module decides only *when* they run and in
//! *what order* their results are published.

use anyhow::{anyhow, Result};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::mpsc::{sync_channel, Receiver, SyncSender};
use std::sync::Arc;
use std::thread;
use std::time::Instant;

use ycash_chain::genesis_hash_internal;

use crate::commit::{BlockWriteWorker, WriteMetrics};
use crate::prospective::{ProspectiveBlockSet, SemanticBlock};
use crate::{BlockCommit, State};

/// Blocks per RocksDB publication. Storage batching only: it bounds WriteBatch
/// size and nothing else. Changing it cannot change which blocks are accepted.
pub const MAX_BLOCKS_PER_PUBLICATION: usize = 48;

/// Candidates held in memory while waiting for parent state. Resource bound.
pub const DEFAULT_PROSPECTIVE_CAPACITY: usize = 192;

/// Deepest reorganisation the service will select, matching the depth beyond
/// which the state layer stops retaining spent outputs.
pub const MAX_REORG_DEPTH: u64 = 100;

/// Live pipeline counters. Every field is diagnostics only; none of them feeds
/// a consensus decision.
#[derive(Debug, Default)]
pub struct SyncMetrics {
    // heights, kept separate so a stall can be attributed to one stage
    pub highest_header_height: AtomicU64,
    pub download_height: AtomicU64,
    pub highest_semantically_verified_height: AtomicU64,
    pub highest_contextually_verified_height: AtomicU64,
    pub canonical_height: AtomicU64,

    // queues and transport
    pub peers: AtomicU64,
    pub blocks_in_flight_total: AtomicU64,
    pub prospective_blocks: AtomicU64,
    pub semantic_queue: AtomicU64,
    pub contextual_queue: AtomicU64,
    pub verifier_workers: AtomicU64,

    // outcomes
    pub blocks_downloaded: AtomicU64,
    pub bytes_downloaded: AtomicU64,
    pub committed_blocks: AtomicU64,
    pub reorgs: AtomicU64,
    pub invalid_blocks: AtomicU64,
    pub duplicate_blocks: AtomicU64,
    pub stalled_parent_waits: AtomicU64,
    pub evicted_prospective: AtomicU64,
    pub expired_requests: AtomicU64,

    // timings (microseconds)
    pub semantic_verify_us: AtomicU64,
    pub contextual_prepare_us: AtomicU64,
    pub database_write_us: AtomicU64,
    pub last_publication_blocks: AtomicU64,
}

impl SyncMetrics {
    pub fn new() -> Arc<Self> {
        Arc::new(Self::default())
    }

    fn raise(field: &AtomicU64, value: u64) {
        let mut current = field.load(Ordering::Relaxed);
        while value > current {
            match field.compare_exchange_weak(current, value, Ordering::Relaxed, Ordering::Relaxed) {
                Ok(_) => break,
                Err(observed) => current = observed,
            }
        }
    }

    pub fn raise_semantic_height(&self, height: u64) {
        Self::raise(&self.highest_semantically_verified_height, height);
    }

    pub fn raise_download_height(&self, height: u64) {
        Self::raise(&self.download_height, height);
    }

    pub fn raise_header_height(&self, height: u64) {
        Self::raise(&self.highest_header_height, height);
    }
}

/// One semantically verified block offered to the canonical gate.
pub enum StateRequest {
    Block(Box<SemanticBlock>),
    /// Reconsider the candidate tree, e.g. after the header chain advanced.
    Poke,
}

/// Handle used by verifier threads to hand work to the ordered gate.
#[derive(Clone)]
pub struct StateServiceHandle {
    tx: SyncSender<StateRequest>,
    metrics: Arc<SyncMetrics>,
}

impl StateServiceHandle {
    /// Offer a semantically verified block. Blocks the caller when the gate is
    /// saturated: that is the backpressure signal for the verifier pool, and it
    /// never rejects the block.
    pub fn offer(&self, block: SemanticBlock) -> Result<()> {
        self.metrics.contextual_queue.fetch_add(1, Ordering::Relaxed);
        self.tx
            .send(StateRequest::Block(Box::new(block)))
            .map_err(|_| anyhow!("state service stopped"))
    }

    pub fn poke(&self) {
        let _ = self.tx.try_send(StateRequest::Poke);
    }

    pub fn metrics(&self) -> Arc<SyncMetrics> {
        Arc::clone(&self.metrics)
    }
}

pub struct StateService {
    state: Arc<State>,
    writer: BlockWriteWorker,
    prospective: ProspectiveBlockSet,
    metrics: Arc<SyncMetrics>,
}

impl StateService {
    pub fn new(state: Arc<State>, capacity: usize, metrics: Arc<SyncMetrics>) -> Result<Self> {
        let writer = BlockWriteWorker::new(Arc::clone(&state))?;
        Ok(Self { state, writer, prospective: ProspectiveBlockSet::new(capacity), metrics })
    }

    pub fn write_metrics(&self) -> Arc<WriteMetrics> {
        self.writer.metrics()
    }

    /// Start the gate on its own thread and return the handle verifiers use.
    pub fn spawn(state: Arc<State>, capacity: usize, metrics: Arc<SyncMetrics>) -> Result<StateServiceHandle> {
        let mut service = Self::new(state, capacity, Arc::clone(&metrics))?;
        let (tx, rx): (SyncSender<StateRequest>, Receiver<StateRequest>) = sync_channel(capacity.max(8));
        let handle = StateServiceHandle { tx, metrics: Arc::clone(&metrics) };
        thread::Builder::new()
            .name("yortal-state".into())
            .spawn(move || {
                while let Ok(request) = rx.recv() {
                    service.absorb(request);
                    // Absorb everything already queued before advancing. Each
                    // publication then carries the longest run available
                    // instead of one block at a time, without waiting for work
                    // that has not arrived: no linger timer, no added latency.
                    while let Ok(next) = rx.try_recv() {
                        service.absorb(next);
                    }
                    if let Err(e) = service.advance() {
                        eprintln!("[STATE] canonical advance failed: {e}");
                    }
                    service.publish_queue_metrics();
                }
            })
            .map_err(|e| anyhow!("failed to start state service thread: {e}"))?;
        Ok(handle)
    }

    fn absorb(&mut self, request: StateRequest) {
        match request {
            StateRequest::Block(block) => {
                self.metrics.contextual_queue.fetch_sub(1, Ordering::Relaxed);
                if !self.prospective.insert(*block) {
                    self.metrics.duplicate_blocks.fetch_add(1, Ordering::Relaxed);
                }
            }
            StateRequest::Poke => {}
        }
    }

    fn publish_queue_metrics(&self) {
        self.metrics.prospective_blocks.store(self.prospective.len() as u64, Ordering::Relaxed);
        self.metrics.evicted_prospective.store(self.prospective.evicted(), Ordering::Relaxed);
    }

    fn canonical_tip(&self) -> Result<(Option<[u8; 32]>, u64)> {
        let height = self.state.tip_height()?.unwrap_or(0);
        let hash = match self.state.tip_hash()? {
            Some(raw) => <[u8; 32]>::try_from(raw.as_slice()).ok(),
            None => None,
        };
        Ok((hash, height))
    }

    /// The hash a block extending the canonical tip must name as its parent.
    fn expected_parent(&self) -> Result<([u8; 32], u64)> {
        let (hash, height) = self.canonical_tip()?;
        match hash {
            Some(h) => Ok((h, height + 1)),
            None => Ok((genesis_hash_internal(), 1)),
        }
    }

    /// Advance the canonical chain as far as the candidate tree allows.
    pub fn advance(&mut self) -> Result<()> {
        loop {
            let (parent, next_height) = self.expected_parent()?;
            let run = self.best_run(&parent, next_height);
            if run.is_empty() {
                // Nothing extends the tip. A heavier branch may still exist.
                if self.try_reorg()? {
                    continue;
                }
                if !self.prospective.is_empty() {
                    self.metrics.stalled_parent_waits.fetch_add(1, Ordering::Relaxed);
                }
                return Ok(());
            }
            if !self.commit_run(run)? {
                return Ok(());
            }
        }
    }

    /// Longest chain of candidates starting at `parent`, following the
    /// best child at each step, bounded by the publication size.
    ///
    /// The bound is storage batching. Because each step still runs every
    /// contextual rule in height order inside `prepare_commit_batch`, a run of
    /// 48 and 48 runs of one produce the same canonical state.
    fn best_run(&self, parent: &[u8; 32], next_height: u64) -> Vec<[u8; 32]> {
        let mut run = Vec::new();
        let mut cursor = *parent;
        let mut height = next_height;
        while run.len() < MAX_BLOCKS_PER_PUBLICATION {
            let Some(next) = self.best_child(&cursor, height) else { break };
            run.push(next);
            cursor = next;
            height += 1;
        }
        run
    }

    /// Chain selection among competing children: most cumulative work first,
    /// lowest hash as a deterministic tie-break so two nodes with the same
    /// candidates make the same choice.
    fn best_child(&self, parent: &[u8; 32], height: u64) -> Option<[u8; 32]> {
        let mut best: Option<(&SemanticBlock, [u8; 32])> = None;
        for hash in self.prospective.children_of(parent) {
            let Some(candidate) = self.prospective.get(&hash) else { continue };
            if candidate.height != height {
                continue;
            }
            best = match best {
                None => Some((candidate, hash)),
                Some((current, current_hash)) => {
                    let better = candidate.work() > current.work()
                        || (candidate.work() == current.work() && hash < current_hash);
                    if better { Some((candidate, hash)) } else { Some((current, current_hash)) }
                }
            };
        }
        best.map(|(_, hash)| hash)
    }

    /// Contextually validate and publish one run. Returns false when the run
    /// could not be committed, so the caller stops instead of spinning.
    fn commit_run(&mut self, run: Vec<[u8; 32]>) -> Result<bool> {
        let mut blocks: Vec<BlockCommit> = Vec::with_capacity(run.len());
        for hash in &run {
            match self.prospective.take(hash) {
                Some(candidate) => blocks.push(candidate.commit),
                None => break,
            }
        }
        if blocks.is_empty() {
            return Ok(false);
        }
        let first_height = blocks[0].height;
        let last_height = blocks[blocks.len() - 1].height;

        let prepare_started = Instant::now();
        let prepared = match self.state.prepare_commit_batch(&blocks) {
            Ok(p) => p,
            Err(e) => {
                // Contextual rejection. The run's first block is the culprit;
                // its descendants are dropped with it and may be re-downloaded
                // behind a different parent, so one bad block cannot silently
                // validate or invalidate unrelated candidates.
                self.metrics.invalid_blocks.fetch_add(1, Ordering::Relaxed);
                eprintln!("[STATE] contextual validation rejected {first_height}..{last_height}: {e}");
                return Ok(false);
            }
        };
        self.metrics
            .contextual_prepare_us
            .store(prepare_started.elapsed().as_micros() as u64, Ordering::Relaxed);
        SyncMetrics::raise(&self.metrics.highest_contextually_verified_height, last_height);

        let write_started = Instant::now();
        if let Err(e) = self.writer.publish(prepared) {
            // The canonical tip moved, or the write failed: nothing was
            // published. The blocks are dropped and can be offered again.
            eprintln!("[STATE] publication of {first_height}..{last_height} failed: {e}");
            return Ok(false);
        }
        self.metrics
            .database_write_us
            .store(write_started.elapsed().as_micros() as u64, Ordering::Relaxed);
        self.metrics.last_publication_blocks.store(blocks.len() as u64, Ordering::Relaxed);
        self.metrics.committed_blocks.fetch_add(blocks.len() as u64, Ordering::Relaxed);
        self.metrics.canonical_height.store(last_height, Ordering::Relaxed);

        // Candidates buried deeper than a selectable reorg can no longer win.
        if last_height > MAX_REORG_DEPTH {
            self.prospective.prune_to(last_height - MAX_REORG_DEPTH);
        }
        Ok(true)
    }

    /// Select a heavier branch that forks below the current tip.
    ///
    /// The rollback and the new branch are separate ordered state transitions,
    /// each atomic: the obsolete branch's state is removed before any block of
    /// the new branch is published, so no prepared work from the obsolete
    /// branch can become canonical.
    fn try_reorg(&mut self) -> Result<bool> {
        let (tip_hash, tip_height) = self.canonical_tip()?;
        let Some(_) = tip_hash else { return Ok(false) };
        let Some(tip_work) = self.state.canonical_tip_work()? else { return Ok(false) };
        let Some(highest) = self.prospective.highest_height() else { return Ok(false) };

        let floor = tip_height.saturating_sub(MAX_REORG_DEPTH);
        let mut best: Option<(u64, [u8; 32], [u8; 32])> = None; // (fork height, work, branch head)
        let mut height = highest;
        while height > floor {
            for hash in self.prospective.hashes_at_height(height) {
                let Some(candidate) = self.prospective.get(&hash) else { continue };
                if candidate.work() <= tip_work {
                    continue;
                }
                if let Some(fork_height) = self.fork_point(&hash, floor)? {
                    let better = match best {
                        Some((_, best_work, _)) => candidate.work() > best_work,
                        None => true,
                    };
                    if better {
                        best = Some((fork_height, candidate.work(), hash));
                    }
                }
            }
            height -= 1;
        }

        let Some((fork_height, _, _)) = best else { return Ok(false) };
        if fork_height >= tip_height {
            return Ok(false);
        }
        eprintln!("[STATE] reorganising: rolling canonical state back to height {fork_height}");
        self.state.rollback_to(fork_height)?;
        self.metrics.reorgs.fetch_add(1, Ordering::Relaxed);
        self.metrics.canonical_height.store(fork_height, Ordering::Relaxed);
        Ok(true)
    }

    /// Walk a candidate's ancestry back to a canonical block, through other
    /// candidates as needed. Returns the height of that canonical ancestor.
    fn fork_point(&self, head: &[u8; 32], floor: u64) -> Result<Option<u64>> {
        let mut cursor = *head;
        for _ in 0..=MAX_REORG_DEPTH {
            let Some(candidate) = self.prospective.get(&cursor) else { return Ok(None) };
            let parent_height = candidate.height.saturating_sub(1);
            if parent_height < floor {
                return Ok(None);
            }
            if self.state.canonical_hash_at(parent_height)? == Some(candidate.prev) {
                return Ok(Some(parent_height));
            }
            cursor = candidate.prev;
        }
        Ok(None)
    }
}
