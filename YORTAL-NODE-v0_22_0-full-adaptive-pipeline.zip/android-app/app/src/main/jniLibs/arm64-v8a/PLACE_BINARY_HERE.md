Put the compiled node binary here as `libycashandroidnode.so`
(NOT a real shared library -- it's the same ELF executable produced by
`cargo build --release -p ycash-android-node --target aarch64-linux-android`,
just renamed with the lib/.so wrapper so Android's packager treats it as a
native library and installs it to nativeLibraryDir).

Use tools/package-node-binary.sh to do this copy+rename automatically.
This directory must be empty of anything else -- AGP packages every file
under jniLibs/<abi>/ into the APK's native library set.
