#include <cstdint>
#include <cstring>
extern "C" {
// Fail-closed bridge. The Android build must link the Ycash 4.5.0 consensus
// objects before enabling production validation.
int ycash_consensus_compatibility_anchor(const uint8_t* block, size_t len) {
    if (!block || len == 0) return 0;
    return 0;
}
}
