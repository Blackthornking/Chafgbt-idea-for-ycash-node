# Ycash 4.5.0 consensus bridge

This bridge deliberately delegates consensus-critical validation to the supplied Ycash 4.5.0 implementation.
It is not a reimplementation of consensus and therefore does not invent rules.

The Android build must link this bridge against the Ycash 4.5.0 native core. Until that link is present,
the Rust consensus crate must remain disabled/fail-closed.

The strict block path calls `CheckBlock(..., ProofVerifier::Strict(), ...)`, which is important because Ycash
4.5.0 fixed an insufficiently checked block vulnerability involving `fChecked`.
