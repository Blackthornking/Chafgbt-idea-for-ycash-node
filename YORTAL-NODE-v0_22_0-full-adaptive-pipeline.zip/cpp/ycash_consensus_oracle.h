#pragma once
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Returns 1 for a strictly valid mainnet block, 0 for invalid, -1 for a bridge error. */
int ycash_check_block_mainnet(const uint8_t* data, size_t len,
                              int check_pow, int check_merkle, int check_transactions,
                              char* reason, size_t reason_len);

/* Returns 1 for a structurally valid transaction, 0 for invalid, -1 for a bridge error. */
int ycash_check_tx_mainnet(const uint8_t* data, size_t len,
                           char* reason, size_t reason_len);

#ifdef __cplusplus
}
#endif
