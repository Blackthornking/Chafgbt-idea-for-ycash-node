# Ycash Android Node — Rust Full v0.7

## Phase 7: Live-network connectivity foundation

This phase adds the real Ycash mainnet transport boundary:
- Ycash mainnet magic `24 e9 27 64`
- default P2P port `8833`
- Bitcoin/Zcash-style 24-byte message envelope
- bounded payload handling
- command parsing
- checksum verification boundary
- peer lifecycle and scoring
- peer banning
- header locator scheduling
- explicit separation of transport from consensus

Ycash's official chain parameters specify port 8833 for mainnet, and the project
describes `ycashd` as the full node that downloads and stores the complete chain.

### Important

This is the connectivity layer, not yet a claim of safe mainnet synchronization.
Incoming headers/blocks remain untrusted until exact Ycash 4.5.0-compatible consensus
validation succeeds and the state engine commits them.

### Next

Phase 8 should add the actual async socket runtime, version/verack handshake,
getheaders/headers exchange, block request/download, timeout/retry logic and a
controlled read-only mainnet synchronization test.
