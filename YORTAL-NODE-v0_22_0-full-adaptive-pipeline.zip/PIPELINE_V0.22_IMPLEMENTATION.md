# YORTAL v0.22 — Full Adaptive Multi-Peer Pipeline

## Scope
This release turns the previous fixed-window design into a bounded, adaptive,
multi-peer synchronization architecture. Consensus and wire semantics remain
unchanged.

### Pipeline
Peer discovery → peer scoring → range scheduler → header stream → header
validation → block fetch → structural validation → parallel transaction
validation → ordered state transition → bounded commit buffer → batched DB commit.

## Scheduling
- Target window: 64..4096 items, adaptive.
- Work is represented as height ranges, not peer-owned requests.
- Peers lease ranges.
- Timeout/disconnect releases a lease.
- Retry count >= 3 quarantines a range for duplicate fetch/diagnostics.
- Slow peers receive smaller ranges; high-throughput peers receive larger ones.
- The protocol's `getheaders` response bound remains intact; the scheduler
  pipelines successive header rounds instead of increasing the wire limit.

## Backpressure
The controller decreases concurrency when CPU, RAM, DB queue, or validation
queue exceeds the high watermark. It increases concurrency only when pressure
is low and the network is underutilised.

## Ordering / consensus safety
Independent parsing and validation may run concurrently. State transitions and
canonical DB commits remain strictly height ordered. No out-of-order state
mutation is permitted.

## Recovery
- Range timeout → release.
- Peer disconnect → release all active leases.
- Repeated range failure → quarantine.
- Optional duplicate fetch of quarantined ranges from independent peers.
- A range is committed only after all required validation succeeds.

## Telemetry
Dashboard/API should expose:
- blocks/sec (bps)
- headers/sec
- receive B/s
- validation blocks/sec
- DB writes/sec and DB B/s
- current/adaptive window
- blocks in flight
- validation queue
- commit queue
- worker count
- average validation ms
- average commit ms
- request rounds
- completed/retried/quarantined ranges
- blocks behind and sync %
- peer count and active peers
- last block age
- uptime
- storage/DB size
- pipeline utilisation and backpressure state

## Correctness gates
Before calling the implementation production-ready:
1. Existing consensus tests pass unchanged.
2. Existing P2P protocol tests pass unchanged.
3. Reorg handling passes.
4. Interrupted sync resumes without corrupting the DB.
5. A malicious/invalid block cannot enter the commit queue.
6. Out-of-order validation results cannot change canonical state.
7. Peer timeouts do not stall the global scheduler.
8. Benchmark sequential vs pipelined sync on identical chain snapshots.
