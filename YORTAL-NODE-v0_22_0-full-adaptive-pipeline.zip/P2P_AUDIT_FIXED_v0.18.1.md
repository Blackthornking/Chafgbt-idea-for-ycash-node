# Ycash Android Rust Node v0.18.1 — P2P audit fixes

Based on the supplied `YCASH_RUST_P2P_AUDIT.md` and Ycash `ycashd` v4.5.0 protocol behavior.

## Fixed in this tree

- Corrected P2P command decoding from bytes `[12..16]` to `[4..16]`.
- Corrected the framing unit test to assert `ping` at `[4..8]`.
- Removed the duplicate `PeerCandidate` declaration and duplicate `advertised_height` implementation.
- Changed the protocol message ceiling from 4 MiB to Ycash's 2 MiB limit.
- Added the Ycash `hashLightClientRoot` field to every block header.
- Added 400-byte post-Ycash-fork Equihash solution parsing and 1344-byte pre-fork parsing.
- Implemented Ycash header synchronization using `getheaders` / `headers` with a maximum of 160 headers per response.
- Implemented locator construction ending at the Ycash genesis hash.
- Added contextual header validation: previous-hash linkage, MTP, future-time bound, nBits calculation, PoW target range, Equihash verification and block-hash target verification.
- Implemented the Ycash difficulty algorithm: 17-block averaging, median-time calculation, damped/clamped timespan, Blossom 150s/75s spacing, and the Ycash-fork scaled-difficulty bootstrap.
- Added cumulative chain-work tracking and the v4.5.0 minimum-chain-work constant.
- Added persistent SQLite header storage and block storage.
- Implemented block download in batches of up to 16 requested blocks.
- Added block/header consistency checks and strict Equihash/header validation before storing blocks.
- Added peer address persistence with timestamps, attempts and tried state.
- Added netgroup-diverse candidate selection, banlist handling and continuous peer worker retry.
- Added an 8-worker outbound supervisor rather than the old one-shot thread/join model.
- Added ping/pong keepalive and timeout handling.
- Added `reject` handling/logging.
- Added `inv` handling so newly announced blocks trigger header/block synchronization.
- Wired the real SQLite heights into the Android status API.
- Added a complete GitHub Actions Android ARM64 build workflow which builds the Rust node and packages it as an APK asset.

## Consensus scope note

The Rust implementation now performs consensus-critical **header/PoW validation** itself and does not use the previous non-functional C++ oracle bridge.

Full Sapling transaction proof/consensus validation remains a separate layer because the supplied project does not contain the complete Ycash 4.5.0 native consensus source/dependency graph. The block wire data is retained verbatim rather than being incorrectly treated as length-prefixed transactions. This is intentional: accepting fabricated transaction parsing would be less safe than failing closed at that layer.

The supplied Ycash C++ oracle remains in `cpp/` as the optional route for integrating the complete pinned ycashd 4.5.0 consensus implementation later.

## Build

Run the GitHub Actions workflow:

`Build Ycash Android Rust Full Node`

It performs `cargo check`, builds `aarch64-linux-android`, packages the native binary into `app/src/main/assets/ycash-android-node`, builds the release APK, and verifies that the native node is present in the APK.
