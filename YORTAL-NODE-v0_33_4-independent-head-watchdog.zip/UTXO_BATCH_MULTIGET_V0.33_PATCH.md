# YORTAL v0.33 UTXO batch MultiGet + scaling telemetry

Implemented in this build:

- Collects transparent transaction inputs across the entire ordered commit batch before consensus mutation.
- Deduplicates OutPoints and resolves RAM-cache hits first.
- Issues one RocksDB `MultiGet` for the remaining persistent UTXO misses across the whole commit batch.
- Keeps consensus mutation strictly ordered; `connect_tx()` still validates/spends/adds outputs in transaction order.
- Preserves intra-batch outputs in `CoinsView`, so a transaction can spend an output created by an earlier transaction in the same commit batch without a database read.
- Measures the actual `snap.multi_get_cf()` wall time separately from `CoinRec` decoding.
- Reports, per commit range/height:
  - `utxo_cache_hits`
  - `utxo_cache_misses`
  - `utxo_cache_hit_rate_ppm`
  - `utxo_db_lookup_us`
  - `utxo_db_lookup_keys`
  - existing `utxo_lookups` and `utxo_lookup_us`
- Exposes the new measurements through the Android runtime JSON as:
  - `last_utxo_db_lookup_us`
  - `last_utxo_db_lookup_keys`
  - `last_utxo_cache_hit_rate_ppm`
- Adds `tools/verify-utxo-batch-multiget.sh` static verification.

## Interpretation

`utxo_db_lookup_us` is intentionally measured around only RocksDB `multi_get_cf`, so it can be compared against cache-hit rate and block height without mixing in UTXO record decoding or script validation.

`utxo_cache_hit_rate_ppm` is `hits / (hits + misses) * 1,000,000` for the commit batch.

A useful scaling trace is therefore:

`height -> cache hit rate -> RocksDB MultiGet keys -> RocksDB MultiGet microseconds -> total UTXO lookup microseconds`

The database remains authoritative; this patch changes only the read scheduling/telemetry, not consensus rules or canonical commit ordering.
