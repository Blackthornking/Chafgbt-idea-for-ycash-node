# YORTAL v0.30.9 — Real Prepared Commit Path

## Patch objective

Turn `State::prepare_commit_batch()` from a zero-copy API wrapper into a real
Zebra-style preparation boundary while preserving the existing consensus order
and the single permanent canonical commit worker.

## Implemented

- `State::prepare_commit_batch()` now performs the complete ordered consensus/state
  transition against a SQLite read transaction.
- Preparation uses the dedicated read-only WAL connection when available, so the
  expensive validation phase no longer holds the canonical write connection mutex.
- The prepared object owns the complete mutation plan needed by the write phase:
  - per-block Sapling roots/frontiers
  - transparent UTXO mutation set
  - Sprout nullifier/block-state mutation set
  - final Sapling consensus state
  - final Sprout tree/value-pool state
  - canonical extension/reorg decision
  - exact canonical tip snapshot used for preparation
- `PreparedUtxoChanges` and `PreparedSproutChanges` are now owned snapshots rather
  than references to temporary state views.
- `State::apply_prepared_commit()` performs only the canonical SQLite mutation
  phase and final in-memory publication.
- The apply phase rechecks the exact canonical tip captured during preparation.
  If the tip changed, the prepared plan is rejected before mutation.
- The existing contiguous-height and parent/hash validation remains in place.
- The existing one-transaction atomic SQLite write is preserved.
- RAM consensus cache publication still happens only after SQLite COMMIT succeeds.
- The permanent desktop and Android commit workers continue to use the
  prepare -> apply boundary.

## Consensus ordering

The safe sequence remains:

    validated ranges
        -> ordered commit worker
        -> prepare canonical state transition
        -> prepared mutation plan
        -> verify canonical tip unchanged
        -> one SQLite write transaction
        -> COMMIT
        -> publish RAM state

No transaction, UTXO, Sapling, Sprout, or script state mutation is parallelized
across canonical block order.

## Expected performance effect

The patch does **not** attempt to make canonical SQLite writes concurrent.
Its main database-side benefit is removing the long state-validation interval
from the canonical write connection. The expensive TX-connect/state work can
therefore proceed on the WAL reader while the write connection remains available
for other non-canonical reads/writes.

The prepared mutation snapshot adds a deliberate copy of touched UTXO/Sprout
mutation structures. Raw block data remains borrowed, avoiding a second raw-block
copy.

## Validation

The archive was structurally checked after patching:

- prepared/apply API present
- old `commit_blocks_batch_inner()` removed
- preparation uses the WAL reader when available
- exact canonical-tip guard present
- atomic SQLite commit remains present
- UTXO/Sprout prepared mutation types are owned
- Rust brace balance checked

This environment does not contain `cargo` or `rustc`, so Rust compilation and
runtime consensus tests still need to run in CI.
