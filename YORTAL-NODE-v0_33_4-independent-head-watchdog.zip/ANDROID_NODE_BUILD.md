# Android node build and packaging

## Root cause fixed

The APK must contain the Rust ARM64 executable at:

`android-app/app/src/main/jniLibs/arm64-v8a/libycashandroidnode.so`

`NodeService` now **only** executes that PackageManager-installed native binary. It no longer copies an asset into `getFilesDir()` and tries to `chmod`/execute it.

## Build the native node

The state backend is RocksDB (see `ROCKSDB_MIGRATION_V0.32.md`), which compiles
C++ from source and generates bindings with bindgen, so the host also needs
clang/libclang:

```bash
sudo apt-get install -y clang libclang-dev   # Debian/Ubuntu
```

Install Rust/rustup and an Android SDK/NDK, then run from the repository root:

```bash
export ANDROID_NDK_ROOT=/path/to/android-sdk/ndk/<version>
tools/build-android-arm64.sh
```

The script:

1. installs the `aarch64-linux-android` Rust target;
2. selects the Android API 35 NDK clang linker;
3. configures the RocksDB cross-build (NDK sysroot for bindgen, NDK `llvm-ar`,
   statically linked libc++ so no `libc++_shared.so` has to be shipped);
4. builds `ycash-android-node` in release mode;
5. installs it as `libycashandroidnode.so` under `jniLibs/arm64-v8a`;
6. removes the old placeholder file.

The first build compiles RocksDB itself and takes several minutes.

## Build the APK

This source export does not include the generated Gradle wrapper JAR, so use an installed Gradle 8.10.2 (or let CI install it):

```bash
cd android-app
gradle assembleRelease --no-daemon
```

Before building, verify the native package:

```bash
cd ..
tools/verify-android-package.sh
```

## Runtime behaviour

The Activity now shows `STARTING` immediately after pressing **START NODE**. It changes to the Rust node's real status only after `127.0.0.1:8834/status` responds. This avoids displaying a false `RUNNING` state while the process is still starting or has already failed.
