//! The single canonical writer.
//!
//! Exactly one of these exists per process. It is the only component permitted
//! to mutate canonical state, which is what makes "ordered canonical state
//! transitions" an enforced property rather than a convention: construction of
//! a second worker fails, so a second writer cannot appear by accident during a
//! refactor.
//!
//! The writer performs no consensus decisions. It receives an already prepared
//! mutation plan from [`crate::state_service`] and publishes it as one RocksDB
//! WriteBatch. A WriteBatch is a storage atomicity device; it never means "these
//! N blocks are one consensus transition".

use anyhow::{bail, Result};
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::Instant;

use crate::{PreparedCommit, State};

static WRITERS: AtomicUsize = AtomicUsize::new(0);

/// Publication counters, in microseconds where timed.
#[derive(Debug, Default)]
pub struct WriteMetrics {
    pub batches: AtomicU64,
    pub blocks: AtomicU64,
    pub last_batch_blocks: AtomicU64,
    pub last_write_us: AtomicU64,
    pub total_write_us: AtomicU64,
    pub failures: AtomicU64,
}

pub struct BlockWriteWorker {
    state: Arc<State>,
    metrics: Arc<WriteMetrics>,
}

impl BlockWriteWorker {
    /// Create the process's canonical writer. Fails if one already exists.
    pub fn new(state: Arc<State>) -> Result<Self> {
        if WRITERS.fetch_add(1, Ordering::SeqCst) != 0 {
            WRITERS.fetch_sub(1, Ordering::SeqCst);
            bail!("a canonical block write worker already exists: only one writer may own canonical state");
        }
        Ok(Self { state, metrics: Arc::new(WriteMetrics::default()) })
    }

    pub fn metrics(&self) -> Arc<WriteMetrics> {
        Arc::clone(&self.metrics)
    }

    pub fn state(&self) -> &Arc<State> {
        &self.state
    }

    /// Publish one prepared state transition.
    ///
    /// `apply_prepared_commit` rechecks the canonical tip and parent linkage
    /// before it writes anything, so a plan prepared against a chain that has
    /// since moved is rejected rather than published.
    pub fn publish(&self, prepared: PreparedCommit<'_>) -> Result<()> {
        let blocks = prepared.blocks.len() as u64;
        let started = Instant::now();
        match self.state.apply_prepared_commit(prepared) {
            Ok(()) => {
                let us = started.elapsed().as_micros() as u64;
                self.metrics.batches.fetch_add(1, Ordering::Relaxed);
                self.metrics.blocks.fetch_add(blocks, Ordering::Relaxed);
                self.metrics.last_batch_blocks.store(blocks, Ordering::Relaxed);
                self.metrics.last_write_us.store(us, Ordering::Relaxed);
                self.metrics.total_write_us.fetch_add(us, Ordering::Relaxed);
                Ok(())
            }
            Err(e) => {
                self.metrics.failures.fetch_add(1, Ordering::Relaxed);
                Err(e)
            }
        }
    }
}

impl Drop for BlockWriteWorker {
    fn drop(&mut self) {
        WRITERS.fetch_sub(1, Ordering::SeqCst);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn only_one_canonical_writer_may_exist() {
        // The guard is process-wide, so exercise it without opening a database.
        assert_eq!(WRITERS.fetch_add(1, Ordering::SeqCst), 0);
        assert_eq!(WRITERS.load(Ordering::SeqCst), 1);
        WRITERS.fetch_sub(1, Ordering::SeqCst);
        assert_eq!(WRITERS.load(Ordering::SeqCst), 0);
    }
}
