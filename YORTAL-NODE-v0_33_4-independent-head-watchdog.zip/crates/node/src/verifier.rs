//! Semantic (context-free) verification.
//!
//! These are the consensus checks whose result does not depend on mutable
//! canonical state: block and transaction structure, proof-of-work, Merkle
//! roots, Sapling Groth16 proofs, signature and script precomputation. They are
//! deterministic per block, so they can run on every core and complete out of
//! order without affecting what the chain accepts.
//!
//! Semantic readiness is not canonical readiness. A block that passes here has
//! only earned a place in the prospective set; the ordered state gate still
//! runs every contextual rule before anything becomes canonical.

use std::sync::atomic::Ordering;
use std::sync::mpsc::{sync_channel, Receiver, SyncSender};
use std::sync::Arc;
use std::thread;
use std::time::Instant;

use anyhow::{anyhow, bail, Result};
use ycash_chain::txid;
use ycash_consensus::{validate_for_commit_batched_with_parsed, Context, ProofBatch};
use ycash_state::prospective::SemanticBlock;
use ycash_state::state_service::{StateServiceHandle, SyncMetrics};
use ycash_state::BlockCommit;

use crate::downloader::{BlockRequest, InFlightRegistry};

/// Optional assume-valid checkpoint, carried over unchanged. Full verification
/// is the default; this is used only when YCASH_ASSUME_VALID=1 and the verified
/// header at the checkpoint height matches.
pub const ASSUME_VALID_HEIGHT: u64 = 2_250_000;
pub const ASSUME_VALID_HASH_DISPLAY: &str =
    "000003f98b7497fdcd8a6b6d10a93a887c5d47127e24a9dc3a40cb65754d21e7";

/// Blocks a verifier thread folds into one Groth16 batch.
///
/// The batch identity costs one final exponentiation regardless of how many
/// proofs it holds, so a bigger batch amortises it better. One block per batch
/// wastes that on blocks with few shielded transactions. Grouping is bounded
/// rather than unlimited because a worker only groups what has *already*
/// arrived: it never waits for more blocks, so latency at the chain tip is
/// unchanged.
///
/// This is a scheduling constant. It changes how proofs are grouped for
/// verification, never which proofs must verify.
pub const MAX_BLOCKS_PER_PROOF_BATCH: usize = 8;

/// A downloaded block with the header context its verification needs.
pub struct RawBlock {
    pub request: BlockRequest,
    pub raw: Vec<u8>,
    /// Peer that supplied the block. Diagnostic provenance only.
    pub source_peer: String,
}

/// Result of one verifier attempt with enough provenance to close the block
/// lifecycle exactly once.
pub struct VerifyOutcome {
    pub height: u64,
    pub hash: [u8; 32],
    pub source_peer: String,
    pub result: Result<SemanticBlock>,
}

/// The prev-hash field of a block header, read straight from the wire bytes.
///
/// Header layout: version(4) | prev(32) | merkle(32) | final Sapling root(32) |
/// time(4) | bits(4) | nonce(32) | solution.
pub fn header_prev(raw: &[u8]) -> Result<[u8; 32]> {
    if raw.len() < 36 {
        bail!("block is too short to contain a header");
    }
    let mut prev = [0u8; 32];
    prev.copy_from_slice(&raw[4..36]);
    Ok(prev)
}

/// Run every context-free consensus check for one block.
///
/// This is the same entry point the previous pipeline used, called with the
/// same arguments for the same block; only the surrounding scheduling changed.
pub fn semantic_verify(block: RawBlock, assume_valid: bool) -> Result<SemanticBlock> {
    let RawBlock { request, raw, .. } = block;
    let height = request.height;
    let ctx = Context {
        height,
        prev_height: height.saturating_sub(1),
        median_time_past: request.median_time_past,
    };
    let assume_valid = assume_valid && height <= ASSUME_VALID_HEIGHT;

    // Sapling proofs in one block share a batch: one multi-Miller loop per
    // verifying key rather than one pairing check per proof. A rejection is
    // re-checked by the single-proof verifier, whose result is final.
    let mut proofs = ProofBatch::new();
    let (validated, parsed_txs) = validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, &mut proofs)
        .map_err(|e| anyhow!("block {height}: {e:?}"))?;
    if proofs.proofs() > 0 {
        if let Err((h, e)) = proofs.finish() {
            bail!("block {h}: {e:?}");
        }
    }
    if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
        bail!("block {height}: consensus decoder returned inconsistent transaction data");
    }

    let prev = header_prev(&raw)?;
    let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
    let precomputed_txs: Vec<ycash_script::PrecomputedTxData> =
        parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();

    Ok(SemanticBlock::from_commit(BlockCommit {
        height,
        hash: request.hash,
        prev,
        work: request.work,
        raw,
        txs,
        parsed_txs,
        precomputed_txs,
        proofs_verified: true,
    }))
}

/// Verify a group of blocks, folding every Sapling proof in the group into one
/// batch.
///
/// On batch rejection each block is re-verified on its own. The batch says only
/// that something in the set is bad, never which block, so a batch verdict is
/// never reported as a per-block result.
pub fn verify_group(blocks: Vec<RawBlock>, assume_valid: bool) -> Vec<VerifyOutcome> {
    if blocks.len() == 1 {
        let mut blocks = blocks;
        let block = blocks.remove(0);
        let height = block.request.height;
        let hash = block.request.hash;
        let source_peer = block.source_peer.clone();
        return vec![VerifyOutcome { height, hash, source_peer, result: semantic_verify(block, assume_valid) }];
    }

    let mut batch = ProofBatch::new();
    let mut staged: Vec<Result<SemanticBlock>> = Vec::with_capacity(blocks.len());
    let mut retained: Vec<RawBlock> = Vec::with_capacity(blocks.len());
    for block in blocks {
        let raw_for_retry = RawBlock {
            request: block.request.clone(),
            raw: block.raw.clone(),
            source_peer: block.source_peer.clone(),
        };
        retained.push(raw_for_retry);
        staged.push(verify_into_batch(block, assume_valid, &mut batch));
    }

    if batch.proofs() > 0 {
        if let Err((height, e)) = batch.finish() {
            // Isolate: re-verify every block in the group individually. The
            // lifecycle remains owned throughout this retry; no transport
            // request can be issued for any member while isolation runs.
            eprintln!("[VERIFY] proof batch rejected at height {height} ({e:?}); isolating {} blocks", retained.len());
            return retained
                .into_iter()
                .map(|raw| {
                    let height = raw.request.height;
                    let hash = raw.request.hash;
                    let source_peer = raw.source_peer.clone();
                    VerifyOutcome { height, hash, source_peer, result: semantic_verify(raw, assume_valid) }
                })
                .collect();
        }
    }

    retained
        .into_iter()
        .zip(staged)
        .map(|(raw, result)| VerifyOutcome {
            height: raw.request.height,
            hash: raw.request.hash,
            source_peer: raw.source_peer,
            result,
        })
        .collect()
}

/// Every context-free check for one block except the Groth16 pairing, which is
/// queued into the caller's batch.
fn verify_into_batch(block: RawBlock, assume_valid: bool, batch: &mut ProofBatch) -> Result<SemanticBlock> {
    let RawBlock { request, raw, .. } = block;
    let height = request.height;
    let ctx = Context {
        height,
        prev_height: height.saturating_sub(1),
        median_time_past: request.median_time_past,
    };
    let assume_valid = assume_valid && height <= ASSUME_VALID_HEIGHT;
    let (validated, parsed_txs) = validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, batch)
        .map_err(|e| anyhow!("block {height}: {e:?}"))?;
    if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
        bail!("block {height}: consensus decoder returned inconsistent transaction data");
    }
    let prev = header_prev(&raw)?;
    let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
    let precomputed_txs: Vec<ycash_script::PrecomputedTxData> =
        parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();
    Ok(SemanticBlock::from_commit(BlockCommit {
        height,
        hash: request.hash,
        prev,
        work: request.work,
        raw,
        txs,
        parsed_txs,
        precomputed_txs,
        proofs_verified: true,
    }))
}

/// A fixed pool of verifier threads feeding the ordered state gate.
#[derive(Clone)]
pub struct VerifierPool {
    tx: SyncSender<RawBlock>,
    metrics: Arc<SyncMetrics>,
    registry: Arc<InFlightRegistry>,
}

impl VerifierPool {
    pub fn spawn(
        workers: usize,
        queue_depth: usize,
        state: StateServiceHandle,
        metrics: Arc<SyncMetrics>,
        registry: Arc<InFlightRegistry>,
        assume_valid: bool,
    ) -> Result<Self> {
        let workers = workers.max(1);
        let (tx, rx) = sync_channel::<RawBlock>(queue_depth.max(workers));
        let rx = Arc::new(std::sync::Mutex::new(rx));
        metrics.verifier_workers.store(workers as u64, Ordering::Relaxed);
        for id in 0..workers {
            let rx: Arc<std::sync::Mutex<Receiver<RawBlock>>> = Arc::clone(&rx);
            let state = state.clone();
            let metrics = Arc::clone(&metrics);
            let registry = Arc::clone(&registry);
            thread::Builder::new()
                .name(format!("yortal-verify-{id}"))
                .spawn(move || loop {
                    // Take one block, then whatever else is already waiting, up
                    // to the group bound. Never wait for more: the group is
                    // built from work that has already arrived.
                    let group = {
                        let Ok(guard) = rx.lock() else { return };
                        let Ok(first) = guard.recv() else { return };
                        let mut group = vec![first];
                        while group.len() < MAX_BLOCKS_PER_PROOF_BATCH {
                            match guard.try_recv() {
                                Ok(next) => group.push(next),
                                Err(_) => break,
                            }
                        }
                        group
                    };
                    metrics.semantic_queue.fetch_sub(group.len() as u64, Ordering::Relaxed);
                    for block in &group {
                        if metrics.canonical_height.load(Ordering::Relaxed).saturating_add(1) == block.request.height {
                            metrics.trace_head(
                                block.source_peer.clone(),
                                "VERIFYING",
                                block.request.height,
                                Some(block.request.hash),
                                "block removed from transport window; semantic verifier owns lifecycle",
                            );
                        }
                    }
                    let started = Instant::now();
                    let results = verify_group(group, assume_valid);
                    let verify_us = started.elapsed().as_micros() as u64;
                    metrics.semantic_verify_us.store(verify_us, Ordering::Relaxed);
                    metrics.semantic_verify_total_us.fetch_add(verify_us, Ordering::Relaxed);
                    for outcome in results {
                        let VerifyOutcome { height, hash, source_peer, result } = outcome;
                        match result {
                            Ok(verified) => {
                                if !registry.mark_verified(&hash) {
                                    eprintln!("[VERIFY] lifecycle transition failed at height {height}");
                                    registry.release(&hash);
                                    continue;
                                }
                                metrics.semantic_verified_blocks.fetch_add(1, Ordering::Relaxed);
                                metrics.raise_semantic_height(height);
                                let is_head = metrics.canonical_height.load(Ordering::Relaxed).saturating_add(1) == height;
                                if is_head {
                                    metrics.trace_head(
                                        source_peer.clone(),
                                        "VERIFIED",
                                        height,
                                        Some(hash),
                                        "semantic verification complete; lifecycle retained until ordered publication",
                                    );
                                }
                                if state.offer(verified).is_err() {
                                    registry.release(&hash);
                                    return;
                                }
                                if is_head {
                                    metrics.trace_head(
                                        source_peer,
                                        "CANDIDATE_QUEUED",
                                        height,
                                        Some(hash),
                                        "verified candidate handed to ordered state gate",
                                    );
                                }
                            }
                            Err(e) => {
                                registry.release(&hash);
                                metrics.invalid_blocks.fetch_add(1, Ordering::Relaxed);
                                let is_head = metrics.canonical_height.load(Ordering::Relaxed).saturating_add(1) == height;
                                if is_head {
                                    metrics.trace_head(
                                        source_peer,
                                        "VERIFY_REJECTED",
                                        height,
                                        Some(hash),
                                        format!("semantic verification rejected block: {e}"),
                                    );
                                }
                                eprintln!("[VERIFY] rejected block at height {height}: {e}");
                            }
                        }
                    }
                })
                .map_err(|e| anyhow!("failed to start verifier thread: {e}"))?;
        }
        Ok(Self { tx, metrics, registry })
    }

    /// Hand a downloaded block to the pool. Blocks the calling peer thread when
    /// the queue is full, which is the backpressure path from CPU to network.
    pub fn submit(&self, block: RawBlock) -> Result<()> {
        self.metrics.semantic_queue.fetch_add(1, Ordering::Relaxed);
        self.tx.send(block).map_err(|_| anyhow!("verifier pool stopped"))
    }

    /// Non-blocking variant for callers that must keep servicing a socket.
    pub fn try_submit(&self, block: RawBlock) -> std::result::Result<(), RawBlock> {
        self.metrics.semantic_queue.fetch_add(1, Ordering::Relaxed);
        match self.tx.try_send(block) {
            Ok(()) => Ok(()),
            Err(e) => {
                self.metrics.semantic_queue.fetch_sub(1, Ordering::Relaxed);
                Err(match e {
                    std::sync::mpsc::TrySendError::Full(b) => b,
                    std::sync::mpsc::TrySendError::Disconnected(b) => b,
                })
            }
        }
    }
}

/// Default verifier width: leave one core for the ordered state engine and one
/// for the Android UI thread, and never drop below one worker.
pub fn default_verifier_workers() -> usize {
    std::thread::available_parallelism()
        .map(|n| n.get().saturating_sub(2).max(1))
        .unwrap_or(1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn header_prev_is_read_from_the_wire_bytes() {
        let mut raw = vec![0u8; 140];
        raw[4..36].copy_from_slice(&[9u8; 32]);
        assert_eq!(header_prev(&raw).unwrap(), [9u8; 32]);
        assert!(header_prev(&[0u8; 8]).is_err());
    }
}
