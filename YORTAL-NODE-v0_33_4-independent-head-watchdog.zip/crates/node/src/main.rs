//! Desktop/headless entry point.
//!
//! The synchronisation engine itself lives in this crate's library
//! (`downloader`, `peer_manager`, `verifier` and the state crate's ordered
//! gate), which is what the Android node links against. This binary opens the
//! state, starts the same engine, and reports the canonical tip.
//!
//! The old range-based desktop driver was removed with the rest of the range
//! scheduler rather than left behind under a new name; a headless peer
//! transport can be added on top of `SyncEngine` exactly as
//! `sync_coordinator.rs` does on Android.

use anyhow::Result;
use std::path::PathBuf;
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::time::Duration;

use ycash_node::{SyncConfig, SyncEngine};
use ycash_state::State;

fn main() -> Result<()> {
    tracing_subscriber::fmt::init();
    let db = std::env::var_os("YCASH_NODE_DB")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("ycash-node.rocksdb"));
    let state = Arc::new(State::open(db)?);
    tracing::info!(tip = ?state.tip_height()?, "Ycash node state engine initialized");

    let config = SyncConfig::from_env();
    tracing::info!(
        blocks_in_transit_per_peer = config.blocks_in_transit_per_peer,
        max_blocks_in_flight = config.max_blocks_in_flight,
        verifier_workers = config.verifier_workers,
        "transport configuration (non-consensus)"
    );
    let engine = SyncEngine::start(Arc::clone(&state), config)?;

    loop {
        std::thread::sleep(Duration::from_secs(10));
        tracing::info!(
            canonical = engine.metrics.canonical_height.load(Ordering::Relaxed),
            headers = engine.metrics.highest_header_height.load(Ordering::Relaxed),
            prospective = engine.metrics.prospective_blocks.load(Ordering::Relaxed),
            in_flight = engine.metrics.blocks_in_flight_total.load(Ordering::Relaxed),
            committed = engine.metrics.committed_blocks.load(Ordering::Relaxed),
            "sync"
        );
    }
}
