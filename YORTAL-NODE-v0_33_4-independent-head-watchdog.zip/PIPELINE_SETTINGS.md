# Pipeline settings: where they actually come from

## The bug this fixes

`config/pipeline.toml` is parsed by `crates/node/src/main.rs` (desktop node) only.
The Android node built its `AdaptiveConfig` as a literal inside
`BlockPipeline::new` (`crates/ycash-android-node/src/pipeline_sync.rs`), so editing
the TOML changed nothing on device and every setting needed a full rebuild of the
native `.so`.

Separately, the dashboard row "Pipeline limits" was reading
`PipelineEngine::max_inflight_ranges()` / `max_validation_workers()`, which return
the controller's **current** adaptive budget, not the configured ceiling. Above
`low_watermark` the controller halves both, so a device sitting in the mid-pressure
band showed `max ranges 10 · verify 2` against a configured 20 / 4 — indistinguishable
from a setting that had been ignored.

## Android: where settings come from now

Resolved in `NodeService.applyPipelineEnv`, lowest precedence first:

1. Rust defaults in `pipeline_config()`
2. `<externalFilesDir>/pipeline.conf` — `/sdcard/Android/data/com.ycash.androidnode/files/pipeline.conf`,
   editable from any file manager, no root, no rebuild. A commented template is
   written here on first run.
3. `<filesDir>/pipeline.conf` — private dir, for `adb run-as` / rooted devices
4. `SharedPreferences("ycash_node")`, key `pipeline_<lowercased name>` — for a future settings UI

Each resolved key is exported as `YORTAL_<NAME>` into the node process.

| conf key / env suffix | default | clamp |
|---|---|---|
| `min_window` | 16 | 1..2000 |
| `initial_window` | 100 | min..max window |
| `max_window` | 2000 | min_window..2000 |
| `window_step` | 100 | 1..max_window |
| `high_watermark` | 0.85 | 0.05..1.0 |
| `low_watermark` | 0.50 | 0.0..high_watermark |
| `verify_threads` | cores-1 (one Android/housekeeping core reserved) | 1..cores-1 |
| `max_inflight_ranges` | 2 × (cores-1) | 1..256 |
| `max_range_len` | 100 | 1..100 |
| `commit_batch_cap` | 512 | 1..512 |
| `commit_linger_ms` | 50 | 0..300 |
| `script_workers` | cores-1 | 1..cores-1 |
| `script_parallel_threshold` | 2 | 1..8 |

`max_range_len` was a hardcoded `const MAX_RANGE_LEN: u64 = 100` inside
`PipelineEngine::plan_parallel_ranges`; it is now an `AdaptiveConfig` field, so the
setting reaches the planner on both the desktop and Android paths. It stays clamped
at 100 because that is the range shape this build's peer requests are tested against.

On startup the node logs the resolved config:

```
[PIPELINE] stage=CONFIG min_window=16 initial_window=100 max_window=2000 step=8 ...
```

and `NodeService` logs `Pipeline settings: ...` to `node.log`, so a setting that
didn't take can be told apart from a setting that took and was then throttled.

## Configured vs current on the dashboard

The status JSON now carries both. Existing `pipeline_max_*` fields keep their
meaning (current adaptive budget); new fields are the settings:

- `pipeline_cfg_validation_workers`
- `pipeline_cfg_inflight_ranges`
- `pipeline_cfg_min_window`
- `pipeline_cfg_max_window`
- `pipeline_cfg_window_step`

The row now reads e.g.

```
ranges 10/20 · verify 2/4 · window 100 (16–2000) · lookahead 1000 · commit 100 · range 100
```

left = current, right = configured.

## Reading the screenshot that started this

`max ranges 10 · verify 2 · lookahead 1000` was self-consistent: pressure was in the
`[0.50, 0.85)` band, so the controller ran at half of 20 and half of 4, and
`lookahead = window × current_inflight = 100 × 10 = 1000`. The window never grew past
its initial 100 because growth requires pressure at or below `low_watermark`. If that
persists, `low_watermark` is the knob — not `max_window`.

## v0.30.9 commit CPU and database path

The ordered commit worker remains exactly one thread and remains the only canonical state publisher. During state preparation the CPU budget is explicitly split so the expensive transparent-script verifier can use the remaining device capacity:

```text
8 logical CPUs (example device)
  1 Android/housekeeping reserve
  1 ordered commit worker
  1 live pipeline verifier
  5 transparent-script workers
```

The script pool is persistent and uses dynamic per-input Rayon scheduling. `ScriptPermit` is a shared gate, not a fixed one-worker limit; the dashboard now exposes the active script budget, pool size, observed active peak, permit wait, and scheduler gap.

UTXO reads are prefetched in bounded groups of 64 inputs. The canonical UTXO RAM cache is now an explicit bounded LRU cache; its order is updated at the commit publication boundary so cache hits do not require a hot-path global lock. The successful commit path reuses the cache allocation with copy-on-write instead of cloning the full 50,000-entry cache every batch.

SQLite remains authoritative. No additional canonical SQLite writers are introduced and consensus ordering is unchanged.
