#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CHAIN="$ROOT/crates/state/src/chainstate.rs"
LIB="$ROOT/crates/state/src/lib.rs"
DB="$ROOT/crates/state/src/db.rs"
test -f "$CHAIN" && test -f "$LIB" && test -f "$DB"
grep -q 'batch_outputs: HashMap<OutPoint, (u64, usize, Coin)>' "$CHAIN"
grep -q 'pub fn register_batch_output' "$CHAIN"
grep -q 'pub fn set_position' "$CHAIN"
grep -q 'pub fn prefetch_batch' "$CHAIN"
grep -q 'coins.register_batch_output' "$LIB"
grep -q 'coins.prefetch_batch(&read_tx, &batch_utxo_ops)' "$LIB"
grep -q 'utxo_batch_input_count' "$LIB"
grep -q 'utxo_batch_unique_inputs' "$LIB"
grep -q 'utxo_batch_local_hits' "$LIB"
grep -q 'snap.multi_get_cf' "$DB"
echo 'Zebra-style batch UTXO overlay checks passed.'
