#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STATE="$ROOT/crates/state/src/lib.rs"

# The verifier is the single TXID producer. The ordered state path must reuse
# the carried (txid, rawtx) pair rather than recomputing txid(rawtx).
if grep -n 'ycash_chain::txid(rawtx)' "$STATE"; then
  echo "ERROR: ordered state path still recomputes TXIDs from rawtx" >&2
  exit 1
fi

grep -q 'let (txid, supplied_rawtx) = &b.txs\[tx_index\];' "$STATE"
grep -q 'supplied transaction bytes do not match raw block' "$STATE"
grep -q 'for (tx_index, ((txid, _rawtx), tx))' "$STATE"

echo "TXID reuse verification: PASS"
echo "  verifier-owned TXIDs are reused by batch UTXO prefetch and ordered commit"
echo "  supplied transaction bytes are checked before the carried TXID is used"
