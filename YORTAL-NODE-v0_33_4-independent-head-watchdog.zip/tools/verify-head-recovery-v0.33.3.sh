#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
D="$ROOT/crates/node/src/downloader.rs"
P="$ROOT/crates/node/src/peer_manager.rs"
# Every claim records its owner (the v0.33.2 bug: forward claims had none).
grep -q 'pub fn claim(&self, hash: \[u8; 32\], peer: &str)' "$D"
grep -q 'owner: String' "$D"
# Global watchdog + bounded back-off + owner-checked release.
grep -q 'pub fn steal_stale_head' "$D"
grep -q 'pub fn head_retry_timeout' "$D"
grep -q 'pub fn release_transport' "$D"
grep -q 'pub fn adopt_arrival' "$D"
grep -q 'head_only' "$D"
grep -q 'fn a_forward_claim_promoted_to_head_can_be_reassigned' "$D"
grep -q 'pub fn best_alternate' "$P"
# The optimistic "in flight" flag must be derived from the registry.
grep -q 'set_missing_parent_in_flight(self.registry.is_claimed(&hash))' "$D"
# No unconditional session-side release of possibly foreign claims.
! grep -q 'self.registry.release(hash)' "$D"
! grep -q 'self.registry.release(&hash)' "$D"
echo "v0.33.3 head-recovery static checks passed"
