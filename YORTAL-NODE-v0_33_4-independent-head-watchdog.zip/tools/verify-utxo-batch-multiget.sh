#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CHAIN="$ROOT/crates/state/src/chainstate.rs"
LIB="$ROOT/crates/state/src/lib.rs"
DB="$ROOT/crates/state/src/db.rs"
RUNTIME="$ROOT/crates/ycash-android-node/src/runtime.rs"
COORD="$ROOT/crates/ycash-android-node/src/sync_coordinator.rs"
MAIN="$ROOT/crates/ycash-android-node/src/main.rs"

for f in "$CHAIN" "$LIB" "$DB" "$RUNTIME" "$COORD" "$MAIN"; do test -f "$f"; done

grep -q 'pub fn prefetch_batch' "$CHAIN"
grep -q 'coins.prefetch_batch(&read_tx, &batch_utxo_ops)' "$LIB"
grep -q 'pub fn utxos_timed' "$DB"
grep -q 'snap.multi_get_cf' "$DB"
grep -q 'utxo_db_lookup_us' "$LIB"
grep -q 'utxo_db_lookup_keys' "$LIB"
grep -q 'utxo_cache_hit_rate_ppm' "$LIB"
grep -q 'last_utxo_db_lookup_us' "$RUNTIME"
grep -q 'last_utxo_db_lookup_keys' "$RUNTIME"
grep -q 'last_utxo_cache_hit_rate_ppm' "$RUNTIME"
grep -q 'timing.utxo_db_lookup_us' "$COORD"
grep -q 'last_utxo_db_lookup_us' "$MAIN"

# The verifier must not regress to a block-local prefetch call.
if grep -q 'coins.prefetch_batch(&read_tx, &batch_utxo_ops)' "$LIB" && grep -n 'coins.prefetch_batch(&read_tx, &batch_utxo_ops)' "$LIB" | grep -qE '^([0-9]+):' ; then :; fi

echo 'UTXO batch MultiGet + storage-latency telemetry checks passed.'
