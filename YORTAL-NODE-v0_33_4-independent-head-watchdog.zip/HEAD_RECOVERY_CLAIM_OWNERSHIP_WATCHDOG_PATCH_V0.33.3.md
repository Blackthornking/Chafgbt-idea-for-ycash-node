# YORTAL v0.33.3 — Head-request ownership fix + global head watchdog

## Symptom (v0.33.2)

Sync stops at a canonical head (height 5815 in the field report) while headers keep
arriving at hundreds per second and CPU, validation and DB commit are all idle:

```
Canonical head blocked at height 5815 — missing block parent
wait 14s · head request active · retries 0
```

`retries` stays 0 and the request is never replaced until the generic 90 s transport
timeout finally fires.

## Root cause

`InFlightRegistry` only recorded a *head owner* for claims made through
`claim_head()`. But the block that becomes `canonical + 1` is, almost every time, a
block that was **already claimed earlier as ordinary forward work** (`claim()` in
`assign_forward`) — it sat inside the 48-block download window before the chain
reached it. For such a block:

1. `retry_canonical_parent()` → `reassign_head()` found no head owner → returned
   `false` → "do not drop the local request" → nothing happened.
2. `assign()` saw `is_claimed(head)` and set `missing_parent_in_flight = true` again.
3. Result: "head request active", `retries = 0`, and the pipeline waited for the
   90 s `REQUEST_TIMEOUT` (or forever if the owning peer thread was blocked).

Related defects found while tracing it:

* `assign()` also set the "in flight" flag when `claim_head()` was *refused* by the
  hand-off window, so the dashboard reported an active request nobody had made.
* Recovery ran only on the owning peer's own thread. A peer thread blocked in
  header sync or in a slow mid-frame socket read could never retry its own head.
* A peer whose 16-slot window was full of forward blocks could never be handed the
  head (`top_up()` returned before asking for work).
* `alternate_peer()` picked an arbitrary map entry — possibly the failing peer's
  equally dead neighbour.
* `expire_stale()`/`release_all()`/`release_hash()` released claims *unconditionally*,
  so a session could free a claim that had meanwhile moved to another peer or into
  verification, creating duplicate downloads.
* A late (but valid) delivery from a peer whose head request had just been handed off
  was thrown away and downloaded again.
* `assign()` could leave a head claim behind if the forward assignment errored.
* `break_stale_transport_claim()` and `HEAD_STALL_TIMEOUT` existed but nothing used them.

## Changes (crates/node)

`downloader.rs`

* **One-lock registry** (`RegistryInner`): claim state, **owner of every claim**, claim
  time, time it became the head, hand-off nomination and per-head failure history.
* `claim(hash, peer)` now records the owner, so a forward claim promoted to head is
  retried / reassigned like any other head request.
* **Global head watchdog** (`steal_stale_head`, called from `assign()`): any peer that
  asks for work can atomically take over a head transport request older than the
  timeout. Recovery no longer depends on the owner's thread being responsive.
  Verifying/Verified claims are never stolen.
* Staleness is measured from `max(claim time, time it became head)` so a block that
  was claimed long ago as forward work gets a fair window after promotion.
* **Bounded back-off**: 8 s base (`CANONICAL_PARENT_RETRY_TIMEOUT`), ×1.5 per failed
  attempt on the same hash, capped at `HEAD_STALL_TIMEOUT` (30 s). Reset on commit.
* **Per-head peer cool-down** (20 s): a peer that just failed a head is not given it
  again while another peer is connected; with a single peer it retries immediately.
* **Head may use one slot beyond the per-peer limit** (`assign(.., head_only)`), so a
  full window cannot prevent taking the head.
* `release_transport(hash, peer)`: sessions only free claims they still own.
* `adopt_arrival()`: a valid late delivery whose claim was released is adopted into
  verification instead of discarded (never for already-canonical heights).
* Orphaned Verifying/Verified head claims (>120 s, never reached the gate) are broken
  and re-requested (`break_stale_lifecycle`).
* `missing_parent_in_flight` is now set from the registry (`is_claimed`), never
  optimistically. The dashboard shows `head request needs recovery` when nobody holds it.
* `assign()` rolls back its head claim if forward assignment errors.
* Extra head trace events: `STOLEN`, `LIFECYCLE_RECOVERED`, and unified
  `TIMEOUT_REASSIGN` / `NOTFOUND` / `DISCONNECT_REASSIGN` details.

`peer_manager.rs`

* `best_alternate()` — healthiest other peer (fewest timeouts, then fewest in flight,
  then name). `alternate_peer()` delegates to it.

## Consensus impact

None. Only transport ownership, retry policy and diagnostics changed. Validation,
chain selection and commit paths are untouched.

## Tests added

`downloader.rs`: forward-claim-promoted-to-head reassignment (the field bug), stale
head takeover + cool-down, non-owner cannot release, late-delivery adoption, back-off
bound/reset, head status, orphaned lifecycle recovery, verified candidates never
stolen. `peer_manager.rs`: healthiest alternate selection.

## Build note

This environment has no Rust toolchain, so `cargo build` / `cargo test` could not be
run here. Run `cargo test -p ycash-node` before packaging; `tools/verify-head-recovery-v0.33.3.sh`
performs the static checks.
