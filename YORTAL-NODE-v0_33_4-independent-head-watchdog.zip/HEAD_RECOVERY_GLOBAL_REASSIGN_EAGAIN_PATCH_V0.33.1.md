# YORTAL v0.33.1 — Global Head Recovery + EAGAIN Diagnostic Isolation

## Purpose

Fix the remaining canonical-height+1 head-of-line stall without allowing a timed-out
peer to immediately reclaim the same block, and stop Android/Linux EAGAIN handshake
noise from replacing the pipeline diagnosis shown in the dashboard.

## Global canonical-head recovery

The exact `canonical_height + 1` block now has global transport ownership in the
shared `InFlightRegistry`:

- records the current head owner peer;
- records a preferred replacement peer after a timeout;
- atomically releases the stale transport claim;
- temporarily prevents the old peer from reclaiming the head;
- allows the selected replacement peer to claim the head first;
- falls back to any peer after the short hand-off window if the selected peer does
  not request it;
- keeps verification/prospective lifecycle claims protected from transport theft.

The speculative forward assignment path also explicitly skips `canonical+1`, so it
cannot bypass the head hand-off and accidentally reclaim the block.

The previous per-session `retry_canonical_parent()` behaviour is therefore no longer
"release then immediately request the same hash from the same session". It is now a
global peer-to-peer hand-off.

## Diagnostics

Added a separate `pipeline_error` field to `LiveNodeState` and the status JSON.

- `last_error` remains the latest network/peer/process error and may contain
  `EAGAIN (os error 11)`.
- `pipeline_error` is owned by the sync pipeline and reports the actual ordered
  bottleneck, including missing canonical parent state.
- The Android dashboard now displays `pipeline_error` in the pipeline diagnostic
  panel and shows the network/peer error separately in the detailed diagnostics.

Therefore a transient handshake EAGAIN cannot overwrite an active
`ORDERED HEAD / MISSING PARENT` diagnosis.

## Tests added

A downloader unit test verifies that after a head is reassigned from peer A to
peer B, peer A cannot reclaim it during the hand-off and peer B can claim it.

## Build note

This environment does not contain the Rust toolchain (`cargo`/`rustc`), so a local
Rust compile/test run could not be executed here. The source changes were checked
for all call-site updates and the Android JSON/UI field wiring.
