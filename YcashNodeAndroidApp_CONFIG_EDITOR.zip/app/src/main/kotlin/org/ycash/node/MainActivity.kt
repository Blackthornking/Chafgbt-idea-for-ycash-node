package org.ycash.node

import android.graphics.Color
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.os.Bundle
import android.view.Gravity
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var dashboard: TextView
    private lateinit var logs: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var saveIndexButton: Button
    private lateinit var optionsButton: Button

    private var daemon: Process? = null
    private var monitorJob: Job? = null
    private lateinit var dataDir: File
    private lateinit var indexDb: YTeleportIndexDb
    private var indexBuilding = false
    private var indexedTip = -1L
    private val checkpointStride = 1000L

    private val rpcUrl = "http://127.0.0.1:8832/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        dataDir = File(filesDir, "ycash")
        dataDir.mkdirs()
        indexDb = YTeleportIndexDb(this, File(dataDir, "yteleport_index.db").absolutePath)

        buildUi()
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val c = indexDb.readableDatabase.rawQuery("SELECT value FROM metadata WHERE key = ?", arrayOf("indexed_tip"))
                c.use { if (it.moveToFirst()) indexedTip = it.getString(0).toLongOrNull() ?: -1L }
            } catch (_: Exception) {}
        }

        lifecycleScope.launch(Dispatchers.IO) {
            val bin = daemonBinary()
            runOnUiThread {
                if (daemonAvailable()) {
                    status.text = "READY"
                    dashboard.text = "Daemon: packaged\nExecutable: ${bin.absolutePath}\nData: ${dataDir.absolutePath}\nRPC: 127.0.0.1:8832 (local only)"
                    startButton.isEnabled = true
                } else {
                    status.text = "DAEMON NOT INSTALLED"
                    dashboard.text = "ycashd was not packaged into the native library directory.\nExpected: ${bin.absolutePath}"
                    startButton.isEnabled = false
                }
            }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val title = TextView(this).apply {
            text = "Ycash Node"
            textSize = 30f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.BLACK)
            setPadding(20, 20, 20, 20)
            gravity = Gravity.CENTER_VERTICAL
        }

        status = TextView(this).apply {
            text = "STARTING"
            textSize = 18f
            setPadding(0, 20, 0, 8)
        }

        dashboard = TextView(this).apply {
            textSize = 16f
            setPadding(0, 8, 0, 16)
        }

        startButton = Button(this).apply {
            text = "START NODE"
            isEnabled = false
            setOnClickListener { startNode() }
        }

        saveIndexButton = Button(this).apply {
            text = "SAVE YTELEPORT INDEX AS TEXT"
            isEnabled = false
            setOnClickListener { saveIndexAsText() }
        }

        optionsButton = Button(this).apply {
            text = "⚙ OPTIONS — Ycash.conf"
            setOnClickListener { showConfigEditor() }
        }

        stopButton = Button(this).apply {
            text = "STOP NODE"
            setOnClickListener { stopNode() }
        }

        val logTitle = TextView(this).apply {
            text = "Node log"
            textSize = 18f
            setPadding(0, 16, 0, 8)
        }

        logs = TextView(this).apply {
            textSize = 12f
            setPadding(0, 0, 0, 16)
        }

        val scroll = ScrollView(this).apply {
            addView(logs)
        }

        root.addView(title)
        root.addView(status)
        root.addView(dashboard)
        root.addView(startButton)
        root.addView(saveIndexButton)
        root.addView(optionsButton)
        root.addView(stopButton)
        root.addView(logTitle)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    // The daemon is packaged by the CI workflow as:
    //   app/src/main/jniLibs/arm64-v8a/libycashd.so
    //
    // Android installs that file into applicationInfo.nativeLibraryDir.
    // Do NOT copy the executable into filesDir/cacheDir/codeCacheDir and try
    // to chmod/execute it there: Android 10+ W^X prevents executing binaries
    // from app-writable storage and that produces error=13 (EACCES).
    private fun daemonBinary(): File {
        return File(applicationInfo.nativeLibraryDir, "libycashd.so")
    }

    private fun daemonAvailable(): Boolean {
        val bin = daemonBinary()
        return bin.isFile && bin.length() > 0L && bin.canExecute()
    }

    /**
     * Open the actual ycash.conf used by ycashd. The editor deliberately edits
     * the complete file so advanced Ycash options are not silently discarded.
     * Saving is blocked while the daemon is running; restart is required for
     * configuration changes to take effect.
     */
    private fun showConfigEditor() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val configFile = ensureYcashConfig()
                val current = configFile.readText()
                runOnUiThread {
                    val editor = EditText(this@MainActivity).apply {
                        setText(current)
                        setSelection(text.length)
                        setPadding(24, 16, 24, 16)
                        gravity = Gravity.TOP or Gravity.START
                        minLines = 18
                        maxLines = 28
                        inputType = InputType.TYPE_CLASS_TEXT or
                            InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                        isSingleLine = false
                    }

                    val dialog = AlertDialog.Builder(this@MainActivity)
                        .setTitle("Ycash.conf")
                        .setMessage("Editing: ${configFile.absolutePath}\n\nStop the node before saving. Changes are applied after the next node start.")
                        .setView(editor)
                        .setNegativeButton("CANCEL", null)
                        .setPositiveButton("SAVE", null)
                        .create()

                    dialog.setOnShowListener {
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                            if (daemon?.isAlive == true) {
                                android.widget.Toast.makeText(
                                    this@MainActivity,
                                    "Stop the node before saving ycash.conf",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                                return@setOnClickListener
                            }

                            val text = editor.text.toString()
                            if (text.isBlank()) {
                                android.widget.Toast.makeText(
                                    this@MainActivity,
                                    "ycash.conf cannot be empty",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                                return@setOnClickListener
                            }

                            lifecycleScope.launch(Dispatchers.IO) {
                                try {
                                    val tmp = File(configFile.parentFile, "ycash.conf.tmp")
                                    tmp.writeText(if (text.endsWith("\n")) text else "$text\n")
                                    if (!tmp.renameTo(configFile)) {
                                        configFile.writeText(if (text.endsWith("\n")) text else "$text\n")
                                        tmp.delete()
                                    }
                                    runOnUiThread {
                                        logs.append("ycash.conf saved: ${configFile.absolutePath}\n")
                                        android.widget.Toast.makeText(
                                            this@MainActivity,
                                            "Saved to the node's ycash.conf",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                        dialog.dismiss()
                                    }
                                } catch (e: Exception) {
                                    runOnUiThread {
                                        android.widget.Toast.makeText(
                                            this@MainActivity,
                                            "Could not save ycash.conf: ${e.message ?: "unknown error"}",
                                            android.widget.Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            }
                        }
                    }
                    dialog.show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    android.widget.Toast.makeText(
                        this@MainActivity,
                        "Could not open ycash.conf: ${e.message ?: "unknown error"}",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun startNode() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val bin = daemonBinary()
                val configFile = ensureYcashConfig()
                val runtime = File(applicationInfo.nativeLibraryDir, "libc++_shared.so")
                if (!daemonAvailable()) {
                    throw IllegalStateException("ycashd is not executable from nativeLibraryDir: ${bin.absolutePath}")
                }
                if (!runtime.isFile || runtime.length() == 0L) {
                    throw IllegalStateException("Required libc++_shared.so is missing from nativeLibraryDir: ${runtime.absolutePath}")
                }
                if (daemon?.isAlive == true) return@launch

                // Report what is actually on disk before launching.
                //
                // "cannot locate symbol ..." has now been chased twice on
                // theory alone -- first the library was missing, then the
                // linker was not told where to look. Rather than guess a
                // third time, list nativeLibraryDir and the environment the
                // process will get. One run then answers whether
                // libc++_shared.so is present at all, which distinguishes a
                // packaging problem from a lookup problem.
                val libDirPath = applicationInfo.nativeLibraryDir
                val libDirFile = File(libDirPath)
                val listing = (libDirFile.listFiles() ?: emptyArray())
                    .sortedBy { it.name }
                    .joinToString("\n") { f ->
                        "  ${f.name}  ${f.length()} bytes  exec=${f.canExecute()}"
                    }
                    .ifEmpty { "  (empty or unreadable)" }

                // Which build is this, really.
                //
                // Three consecutive launches produced a byte-identical
                // daemon, which only showed up by comparing sizes across
                // screenshots. The fingerprint is written by CI at package
                // time, so a stale install is obvious immediately rather
                // than after another round of theorising.
                val fingerprint = try {
                    assets.open("ycashd-build.txt").bufferedReader().readText().trim()
                } catch (_: Exception) {
                    "(no build fingerprint — built before this was added)"
                }

                val diagnostics = buildString {
                    appendLine("ycashd build:")
                    appendLine(fingerprint.prependIndent("  "))
                    appendLine()
                    appendLine("nativeLibraryDir: $libDirPath")
                    appendLine(listing)
                    appendLine("libc++_shared.so present (required): " +
                        File(libDirFile, "libc++_shared.so").isFile)
                }

                runOnUiThread {
                    status.text = "STARTING NODE…"
                    startButton.isEnabled = false
                    logs.text = diagnostics + "\nycash.conf: ${configFile.absolutePath}\n"
                }

                val builder = ProcessBuilder(
                    bin.absolutePath,
                    "-datadir=${dataDir.absolutePath}",
                    "-daemon=0",
                    "-listen=1",
                    "-discover=1",
                    // Keep the complete blockchain on disk. Do not enable pruning.
                    "-prune=0",
                    "-rpcbind=127.0.0.1",
                    "-rpcallowip=127.0.0.1",
                    "-rpcport=8832",
                    "-printtoconsole=1"
                ).redirectErrorStream(true)

                // Tell the dynamic linker where ycashd's bundled libraries live.
                // The APK contains the exact NDK libc++_shared.so used for the
                // build, in the same nativeLibraryDir as ycashd.
                //
                // A ProcessBuilder child does not inherit a useful Android
                // application library search path automatically, so set it
                // explicitly before exec.
                //
                // If libc++_shared.so is absent, the diagnostics above make
                // that immediately visible instead of hiding it behind:
                //
                //   cannot locate symbol "_ZTVNSt6__ndk119basic_ostringstream..."
                //
                // which is a libc++ vtable. The library was present the whole
                // time; nothing was looking for it in the right place.
                val existing = System.getenv("LD_LIBRARY_PATH")
                val ldPath =
                    if (existing.isNullOrEmpty()) libDirPath else "$libDirPath:$existing"
                builder.environment()["LD_LIBRARY_PATH"] = ldPath

                runOnUiThread {
                    logs.append("LD_LIBRARY_PATH=$ldPath\n\n")
                }

                val proc = builder.start()

                daemon = proc

                runOnUiThread {
                    status.text = "RUNNING — FULL BLOCKCHAIN SYNC"
                    startButton.isEnabled = false
                }

                startMonitoring()

                proc.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { line ->
                        appendLog(line)
                    }
                }

                monitorJob?.cancel()
                runOnUiThread {
                    status.text = "STOPPED"
                    startButton.isEnabled = true
                }
            } catch (e: Exception) {
                monitorJob?.cancel()
                runOnUiThread {
                    status.text = "START FAILED"
                    dashboard.text = e.message ?: "Unknown error"
                    startButton.isEnabled = true
                }
            }
        }
    }

    /**
     * Create the daemon configuration on first start.
     *
     * The layout follows the Ycash 4.5.0 contrib/debian/examples/ycash.conf
     * template, with Android-specific localhost-only RPC settings. The file
     * lives under the app-private data directory, so credentials are not
     * exposed to other apps. Existing user configuration is never overwritten.
     */
    private fun ensureYcashConfig(): File {
        val configFile = File(dataDir, "ycash.conf")
        if (configFile.isFile && configFile.length() > 0L) {
            return configFile
        }

        val random = ByteArray(32)
        SecureRandom().nextBytes(random)
        val rpcPassword = random.joinToString("") { "%02x".format(it.toInt() and 0xff) }

        val config = """
            ## Ycash Android Node configuration
            ## Generated automatically on first node start.
            ## Based on the Ycash 4.5.0 example configuration.

            # Full blockchain storage; do not prune.
            prune=0

            # P2P listening/discovery.
            listen=1
            discover=1

            # Enable JSON-RPC for the wallet/node UI.
            server=1

            # RPC is deliberately restricted to the local Android app.
            rpcbind=127.0.0.1
            rpcallowip=127.0.0.1
            rpcport=8832
            rpcuser=ycashandroid
            rpcpassword=$rpcPassword
            rpcclienttimeout=30

            # Keep RPC client connections local; do not expose port 8832.
        """.trimIndent() + "\n"

        configFile.parentFile?.mkdirs()
        configFile.writeText(config)
        try {
            configFile.setReadable(false, false)
            configFile.setWritable(false, false)
            configFile.setReadable(true, true)
            configFile.setWritable(true, true)
        } catch (_: Exception) {
            // Android app-private storage is already protected by the app UID.
        }
        return configFile
    }

    private fun startMonitoring() {
        monitorJob?.cancel()
        monitorJob = lifecycleScope.launch(Dispatchers.IO) {
            while (isActive && daemon?.isAlive == true) {
                updateDashboard()
                delay(2000)
            }
        }
    }

    private fun updateDashboard() {
        try {
            val chain = rpc("getblockchaininfo")
            val network = rpc("getnetworkinfo")
            val peers = rpc("getpeerinfo")

            val chainName = chain.optString("chain", "unknown")
            val blocks = chain.optLong("blocks", 0L)
            val headers = chain.optLong("headers", blocks)
            val progress = chain.optDouble("verificationprogress", 0.0)
            val initialDownload = chain.optBoolean("initial_block_download", false)
            val diskBytes = chain.optLong("size_on_disk", calculateDataSize(dataDir))

            val connections = network.optInt("connections", peers.length())
            val version = network.optString("subversion", "unknown")
            val protocol = network.optInt("protocolversion", 0)

            val percent = (progress * 100.0).coerceIn(0.0, 100.0)
            val syncState = when {
                initialDownload -> "SYNCING"
                headers > blocks -> "CATCHING UP"
                else -> "SYNCHRONIZED"
            }

            if (!initialDownload && headers <= blocks && blocks >= 0) {
                buildIndexIfNeeded(blocks, chainName)
            }

            val text = buildString {
                appendLine("$syncState")
                appendLine()
                appendLine("Block height       $blocks")
                appendLine("Network headers    $headers")
                appendLine(String.format(Locale.US, "Verification        %.2f%%", percent))
                appendLine("Peers              $connections")
                appendLine("Chain              $chainName")
                appendLine("Node version       $version")
                appendLine("Protocol           $protocol")
                appendLine("Blockchain data    ${formatBytes(diskBytes)}")
                appendLine("RPC                LOCAL ONLY (127.0.0.1:8832)")
                appendLine()
                appendLine("YTeleport Index    ${if (indexedTip >= blocks && blocks > 0) "READY" else if (indexBuilding) "BUILDING" else "NOT BUILT"}")
                appendLine("Index database     ${File(dataDir, "yteleport_index.db").absolutePath}")
                appendLine("Checkpoint stride  $checkpointStride blocks")
                appendLine("ProofSkip           NOT IMPLEMENTED")
                appendLine("BridgeSkip          NOT IMPLEMENTED")
            }

            runOnUiThread {
                status.text = syncState
                dashboard.text = text
            }
        } catch (e: Exception) {
            runOnUiThread {
                if (daemon?.isAlive == true) {
                    status.text = "RUNNING — RPC WAITING"
                    dashboard.text = "Node process is running, but RPC status is not available yet.\n\nRPC: 127.0.0.1:8832 (local only)\n${e.message ?: "Waiting for daemon RPC…"}"
                }
            }
        }
    }

    private fun buildIndexIfNeeded(tipHeight: Long, chainName: String) {
        if (indexBuilding || tipHeight <= 0L) return
        if (indexedTip >= tipHeight) {
            runOnUiThread { saveIndexButton.isEnabled = true }
            return
        }
        indexBuilding = true
        runOnUiThread {
            saveIndexButton.isEnabled = false
            dashboard.text = dashboard.text.toString() + "\n\nBuilding YTeleport checkpoint index…"
        }
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                indexDb.putMetadata("chain", chainName)
                indexDb.putMetadata("tip_height", tipHeight.toString())
                indexDb.putMetadata("checkpoint_stride", checkpointStride.toString())
                indexDb.putMetadata("format_version", "1")
                indexDb.putMetadata("created_or_updated", System.currentTimeMillis().toString())

                var height = 0L
                while (height <= tipHeight) {
                    addBlockCheckpoint(height)
                    height += checkpointStride
                }
                if (tipHeight % checkpointStride != 0L) addBlockCheckpoint(tipHeight)
                indexedTip = tipHeight
                indexDb.putMetadata("indexed_tip", tipHeight.toString())
                runOnUiThread {
                    saveIndexButton.isEnabled = true
                    dashboard.text = dashboard.text.toString().replace("Building YTeleport checkpoint index…", "YTeleport checkpoint index READY")
                }
            } catch (e: Exception) {
                appendLog("YTeleport index build failed: ${e.message ?: "unknown error"}")
            } finally {
                indexBuilding = false
            }
        }
    }

    private fun addBlockCheckpoint(height: Long) {
        val hashResult = rpcWithParams("getblockhash", JSONArray().put(height))
        val hash = hashResult.optString("result", "")
        if (hash.isEmpty()) throw IllegalStateException("No block hash for height $height")
        val header = rpcWithParams("getblockheader", JSONArray().put(hash))
        indexDb.addCheckpoint(
            height = height,
            hash = header.optString("hash", hash),
            previousHash = header.optString("previousblockhash", null),
            time = if (header.has("time")) header.optLong("time") else null,
            medianTime = if (header.has("mediantime")) header.optLong("mediantime") else null,
            nTx = if (header.has("nTx")) header.optLong("nTx") else null,
            chainwork = header.optString("chainwork", null)
        )
    }

    private fun rpcWithParams(method: String, params: JSONArray): JSONObject {
        val cookieFile = File(dataDir, ".cookie")
        if (!cookieFile.exists()) throw IllegalStateException("RPC cookie not available yet")
        val cookie = cookieFile.readText().trim()
        val connection = (URL(rpcUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 3000
            readTimeout = 8000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Basic " + android.util.Base64.encodeToString(cookie.toByteArray(), android.util.Base64.NO_WRAP))
        }
        try {
            val request = JSONObject().apply {
                put("jsonrpc", "1.0")
                put("id", "ycash-node-index")
                put("method", method)
                put("params", params)
            }
            connection.outputStream.use { it.write(request.toString().toByteArray()) }
            val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            val error = json.opt("error")
            if (error != null && error != JSONObject.NULL) throw IllegalStateException(error.toString())
            return json
        } finally { connection.disconnect() }
    }

    private fun saveIndexAsText() {
        if (indexedTip <= 0L || indexBuilding) return
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "ycash_yteleport_checkpoint_index.txt")
        }
        startActivityForResult(intent, 4101)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 4101 || resultCode != RESULT_OK || data?.data == null) return
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter()?.use { it.write(indexDb.exportText()) }
                runOnUiThread { appendLog("YTeleport index saved as text file") }
            } catch (e: Exception) {
                appendLog("Could not save index: ${e.message ?: "unknown error"}")
            }
        }
    }

    private fun rpc(method: String): JSONObject {
        val cookieFile = File(dataDir, ".cookie")
        if (!cookieFile.exists()) {
            throw IllegalStateException("RPC cookie not available yet")
        }

        val cookie = cookieFile.readText().trim()
        val connection = (URL(rpcUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 1500
            readTimeout = 2500
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Basic " + android.util.Base64.encodeToString(cookie.toByteArray(), android.util.Base64.NO_WRAP))
        }

        try {
            val request = JSONObject().apply {
                put("jsonrpc", "1.0")
                put("id", "ycash-node-dashboard")
                put("method", method)
                put("params", JSONArray())
            }

            connection.outputStream.use { it.write(request.toString().toByteArray()) }
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(response)
            val error = json.opt("error")
            if (error != null && error != JSONObject.NULL) {
                throw IllegalStateException(error.toString())
            }
            return json.optJSONObject("result") ?: throw IllegalStateException("Invalid RPC response")
        } finally {
            connection.disconnect()
        }
    }

    private fun appendLog(line: String) {
        runOnUiThread {
            val current = logs.text.toString()
            val updated = (current + line + "\n").takeLast(12000)
            logs.text = updated
        }
    }

    private fun calculateDataSize(dir: File): Long {
        if (!dir.exists()) return 0L
        return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var index = -1
        while (value >= 1024 && index < units.lastIndex) {
            value /= 1024.0
            index++
        }
        return String.format(Locale.US, "%.2f %s", value, units[index])
    }

    private fun stopNode() {
        monitorJob?.cancel()
        daemon?.destroy()
        daemon = null
        status.text = "STOPPED"
        dashboard.text = "Node stopped\nData: ${dataDir.absolutePath}\nRPC: local only"
        startButton.isEnabled = daemonAvailable()
    }

    override fun onDestroy() {
        monitorJob?.cancel()
        daemon?.destroy()
        daemon = null
        super.onDestroy()
    }
}
