# Android (NDK) host support.
#
# Requires ANDROID_NDK_HOME to point at an installed NDK, and (optionally)
# ANDROID_API to override the target API level (default 26, matching this
# app's minSdk). Invoke depends as e.g.:
#
#   ANDROID_NDK_HOME=/path/to/ndk make -C depends HOST=aarch64-linux-android NO_WALLET=1
#
# This has not been exercised against a real NDK by the assistant that wrote
# it (no network/NDK available in that environment) -- treat it as a starting
# point to iterate on against real CI build logs, not a guaranteed-green path.

ANDROID_API ?= 26
android_toolchain_bin=$(ANDROID_NDK_HOME)/toolchains/llvm/prebuilt/linux-x86_64/bin

android_CC=$(android_toolchain_bin)/aarch64-linux-android$(ANDROID_API)-clang
android_CXX=$(android_toolchain_bin)/aarch64-linux-android$(ANDROID_API)-clang++
android_AR=$(android_toolchain_bin)/llvm-ar
android_RANLIB=$(android_toolchain_bin)/llvm-ranlib
android_STRIP=$(android_toolchain_bin)/llvm-strip
android_NM=$(android_toolchain_bin)/llvm-nm
android_LIBTOOL=$(android_toolchain_bin)/llvm-ar

# NDK clang already targets bionic + bundles its own libc++ (the only STL
# option on modern NDK) -- do not pull in depends' own libcxx package or try
# to link libstdc++.
android_CXXFLAGS=-stdlib=libc++
android_LDFLAGS=-stdlib=libc++ -fPIE -pie -llog

android_CFLAGS=-pipe -fPIC
android_CXXFLAGS+=$(android_CFLAGS)

android_release_CFLAGS=-O2
android_release_CXXFLAGS=$(android_release_CFLAGS)

android_debug_CFLAGS=-O0 -g
android_debug_CXXFLAGS=$(android_debug_CFLAGS)

aarch64_android_CC=$(android_CC)
aarch64_android_CXX=$(android_CXX)
aarch64_android_AR=$(android_AR)
aarch64_android_RANLIB=$(android_RANLIB)
aarch64_android_STRIP=$(android_STRIP)
aarch64_android_NM=$(android_NM)
