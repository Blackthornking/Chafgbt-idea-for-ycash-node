//! YORTAL v0.30.1 batch proof verifier.
//!
//! This module verifies many proofs against the same verifying key with ONE
//! multi-Miller loop and ONE final exponentiation, using the random
//! linear-combination technique.
//!
//! It no longer depends on bellman. Proof and verifying-key decoding now come
//! from [`crate::groth16`], a verify-only implementation: a node never proves,
//! and bellman's proving half — R1CS synthesis, gadgets, evaluation domains,
//! the query vectors — is weight that was linked and never called. The
//! verifying key is read from the prefix of the parameter file rather than
//! taken from a loaded proving key.
//!
//! Two properties here are worth stating because they are easy to lose in a
//! rewrite and both are better than the obvious implementation:
//!
//! * The public-input commitments are regrouped. Rather than building each
//!   `L_i = IC_0 + Σ_j x_ij·IC_{j+1}` and then combining them — N·(k+1) group
//!   multiplications — `ic_coeff` accumulates `Σ_i r_i·x_ij` in the scalar
//!   field and multiplies each fixed IC base once. The batch costs k+1 group
//!   multiplications no matter how many proofs it holds: 8 instead of 8N for a
//!   Sapling spend. This is exact algebra, so the element fed to the pairing is
//!   identical and the soundness bound is unchanged. bellman's per-proof API
//!   cannot express it.
//! * A batch of one uses r = 1 rather than a random scalar, so the single-proof
//!   path through this code is the exact Groth16 equation with no wasted
//!   randomness, and `verify_set` bisects a failing batch to the exact failing
//!   items instead of re-checking everything linearly.
//!
//! For proofs (A_i, B_i, C_i) with public inputs x_i, each valid proof satisfies
//!
//! ```text
//!   e(A_i, B_i) = e(alpha, beta) * e(L_i, gamma) * e(C_i, delta)
//!   L_i = IC_0 + sum_j x_ij * IC_{j+1}
//! ```
//!
//! With secret random 128-bit scalars r_i the batch checks
//!
//! ```text
//!   prod_i e(r_i*A_i, B_i) * e(sum r_i*L_i, -gamma) * e(sum r_i*C_i, -delta)
//!     == e(alpha, beta)^(sum r_i)
//! ```
//!
//! If any proof is invalid the batch equation holds with probability at most
//! ~2^-128. When a batch fails, every item is re-checked on its own (a batch of
//! one) so the exact failing items are reported.
//!
//! [`SaplingBatchTx`] runs every Sapling check that is *not* a Groth16 pairing
//! exactly as `zcash_proofs::sapling::SaplingVerificationContext` (v0.5) does:
//! small-order checks on cv and rk, spendAuthSig, the cv sum and bindingSig. It
//! derives the same public inputs and queues the proof instead of verifying it.
//! Callers treat a batch rejection as a hint only: the consensus layer re-runs
//! the original single-proof verifier on the rejected transaction and that
//! result is final.

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::OnceLock;

use crate::groth16::{Proof, VerifyingKey};
use bls12_381::{multi_miller_loop, pairing, Bls12, G1Affine, G1Projective, G2Prepared, Gt, Scalar};
use group::{Group, GroupEncoding};
use rand_core::{OsRng, RngCore};
use zcash_primitives::{
    constants::{SPENDING_KEY_GENERATOR, VALUE_COMMITMENT_RANDOMNESS_GENERATOR, VALUE_COMMITMENT_VALUE_GENERATOR},
    redjubjub::{PublicKey, Signature},
    transaction::components::Amount,
};

use crate::verify::ProofError;

/// Global switch. Cleared by [`disable_batching`] (env `YORTAL_BATCH_VERIFY=0`
/// or repeated batch/legacy disagreement) so the node falls back to the
/// original per-proof verifier.
static BATCH_DISABLED: AtomicBool = AtomicBool::new(false);
static BATCHES_RUN: AtomicU64 = AtomicU64::new(0);
static BATCH_PROOFS: AtomicU64 = AtomicU64::new(0);
static BATCH_FAILURES: AtomicU64 = AtomicU64::new(0);

pub fn batching_enabled() -> bool {
    if BATCH_DISABLED.load(Ordering::Relaxed) { return false; }
    if std::env::var("YORTAL_BATCH_VERIFY").ok().as_deref() == Some("0") {
        BATCH_DISABLED.store(true, Ordering::Relaxed);
        return false;
    }
    true
}

pub fn disable_batching() { BATCH_DISABLED.store(true, Ordering::Relaxed); }

/// (batches verified, proofs in them, batches that failed)
pub fn batch_stats() -> (u64, u64, u64) {
    (BATCHES_RUN.load(Ordering::Relaxed), BATCH_PROOFS.load(Ordering::Relaxed), BATCH_FAILURES.load(Ordering::Relaxed))
}

/// Verifying key with the parts the batch equation needs precomputed.
struct BatchKey {
    ic: Vec<G1Affine>,
    alpha_beta: Gt,
    neg_gamma: G2Prepared,
    neg_delta: G2Prepared,
}

impl BatchKey {
    fn new(vk: &VerifyingKey) -> Self {
        BatchKey {
            ic: vk.ic.clone(),
            alpha_beta: pairing(&vk.alpha_g1, &vk.beta_g2),
            neg_gamma: G2Prepared::from(-vk.gamma_g2),
            neg_delta: G2Prepared::from(-vk.delta_g2),
        }
    }
}

static SPEND_KEY: OnceLock<BatchKey> = OnceLock::new();
static OUTPUT_KEY: OnceLock<BatchKey> = OnceLock::new();

// The batch verifier needs the verifying key and nothing else. It no longer
// reaches into the loaded proving-key `Parameters` for `params.vk`, which is
// what forced ~51 MB of proving key to stay resident to read ~3 KB off its
// front. `crate::groth16_verifying_keys` holds keys parsed from the params
// prefix.
fn spend_key() -> Option<&'static BatchKey> {
    if let Some(k) = SPEND_KEY.get() { return Some(k); }
    let vk = crate::sapling_spend_verifying_key()?;
    Some(SPEND_KEY.get_or_init(|| BatchKey::new(vk)))
}

fn output_key() -> Option<&'static BatchKey> {
    if let Some(k) = OUTPUT_KEY.get() { return Some(k); }
    let vk = crate::sapling_output_verifying_key()?;
    Some(OUTPUT_KEY.get_or_init(|| BatchKey::new(vk)))
}

/// One queued proof and its public inputs. `tag` identifies the owner
/// (the consensus layer encodes block index + transaction index).
struct Item {
    proof: Proof,
    inputs: Vec<Scalar>,
    tag: u64,
}

/// Non-zero random 128-bit scalar.
fn random_scalar(rng: &mut OsRng) -> Scalar {
    loop {
        let mut b = [0u8; 16];
        rng.fill_bytes(&mut b);
        if b.iter().any(|x| *x != 0) {
            let mut repr = [0u8; 32];
            repr[..16].copy_from_slice(&b);
            // < 2^128, always canonical.
            return crate::de_ct(Scalar::from_bytes(&repr)).expect("128-bit scalar is canonical");
        }
    }
}

/// The batch equation over `items`. A slice of one is an exact single-proof check.
fn verify_items(key: &BatchKey, items: &[&Item]) -> bool {
    if items.is_empty() { return true; }
    let n = key.ic.len();
    let mut rng = OsRng;
    let mut ic_coeff = vec![Scalar::zero(); n];
    let mut acc_c = G1Projective::identity();
    let mut r_sum = Scalar::zero();
    let mut terms: Vec<(G1Affine, G2Prepared)> = Vec::with_capacity(items.len() + 2);
    for it in items {
        if it.inputs.len() + 1 != n { return false; }
        let r = if items.len() == 1 { Scalar::one() } else { random_scalar(&mut rng) };
        r_sum += r;
        ic_coeff[0] += r;
        for (j, x) in it.inputs.iter().enumerate() {
            ic_coeff[j + 1] += r * x;
        }
        acc_c += it.proof.c * r;
        terms.push((G1Affine::from(it.proof.a * r), G2Prepared::from(it.proof.b)));
    }
    let mut acc_l = G1Projective::identity();
    for (base, coeff) in key.ic.iter().zip(ic_coeff.iter()) {
        acc_l += base * coeff;
    }
    let l = G1Affine::from(acc_l);
    let c = G1Affine::from(acc_c);
    let mut refs: Vec<(&G1Affine, &G2Prepared)> = terms.iter().map(|(a, b)| (a, b)).collect();
    refs.push((&l, &key.neg_gamma));
    refs.push((&c, &key.neg_delta));
    multi_miller_loop(&refs).final_exponentiation() == key.alpha_beta * r_sum
}

/// Verify a set of items; on failure bisect down to the exact failing tags.
fn verify_set(key: &BatchKey, items: &[&Item], failed: &mut Vec<u64>) {
    if items.is_empty() { return; }
    if verify_items(key, items) { return; }
    if items.len() == 1 {
        failed.push(items[0].tag);
        return;
    }
    let mid = items.len() / 2;
    verify_set(key, &items[..mid], failed);
    verify_set(key, &items[mid..], failed);
}

/// Accumulates Sapling spend and output proofs across many transactions.
#[derive(Default)]
pub struct SaplingBatch {
    spends: Vec<Item>,
    outputs: Vec<Item>,
}

impl SaplingBatch {
    pub fn new() -> Self { Self::default() }

    pub fn len(&self) -> usize { self.spends.len() + self.outputs.len() }
    pub fn is_empty(&self) -> bool { self.len() == 0 }

    /// Move a transaction's proofs (which passed every non-pairing check)
    /// into the batch under `tag`.
    pub fn push(&mut self, tag: u64, tx: SaplingBatchTx) {
        for (proof, inputs) in tx.spends { self.spends.push(Item { proof, inputs, tag }); }
        for (proof, inputs) in tx.outputs { self.outputs.push(Item { proof, inputs, tag }); }
    }

    /// Check every queued proof. `Ok(())` if all are valid, otherwise the
    /// sorted, de-duplicated tags that own at least one invalid proof.
    pub fn verify(self) -> Result<(), Vec<u64>> {
        if self.is_empty() { return Ok(()); }
        let (Some(sk), Some(ok)) = (spend_key(), output_key()) else {
            let mut tags: Vec<u64> = self.spends.iter().chain(self.outputs.iter()).map(|i| i.tag).collect();
            tags.sort_unstable();
            tags.dedup();
            return Err(tags);
        };
        BATCHES_RUN.fetch_add(1, Ordering::Relaxed);
        BATCH_PROOFS.fetch_add(self.len() as u64, Ordering::Relaxed);
        let mut failed = Vec::new();
        let spends: Vec<&Item> = self.spends.iter().collect();
        let outputs: Vec<&Item> = self.outputs.iter().collect();
        verify_set(sk, &spends, &mut failed);
        verify_set(ok, &outputs, &mut failed);
        if failed.is_empty() { return Ok(()); }
        BATCH_FAILURES.fetch_add(1, Ordering::Relaxed);
        failed.sort_unstable();
        failed.dedup();
        Err(failed)
    }
}

/// Per-transaction Sapling checks with the Groth16 pairing deferred.
/// Mirrors `SaplingVerificationContext` from zcash_proofs 0.5.
pub struct SaplingBatchTx {
    cv_sum: jubjub::ExtendedPoint,
    spends: Vec<(Proof, Vec<Scalar>)>,
    outputs: Vec<(Proof, Vec<Scalar>)>,
}

fn is_small_order(p: &jubjub::ExtendedPoint) -> bool {
    bool::from(p.mul_by_cofactor().is_identity())
}

/// `multipack::compute_multipacking(bytes_to_bits_le(bytes))` for 32 bytes:
/// 254 low bits in the first scalar, the top 2 bits in the second.
fn multipack_32(bytes: &[u8; 32]) -> Option<[Scalar; 2]> {
    let mut lo = *bytes;
    lo[31] &= 0x3f;
    let mut hi = [0u8; 32];
    hi[0] = bytes[31] >> 6;
    let a = crate::de_ct(Scalar::from_bytes(&lo))?;
    let b = crate::de_ct(Scalar::from_bytes(&hi))?;
    Some([a, b])
}

fn affine_uv(p: &jubjub::ExtendedPoint) -> (Scalar, Scalar) {
    let a = jubjub::AffinePoint::from(*p);
    (a.get_u(), a.get_v())
}

impl SaplingBatchTx {
    pub fn new() -> Self {
        Self { cv_sum: jubjub::ExtendedPoint::identity(), spends: Vec::new(), outputs: Vec::new() }
    }

    pub fn check_spend(
        &mut self,
        cv: &[u8; 32],
        anchor: &[u8; 32],
        nullifier: &[u8; 32],
        rk: &[u8; 32],
        zkproof: &[u8; 192],
        spend_auth_sig: &[u8; 64],
        sighash: &[u8; 32],
    ) -> Result<(), ProofError> {
        let bad = || ProofError::InvalidSpendProof;
        let cv = crate::de_ct(jubjub::ExtendedPoint::from_bytes(cv)).ok_or_else(bad)?;
        let anchor = crate::de_ct(Scalar::from_bytes(anchor)).ok_or_else(bad)?;
        let rk = PublicKey::read(&rk[..]).map_err(|_| bad())?;
        let sig = Signature::read(&spend_auth_sig[..]).map_err(|_| bad())?;
        let proof = Proof::read(&zkproof[..]).map_err(|_| bad())?;

        if is_small_order(&cv) { return Err(bad()); }
        self.cv_sum += cv;
        if is_small_order(&rk.0) { return Err(bad()); }

        let mut msg = [0u8; 64];
        msg[0..32].copy_from_slice(&rk.0.to_bytes());
        msg[32..64].copy_from_slice(sighash);
        if !rk.verify(&msg, &sig, SPENDING_KEY_GENERATOR) { return Err(bad()); }

        let (rk_u, rk_v) = affine_uv(&rk.0);
        let (cv_u, cv_v) = affine_uv(&cv);
        let nf = multipack_32(nullifier).ok_or_else(bad)?;
        self.spends.push((proof, vec![rk_u, rk_v, cv_u, cv_v, anchor, nf[0], nf[1]]));
        Ok(())
    }

    pub fn check_output(
        &mut self,
        cv: &[u8; 32],
        cmu: &[u8; 32],
        ephemeral_key: &[u8; 32],
        zkproof: &[u8; 192],
    ) -> Result<(), ProofError> {
        let bad = || ProofError::InvalidOutputProof;
        let cv = crate::de_ct(jubjub::ExtendedPoint::from_bytes(cv)).ok_or_else(bad)?;
        let cmu = crate::de_ct(Scalar::from_bytes(cmu)).ok_or_else(bad)?;
        // epk must decode, like librustzcash_sapling_check_output.
        let _epk = crate::de_ct(jubjub::ExtendedPoint::from_bytes(ephemeral_key)).ok_or_else(bad)?;
        let proof = Proof::read(&zkproof[..]).map_err(|_| bad())?;

        if is_small_order(&cv) { return Err(bad()); }
        self.cv_sum -= cv;

        let (cv_u, cv_v) = affine_uv(&cv);
        self.outputs.push((proof, vec![cv_u, cv_v, cmu]));
        Ok(())
    }

    pub fn final_check(&self, value_balance: i64, binding_sig: &[u8; 64], sighash: &[u8; 32]) -> Result<(), ProofError> {
        let bad = || ProofError::InvalidBindingSignature;
        let amount = Amount::from_i64(value_balance).map_err(|_| bad())?;
        let sig = Signature::read(&binding_sig[..]).map_err(|_| bad())?;
        let vb = compute_value_balance(amount).ok_or_else(bad)?;
        let bvk = PublicKey(self.cv_sum - vb);
        let mut msg = [0u8; 64];
        msg[0..32].copy_from_slice(&bvk.0.to_bytes());
        msg[32..64].copy_from_slice(sighash);
        if bvk.verify(&msg, &sig, VALUE_COMMITMENT_RANDOMNESS_GENERATOR) { Ok(()) } else { Err(bad()) }
    }
}

/// `zcash_proofs::sapling::compute_value_balance` (v0.5).
fn compute_value_balance(value: Amount) -> Option<jubjub::ExtendedPoint> {
    let raw = i64::from(value);
    let abs = raw.checked_abs()? as u64;
    let mut vb = VALUE_COMMITMENT_VALUE_GENERATOR * jubjub::Fr::from(abs);
    if raw < 0 { vb = -vb; }
    Some(vb.into())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn multipack_matches_bit_packing() {
        let mut bytes = [0u8; 32];
        for (i, b) in bytes.iter_mut().enumerate() { *b = (i as u8).wrapping_mul(37).wrapping_add(11); }
        bytes[31] = 0xff;
        let [a, b] = multipack_32(&bytes).unwrap();
        // Reference: pack little-endian bits into 254-bit chunks.
        let bits: Vec<bool> = bytes.iter().flat_map(|byte| (0..8).map(move |i| (byte >> i) & 1 == 1)).collect();
        let pack = |chunk: &[bool]| {
            let mut out = [0u8; 32];
            for (i, bit) in chunk.iter().enumerate() { if *bit { out[i / 8] |= 1 << (i % 8); } }
            Scalar::from_bytes(&out).unwrap()
        };
        assert_eq!(a, pack(&bits[..254]));
        assert_eq!(b, pack(&bits[254..]));
    }

    #[test]
    fn random_scalars_are_nonzero() {
        let mut rng = OsRng;
        for _ in 0..64 { assert_ne!(random_scalar(&mut rng), Scalar::zero()); }
    }
}
