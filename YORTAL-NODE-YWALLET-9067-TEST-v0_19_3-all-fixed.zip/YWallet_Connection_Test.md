# YWallet / Lightwalletd connection diagnostics

The app tests the entered endpoint in layers: DNS, TCP, TLS 1.3/cipher, ALPN h2, HTTP/2 SETTINGS, then the standard gRPC `CompactTxStreamer/GetLatestBlock` call. It also reports RST_STREAM and GOAWAY error codes and now sends standard `grpc-accept-encoding` and diagnostic user-agent headers.

For Ycash, the documented lightwalletd endpoint is `https://lite.ycash.xyz:9067`. The gRPC service uses the standard `cash.z.wallet.sdk.rpc.CompactTxStreamer` service and `GetLatestBlock` method.

The Android node's own ports are separate: P2P 8833, JSON-RPC 8832, and localhost status API 8834. The status API is HTTP on loopback only; Android cleartext is explicitly enabled so the app can poll `127.0.0.1:8834/status`.
