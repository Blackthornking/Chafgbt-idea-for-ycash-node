# YORTAL v0.24 — Rust-only Ycash consensus

This revision removes the previous consensus-oracle/daemon dependency. The node is intended to
validate Ycash mainnet blocks itself and to fail closed whenever a consensus-critical verifier is
not available.

## Rules locked to Ycash 4.5.0

- mainnet magic `24e92764`
- P2P port `8833`
- protocol `270013`
- maximum `160` headers per wire `headers` response
- genesis time `1477641360`
- genesis hash `00040fe8ec8471911baa1db1266ea15dd06b4a8a5c453883c000b031973dce08`
- PoW limit `0007ffff...`
- Equihash `200,9` through height `569999`; `192,7` from height `570000`
- 17-block averaging window
- 16% upward / 32% downward adjustment limits
- damping factor 4
- 150-second spacing before Blossom; 75 seconds from Blossom
- Ycash fork scaled-difficulty rules for the first 17 Ycash-fork blocks
- Blossom `1100000`, Heartwood `1100003`, Canopy `1100006`
- NU5 is disabled on mainnet; no v5/Orchard transactions are accepted
- Ycash founders/YDF mandate ends at height `2275000`
- max money `21,000,000 YEC`
- coinbase maturity `100`
- expiry-height threshold `500000000`
- max block size `2,000,000` bytes
- max block sigops `20,000`
- future-time limits: MTP + 3 hours and local clock + 4 hours

## Validation pipeline

1. Parse the complete Ycash transaction format, not just opaque transaction bytes.
2. Validate transaction version/group/expiry rules at the target height.
3. Validate transparent value ranges, duplicate inputs, coinbase structure, duplicate
   Sprout/Sapling nullifiers, and value-balance rules.
4. Validate the complete block transaction list, coinbase position, BIP34 height prefix,
   transaction merkle root, and CVE-2012-2459 merkle mutation rule.
5. Validate header linkage, MTP, difficulty, Equihash and proof-of-work.
6. Before a block is committed, validate transparent UTXO/script state and every shielded
   proof/signature/nullifier requirement. Missing consensus-critical backends are a hard reject,
   never an acceptance shortcut.
7. Commit only after all checks pass, in height order.

## Shielded crypto

`crates/ycash-crypto` contains the Rust cryptographic FFI source used by the Ycash 4.5.0
Rust stack. It is not a daemon and it does not launch a separate node. Sapling/Sprout verification
keys are initialized from external parameter files; the large parameter files are intentionally
not included in the project ZIP.

## Important status

The project must not be described as mainnet-ready until the strict shielded verifier, transparent
script/UTXO verifier, historical replay, and differential corpus all pass. The validator is
fail-closed while any consensus-critical stage is unavailable.
