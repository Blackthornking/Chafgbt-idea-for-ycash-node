# YORTAL v0.30.1 — DB pipeline instrumentation and hot-path fix

Implemented before increasing verifier/commit worker counts.

## 1. Precise commit-stage measurement

`State::commit_blocks_batch()` now reports the existing four timing stages:

- `state_validation_ms` — ordered state/UTXO/Sprout/Sapling checks and transparent script execution.
- `rollback_ms` — reorg cleanup, when applicable.
- `db_write_ms` — block/tx/root/nullifier/UTXO/state writes before SQLite commit.
- `sqlite_commit_ms` — the actual SQLite transaction commit.

Additional counters are logged with `[DBPIPE]`: UTXO lookups, BIP30 checks, and script checks.

This separates a true SQLite fsync/commit bottleneck from CPU-heavy consensus/state work.

## 2. Commit-path optimization

- Transparent UTXO input lookups now use `prepare_cached()` rather than preparing a fresh SQL statement for every lookup.
- BIP30 checks likewise reuse SQLite's prepared-statement cache.
- Normal block/transaction/Sapling-root writes use SQLite UPSERT instead of `INSERT OR REPLACE`; this avoids the delete+insert behavior of REPLACE and reduces B-tree/index churn when a side-chain row becomes canonical during a reorg.
- Existing parsed transactions are still carried from the stateless verification stage into the ordered commit stage; commit does not reparse them when available.
- Canonical state commit remains one ordered transaction. No concurrent DB writers were introduced.

## Consensus safety

No consensus rule is skipped or reordered. The canonical commit path remains height ordered and atomic. `synchronous=NORMAL` is unchanged; durability policy was not changed as a performance shortcut.

## Next measurement

Run the same 16-block baseline and inspect `[DBPIPE] COMMIT` lines. The next decision should be based on the relative values of `state_validation_ms`, `db_write_ms`, and `sqlite_commit_ms`, rather than assuming that the full commit duration is SQLite.
