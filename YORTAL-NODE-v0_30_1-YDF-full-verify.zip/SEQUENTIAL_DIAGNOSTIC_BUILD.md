# Sequential pipeline diagnostic build

This build intentionally serializes block synchronization to one worker/range at a time. It is meant to isolate the first failing stage without concurrent peers producing overlapping retries.

Changes:
- Force pipeline planning to 1 worker.
- Force the Android peer session to run block work with one worker.
- Correct the lookahead height-count check so a 16-height window is not treated as 15.
- Show the node `message` / `last_error` directly below the pipeline card.

Expected diagnostic behavior:
- `In flight` should stay at or below 16 before a range completes.
- `Active workers` should be 1.
- If fetching fails, the main screen should show `Pipeline error: ...` with the concrete error returned by the fetch/validation/commit stage.
