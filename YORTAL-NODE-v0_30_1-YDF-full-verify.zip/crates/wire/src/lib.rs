use anyhow::{bail,Result};
use sha2::{Digest,Sha256};
use ycash_chain::MAINNET_MAGIC;

pub fn checksum(payload:&[u8])->[u8;4]{let a=Sha256::digest(payload); let b=Sha256::digest(a); [b[0],b[1],b[2],b[3]]}
pub fn frame(command:&str,payload:&[u8])->Vec<u8>{let mut o=Vec::with_capacity(24+payload.len());o.extend_from_slice(&MAINNET_MAGIC);let mut c=[0u8;12];let n=command.as_bytes().len().min(12);c[..n].copy_from_slice(&command.as_bytes()[..n]);o.extend_from_slice(&c);o.extend_from_slice(&(payload.len() as u32).to_le_bytes());o.extend_from_slice(&checksum(payload));o.extend_from_slice(payload);o}
pub fn parse_header(h:&[u8])->Result<(String,u32,[u8;4])>{if h.len()!=24{bail!("bad header")} if h[..4]!=MAINNET_MAGIC{bail!("bad network magic")} let end=h[4..16].iter().position(|x|*x==0).unwrap_or(12);let cmd=String::from_utf8(h[4..4+end].to_vec())?;let len=u32::from_le_bytes(h[16..20].try_into().unwrap());Ok((cmd,len,h[20..24].try_into().unwrap()))}
