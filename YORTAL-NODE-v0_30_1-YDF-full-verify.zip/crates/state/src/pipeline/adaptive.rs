//! YORTAL Adaptive Parallel Sync controller.
//! Consensus-neutral scheduling policy: it only controls concurrency and buffering.

#[derive(Debug, Clone, Copy)]
pub struct ResourceSample {
    pub cpu_ratio: f64,
    pub memory_ratio: f64,
    pub db_queue_ratio: f64,
    pub network_ratio: f64,
    pub validation_queue_ratio: f64,
}

#[derive(Debug, Clone, Copy)]
pub struct AdaptiveConfig {
    pub min_window: usize,
    pub initial_window: usize,
    pub max_window: usize,
    pub step: usize,
    pub high_watermark: f64,
    pub low_watermark: f64,
}

impl Default for AdaptiveConfig {
    fn default() -> Self {
        Self {
            // Conservative sequential sync mode: one small block batch at a time.
            min_window: 16,
            initial_window: 16,
            max_window: 16,
            step: 1,
            high_watermark: 0.90,
            low_watermark: 0.55,
        }
    }
}

#[derive(Debug, Clone)]
pub struct AdaptiveController {
    cfg: AdaptiveConfig,
    window: usize,
}

impl AdaptiveController {
    pub fn new(cfg: AdaptiveConfig) -> Self {
        let window = cfg.initial_window.clamp(cfg.min_window, cfg.max_window);
        Self { cfg, window }
    }

    pub fn window(&self) -> usize { self.window }

    /// AIMD-like controller. DB/memory pressure dominates network pressure.
    pub fn observe(&mut self, s: ResourceSample) -> usize {
        let pressure = s.cpu_ratio
            .max(s.memory_ratio)
            .max(s.db_queue_ratio)
            .max(s.validation_queue_ratio);

        if pressure >= self.cfg.high_watermark {
            self.window = self.window.saturating_sub(self.cfg.step)
                .max(self.cfg.min_window);
        } else if pressure <= self.cfg.low_watermark && s.network_ratio < 0.85 {
            self.window = (self.window + self.cfg.step).min(self.cfg.max_window);
        }
        self.window
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn starts_at_configured_initial_window() {
        let cfg = AdaptiveConfig {
            min_window: 64, initial_window: 256, max_window: 4096,
            step: 128, high_watermark: 0.90, low_watermark: 0.55,
        };
        assert_eq!(AdaptiveController::new(cfg).window(), 256);
    }

    #[test]
    fn initial_window_is_clamped() {
        let cfg = AdaptiveConfig {
            min_window: 64, initial_window: 8192, max_window: 4096,
            step: 128, high_watermark: 0.90, low_watermark: 0.55,
        };
        assert_eq!(AdaptiveController::new(cfg).window(), 4096);
    }
}
