
use std::path::Path;
use zcash_proofs::sapling::SaplingVerificationContext;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ProofError {
    NotInitialized,
    InvalidSpendProof,
    InvalidOutputProof,
    InvalidBindingSignature,
    InvalidSproutProof,
}

pub struct SaplingVerifier {
    ctx: *mut SaplingVerificationContext,
}

unsafe impl Send for SaplingVerifier {}
unsafe impl Sync for SaplingVerifier {}

impl SaplingVerifier {
    pub fn new() -> Result<Self, ProofError> {
        let ctx = unsafe { crate::librustzcash_sapling_verification_ctx_init() };
        if ctx.is_null() { return Err(ProofError::NotInitialized); }
        Ok(Self { ctx })
    }

    pub fn check_spend(
        &mut self,
        cv: [u8;32],
        anchor: [u8;32],
        nullifier: [u8;32],
        rk: [u8;32],
        zkproof: [u8;192],
        spend_auth_sig: [u8;64],
        sighash: [u8;32],
    ) -> Result<(), ProofError> {
        let ok = unsafe {
            crate::librustzcash_sapling_check_spend(
                self.ctx, &cv, &anchor, &nullifier, &rk, &zkproof, &spend_auth_sig, &sighash,
            )
        };
        if ok { Ok(()) } else { Err(ProofError::InvalidSpendProof) }
    }

    pub fn check_output(
        &mut self,
        cv: [u8;32],
        cmu: [u8;32],
        ephemeral_key: [u8;32],
        zkproof: [u8;192],
    ) -> Result<(), ProofError> {
        let ok = unsafe {
            crate::librustzcash_sapling_check_output(
                self.ctx, &cv, &cmu, &ephemeral_key, &zkproof,
            )
        };
        if ok { Ok(()) } else { Err(ProofError::InvalidOutputProof) }
    }

    pub fn final_check(
        &self,
        value_balance: i64,
        binding_sig: [u8;64],
        sighash: [u8;32],
    ) -> Result<(), ProofError> {
        let ok = unsafe {
            crate::librustzcash_sapling_final_check(
                self.ctx, value_balance, &binding_sig, &sighash,
            )
        };
        if ok { Ok(()) } else { Err(ProofError::InvalidBindingSignature) }
    }
}

impl Drop for SaplingVerifier {
    fn drop(&mut self) {
        unsafe { crate::librustzcash_sapling_verification_ctx_free(self.ctx) }
    }
}

// The verifier parameters are intentionally external to the project ZIP.
// The node receives absolute paths at startup and initializes the Ycash-patched
// Rust proving/verifying keys without embedding multi-hundred-MB parameter files.
pub fn init_zksnark_params(spend: &Path, output: &Path, sprout: Option<&Path>) -> Result<(), ProofError> {
    use std::ffi::CString;
    use std::os::unix::ffi::OsStrExt;

    let spend = CString::new(spend.as_os_str().as_bytes()).map_err(|_| ProofError::NotInitialized)?;
    let output = CString::new(output.as_os_str().as_bytes()).map_err(|_| ProofError::NotInitialized)?;
    let sprout_c = sprout.map(|p| CString::new(p.as_os_str().as_bytes()).ok()).flatten();

    unsafe {
        crate::librustzcash_init_zksnark_params(
            spend.as_ptr() as *const u8, spend.as_bytes().len(),
            output.as_ptr() as *const u8, output.as_bytes().len(),
            sprout_c.as_ref().map(|x| x.as_ptr() as *const u8).unwrap_or(std::ptr::null()),
            sprout_c.as_ref().map(|x| x.as_bytes().len()).unwrap_or(0),
        );
    }
    Ok(())
}
