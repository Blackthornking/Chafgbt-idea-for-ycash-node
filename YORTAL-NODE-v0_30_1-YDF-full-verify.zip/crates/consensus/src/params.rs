use sha2::{Digest, Sha256};
use std::fs::File;
use std::io::{Read, Result as IoResult};
use std::path::{Path, PathBuf};

#[derive(Debug, Clone)]
pub struct ShieldedParams {
    pub spend: PathBuf,
    pub output: PathBuf,
    pub sprout: Option<PathBuf>,
}

fn sha256_file(path: &Path) -> IoResult<[u8; 32]> {
    let mut f = File::open(path)?;
    let mut h = Sha256::new();
    let mut buf = [0u8; 1024 * 1024];
    loop {
        let n = f.read(&mut buf)?;
        if n == 0 { break; }
        h.update(&buf[..n]);
    }
    Ok(h.finalize().into())
}

fn require_file(path: &Path, label: &str) -> Result<[u8; 32], String> {
    if !path.is_file() { return Err(format!("missing {label} parameter file: {}", path.display())); }
    sha256_file(path).map_err(|e| format!("cannot hash {label} parameter file {}: {e}", path.display()))
}

impl ShieldedParams {
    pub fn verify_files(&self) -> Result<([u8; 32], [u8; 32], Option<[u8; 32]>), String> {
        let spend = require_file(&self.spend, "Sapling spend")?;
        let output = require_file(&self.output, "Sapling output")?;
        let sprout = match &self.sprout {
            Some(p) => Some(require_file(p, "Sprout")?),
            None => None,
        };
        Ok((spend, output, sprout))
    }
}
