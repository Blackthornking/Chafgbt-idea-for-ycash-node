//! Sprout note commitment tree and JoinSplit verification helpers,
//! following ycashd 4.5.0 `zcash/IncrementalMerkleTree.cpp` (depth 29,
//! SHA256Compress) and `zcash/JoinSplit.cpp` (h_sig).

use crate::ConsensusError;
use std::sync::OnceLock;

pub const SPROUT_TREE_DEPTH: usize = 29;

const SHA256_IV: [u32; 8] = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
];
const SHA256_K: [u32; 64] = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

/// `SHA256Compress::combine`: one SHA-256 compression of `a || b` from the
/// standard IV with no padding, output as big-endian state words.
pub fn sha256_compress(a: &[u8; 32], b: &[u8; 32]) -> [u8; 32] {
    let mut block = [0u8; 64];
    block[..32].copy_from_slice(a);
    block[32..].copy_from_slice(b);
    let mut w = [0u32; 64];
    for i in 0..16 {
        w[i] = u32::from_be_bytes([block[4 * i], block[4 * i + 1], block[4 * i + 2], block[4 * i + 3]]);
    }
    for i in 16..64 {
        let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
        let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16].wrapping_add(s0).wrapping_add(w[i - 7]).wrapping_add(s1);
    }
    let [mut a0, mut b0, mut c0, mut d0, mut e0, mut f0, mut g0, mut h0] = SHA256_IV;
    for i in 0..64 {
        let s1 = e0.rotate_right(6) ^ e0.rotate_right(11) ^ e0.rotate_right(25);
        let ch = (e0 & f0) ^ (!e0 & g0);
        let t1 = h0.wrapping_add(s1).wrapping_add(ch).wrapping_add(SHA256_K[i]).wrapping_add(w[i]);
        let s0 = a0.rotate_right(2) ^ a0.rotate_right(13) ^ a0.rotate_right(22);
        let maj = (a0 & b0) ^ (a0 & c0) ^ (b0 & c0);
        let t2 = s0.wrapping_add(maj);
        h0 = g0;
        g0 = f0;
        f0 = e0;
        e0 = d0.wrapping_add(t1);
        d0 = c0;
        c0 = b0;
        b0 = a0;
        a0 = t1.wrapping_add(t2);
    }
    let state = [a0, b0, c0, d0, e0, f0, g0, h0];
    let mut out = [0u8; 32];
    for i in 0..8 {
        out[4 * i..4 * i + 4].copy_from_slice(&SHA256_IV[i].wrapping_add(state[i]).to_be_bytes());
    }
    out
}

fn empty_roots() -> &'static [[u8; 32]; SPROUT_TREE_DEPTH + 1] {
    static ROOTS: OnceLock<[[u8; 32]; SPROUT_TREE_DEPTH + 1]> = OnceLock::new();
    ROOTS.get_or_init(|| {
        let mut r = [[0u8; 32]; SPROUT_TREE_DEPTH + 1];
        for d in 1..=SPROUT_TREE_DEPTH {
            r[d] = sha256_compress(&r[d - 1], &r[d - 1]);
        }
        r
    })
}

/// Sprout incremental Merkle tree, stored as a frontier.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SproutTree {
    pub count: u64,
    pub frontier: [Option<[u8; 32]>; SPROUT_TREE_DEPTH],
}

impl Default for SproutTree {
    fn default() -> Self {
        Self::new()
    }
}

impl SproutTree {
    pub fn new() -> Self {
        Self { count: 0, frontier: [None; SPROUT_TREE_DEPTH] }
    }

    pub fn empty_root() -> [u8; 32] {
        empty_roots()[SPROUT_TREE_DEPTH]
    }

    pub fn root(&self) -> [u8; 32] {
        let empty = empty_roots();
        let mut node = empty[0];
        for level in 0..SPROUT_TREE_DEPTH {
            node = match self.frontier[level] {
                Some(left) => sha256_compress(&left, &node),
                None => sha256_compress(&node, &empty[level]),
            };
        }
        node
    }

    pub fn append(&mut self, leaf: [u8; 32]) -> Result<(), ConsensusError> {
        if self.count >= (1u64 << SPROUT_TREE_DEPTH) {
            return Err(ConsensusError::Invalid("Sprout note commitment tree is full".into()));
        }
        let mut node = leaf;
        let mut n = self.count;
        for level in 0..SPROUT_TREE_DEPTH {
            if n & 1 == 0 {
                self.frontier[level] = Some(node);
                break;
            }
            let left = self.frontier[level]
                .take()
                .ok_or_else(|| ConsensusError::Invalid("Sprout frontier corruption".into()))?;
            node = sha256_compress(&left, &node);
            n >>= 1;
        }
        self.count += 1;
        Ok(())
    }

    pub fn encode(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(8 + 33 * SPROUT_TREE_DEPTH);
        out.extend_from_slice(&self.count.to_le_bytes());
        for slot in &self.frontier {
            match slot {
                Some(v) => {
                    out.push(1);
                    out.extend_from_slice(v);
                }
                None => {
                    out.push(0);
                    out.extend_from_slice(&[0u8; 32]);
                }
            }
        }
        out
    }

    pub fn decode(b: &[u8]) -> Result<Self, ConsensusError> {
        if b.len() != 8 + 33 * SPROUT_TREE_DEPTH {
            return Err(ConsensusError::Invalid("invalid Sprout frontier length".into()));
        }
        let mut c = [0u8; 8];
        c.copy_from_slice(&b[..8]);
        let count = u64::from_le_bytes(c);
        let mut frontier = [None; SPROUT_TREE_DEPTH];
        for (i, slot) in frontier.iter_mut().enumerate() {
            let off = 8 + 33 * i;
            match b[off] {
                0 => {}
                1 => {
                    let mut v = [0u8; 32];
                    v.copy_from_slice(&b[off + 1..off + 33]);
                    *slot = Some(v);
                }
                _ => return Err(ConsensusError::Invalid("invalid Sprout frontier slot".into())),
            }
        }
        Ok(Self { count, frontier })
    }
}

/// `JoinSplit::h_sig`.
pub fn h_sig(random_seed: &[u8; 32], nullifiers: &[[u8; 32]; 2], joinsplit_pubkey: &[u8; 32]) -> [u8; 32] {
    let mut data = Vec::with_capacity(128);
    data.extend_from_slice(random_seed);
    data.extend_from_slice(&nullifiers[0]);
    data.extend_from_slice(&nullifiers[1]);
    data.extend_from_slice(joinsplit_pubkey);
    let h = blake2b_simd::Params::new().hash_length(32).personal(b"ZcashComputehSig").hash(&data);
    let mut out = [0u8; 32];
    out.copy_from_slice(h.as_bytes());
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn hex32(s: &str) -> [u8; 32] {
        let v = hex::decode(s).unwrap();
        let mut o = [0u8; 32];
        o.copy_from_slice(&v);
        o
    }

    #[test]
    fn empty_roots_match_ycashd_table() {
        let r = empty_roots();
        assert_eq!(r[1], hex32("da5698be17b9b46962335799779fbeca8ce5d491c0d26243bafef9ea1837a9d8"));
        assert_eq!(r[2], hex32("dc766fab492ccf3d1e49d4f374b5235fa56506aac2224d39f943fcd49202974c"));
        assert_eq!(SproutTree::new().root(), hex32("d7c612c817793191a1e68652121876d6b3bde40f4fa52bc314145ce6e5cdd259"));
    }

    #[test]
    fn frontier_roundtrip() {
        let mut t = SproutTree::new();
        for i in 0..5u8 {
            t.append([i; 32]).unwrap();
        }
        let d = SproutTree::decode(&t.encode()).unwrap();
        assert_eq!(t, d);
        assert_eq!(t.root(), d.root());
    }
}
