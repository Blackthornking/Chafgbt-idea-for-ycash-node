# YWallet / Lightwalletd connection diagnostics

The app tests the entered endpoint in layers: DNS, TCP, TLS 1.3/cipher, ALPN h2, HTTP/2 SETTINGS, then the standard gRPC `CompactTxStreamer/GetLatestBlock` call. It also reports RST_STREAM and GOAWAY error codes and now sends standard `grpc-accept-encoding` and diagnostic user-agent headers.

For Ycash, the documented lightwalletd endpoint is `https://lite.ycash.xyz:9067`. The gRPC service uses the standard `cash.z.wallet.sdk.rpc.CompactTxStreamer` service and `GetLatestBlock` method.

The Android node's own ports are separate: P2P 8833, JSON-RPC 8832, and localhost status API 8834. The status API is HTTP on loopback only; Android cleartext is explicitly enabled so the app can poll `127.0.0.1:8834/status`.


## v0.19.4 fixes

- P2P discovery now prioritizes `seed.ycash.xyz:8833` and previously successful `peers.dat` entries.
- The two Ycash 4.5.0 fixed seeds are fallback-only and are always tried last (after DNS and peers.dat); disable with `YCASH_NO_FIXED_SEEDS=1`.
- P2P handshake status is now staged as TCP CONNECT, VERSION SEND/RECV, VERACK SEND/RECV, handshake PASS, and session/sync failures.
- Inbound P2P connections now parse complete Ycash frames after the handshake instead of consuming the stream one byte at a time.
- The Lightwalletd diagnostic sends a standards-compliant unary `CompactTxStreamer/GetLatestBlock` gRPC request over HTTP/2, including `grpc-timeout` immediately after the reserved headers, and reports HTTP/2/RST/GOAWAY/EOF stages.
