# Development Status

Current project line: v0.19.0 — Rust Ycash P2P + inbound listener + authenticated JSON-RPC implementation.

Implemented and wired:
- Rust Android node is a workspace member and builds as its own binary.
- Android foreground service launches the bundled ARM64 node process.
- Node exposes localhost status telemetry.
- Node resolves `YCASH_PEER` or defaults to `seed.ycash.xyz:8833`.
- Node sends `version`, receives `version`, sends/receives `verack`, and answers `ping` with `pong`.
- Peer advertised start height is surfaced as target/header telemetry.

Not yet complete:
- Header locator construction and validated header synchronization.
- Block download, consensus validation and persistent main-chain commit.
- Full peer discovery/peer manager and transaction relay.

These are deliberately not reported as complete until tested against Ycash mainnet and a reference node.


## v0.17 networking/logo update

- DNS seed resolution failure is recoverable via the fixed Ycash mainnet seeds from Ycash 4.5.0 `pnSeed6_main`.
- The Android network test tries DNS-resolved peers and fixed-seed fallbacks.
- The native node retries peer discovery and connection instead of stopping after one DNS failure.
- App launcher icon and in-app logo use `ycash_logo.png`.
- This update does **not** claim full header/block synchronization; the existing prototype still requires a validated chain locator and consensus-backed sync pipeline before sync is enabled.


v0.18.1 P2P implementation:
- Protocol version aligned with Ycash 4.5.0 (`270013`).
- Advertises NODE_NETWORK.
- Uses DNS seed, fixed seeds, manual peer override, and persistent peer addresses.
- Maintains up to 8 outbound sessions concurrently.
- Implements version/verack, getaddr/addr and ping/pong.
- Keeps peers.dat bounded and reconnects after peer loss.
- Does not claim validated chain synchronization yet.

## v0.19.13 block-sync milestone
- Mainnet block payloads are now parsed as real Ycash v1/v2/v3/v4 transactions instead of being accepted with an empty transaction vector.
- Transaction boundaries are derived from the versioned Ycash serialization; no generic length-prefix assumption is used.
- Block acceptance now requires at least one transaction, exact end-of-block consumption, and a matching double-SHA256 transaction Merkle root.
- Validated transactions are indexed in SQLite by txid and block hash during the same state commit as the block tip update.
- Android status telemetry now exposes blocks received/validated, indexed transaction count, last block size and last validated height.
- Ycash mainnet NU5 is disabled in the current Ycash chain parameters, so the active v4 parser is intentionally fail-closed for v5/future formats.
- Full shielded proof/signature validation remains dependent on the native Ycash consensus implementation; this milestone does not claim equivalence with Ycash 4.5.0 reference implementation until differential replay is completed.
