# v0.28.0 — transparent UTXO/script backend + Sprout backend

Own Rust implementation. ycashd 4.5.0 source used only as the behavioural
reference; nothing from it is embedded or linked.

## New / changed
- `crates/script` (new): script interpreter, signature hashes (legacy,
  ZIP 143, ZIP 243), sigop counting, secp256k1 verification.
- `crates/consensus/src/sprout.rs` (new): Sprout tree (depth 29,
  SHA256Compress, empty roots tested against ycashd's table), h_sig.
- `crates/consensus`: joinSplitSig + Groth16 JoinSplit verification,
  IsFinalTx, block subsidy (ZIP 208), GetValueOut / GetShieldedValueIn.
  Sighash now delegates to `ycash-script` (fixes v3 hashing and
  SIGHASH_SINGLE edge case).
- `crates/state/src/chainstate.rs` (new): UTXO set, coinbase maturity and
  must-shield rule, value in >= out, fees, scripts, sigops, BIP30,
  bad-cb-amount, Sprout nullifiers/anchors (incl. intermediate anchors),
  ZIP 209 turnstile. Reorg-safe via created/spent heights; spent outputs
  pruned after 100 blocks.
- `crates/ycash-crypto`: safe wrappers (params-loaded checks, sprout_verify,
  ed25519 ZIP 215).
- Android node: loads shielded params at startup; checkpoint 2,250,000
  (ycashd's last) skips scripts/Groth16 below it (YCASH_FULL_VERIFY=1 to
  disable); commit failures halt sync with the reason.

## Migration
Schema v3. On first start block-derived tables are dropped and blocks
re-sync from height 1; headers are kept.

## Parameters
`<data dir>/params/` or `$YCASH_PARAMS_DIR`:
- sapling-spend.params, sapling-output.params — required from height 419,200
- sprout-groth16.params — only needed above the checkpoint (or with full verify)

## Not done
- Founders reward / YDF mandate output check (still a stub).
- Not compiled in the authoring environment — first CI run may need fixes.
