# Live Node Log

The Android dashboard now includes a persistent **NODE LOG** panel. It polls the existing
localhost `/status` telemetry and records changes to header height, block height, blocks
received, in-flight ranges, connection detail, status messages, and errors. The log is
kept in the app's private files directory as `node-live.log`, capped at 250 lines / 256 KiB,
and can be cleared from the dashboard.

This is deliberately based on the node's existing status telemetry, so no network
exposure or new public logging endpoint is required. It is intended for diagnosing the
case where headers advance but blocks do not.
