# YORTAL v0.29.0 — ZEBRA-SPEED parallel node

Same Ycash consensus. Different engine layout. Every rule that ran in v0.28.1
still runs, on the same bytes, with the same inputs; only the thread it runs
on and the moment it runs changed.

## What was slow in v0.28.1
1. `ensure_planned` forced `workers = 1` and the window was 16: one range at a time.
2. Each peer thread downloaded **and** validated its range inline, so the socket
   sat idle during Sapling proof checks.
3. Validation read MTP/work/prev from SQLite per block, fighting the commit mutex.
4. Every 16-block range was its own SQLite transaction.
5. Header sync verified Equihash for 160 headers one at a time on one core.

## v0.29 pipeline (Zebra's shape)
| Stage | Zebra | YORTAL v0.29 |
|---|---|---|
| Headers / PoW | parallel checkpoint + semantic verify | Equihash for each 160-header batch on all cores, then contextual header rules in order |
| Download | many peers, big lookahead | ≤12 peers, ≤16 blocks each, 2048-height lookahead |
| Contextless verify | tower-batch verifier services on rayon | N verifier threads (cores−1), bounded job channel, zero DB access |
| Contextual verify + write | single state service, ordered | single committer thread, ordered, contiguous ranges coalesced into ≤256-block transactions |

## Consensus invariants (audit list)
- `validate_header_opts(.., false)` is byte-for-byte `validate_header` minus the
  trailing `check_pow`, which `parallel_check_pow` has already run on the same
  header. A PoW failure rejects the whole batch before any header is stored.
- Median-time-past in the fetch stage (`mtp_range`) reproduces `mtp()` exactly:
  heights `[max(h-11,1), h)` plus genesis time when `h ≤ 11`, median `v[len/2]`.
- `validate_for_commit_opts` and `State::commit_blocks_batch` are unchanged.
- Commits are strictly contiguous from `next_commit`; a batch is only formed from
  ranges that start exactly where the previous one ended.
- Assume-valid behaviour is unchanged (ycashd checkpoint semantics).

## Failure handling
- Download error / timeout / notfound → range released (retry, then quarantine
  and requeue at head-of-line), peer session closed. Same as before.
- Contextless validation failure → range released, peer flagged and disconnected
  on its next claim.
- `node-unsupported` or commit failure → pipeline halts with the reason (as before).

## Tuning (environment)
`YORTAL_VERIFY_THREADS`, `YORTAL_LOOKAHEAD`, `YORTAL_COMMIT_BATCH` — see
`config/pipeline.toml`. On a low-RAM phone try `YORTAL_LOOKAHEAD=512`.

## Log lines to watch
`[PIPELINE] stage=START`, `VERIFIED`, `COMMIT_OK ... blocks_per_sec=`.

## Not done yet (next phases toward full Zebra parity)
- Batch Groth16 / RedJubjub / Ed25519 verification (Zebra's biggest CPU win).
  Needs a change inside `ycash-crypto`; accept set is identical except with
  negligible probability, so it deserves its own audited release.
- Dense checkpoint list (Zebra checkpoints every ~400 blocks and skips proof
  checks below them). That skips more than ycashd does, so it is left out to
  keep behaviour identical to ycashd.
- RocksDB-style state backend; async (tokio) networking.
