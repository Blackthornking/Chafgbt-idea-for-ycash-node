#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NS="$ROOT/android-app/app/src/main/java/com/ycash/androidnode/NodeService.java"
RS="$ROOT/crates/ycash-android-node/src/main.rs"

need(){ grep -Fq "$2" "$1" || { echo "MISSING: $2 in $1" >&2; exit 1; }; }
need "$NS" 'return START_STICKY;'
need "$NS" 'YCASH_NODE_DB'
need "$NS" 'YCASH_DATA_DIR'
need "$NS" 'discoverPeers(log)'
need "$NS" 'YCASH_AUTO_PEER'
need "$RS" 'peers.dat'
need "$RS" 'learn_peers'
need "$RS" 'YCASH_AUTO_PEER'
need "$RS" 'YCASH_PEER'
need "$RS" 'const MAX_OUTBOUND:usize=12;'
need "$RS" 'start_p2p_listener'
need "$RS" 'start_api'
need "$RS" 'State::open'

# The Android 10+ unsafe private-storage executable fallback must stay gone.
if grep -Fq 'getFilesDir(), LEGACY_ASSET_NAME' "$NS"; then
  echo 'FAIL: legacy getFilesDir executable fallback is present' >&2
  exit 1
fi

echo 'PASS: v0.23.4 P2P/peer persistence/database/service feature parity checks'
