# Consensus rule audit — Ycash 4.5.0 → YORTAL Rust

The audit compares the supplied `ycash-4.5.0` source against YORTAL's consensus configuration.

## Verified configuration

| Rule | Ycash 4.5.0 | YORTAL |
|---|---:|---:|
| Mainnet magic | `24e92764` | `24e92764` |
| P2P port | 8833 | 8833 |
| Protocol | 270013 | 270013 |
| Header response limit | 160 | 160 |
| Ycash activation | 570000 | 570000 |
| Blossom | 1100000 | 1100000 |
| Heartwood | 1100003 | 1100003 |
| Canopy | 1100006 | 1100006 |
| NU5 | disabled | disabled |
| Equihash pre-Ycash | 200,9 | 200,9 |
| Equihash Ycash+ | 192,7 | 192,7 |
| PoW averaging | 17 | 17 |
| Max adjustment up | 16% | 16% |
| Max adjustment down | 32% | 32% |
| Damping | 4 | 4 |
| Pre-Blossom spacing | 150 s | 150 s |
| Post-Blossom spacing | 75 s | 75 s |
| MTP future limit | 3 h | 3 h |
| Local future limit | 4 h | 4 h |
| Max block | 2,000,000 | 2,000,000 |
| Max block sigops | 20,000 | 20,000 |
| Max money | 21,000,000 × 100,000,000 | same |
| Coinbase maturity | 100 | 100 |
| Expiry threshold | 500,000,000 | 500,000,000 |
| YDF mandate end | 2,275,000 | 2,275,000 |

## Security correction

Ycash 4.5.0 contains a fix for an insufficiently checked block-validation cache issue.
YORTAL therefore does not use a "checked" shortcut before strict proof validation. A block may
enter the canonical database only after every enabled consensus-critical verifier succeeds.

Source: Ycash v4.5.0 release notes and the supplied source tree.
