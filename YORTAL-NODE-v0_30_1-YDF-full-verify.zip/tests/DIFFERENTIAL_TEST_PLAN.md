# Differential consensus test plan

The Rust node must never be considered mainnet-ready until these comparisons pass against Ycash 4.5.0.

1. Genesis block and known historical blocks.
2. Every available Ycash validation test vector.
3. Valid/invalid transaction vectors.
4. Equihash solutions and proof-of-work boundaries.
5. Merkle-root mutation cases.
6. Coinbase height and block-version rules.
7. Median-time-past and future-time rules.
8. Network-upgrade activation boundaries.
9. Shielded proof verification and signature edge cases.
10. Reorg/UTXO/nullifier-state transitions.
11. Mempool-vs-block validation agreement.
12. Randomized malformed-input fuzzing.
13. Historical mainnet block replay from genesis to current tip.

The comparison result must include accept/reject plus rejection class/reason where observable.
A mismatch is a release blocker.
