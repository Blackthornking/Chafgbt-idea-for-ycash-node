# YORTAL v0.29.2 — peer drops + commit stalls

No consensus rule added, removed or reordered.

## Diagnosis (checked against ycash 4.5.0 main.cpp / net.cpp)
- YORTAL is not being banned. It only sends version, verack, getaddr, getheaders,
  getdata(≤16), ping and pong; none hit a `Misbehaving()` path. A banned IP is
  closed at accept time, which is not what "broken pipe" mid-session looks like.
- "BLOCK WORKER FAIL: broken pipe" = getdata written to a socket that died while
  the worker was blocked. Workers blocked on the single SQLite mutex while the
  committer held it for the whole commit transaction.
- "handshake: Try again (os error 11)" = our own 8s read timeout (EAGAIN on
  Android) treated as fatal during the handshake.
- Peers hit 0 because every ended session, healthy or not, waited 5 minutes
  before the same address was tried again.

## Fixes
1. **Read-only header connection** (`state/src/lib.rs`, `open_reader`, `rd()`).
   All `headers` lookups (hashes/works/times ranges, hash/work/time by height,
   header height, rows range) use a second read-only WAL connection. Fetchers and
   header sync no longer wait for block commits. Both connections get a 10s
   busy timeout.
2. **Leaner `commit_blocks_batch`.** Blocks and transactions are parsed once;
   nullifiers and per-block trees are collected during validation; all writes use
   cached prepared statements; tip meta written once per batch; previous-block
   lookup is O(1).
3. **Per-block Sapling root rows.** v0.29.1 wrote the batch-final tree to every
   block's `sapling_roots` row. Each row now gets that block's own root/frontier.
   `meta.sapling_roots_per_block_from` records the first height written this way.
   Rows below it may carry a batch-final root for non-last blocks in a batch; if
   sync ever halts with a Sapling anchor error below that height, clear app data
   and resync.
4. **Handshake** tolerates quiet reads for 30s after VERSION is sent.
5. **Mid-range idle** tolerance 8s → 30s (head-of-line range is still hedged at 20s).
6. **Healthy reconnect.** A peer that completed a handshake is retried after 15s
   instead of 5 minutes. Peers that never handshake keep the 5-minute backoff.
7. Assume-valid checkpoint lookup cached once confirmed.
