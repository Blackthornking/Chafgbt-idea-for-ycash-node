# Android release invariant

A release APK is not considered node-capable unless all of these are true:

- `android-app/app/src/main/jniLibs/arm64-v8a/libycashandroidnode.so` exists.
- The file is an ARM64/aarch64 ELF executable.
- `android-app/app/build.gradle` packages that file without stripping it.
- `AndroidManifest.xml` keeps native-library extraction enabled.
- `NodeService` resolves the executable from `ApplicationInfo.nativeLibraryDir`.
- No asset/getFilesDir execution fallback exists.
- The APK contains `lib/arm64-v8a/libycashandroidnode.so`.
- After START NODE, the UI remains `STARTING` until `127.0.0.1:8834/status` actually answers.

The GitHub Actions workflow checks the first seven items automatically at build time.
