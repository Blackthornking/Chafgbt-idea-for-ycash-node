//! YORTAL v0.31 stage-separated sync pipeline.
//!
//! v0.30.4: Sapling Groth16 proofs are batch-verified per range
//! (`ycash_consensus::ProofBatch`), and the committer no longer re-verifies
//! proofs the verify stage already checked.
//!
//! v0.29.2: header reads use a separate read-only RocksDB connection, so
//! fetchers no longer stall while the committer writes.
//!
//! v0.29.1 adds Zebra-style batching on top of v0.29.0: header batches are
//! validated against an in-memory window and written in one transaction
//! (main.rs), the head-of-line range is hedged to a second peer when it
//! stalls, and the committer lingers briefly to build bigger commit batches.
//!
//! The coordinator is explicitly separated into network, stateless verification, and canonical commit,
//! using existing Ycash consensus primitives. NO consensus rule is added, removed or reordered -- only *where* and
//! *when* each existing check runs changes.
//!
//! ```text
//!  up to 12 peers            N verifier threads          1 committer thread
//!  ┌───────────────┐  jobs   ┌──────────────────┐ ranges ┌─────────────────────┐
//!  │ claim range   │ ──────► │ validate_for_    │ ─────► │ reorder buffer      │
//!  │ getdata ≤48 (fixed)      │ bounded │ commit_opts()    │        │ contiguous ranges → │
//!  │ hash-match    │ channel │ (Equihash-free:  │        │ ONE commit_blocks_  │
//!  │ load ctx      │         │  merkle, Sapling │        │ batch() of ≤256 blk │
//!  └───────────────┘         │  proofs, sigs)   │        │ (UTXO/nullifier/    │
//!        ▲                   └──────────────────┘        │  anchor/value, in   │
//!        └──── backpressure: channel full = peers wait   │  strict height order│
//!                                                        └─────────────────────┘
//! ```
//!
//! Stage 1 (network): each connected peer claims a disjoint ≤48-block fixed range
//! (ycashd's MAX_BLOCKS_IN_TRANSIT_PER_PEER), downloads it, matches each block
//! to our PoW-verified header by hash, and loads everything a verifier needs
//! (median-time-past, chain work, prev hash) in three range queries. It does
//! no validation, so the socket goes straight back to fetching.
//!
//! Stage 2 (verify): contextless checks are independent per block, so they run
//! on every core. Verifier threads never touch RocksDB, so they never wait on a
//! commit.
//!
//! Stage 3 (state/publication): exactly one canonical state owner advances
//! blocks in height order. Expensive state preparation overlaps with semantic
//! verification of later ranges; only the final RocksDB publication is a
//! single ordered WriteBatch. Later ranges never mutate canonical state early.
//!
//! Transport is fixed at 48 blocks per range with a 192-block lookahead (4 range slots).

use std::collections::{BTreeMap, HashMap, HashSet};
use std::io::ErrorKind;
use std::net::TcpStream;
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::mpsc::{sync_channel, Receiver, SyncSender};
use std::sync::{Arc, Condvar, Mutex};
use std::time::{Duration, Instant};

use ycash_chain::{genesis_hash_internal, txid};
use ycash_consensus::{validate_for_commit_batched_with_parsed, Context, ProofBatch, GENESIS_TIME, UNSUPPORTED_PREFIX};
use ycash_network::runtime::{getdata_payload, unix_time};
use ycash_state::pipeline::{BlockWindowId, BlockWindowLease, PipelineConfig, PipelineEngine, MAX_BLOCKS_IN_TRANSIT_PER_PEER, MAX_PROSPECTIVE_BLOCKS};
use ycash_state::{BlockCommit, State};


use crate::runtime::{RollingCommitSample, SharedState};
use crate::{is_timeout, read_message, send};

/// Exactly one permanent worker owns canonical state commitment.
/// Adaptive workers are reserved for validation; they never take over the
/// ordered commit role.
const DEDICATED_COMMIT_WORKERS: usize = 1;

/// Optional assume-valid checkpoint. Full consensus verification is the
/// default; this checkpoint is used only when YCASH_ASSUME_VALID=1 and the
/// verified header at the checkpoint height matches. YCASH_FULL_VERIFY=1
/// explicitly forces full verification as well.
pub const ASSUME_VALID_HEIGHT: u64 = 2_250_000;
pub const ASSUME_VALID_HASH_DISPLAY: &str = "000003f98b7497fdcd8a6b6d10a93a887c5d47127e24a9dc3a40cb65754d21e7";

/// Head-of-line recovery threshold. The canonical head may be re-leased even
/// while an older verifier still owns a stale generation. The old verifier is
/// never allowed to publish its result after the generation changes, so this
/// is recovery/hedging only; it never skips a height.
const HEDGE_AFTER: Duration = Duration::from_secs(8);

/// Commit linger: once blocks are ready, wait up to this long for more
/// contiguous ranges so each RocksDB transaction carries a bigger batch.
const COMMIT_LINGER: Duration = Duration::from_millis(50);

/// RocksDB pressure is measured from the actual write/commit critical section,
/// never from consensus/state preparation. A 100 ms write/COMMIT interval is
/// already substantial for the Android node and is a better contention signal
/// than the 1+ second consensus preparation time seen on busy batches.
const DB_PRESSURE_TARGET_US: f64 = 100_000.0;

/// Consecutive 1-second read timeouts tolerated mid-range before dropping a peer.
const IDLE_READS_BEFORE_DROP: u32 = 30;

fn env_usize(name: &str) -> Option<usize> {
    std::env::var(name).ok().and_then(|v| v.trim().parse::<usize>().ok())
}

fn env_f64(name: &str) -> Option<f64> {
    std::env::var(name).ok().and_then(|v| v.trim().parse::<f64>().ok())
}

/// Resolve the pipeline settings for this process.
///
/// Every field is overridable from the environment, so the settings can be
/// changed without rebuilding the native binary. `NodeService` fills these in
/// from `<dataDir>/pipeline.conf` and app preferences. Values are clamped to
/// keep an edited config from producing a scheduler that can't make progress.
///
/// | env var                      | default |
/// |------------------------------|---------|
/// | YORTAL_MIN_WINDOW            | 16      |
/// | YORTAL_INITIAL_WINDOW        | 64     |
/// | YORTAL_MAX_WINDOW            | 2000    |
/// | YORTAL_WINDOW_STEP           | 100       |
/// | YORTAL_HIGH_WATERMARK        | 0.85    |
/// | YORTAL_LOW_WATERMARK         | 0.50    |
/// | YORTAL_VERIFY_THREADS        | cores-1 (one core reserved for Android) |
/// | YORTAL_MAX_INFLIGHT_RANGES   | 2 × (cores-1), bounded |
/// | fixed transport range         | 48      |
/// | commit batch                    | adaptive with current window |
/// | YORTAL_COMMIT_LINGER_MS       | 50 ms                         |
pub fn pipeline_config() -> PipelineConfig {
    let text = std::env::var_os("YCASH_PIPELINE_CONFIG")
        .and_then(|p| std::fs::read_to_string(p).ok())
        .unwrap_or_else(|| include_str!("../../../config/pipeline.toml").to_owned());
    let mut cfg = PipelineConfig::default();
    for line in text.lines() {
        let line=line.split('#').next().unwrap_or("").trim();
        let Some((key,value))=line.split_once('=') else { continue };
        let Ok(n)=value.trim().parse::<usize>() else { continue };
        match key.trim() {
            "max_blocks_in_transit_per_peer" => cfg.max_blocks_in_transit_per_peer=n.clamp(1,48),
            "max_prospective_blocks" => cfg.max_prospective_blocks=n.max(48),
            _ => {}
        }
    }
    cfg.max_blocks_in_transit_per_peer=MAX_BLOCKS_IN_TRANSIT_PER_PEER;
    cfg.max_prospective_blocks=cfg.max_prospective_blocks.max(MAX_PROSPECTIVE_BLOCKS);
    cfg
}

#[derive(Clone, Copy, Debug, Default)]
struct ResourceSample {
    cpu_ratio:f64, memory_ratio:f64, db_queue_ratio:f64, network_ratio:f64, validation_queue_ratio:f64,
}


/// Maximum verifier pool size. The pool is fixed once at startup to avoid
/// thread churn; the adaptive controller separately decides how many workers
/// may actively consume jobs at any moment.
pub fn verify_threads() -> usize {
    let detected = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1);
    // Reserve one logical CPU for Android and process housekeeping. A value of
    // zero/unset means fully device-derived; a positive override is capped at
    // the same cores-1 ceiling so configuration can never consume the reserved
    // Android core.
    let ceiling = detected.saturating_sub(1).max(1);
    match env_usize("YORTAL_VERIFY_THREADS") {
        Some(0) | None => ceiling,
        Some(v) => v.clamp(1, ceiling),
    }
}

fn script_pool_threads() -> usize {
    // The state crate keeps the persistent pool private. Its configured size
    // is the device ceiling unless YORTAL_SCRIPT_WORKERS explicitly lowers it.
    let detected = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1);
    let ceiling = detected.saturating_sub(1).max(1);
    match env_usize("YORTAL_SCRIPT_WORKERS") {
        Some(0) | None => ceiling,
        Some(v) => v.clamp(1, ceiling),
    }
}

fn update_commit_cpu_budget(active_pipeline_workers: usize) {
    let total = verify_threads(); // device cores - 1 Android reserve
    let pipeline_workers = active_pipeline_workers.max(1).min(total);
    // Overlap design: the canonical state owner is ordered, but it must NOT
    // stop the independent semantic verifier pool while contextual state
    // preparation is running. Reserve one slot for the coordinator and let
    // the remaining slots be shared explicitly between semantic validation and
    // script execution.
    //
    // Example on an 8-core device: 1 Android reserve -> 7 YORTAL slots.
    // With 4 semantic workers, 2 script workers remain; with 2 semantic
    // workers, 4 script workers remain. This keeps network/semantic work
    // moving while the ordered state stage prepares the next database batch.
    let coordinator_slots = DEDICATED_COMMIT_WORKERS;
    let script_budget = total
        .saturating_sub(coordinator_slots)
        .saturating_sub(pipeline_workers)
        .max(1);
    ycash_state::chainstate::set_script_worker_budget(script_budget);
}

fn update_normal_cpu_budget(validation_workers: usize) {
    let total = verify_threads();
    let validation = validation_workers.max(1).min(total);
    let script_budget = total.saturating_sub(validation).max(1);
    ycash_state::chainstate::set_script_worker_budget(script_budget);
}

/// Adaptive lookahead: how far ahead of the commit tip planning may run. It is
/// the adaptive window itself. In-flight ranges *partition* that window, so
/// multiplying the two (as this used to) reported a lookahead the planner
/// never used.
fn lookahead(engine: &PipelineEngine) -> u64 {
    engine.lookahead()
}

/// Adaptive commit batch. Canonical mutation remains strictly ordered, but
/// the transaction size follows the current sync window: small under pressure,
/// larger when the controller has safely expanded the window.
fn commit_linger() -> Duration {
    Duration::from_millis(env_usize("YORTAL_COMMIT_LINGER_MS").unwrap_or(COMMIT_LINGER.as_millis() as usize).clamp(0, 300) as u64)
}

fn commit_batch_blocks(engine: &PipelineEngine) -> usize {
    let window = engine.window().max(1) as usize;
    let configured_cap = env_usize("YORTAL_COMMIT_BATCH_CAP").unwrap_or(512).clamp(1, 512);
    window.clamp(1, configured_cap)
}

/// Cached once positive: the checkpoint header never changes after it matches,
/// so later ranges skip the lookup.
static ASSUME_VALID_CONFIRMED: AtomicBool = AtomicBool::new(false);

fn assume_valid_active(state: &State) -> bool {
    if std::env::var("YCASH_FULL_VERIFY").ok().as_deref() == Some("1") { return false; }
    if ASSUME_VALID_CONFIRMED.load(Ordering::Relaxed) { return true; }
    let ok = assume_valid_check(state);
    if ok { ASSUME_VALID_CONFIRMED.store(true, Ordering::Relaxed); }
    ok
}

fn assume_valid_check(state: &State) -> bool {
    if ASSUME_VALID_HEIGHT == 0 || ASSUME_VALID_HASH_DISPLAY.len() != 64 { return false; }
    let Ok(bytes) = hex::decode(ASSUME_VALID_HASH_DISPLAY) else { return false };
    let mut internal = [0u8; 32];
    for i in 0..32 { internal[i] = bytes[31 - i]; }
    matches!(state.header_hash_by_height(ASSUME_VALID_HEIGHT), Ok(Some(v)) if v.as_slice() == internal)
}

/// Error kind used for "this node can't validate this block yet". Not the
/// peer's fault: don't release/retry the range and don't drop the connection.
pub fn is_node_unsupported(e: &std::io::Error) -> bool {
    e.kind() == ErrorKind::Unsupported
}

fn pipeline_log(stage: &str, detail: impl std::fmt::Display) {
    eprintln!("[PIPELINE] stage={} {}", stage, detail);
}

/// A downloaded, hash-matched range plus every piece of context the verifier
/// needs, so verifier threads are pure CPU.
struct VerifyJob {
    lease: BlockWindowLease,
    peer: String,
    /// (height, expected hash, median-time-past, chain work, raw block), ascending.
    blocks: Vec<(u64, [u8; 32], u32, [u8; 32], Vec<u8>)>,
    prev_of_start: [u8; 32],
    assume_valid_ok: bool,
    bytes: u64,
}

type Buffered = (BlockWindowLease, Vec<BlockCommit>, u64);

struct Inner {
    engine: PipelineEngine,
    next_commit: u64,
    buffered: BTreeMap<u64, Buffered>,
    planned_up_to: u64,
    halted: Option<String>,
    /// Peers that served a block failing contextless validation. Their session
    /// is closed on the next claim attempt (previously the error dropped the
    /// connection directly; the verifier runs off the peer thread now).
    misbehaving: HashSet<String>,
    /// Ranges sitting in the verify channel or being verified.
    verifying: u64,
    /// Start heights currently represented by a verification job. The lease
    /// id/generation makes this generation-safe: a stale hedged verifier cannot
    /// clear the marker belonging to its replacement job.
    verifying_starts: HashMap<u64, (BlockWindowId, u64, Instant)>,
    /// Inclusive end of the batch the committer is writing right now
    /// (0 = none). Late duplicates at or below it are dropped.
    committing_upto: u64,
    hedged_ranges: u64,
    duplicate_ranges: u64,
}

#[derive(Clone)]
pub struct BlockPipeline {
    inner: Arc<Mutex<Inner>>,
    commit_cv: Arc<Condvar>,
    jobs: Arc<Mutex<Option<SyncSender<VerifyJob>>>>,
    started: Arc<AtomicBool>,
    verified_blocks: Arc<AtomicU64>,
    active_workers: Arc<AtomicUsize>,
    /// True while the permanent commit worker owns the CPU budget for ordered
    /// state preparation. The adaptive sampler must not immediately overwrite
    /// the stage-aware split while this is set.
    commit_active: Arc<AtomicBool>,
    adaptive_sampler_started: Arc<AtomicBool>,
}

impl BlockPipeline {
    /// `next_commit` should be the current validated block tip + 1.
    pub fn new(next_commit: u64) -> Self {
        let cfg = pipeline_config();
        let engine = PipelineEngine::new(cfg);
        pipeline_log("CONFIG", format_args!(
            "max_blocks_in_transit_per_peer={} max_prospective_blocks={} verifier_workers={} active_windows={} window={} commit_batch={} commit_linger_ms={}",
            cfg.max_blocks_in_transit_per_peer, cfg.max_prospective_blocks, verify_threads(), engine.max_inflight_windows(), engine.window(), commit_batch_blocks(&engine), commit_linger().as_millis()
        ));
        pipeline_log("INIT", format_args!(
            "mode=OVERLAPPED_CONTEXTUAL cpu_split=android_reserve:1,canonical_writer:1,semantic_workers=adaptive,script={} next_commit={} verify_threads={} script_pool_threads={} script_budget={} lookahead={} commit_batch={} assume_valid_height={} full_verify={}",
            verify_threads().saturating_sub(2).max(1), next_commit, verify_threads(), script_pool_threads(), ycash_state::chainstate::script_worker_budget(), lookahead(&engine), commit_batch_blocks(&engine), ASSUME_VALID_HEIGHT,
            std::env::var("YCASH_ASSUME_VALID").ok().as_deref() != Some("1")
        ));
        // Start with the full adaptive semantic pool. Contextual state
        // preparation must overlap with verification from the first batch.
        let initial_workers = engine.current_validation_workers().min(verify_threads()).max(1);
        update_commit_cpu_budget(initial_workers);
        Self {
            inner: Arc::new(Mutex::new(Inner {
                engine,
                next_commit,
                buffered: BTreeMap::new(),
                planned_up_to: next_commit.saturating_sub(1),
                halted: None,
                misbehaving: HashSet::new(),
                verifying: 0,
                verifying_starts: HashMap::new(),
                committing_upto: 0,
                hedged_ranges: 0,
                duplicate_ranges: 0,
            })),
            commit_cv: Arc::new(Condvar::new()),
            jobs: Arc::new(Mutex::new(None)),
            started: Arc::new(AtomicBool::new(false)),
            verified_blocks: Arc::new(AtomicU64::new(0)),
            active_workers: Arc::new(AtomicUsize::new(verify_threads())),
            commit_active: Arc::new(AtomicBool::new(false)),
            adaptive_sampler_started: Arc::new(AtomicBool::new(false)),
        }
    }

    /// Spawn the adaptive verifier pool plus exactly one permanent ordered
    /// committer. Idempotent. The commit worker is deliberately outside the
    /// adaptive worker budget so it cannot be shed or repurposed.
    pub fn start(&self, state: Arc<State>, live: SharedState) {
        if self.started.swap(true, Ordering::SeqCst) { return; }
        let n = verify_threads();
        // Bounded: when verifiers fall behind, peer threads block on send
        // instead of piling raw blocks into RAM.
        let (tx, rx) = sync_channel::<VerifyJob>(n * 2);
        *self.jobs.lock().unwrap() = Some(tx);
        let rx = Arc::new(Mutex::new(rx));
        for i in 0..n {
            let me = self.clone();
            let rx = rx.clone();
            let live = live.clone();
            std::thread::Builder::new()
                .name(format!("yortal-verify-{i}"))
                .spawn(move || me.verifier_loop(i, rx, live))
                .expect("spawn verifier");
        }
        let me = self.clone();
        let sampler_live = live.clone();
        // Keep exactly one permanent commit worker. Canonical state mutation
        // is strictly height-ordered and is never part of the adaptive
        // verifier-worker pool. On an 8-core device this leaves up to 7
        // adaptive verifier workers while this dedicated worker remains alive.
        std::thread::Builder::new()
            .name("yortal-commit".into())
            .spawn(move || me.committer_loop(state, live))
            .expect("spawn committer");
        debug_assert_eq!(DEDICATED_COMMIT_WORKERS, 1);
        pipeline_log("START", format_args!(
            "verifier_threads={} committer_workers={} commit_worker_permanent=true",
            n, DEDICATED_COMMIT_WORKERS
        ));
        self.start_adaptive_sampler(sampler_live);
    }

    /// Continuously samples device/pipeline pressure instead of adapting only
    /// after a successful commit.  A long validation or database stall must
    /// be able to shed workers and shrink the planning window while it is
    /// happening.
    fn start_adaptive_sampler(&self, live: SharedState) {
        if self.adaptive_sampler_started.swap(true, Ordering::SeqCst) { return; }
        let me = self.clone();
        std::thread::Builder::new()
            .name("yortal-adaptive".into())
            .spawn(move || loop {
                std::thread::sleep(Duration::from_millis(500));
                if me.halted() { return; }
                let sample = me.resource_sample(&live);
                let (workers, window, inflight) = {
                    let mut g = me.inner.lock().unwrap();
                    (g.engine.current_validation_workers(), g.engine.window(), g.engine.max_inflight_windows())
                };
                // Keep planning/hedging alive even when peer session loops are
                // blocked in a slow read. This is a watchdog, not a new commit
                // path: canonical commitment remains owned by the one permanent
                // ordered committer.
                {
                    let (headers_height, local_height, peers) = {
                        let st = live.read().unwrap();
                        (st.headers_height, st.local_height, st.peers as usize)
                    };
                    if headers_height > local_height {
                        me.ensure_planned(headers_height, peers.max(1));
                    }
                }
                // The controller owns validation concurrency. During canonical
                // preparation the stages overlap, so the sampler must preserve
                // the adaptive semantic worker count rather than collapsing the
                // verifier pool to one.
                if !me.commit_active.load(Ordering::Acquire) {
                    me.active_workers.store(workers.min(verify_threads()).max(1), Ordering::Release);
                    update_normal_cpu_budget(workers);
                    // Close the tiny race where commit starts immediately after
                    // the first check. Reassert the overlap split using the
                    // current adaptive worker count; never collapse verification
                    // to one just because canonical preparation started.
                    if me.commit_active.load(Ordering::Acquire) {
                        let overlap_workers = workers.min(verify_threads()).max(1);
                        me.active_workers.store(overlap_workers, Ordering::Release);
                        update_commit_cpu_budget(overlap_workers);
                    }
                }
                // `workers` (the pressure-driven adaptive count) is still
                // read below for the ADAPT telemetry line -- it just no
                // longer decides the validation/script split.
                me.publish(&live, None);
                pipeline_log("ADAPT", format_args!(
                    "pressure(cpu={:.2} mem={:.2} db={:.2}) net_gate={:.2} demand={:.2} \
                     -> workers={} window={} lookahead={} inflight={}",
                    sample.cpu_ratio, sample.memory_ratio, sample.db_queue_ratio, sample.network_ratio,
                    sample.validation_queue_ratio, workers, window, window, inflight
                ));
            })
            .expect("spawn adaptive sampler");
    }

    fn halted(&self) -> bool {
        self.inner.lock().unwrap().halted.is_some()
    }

    fn resource_sample(&self, live: &SharedState) -> ResourceSample {
        let (verifying, leased, pending, cfg_workers, last_db_write_us, last_sqlite_commit_us, active_outbound, peers) = {
            let g = self.inner.lock().unwrap();
            let st = live.read().unwrap();
            (
                g.verifying,
                g.engine.leased_windows() as u64,
                g.engine.pending_windows() as u64,
                g.engine.configured_max_validation_workers().max(1) as u64,
                st.last_db_write_us,
                st.last_sqlite_commit_us,
                st.active_outbound,
                st.peers,
            )
        };
        let cpu_ratio = read_cpu_pressure();
        let memory_ratio = read_memory_pressure();
        // Workload DEMAND: how much of the verifier pool has work queued for
        // it right now. Measured against the configured pool size rather than
        // the current budget, so it cannot feed back on itself: the old
        // formula divided by the *current* worker count, so shedding workers
        // raised the ratio, which shed more workers.
        let validation_ratio = (verifying as f64 / cfg_workers as f64).clamp(0.0, 1.0);
        // Commit/DB pressure is deliberately based only on the actual RocksDB
        // write critical section. Validated ranges sitting behind the ordered
        // committer are bounded by lookahead/in-flight backpressure rather than
        // being mislabeled as database saturation.
        //
        // IMPORTANT: consensus/state preparation is deliberately excluded from
        // DB pressure. `prepare_commit_batch()` can legitimately take seconds
        // while RocksDB is almost idle. Feeding that wall time into the DB
        // controller made the adaptive scheduler throttle the producer even
        // though the real write critical section was only a few milliseconds.
        //
        // Measure only the actual RocksDB write + COMMIT critical section.
        // Buffered ranges are handled by the hard lookahead/in-flight bounds,
        // not mislabeled as database pressure.
        let db_critical_us = last_db_write_us.saturating_add(last_sqlite_commit_us) as f64;
        let db_ratio = (db_critical_us / DB_PRESSURE_TARGET_US).clamp(0.0, 1.0);
        // Network starvation is a real pipeline condition: planned work exists
        // but no peer is currently carrying it.  This lets the controller stop
        // expanding the window instead of accumulating an invisible backlog.
        let network_ratio = if peers == 0 || (pending > 0 && leased == 0) { 1.0 }
            else if active_outbound == 0 && (pending > 0 || verifying > 0) { 1.0 }
            else { 0.0 };
        ResourceSample { cpu_ratio, memory_ratio, db_queue_ratio: db_ratio, network_ratio, validation_queue_ratio: validation_ratio }
    }

    /// Make sure claimable ranges exist up to `chain_tip`. Cheap to call often.
    pub fn ensure_planned(&self, chain_tip: u64, workers: usize) {
        let mut g = self.inner.lock().unwrap();
        let next_commit = g.next_commit;
        g.engine.requeue_if_quarantined_at(next_commit);
        // Head-of-line recovery is deliberately independent of
        // `verifying_starts`. A verifier can itself be the stalled component;
        // previously that marker disabled the watchdog and allowed 17+ later
        // ranges to accumulate behind an unreachable canonical head.
        // Requeueing advances the lease generation. Any old verifier result is
        // rejected below unless its (id,generation) is still current.
        if !g.buffered.contains_key(&next_commit) && g.committing_upto < next_commit {
            let after = HEDGE_AFTER;
            if let Some(id) = g.engine.window_ids_at_start(next_commit) {
                if let Some(age) = g.engine.lease_age(id) {
                    if age >= after && g.engine.requeue_if_lease_stalled(id, after) {
                        let was_verifying = g.verifying_starts.contains_key(&next_commit);
                        g.hedged_ranges += 1;
                        pipeline_log("HEAD_RECOVERY", format_args!(
                            "window_start={} re-leased after {:?} age={}s old_verifier={} buffered_windows={}",
                            next_commit, after, age.as_secs(), was_verifying, g.buffered.len()
                        ));
                    }
                }
            }
        }
        if chain_tip <= g.planned_up_to { return; }
        // Backpressure: never plan further than `lookahead` past the commit tip.
        if g.planned_up_to.saturating_sub(g.next_commit).saturating_add(1) >= lookahead(&g.engine) {
            return;
        }
        let next = g.next_commit.max(g.planned_up_to.saturating_add(1));
        if next > chain_tip { return; }
        let active_workers = g.engine.current_validation_workers();
        let ids = g.engine.plan_windows(next, chain_tip, active_workers.max(workers.max(1)));
        let window = g.engine.window();
        // Advance only across ranges that really entered the scheduler. When
        // the adaptive in-flight budget is full, the remaining heights must be
        // planned later rather than being skipped by planned_up_to.
        if let Some(end) = ids.iter().filter_map(|id| g.engine.window_end(*id)).max() {
            g.planned_up_to = g.planned_up_to.max(end).min(chain_tip);
        }
        pipeline_log("PLAN", format_args!(
            "next={} planned_up_to={} ranges={} window={} lookahead={} chain_tip={} next_commit={} in_flight={}",
            next, g.planned_up_to, ids.len(), window, lookahead(&g.engine), chain_tip,
            g.next_commit, g.engine.outstanding_heights()
        ));
    }

    /// Claim one range for this peer, download it, and hand it to the verifier
    /// pool. Returns `Ok(true)` if a range was fetched, `Ok(false)` if nothing
    /// was claimable. An `Err` means the session should close.
    pub fn run_once(
        &self,
        stream: &mut TcpStream,
        state: &Arc<State>,
        live: &SharedState,
        peer_label: &str,
        peer_height: Option<u64>,
    ) -> std::io::Result<bool> {
        let max_end = peer_height.unwrap_or(u64::MAX);
        let lease = {
            let mut g = self.inner.lock().unwrap();
            if g.misbehaving.remove(peer_label) {
                return Err(ioe("peer served a block that failed validation; disconnecting"));
            }
            if let Some(reason) = g.halted.clone() {
                drop(g);
                live.write().unwrap().message = reason;
                return Ok(false);
            }
            g.engine.claim_upto(peer_label, max_end)
        };
        let Some(lease) = lease else { return Ok(false) };

        match fetch_range(stream, state, &lease) {
            Ok(mut job) => {
                job.peer = peer_label.to_string();
                let sender = self.jobs.lock().unwrap().clone();
                let Some(sender) = sender else {
                    // Pool not started: give the range back rather than lose it.
                    let mut g = self.inner.lock().unwrap();
                    if g.engine.is_current_lease(lease.id, lease.generation) { g.engine.requeue_lease(lease.id); }
                    return Ok(false);
                };
                {
                    let mut g = self.inner.lock().unwrap();
                    // A hedged twin already delivered this range: skip the work.
                    let st = lease.window.start;
                    let same_generation_verifying = g.verifying_starts.get(&st).map(|(id, generation, _)| {
                        *id == lease.id && *generation == lease.generation
                    }).unwrap_or(false);
                    if st < g.next_commit
                        || (g.committing_upto != 0 && st <= g.committing_upto)
                        || g.buffered.contains_key(&st)
                        || same_generation_verifying
                        || g.engine.window_ids_at_start(st).is_none()
                    {
                        g.duplicate_ranges += 1;
                        return Ok(true);
                    }
                    g.verifying += 1;
                    g.verifying_starts.insert(
                        lease.window.start,
                        (lease.id, lease.generation, Instant::now()),
                    );
                }
                if sender.send(job).is_err() {
                    let mut g = self.inner.lock().unwrap();
                    g.verifying = g.verifying.saturating_sub(1);
                    g.verifying_starts.remove(&lease.window.start);
                    if g.engine.is_current_lease(lease.id, lease.generation) { g.engine.requeue_lease(lease.id); }
                    return Ok(false);
                }
                self.publish(live, None);
                Ok(true)
            }
            Err(e) => {
                pipeline_log("RANGE_ERROR", format_args!(
                    "peer={} range={}..{} kind={:?} error={}",
                    peer_label, lease.window.start, lease.window.end, e.kind(), e
                ));
                {
                    let mut g = self.inner.lock().unwrap();
                    // Only count the failure against the lease we still own;
                    // a hedge may have handed the range to another peer.
                    g.engine.release_if_current(lease.id, lease.generation);
                    let nc = g.next_commit;
                    g.engine.requeue_if_quarantined_at(nc);
                }
                self.publish(live, None);
                Err(e)
            }
        }
    }

    fn verifier_loop(&self, worker_id: usize, rx: Arc<Mutex<Receiver<VerifyJob>>>, live: SharedState) {
        loop {
            // The pool is fixed-size, but the adaptive controller can lower the
            // active worker budget under pressure. Inactive workers sleep rather
            // than competing for the bounded queue, so reducing concurrency also
            // reduces CPU pressure rather than merely moving it elsewhere.
            while worker_id >= self.active_workers.load(Ordering::Acquire) {
                std::thread::sleep(Duration::from_millis(25));
            }
            let job = loop {
                match rx.lock().unwrap().try_recv() {
                    Ok(job) => break Some(job),
                    Err(std::sync::mpsc::TryRecvError::Empty) => {
                        std::thread::sleep(Duration::from_millis(2));
                    }
                    Err(std::sync::mpsc::TryRecvError::Disconnected) => break None,
                }
            };
            let Some(job) = job else { return };
            let (start, end) = (job.lease.window.start, job.lease.window.end);
            let peer = job.peer.clone();
            let started = Instant::now();
            let result = verify_job(job);
            let mut g = self.inner.lock().unwrap();
            // A head recovery can requeue and re-lease this same range while
            // the old verifier is still running. Only the exact lease generation
            // that started this job may publish a result or affect the active
            // verification count. This is the key stale-result safety barrier.
            let (result_id, result_generation) = match &result {
                Ok((lease, _, _)) => (lease.id, lease.generation),
                Err((lease, _)) => (lease.id, lease.generation),
            };
            let job_current = g.engine.is_current_lease(result_id, result_generation);
            if let Some((id, generation, _)) = g.verifying_starts.get(&start).copied() {
                if id == result_id && generation == result_generation {
                    g.verifying_starts.remove(&start);
                    g.verifying = g.verifying.saturating_sub(1);
                }
            }
            if !job_current {
                g.duplicate_ranges += 1;
                pipeline_log("STALE_VERIFY", format_args!(
                    "range={}..{} result discarded because lease generation is no longer current",
                    start, end
                ));
                continue;
            }
            match result {
                Ok((_, _, _)) if start < g.next_commit
                    || (g.committing_upto != 0 && start <= g.committing_upto)
                    || g.buffered.contains_key(&start)
                    || g.engine.window_ids_at_start(start).is_none() => {
                    g.duplicate_ranges += 1;
                    pipeline_log("DUPLICATE", format_args!("range={}..{} dropped (hedged twin already delivered)", start, end));
                }
                Ok((lease, commits, bytes)) => {
                    self.verified_blocks.fetch_add(commits.len() as u64, Ordering::Relaxed);
                    let validation_ms = started.elapsed().as_millis() as u64;
                    {
                        let mut st = live.write().unwrap();
                        st.validation_ms_total = st.validation_ms_total.saturating_add(validation_ms);
                    }
                    pipeline_log("VERIFIED", format_args!(
                        "range={}..{} blocks={} ms={} buffered={}",
                        start, end, commits.len(), started.elapsed().as_millis(), g.buffered.len() + 1
                    ));
                    g.buffered.insert(lease.window.start, (lease, commits, bytes));
                    drop(g);
                    self.commit_cv.notify_one();
                }
                Err((lease, e)) if is_node_unsupported(&e) => {
                    let reason = format!("block sync halted: {}", e);
                    pipeline_log("UNSUPPORTED", format_args!("range={}..{} error={}", start, end, e));
                    if g.engine.is_current_lease(lease.id, lease.generation) { g.engine.requeue_lease(lease.id); }
                    g.halted = Some(reason.clone());
                    drop(g);
                    let mut st = live.write().unwrap();
                    st.last_error = reason.clone();
                    st.message = reason;
                }
                Err((lease, e)) => {
                    pipeline_log("VALIDATION_ERROR", format_args!(
                        "peer={} range={}..{} error={}", peer, start, end, e
                    ));
                    g.engine.release_if_current(lease.id, lease.generation);
                    let nc = g.next_commit;
                    g.engine.requeue_if_quarantined_at(nc);
                    g.misbehaving.insert(peer.clone());
                    drop(g);
                    live.write().unwrap().last_error = format!("{} block validation: {}", peer, e);
                }
            }
        }
    }

    fn committer_loop(&self, state: Arc<State>, live: SharedState) {
        loop {
            // Take the longest run of contiguous validated ranges at next_commit.
            let batch: Vec<Buffered> = {
                let mut g = self.inner.lock().unwrap();
                let mut first_ready: Option<Instant> = None;
                loop {
                    // Re-read the adaptive commit ceiling every iteration.
                    // Previously this was captured once at startup, so changing
                    // the adaptive window never changed commit batch size.
                    let max_blocks = commit_batch_blocks(&g.engine);
                    // How many blocks are ready contiguously from next_commit?
                    let (ready, _) = if g.halted.is_none() {
                        let mut expected = g.next_commit;
                        let mut count = 0usize;
                        while count < max_blocks {
                            let Some(item) = g.buffered.get(&expected) else { break };
                            expected = item.0.window.end + 1;
                            count += item.1.len();
                        }
                        (count, expected)
                    } else { (0, 0) };
                    if ready > 0 && first_ready.is_none() { first_ready = Some(Instant::now()); }
                    // Commit when the batch is full, when nothing else is coming
                    // soon (no range in verification), or the linger expired.
                    let linger_done = first_ready.map(|t| t.elapsed() >= commit_linger()).unwrap_or(false);
                    if ready > 0 && (ready >= max_blocks || g.verifying == 0 || linger_done) {
                        let mut out = Vec::new();
                        let mut expected = g.next_commit;
                        let mut count = 0usize;
                        let mut previous_hash: Option<[u8; 32]> = None;
                        let mut barrier_error = false;
                        while count < max_blocks {
                            let Some(item) = g.buffered.remove(&expected) else { break };
                            if item.1.is_empty() { g.buffered.insert(expected, item); barrier_error = true; break; }
                            for (i, b) in item.1.iter().enumerate() {
                                let want_height = expected + i as u64;
                                if b.height != want_height {
                                    tracing::error!(height=b.height, expected=want_height, "commit barrier rejected non-contiguous block");
                                    barrier_error = true;
                                    break;
                                }
                                if i == 0 {
                                    if let Some(prev) = previous_hash {
                                        if b.prev != prev {
                                            tracing::error!(height=b.height, "commit barrier rejected parent mismatch");
                                            barrier_error = true;
                                            break;
                                        }
                                    }
                                } else if b.prev != item.1[i - 1].hash {
                                    tracing::error!(height=b.height, "commit barrier rejected intra-range parent mismatch");
                                    barrier_error = true;
                                    break;
                                }
                            }
                            if barrier_error { g.buffered.insert(expected, item); break; }
                            previous_hash = item.1.last().map(|b| b.hash);
                            expected = item.0.window.end + 1;
                            count += item.1.len();
                            out.push(item);
                        }
                        if barrier_error {
                            // Do not remove the suspect result. Leave it in the
                            // ordered buffer so the permanent worker can report a
                            // deterministic commit-barrier failure.
                            let reason = format!("commit barrier violation at height {}", g.next_commit);
                            g.halted = Some(reason.clone());
                            tracing::error!(%reason, "permanent commit worker stopped on ordering invariant");
                            return;
                        }
                        g.committing_upto = expected.saturating_sub(1);
                        break out;
                    }
                    let wait = if ready > 0 { Duration::from_millis(50) } else { Duration::from_secs(1) };
                    g = self.commit_cv.wait_timeout(g, wait).unwrap().0;
                }
            };

            let first = batch[0].0.window.start;
            let last = batch[batch.len() - 1].0.window.end;
            // Move (not clone) the raw blocks into one commit vector.
            let mut leases: Vec<(BlockWindowLease, u64)> = Vec::with_capacity(batch.len());
            let mut blocks: Vec<BlockCommit> = Vec::new();
            let mut bytes = 0u64;
            for (lease, b, n) in batch {
                leases.push((lease, b.len() as u64));
                blocks.extend(b);
                bytes += n;
            }
            let started = Instant::now();
            // Stage overlap: contextual preparation is the ordered state stage,
            // but semantic verification of later ranges continues in parallel.
            // Only canonical publication is serialized. Never reduce the
            // verifier pool to one merely because this stage is active.
            self.commit_active.store(true, Ordering::Release);
            let active_verify_workers = {
                let g = self.inner.lock().unwrap();
                g.engine.current_validation_workers().min(verify_threads()).max(1)
            };
            self.active_workers.store(active_verify_workers, Ordering::Release);
            update_commit_cpu_budget(active_verify_workers);
            pipeline_log("STAGE_OVERLAP", format_args!(
                "contextual_prepare={}..{} semantic_workers={} script_budget={} network_lookahead={} transport_window={} canonical_writer=1",
                first, last, active_verify_workers,
                ycash_state::chainstate::script_worker_budget(),
                lookahead(&self.inner.lock().unwrap().engine),
                self.inner.lock().unwrap().engine.transport_window()
            ));
            let prepared = match state.prepare_commit_batch(&blocks) {
                Ok(p) => p,
                Err(e) => {
                    let reason = format!("ordered commit {}..{} preparation failed; requeued for retry: {}", first, last, e);
                    pipeline_log("COMMIT_PREPARE_RETRY", &reason);
                    let mut g = self.inner.lock().unwrap();
                    for (lease, _) in &leases { g.engine.requeue_lease(lease.id); }
                    g.committing_upto = 0;
                    self.commit_cv.notify_all();
                    let mut st = live.write().unwrap();
                    st.last_error = reason.clone();
                    st.message = reason;
                    drop(st);
                    self.commit_active.store(false, Ordering::Release);
                    // Preserve stage overlap after a retry: restore the current
                    // adaptive semantic worker count rather than collapsing to
                    // a single verifier.
                    let workers = self.inner.lock().unwrap().engine.current_validation_workers().min(verify_threads()).max(1);
                    self.active_workers.store(workers, Ordering::Release);
                    update_normal_cpu_budget(workers);
                    continue;
                }
            };
            if let Err(e) = state.apply_prepared_commit(prepared) {
                // Recoverable candidate/state-transition failures do not kill the
                // permanent writer. Requeue the affected leases and retry through
                // the normal validation/fetch path. Terminal invariants are handled
                // separately by the commit-barrier checks above.
                let reason = format!("ordered commit {}..{} failed; requeued for retry: {}", first, last, e);
                pipeline_log("COMMIT_RETRY", &reason);
                {
                    let mut g = self.inner.lock().unwrap();
                    for (lease, _) in &leases { g.engine.requeue_lease(lease.id); }
                    g.committing_upto = 0;
                    self.commit_cv.notify_all();
                }
                let mut st = live.write().unwrap();
                st.last_error = reason.clone();
                st.message = reason;
                drop(st);
                self.commit_active.store(false, Ordering::Release);
                let workers = self.inner.lock().unwrap().engine.current_validation_workers().min(verify_threads()).max(1);
                self.active_workers.store(workers, Ordering::Release);
                update_normal_cpu_budget(workers);
                continue;
            }
            let commit_ms = started.elapsed().as_millis() as u64;
            let commit_timing = state.last_commit_timing();
            {
                let mut g = self.inner.lock().unwrap();
                for (lease, n) in &leases { g.engine.complete(lease.id, *n, 0); }
                g.next_commit = last + 1;
                g.committing_upto = 0;
                // Drop any late duplicate that slipped in below the new tip.
                let nc = g.next_commit;
                g.buffered = g.buffered.split_off(&nc);
                // Do not feed the just-completed consensus preparation time
                // back into the adaptive controller. The 500 ms sampler owns
                // adaptation and reads actual CPU/memory/RocksDB pressure. This
                // avoids the old saw-tooth feedback where an expensive but
                // healthy state transition immediately shrank the producer.
                let new_workers = g.engine.current_validation_workers().min(verify_threads()).max(1);
                self.active_workers.store(new_workers, Ordering::Release);
                update_normal_cpu_budget(new_workers);
            }
            // Wake any committer wait immediately if more is already buffered.
            self.commit_cv.notify_one();
            let rate = blocks.len() as u64 * 1000 / commit_ms.max(1);
            pipeline_log("COMMIT_OK", format_args!(
                "range={}..{} blocks={} ranges={} commit_ms={} blocks_per_sec={}",
                first, last, blocks.len(), leases.len(), commit_ms, rate
            ));
            let tip_time = state.header_time(last).ok().flatten().unwrap_or(0);
            {
                let mut st = live.write().unwrap();
                st.local_height = last;
                st.tip_time = tip_time;
                st.blocks_received = st.blocks_received.saturating_add(blocks.len() as u64);
                st.blocks_validated = st.blocks_validated.saturating_add(blocks.len() as u64);
                st.block_bytes_received = st.block_bytes_received.saturating_add(bytes);
                st.db_commits = st.db_commits.saturating_add(1);
                st.db_commit_ms_total = st.db_commit_ms_total.saturating_add(commit_ms);
                st.last_begin_ms = commit_timing.begin_ms;
                st.last_state_validation_ms = commit_timing.state_validation_ms;
                st.last_state_validation_us = commit_timing.state_validation_us;
                st.last_state_unattributed_us = commit_timing.state_unattributed_us;
                st.last_header_hash_us = commit_timing.header_hash_us;
                st.last_connector_new_us = commit_timing.connector_new_us;
                st.last_connector_other_us = commit_timing.connector_other_us;
                st.last_block_root_us = commit_timing.block_root_us;
                st.last_block_root_level_us = commit_timing.block_root_level_us;
                st.last_block_root_level_hashes = commit_timing.block_root_level_hashes;
                st.last_block_root_empty_us = commit_timing.block_root_empty_us;
                st.last_block_root_empty_hashes = commit_timing.block_root_empty_hashes;
                st.last_block_root_hash_us = commit_timing.block_root_hash_us;
                st.last_block_root_hashes = commit_timing.block_root_hashes;
                st.last_block_loop_other_us = commit_timing.block_loop_other_us;
                st.last_slowest_block_height = commit_timing.slowest_block_height;
                st.last_slowest_block_us = commit_timing.slowest_block_us;
                st.last_slowest_block_other_us = commit_timing.slowest_block_other_us;
                st.last_slowest_tx_height = commit_timing.slowest_tx_height;
                st.last_slowest_tx_index = commit_timing.slowest_tx_index;
                st.last_slowest_tx_us = commit_timing.slowest_tx_us;
                st.last_slowest_tx_other_us = commit_timing.slowest_tx_other_us;
                st.last_commit_total_us = commit_timing.total_us;
                st.last_tree_ms = commit_timing.tree_ms;
                st.last_parent_state_load_ms = commit_timing.parent_state_load_ms;
                st.last_parent_state_load_us = commit_timing.parent_state_load_us;
                st.last_block_parse_us = commit_timing.block_parse_us;
                st.last_txid_us = commit_timing.txid_us;
                st.last_block_parse_ms = commit_timing.block_parse_ms;
                st.last_tx_parse_us = commit_timing.tx_parse_us;
                st.last_tx_connect_ms = commit_timing.tx_connect_ms;
                st.last_tx_connect_us = commit_timing.tx_connect_us;
                st.last_sigops_us = commit_timing.sigops_us;
                st.last_bip30_us = commit_timing.bip30_us;
                st.last_sigops_ms = commit_timing.sigops_ms;
                st.last_bip30_ms = commit_timing.bip30_ms;
                st.last_utxo_lookup_ms = commit_timing.utxo_lookup_ms;
                st.last_utxo_lookup_us = commit_timing.utxo_lookup_us;
                st.last_sprout_requirements_us = commit_timing.sprout_requirements_us;
                st.last_value_checks_us = commit_timing.value_checks_us;
                st.last_script_us = commit_timing.script_us;
                st.last_coin_state_update_us = commit_timing.coin_state_update_us;
                st.last_sprout_apply_us = commit_timing.sprout_apply_us;
                st.last_sprout_requirements_ms = commit_timing.sprout_requirements_ms;
                st.last_value_checks_ms = commit_timing.value_checks_ms;
                st.last_script_ms = commit_timing.script_ms;
                st.last_script_parallel_workers = commit_timing.script_parallel_workers;
                st.last_script_parallel_us = commit_timing.script_parallel_us;
                st.last_script_input_work_us = commit_timing.script_input_work_us;
                st.last_script_transaction_input_extraction_us = commit_timing.script_transaction_input_extraction_us;
                st.last_script_sig_construction_us = commit_timing.script_sig_construction_us;
                st.last_script_pubkey_retrieval_us = commit_timing.script_pubkey_retrieval_us;
                st.last_script_parsing_us = commit_timing.script_parsing_us;
                st.last_signature_hash_preparation_us = commit_timing.signature_hash_preparation_us;
                st.last_ecdsa_verification_us = commit_timing.ecdsa_verification_us;
                st.last_script_interpreter_us = commit_timing.script_interpreter_us;
                st.last_script_cache_lookup_us = commit_timing.script_cache_lookup_us;
                st.last_script_synchronization_us = commit_timing.script_synchronization_us;
                st.last_script_permit_wait_us = commit_timing.script_permit_wait_us;
                st.last_script_active_peak = commit_timing.script_active_peak;
                st.last_script_scheduler_gap_us = commit_timing.script_scheduler_gap_us;
                st.last_script_worker_wall_us = commit_timing.script_worker_wall_us;
                st.last_script_worker_input_work_us = commit_timing.script_worker_input_work_us;
                st.last_script_worker_inputs = commit_timing.script_worker_inputs;
                st.last_script_spawn_us = commit_timing.script_spawn_us;
                st.last_script_join_us = commit_timing.script_join_us;
                st.last_script_pool_overhead_us = commit_timing.script_pool_overhead_us;
                st.last_script_pool_threads = commit_timing.script_pool_threads;
                st.last_script_worker_max_us = commit_timing.script_worker_max_us;
                st.last_script_worker_min_us = commit_timing.script_worker_min_us;
                st.last_script_slowest_input_index = commit_timing.script_slowest_input_index;
                st.last_script_slowest_input_us = commit_timing.script_slowest_input_us;
                st.last_script_slowest_input_tx_height = commit_timing.script_slowest_input_tx_height;
                st.last_script_slowest_input_tx_index = commit_timing.script_slowest_input_tx_index;
                st.last_utxo_cache_hits = commit_timing.utxo_cache_hits;
                st.last_utxo_cache_misses = commit_timing.utxo_cache_misses;
                st.last_parent_state_cache_hit = commit_timing.parent_state_cache_hit;
                st.last_sprout_state_cache_hit = commit_timing.sprout_state_cache_hit;
                st.last_coin_state_update_ms = commit_timing.coin_state_update_ms;
                st.last_sprout_apply_ms = commit_timing.sprout_apply_ms;
                st.last_sapling_validate_ms = commit_timing.sapling_validate_ms;
                st.last_sapling_validate_us = commit_timing.sapling_validate_us;
                st.last_sapling_anchor_lookup_ms = commit_timing.sapling_anchor_lookup_ms;
                st.last_sapling_anchor_lookup_us = commit_timing.sapling_anchor_lookup_us;
                st.last_sapling_nullifier_lookup_ms = commit_timing.sapling_nullifier_lookup_ms;
                st.last_sapling_nullifier_lookup_us = commit_timing.sapling_nullifier_lookup_us;
                st.last_sapling_tree_update_ms = commit_timing.sapling_tree_update_ms;
                st.last_sapling_tree_update_us = commit_timing.sapling_tree_update_us;
                st.last_block_finalize_us = commit_timing.block_finalize_us;
                st.last_tree_encode_us = commit_timing.tree_encode_us;
                st.last_read_transaction_us = commit_timing.read_transaction_us;
                st.last_read_transaction_commit_us = commit_timing.read_transaction_commit_us;
                st.last_parent_frontier_load_us = commit_timing.parent_frontier_load_us;
                st.last_sprout_state_load_us = commit_timing.sprout_state_load_us;
                st.last_block_finalize_ms = commit_timing.block_finalize_ms;
                st.last_sapling_anchor_queries = commit_timing.sapling_anchor_queries;
                st.last_sapling_nullifier_queries = commit_timing.sapling_nullifier_queries;
                st.last_sapling_empty_hashes_avoided = commit_timing.sapling_empty_hashes_avoided;
                st.last_sapling_root_cache_hits = commit_timing.sapling_root_cache_hits;
                st.last_utxo_lookups = commit_timing.utxo_lookups;
                st.last_bip30_checks = commit_timing.bip30_checks;
                st.last_script_checks = commit_timing.script_checks;
                st.last_db_write_ms = commit_timing.db_write_ms;
                st.last_db_write_us = commit_timing.db_write_us;
                st.last_sql_write_ms = commit_timing.sql_write_ms;
                st.last_index_write_ms = commit_timing.index_write_ms;
                st.last_sqlite_commit_ms = commit_timing.sqlite_commit_ms;
                st.last_sqlite_commit_us = commit_timing.sqlite_commit_us;
                st.last_rollback_ms = commit_timing.rollback_ms;
                st.record_rolling_commit(RollingCommitSample {
                    blocks: commit_timing.blocks,
                    txs: commit_timing.txs,
                    total_us: commit_timing.total_us,
                    state_validation_us: commit_timing.state_validation_us,
                    tx_connect_us: commit_timing.tx_connect_us,
                    script_us: commit_timing.script_us,
                    script_transaction_input_extraction_us: commit_timing.script_transaction_input_extraction_us,
                    script_sig_construction_us: commit_timing.script_sig_construction_us,
                    script_pubkey_retrieval_us: commit_timing.script_pubkey_retrieval_us,
                    script_parsing_us: commit_timing.script_parsing_us,
                    signature_hash_preparation_us: commit_timing.signature_hash_preparation_us,
                    ecdsa_verification_us: commit_timing.ecdsa_verification_us,
                    script_interpreter_us: commit_timing.script_interpreter_us,
                    script_cache_lookup_us: commit_timing.script_cache_lookup_us,
                    script_synchronization_us: commit_timing.script_synchronization_us,
                    sqlite_commit_us: commit_timing.sqlite_commit_us,
                    db_write_us: commit_timing.db_write_us,
                });
                st.txs_indexed = st.txs_indexed.saturating_add(blocks.iter().map(|b| b.txs.len() as u64).sum());
                st.batch_size = blocks.len() as u64;
                st.last_commit_unix = unix_time();
            }
            self.commit_active.store(false, Ordering::Release);
            // Restore the current adaptive semantic pool immediately. The next
            // range must overlap its semantic/prefetch work with the following
            // canonical preparation rather than waiting for the sampler tick.
            let workers = self.inner.lock().unwrap().engine.current_validation_workers().min(verify_threads()).max(1);
            self.active_workers.store(workers, Ordering::Release);
            update_normal_cpu_budget(workers);
            let (hedged, dups) = { let g = self.inner.lock().unwrap(); (g.hedged_ranges, g.duplicate_ranges) };
            self.publish(&live, Some(format!(
                "committed {}..{} ({} blocks in 1 tx, {} verifier threads, hedged {}, duplicates dropped {})",
                first, last, blocks.len(), workers, hedged, dups
            )));
        }
    }

    /// Mirror pipeline counters to the dashboard.
    fn publish(&self, live: &SharedState, message: Option<String>) {
        // `current_*` is what the pressure controller is allowing right now;
        // `cfg_*` is the configured ceiling. Publishing both is what makes a
        // settings change visible instead of looking like it was ignored.
        let (snap, outstanding, queue, verifying, buffered_windows, leased_windows, pending_windows,
             current_validation_workers, current_inflight_ranges, lookahead_blocks,
             cfg_validation_workers, cfg_inflight_windows, cfg_transport_window,
             current_commit_batch) = {
            let g = self.inner.lock().unwrap();
            (
                g.engine.snapshot(),
                g.engine.outstanding_heights(),
                g.verifying + g.buffered.len() as u64,
                g.verifying,
                g.buffered.len() as u64,
                g.engine.leased_windows() as u64,
                g.engine.pending_windows() as u64,
                g.engine.current_validation_workers() as u64,
                g.engine.max_inflight_windows() as u64,
                g.engine.lookahead(),
                g.engine.configured_max_validation_workers() as u64,
                g.engine.configured_max_inflight_windows() as u64,
                g.engine.transport_window() as u64,
                commit_batch_blocks(&g.engine) as u64,
            )
        };
        let pressure = self.resource_sample(live);
        let bottleneck = if snap.quarantined_windows > 0 {
            "RANGE RETRY / HEAD-OF-LINE".to_string()
        } else {
            // Only genuine resource limits count as bottlenecks. A deep
            // validation queue is workload demand: it means there is work to
            // do, and reporting it as a constraint is what made the dashboard
            // claim the pipeline was pressured while the device was idle.
            let limits = [
                (pressure.cpu_ratio, "CPU"),
                (pressure.memory_ratio, "MEMORY"),
                (pressure.db_queue_ratio, "DB/COMMIT"),
                (pressure.network_ratio, "NETWORK"),
            ];
            let worst = limits.iter().fold((0.0_f64, "NONE"), |acc, item| {
                if item.0 > acc.0 { (item.0, item.1) } else { acc }
            });
            if worst.0 >= 0.20 {
                worst.1.to_string()
            } else if pressure.validation_queue_ratio >= 0.50 {
                "NONE / VALIDATION DEMAND".to_string()
            } else {
                "NONE / HEALTHY".to_string()
            }
        };
        let mut st = live.write().unwrap();
        st.pipeline_cpu_pressure = pressure.cpu_ratio;
        st.pipeline_memory_pressure = pressure.memory_ratio;
        st.pipeline_db_pressure = pressure.db_queue_ratio;
        st.pipeline_network_pressure = pressure.network_ratio;
        st.pipeline_validation_pressure = pressure.validation_queue_ratio;
        st.pipeline_bottleneck = bottleneck;
        st.blocks_in_flight = outstanding;
        st.pipeline_inflight_windows = leased_windows;
        st.pipeline_pending_windows = pending_windows;
        st.validation_queue = queue;
        st.verifying_jobs = verifying;
        st.buffered_windows = buffered_windows;
        st.active_block_workers = self.active_workers.load(Ordering::Acquire).max(1) as u64;
        st.current_window = snap.window;
        st.pipeline_verify_threads = verify_threads() as u64;
        st.pipeline_script_budget = ycash_state::chainstate::script_worker_budget() as u64;
        st.pipeline_script_pool_threads = script_pool_threads() as u64;
        st.pipeline_max_validation_workers = current_validation_workers;
        st.pipeline_max_inflight_windows = current_inflight_ranges;
        st.pipeline_lookahead = lookahead_blocks;
        st.pipeline_commit_batch = current_commit_batch;
        st.pipeline_max_window_len = cfg_transport_window;
        st.pipeline_active_window_len = snap.window.min(cfg_transport_window).max(1);
        st.pipeline_cfg_validation_workers = cfg_validation_workers;
        st.pipeline_cfg_inflight_windows = cfg_inflight_windows;
        st.pipeline_cfg_transport_window = cfg_transport_window;
        st.completed_windows = snap.completed_windows;
        st.retried_windows = snap.retried_windows;
        st.quarantined_windows = snap.quarantined_windows;
        if let Some(m) = message { st.message = m; }
    }
}

/// `some avg10=<percent>` from a Linux PSI file, as a 0.0..1.0 ratio.
/// PSI measures time actually *stalled* waiting for a resource, which is what
/// "pressure" is supposed to mean. Not every Android kernel exposes it.
fn read_psi_some_avg10(path: &str) -> Option<f64> {
    let s = std::fs::read_to_string(path).ok()?;
    for line in s.lines() {
        if !line.starts_with("some") { continue; }
        for field in line.split_whitespace() {
            if let Some(v) = field.strip_prefix("avg10=") {
                if let Ok(pct) = v.parse::<f64>() {
                    return Some((pct / 100.0).clamp(0.0, 1.0));
                }
            }
        }
    }
    None
}

/// CPU *contention*, not CPU utilisation.
///
/// The old reading was `loadavg / cores`, which is self-defeating: running the
/// 7 verifier threads the controller is supposed to run puts load at ~7/8 =
/// 0.875, above the 0.85 high watermark, so the pipeline throttled itself for
/// doing exactly what it was told to do. Pressure now starts only once the
/// machine is genuinely oversubscribed.
fn read_cpu_pressure() -> f64 {
    if let Some(psi) = read_psi_some_avg10("/proc/pressure/cpu") { return psi; }
    if let Ok(s) = std::fs::read_to_string("/proc/loadavg") {
        if let Some(load) = s.split_whitespace().next().and_then(|v| v.parse::<f64>().ok()) {
            let cpus = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1) as f64;
            return cpu_pressure_from_load(load, cpus);
        }
    }
    0.0
}

/// No pressure until run-queue length reaches core count; full pressure at
/// twice the core count.
fn cpu_pressure_from_load(load: f64, cpus: f64) -> f64 {
    let cpus = cpus.max(1.0);
    let ratio = load / cpus;
    if ratio <= 1.0 { 0.0 } else { (ratio - 1.0).clamp(0.0, 1.0) }
}

/// Below this utilisation there is no memory pressure at all.
const MEMORY_PRESSURE_KNEE: f64 = 0.85;

/// Memory *pressure*, not memory *utilisation*.
///
/// Android/Linux keep the page cache hot, so a device sits at 70-80% "used"
/// with plenty of reclaimable memory and no stalls whatsoever. The old reading
/// reported that as 0.75 pressure, which sat just under the high watermark
/// permanently and blocked the window from ever growing.
fn read_memory_pressure() -> f64 {
    if let Some(psi) = read_psi_some_avg10("/proc/pressure/memory") { return psi; }
    if let Ok(s) = std::fs::read_to_string("/proc/meminfo") {
        let mut total = 0f64;
        let mut available = 0f64;
        for line in s.lines() {
            let mut p = line.split_whitespace();
            match p.next() {
                Some("MemTotal:") => total = p.next().and_then(|v| v.parse().ok()).unwrap_or(0.0),
                Some("MemAvailable:") => available = p.next().and_then(|v| v.parse().ok()).unwrap_or(0.0),
                _ => {}
            }
        }
        if total > 0.0 {
            let used = (1.0 - available / total).clamp(0.0, 1.0);
            return memory_pressure_from_utilisation(used);
        }
    }
    0.0
}

fn memory_pressure_from_utilisation(used: f64) -> f64 {
    if used <= MEMORY_PRESSURE_KNEE { return 0.0; }
    ((used - MEMORY_PRESSURE_KNEE) / (1.0 - MEMORY_PRESSURE_KNEE)).clamp(0.0, 1.0)
}

/// Block hash straight from the raw block bytes (sha256d of the header incl.
/// Equihash solution).
fn raw_block_hash(raw: &[u8]) -> Option<[u8; 32]> {
    use sha2::{Digest, Sha256};
    let mut i = 140usize;
    let sol_len = ycash_network::runtime::read_compact_size(raw, &mut i).ok()? as usize;
    let end = i.checked_add(sol_len)?;
    let header = raw.get(..end)?;
    let a = Sha256::digest(header);
    let b = Sha256::digest(a);
    let mut out = [0u8; 32];
    out.copy_from_slice(&b);
    Some(out)
}

/// Median-time-past for every height in `start..=end`, computed exactly like
/// `crate::mtp` (median of the 11 preceding header times, with the genesis time
/// standing in below height 12) but from a single range query.
fn mtp_range(state: &State, start: u64, end: u64) -> std::io::Result<HashMap<u64, u32>> {
    let from = start.saturating_sub(11).max(1);
    let rows = state.header_times_range(from, end).map_err(|e| ioe(&e.to_string()))?;
    let times: HashMap<u64, u32> = rows.into_iter().collect();
    let mut out = HashMap::new();
    for h in start..=end {
        let s = h.saturating_sub(11);
        let mut v = Vec::with_capacity(11);
        if s == 0 && h > 0 { v.push(GENESIS_TIME); }
        for x in s.max(1)..h {
            if let Some(t) = times.get(&x) { v.push(*t); }
        }
        let m = if v.is_empty() { 0 } else { v.sort_unstable(); v[v.len() / 2] };
        out.insert(h, m);
    }
    Ok(out)
}

/// Stage 1: download a leased range and attach verifier context. No validation.
fn fetch_range(stream: &mut TcpStream, state: &Arc<State>, lease: &BlockWindowLease) -> std::io::Result<VerifyJob> {
    let (start, end) = (lease.window.start, lease.window.end);
    let hashes = state.header_hashes_range(start, end).map_err(|e| ioe(&e.to_string()))?;
    let works = state.header_works_range(start, end).map_err(|e| ioe(&e.to_string()))?;
    let mtps = mtp_range(state, start, end)?;
    let mut requests = Vec::with_capacity((end - start + 1) as usize);
    for h in start..=end {
        let hash = hashes.get(&h).copied().ok_or_else(|| ioe("missing header for claimed range"))?;
        requests.push((h, hash));
    }
    let prev_of_start: [u8; 32] = if start == 1 {
        genesis_hash_internal()
    } else {
        state.header_hash_by_height(start - 1)
            .map_err(|e| ioe(&e.to_string()))?
            .and_then(|v| <[u8; 32]>::try_from(v.as_slice()).ok())
            .ok_or_else(|| ioe("missing previous header"))?
    };
    let assume_valid_ok = start <= ASSUME_VALID_HEIGHT && assume_valid_active(state);
    if assume_valid_ok { state.set_assume_valid_height(ASSUME_VALID_HEIGHT); }

    let by_hash: HashMap<[u8; 32], u64> = requests.iter().map(|(h, hash)| (*hash, *h)).collect();
    let want: Vec<[u8; 32]> = requests.iter().map(|(_, h)| *h).collect();
    send(stream, "getdata", &getdata_payload(&want)).map_err(|e| phase_error("getdata send", e))?;

    let mut got: BTreeMap<u64, Vec<u8>> = BTreeMap::new();
    let mut bytes = 0u64;
    let mut idle = 0u32;
    // Progress deadline: at least one requested block every 180s
    // (ycashd's post-Blossom minimum block timeout is 150s).
    const PROGRESS_TIMEOUT: Duration = Duration::from_secs(180);
    let mut deadline = Instant::now() + PROGRESS_TIMEOUT;
    while got.len() < requests.len() {
        if Instant::now() >= deadline {
            return Err(ioe(&format!(
                "peer made no progress on range {}..{} for 180s (received {}/{} blocks)",
                start, end, got.len(), requests.len()
            )));
        }
        let (cmd, payload) = match read_message(stream) {
            Ok(v) => v,
            Err(e) if is_timeout(&e) => {
                idle += 1;
                // v0.29.2: 30s of silence (was 8s). Mobile links and busy ycashd
                // peers pause longer than 8s; the head-of-line range is hedged
                // to another peer after 20s anyway, so waiting costs nothing.
                if idle >= IDLE_READS_BEFORE_DROP { return Err(ioe("peer sent nothing for 30s on claimed range")); }
                continue;
            }
            Err(e) => return Err(phase_error("block stream read", e)),
        };
        idle = 0;
        if cmd == "ping" {
            send(stream, "pong", &payload).map_err(|e| phase_error("block-stream pong send", e))?;
            continue;
        }
        if cmd == "notfound" {
            return Err(ioe(&format!("peer sent notfound for range {}..{}", start, end)));
        }
        if cmd != "block" { continue; }
        let Some(height) = raw_block_hash(&payload).and_then(|h| by_hash.get(&h).copied()) else { continue };
        if got.contains_key(&height) { continue; }
        deadline = Instant::now() + PROGRESS_TIMEOUT;
        bytes += payload.len() as u64;
        got.insert(height, payload);
    }

    let mut blocks = Vec::with_capacity(requests.len());
    for (h, hash) in requests {
        let raw = got.remove(&h).ok_or_else(|| ioe("range assembly lost a block"))?;
        let m = *mtps.get(&h).unwrap_or(&0);
        let w = works.get(&h).copied().ok_or_else(|| ioe("missing header chain work"))?;
        blocks.push((h, hash, m, w, raw));
    }
    Ok(VerifyJob { lease: lease.clone(), peer: String::new(), blocks, prev_of_start, assume_valid_ok, bytes })
}

/// Stage 2: complete stateless consensus validation of one range. Pure CPU, no DB.
///
/// Every block must pass the same consensus validation entry point before it
/// can enter the ordered state committer. Full verification is the default;
/// the optional assume-valid checkpoint is never enabled implicitly.
///
/// v0.30.0: every Sapling Groth16 proof in the range goes into one
/// `ProofBatch` (one multi-Miller loop per verifying key instead of one
/// pairing check per proof). Non-pairing checks still run per transaction.
/// Any rejection is re-checked by the original single-proof verifier, whose
/// result is final (see `ycash_consensus::ProofBatch`).
fn verify_job(job: VerifyJob) -> Result<Buffered, (BlockWindowLease, std::io::Error)> {
    let VerifyJob { lease, blocks, prev_of_start, assume_valid_ok, bytes, .. } = job;
    let mut out = Vec::with_capacity(blocks.len());
    let mut prev = prev_of_start;
    let mut batch = ProofBatch::new();
    let as_io = |height: u64, e: ycash_consensus::ConsensusError| {
        let msg = format!("{e:?}");
        let kind = if msg.contains(UNSUPPORTED_PREFIX) { ErrorKind::Unsupported } else { ErrorKind::InvalidData };
        std::io::Error::new(kind, format!("block {height}: {msg}"))
    };
    for (height, hash, mtp_time, work, raw) in blocks {
        let ctx = Context { height, prev_height: height.saturating_sub(1), median_time_past: mtp_time };
        let assume_valid = height <= ASSUME_VALID_HEIGHT && assume_valid_ok;
        let (validated, parsed_txs) = match validate_for_commit_batched_with_parsed(&raw, ctx, assume_valid, &mut batch) {
            Ok(v) => v,
            Err(e) => return Err((lease, as_io(height, e))),
        };
        if validated.txs.is_empty() || parsed_txs.len() != validated.txs.len() {
            return Err((lease, ioe("consensus decoder returned inconsistent transaction data")));
        }
        let txs: Vec<([u8; 32], Vec<u8>)> = validated.txs.iter().map(|t| (txid(t), t.clone())).collect();
        let precomputed_txs: Vec<ycash_script::PrecomputedTxData> = parsed_txs.iter().map(ycash_script::PrecomputedTxData::new).collect();
        out.push(BlockCommit { height, hash, prev, work, raw, txs, parsed_txs, precomputed_txs, proofs_verified: true });
        prev = hash;
    }
    let proofs = batch.proofs();
    if proofs > 0 {
        let started = Instant::now();
        if let Err((height, e)) = batch.finish() {
            return Err((lease, as_io(height, e)));
        }
        let (batches, total, failed) = ycash_consensus::batch_stats();
        pipeline_log("BATCH_VERIFY", format_args!(
            "range={}..{} proofs={} ms={} total_batches={} total_proofs={} failed_batches={}",
            lease.window.start, lease.window.end, proofs, started.elapsed().as_millis(), batches, total, failed
        ));
    }
    Ok((lease, out, bytes))
}

fn ioe(s: &str) -> std::io::Error {
    std::io::Error::new(ErrorKind::InvalidData, s.to_string())
}

fn phase_error(phase: &str, e: std::io::Error) -> std::io::Error {
    std::io::Error::new(e.kind(), format!("{}: {}", phase, e))
}
