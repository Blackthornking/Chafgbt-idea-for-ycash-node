YORTAL — COMPLETE ZEBRA-STYLE 48-BLOCK PIPELINE REPLACEMENT
Consensus-Safe Implementation Plan
Updated: 2026-09-18

PURPOSE
=======
Replace YORTAL's current adaptive/range-based synchronization pipeline completely with a Zebra-style separation of downloading, semantic verification, prospective block queuing, contextual consensus processing, and one ordered canonical state writer.

The new networking pipeline uses:

    MAX_BLOCKS_IN_TRANSIT_PER_PEER = 48

The value 48 is a transport/backpressure limit only. It is NOT a Ycash consensus rule, checkpoint, finality rule, or database/consensus batch size.

The implementation is intended as one complete replacement, not a phased compatibility migration.

CONSENSUS-SAFETY PRINCIPLE
===========================
The pipeline may change HOW blocks are obtained, scheduled, verified in parallel, queued, and persisted.

It must not change WHAT constitutes a valid Ycash block, transaction, chain, or state transition.

Zcash's consensus specification defines a blockchain as a tree of candidate blocks rooted at genesis, with valid chains formed by valid blocks connected through parent hashes. The best valid chain is selected by total work. ZIP 200 also requires consensus rules that depend on network upgrades to be gated by the applicable block height. These consensus rules remain outside the 48-block scheduler.

References:
- Zcash Protocol Specification:
  https://zips.z.cash/protocol/protocol.pdf
- ZIP 200 — Network Upgrade Mechanism:
  https://zips.z.cash/zip-0200
- Zcash P2P Protocol:
  https://zips.z.cash/zip-0204

ARCHITECTURE TO REPLACE
=======================
DELETE the existing range/adaptive pipeline as the synchronization architecture.

Remove the concepts and references to:

- AdaptiveController
- RangeScheduler
- RangeId
- RangeLease
- HeightRange
- RangeState
- ValidatedRange
- plan_parallel_ranges()
- adaptive range windows
- max_inflight_ranges
- max_range_len
- range completion/requeue as the primary scheduling model
- range-based commit barriers
- range-based pipeline telemetry
- adaptive validation-worker scheduling
- range-oriented commit retry logic

The old configuration entries controlling adaptive range behavior must no longer control synchronization:

- min_window
- initial_window
- max_window
- window_step
- max_validation_workers
- max_inflight_ranges
- max_range_len
- high_watermark
- low_watermark

Do not leave a hidden compatibility layer that continues using the old range engine underneath a new name.

TARGET ARCHITECTURE
===================
Use these independent components:

    PeerManager
        |
        v
    BlockDownloader
        |
        | up to 48 outstanding blocks PER PEER
        v
    Semantic Verification Pool
        |
        v
    ProspectiveBlockSet
        |
        v
    StateService
        |
        +--> contextual consensus validation
        +--> chain selection / fork handling
        +--> ordered state transition
        |
        v
    BlockWriteWorker
        |
        v
    RocksDB

OWNERSHIP RULES
===============
PeerManager
- Own peer connections and peer health.
- Must not decide canonical chain validity.

BlockDownloader
- Request blocks and replenish requests as blocks complete.
- Enforce the 48-block-per-peer in-flight limit.
- Must not declare blocks consensus-valid.
- Must not select the canonical chain.

Semantic Verification Pool
- Perform parallel checks that do not require serial mutation of canonical state.
- Must preserve all existing Ycash cryptographic and block/transaction validation requirements.
- Must not bypass contextual validation.

ProspectiveBlockSet
- Store semantically verified blocks waiting for their parent/state context.
- Index by block hash, parent hash, and height.
- Support forks and out-of-order arrival.
- Do not reduce the structure to a height-only range map.

StateService
- Own canonical chain/state decisions.
- Determine whether parent state is available.
- Perform contextual consensus validation.
- Handle chain selection and reorganization according to the existing Ycash consensus implementation.
- Produce the ordered state transition.

BlockWriteWorker
- Be the single authoritative writer for canonical state.
- Persist prepared state updates to RocksDB.
- May use RocksDB WriteBatch for storage atomicity.
- Must not reinterpret a database WriteBatch as a consensus batch.

48-BLOCK NETWORKING MODEL
=========================
For every peer:

    peer.in_flight_blocks <= 48

When one block completes:

    in_flight -= 1
    immediately request another block when appropriate

Do NOT implement:

    request 48
    wait for all 48
    validate all 48
    commit all 48

Instead:

    request up to 48
          |
          +--> block A completes --> verify --> queue/state
          |
          +--> block B completes --> verify --> queue/state
          |
          +--> block C completes --> verify --> queue/state
          |
          +--> replenish freed request slot

The 48 limit provides network backpressure and bounded per-peer outstanding work.

It must be possible to change 48 to 32, 64, or another transport value without changing consensus acceptance.

GLOBAL BACKPRESSURE
===================
Per-peer limits are not sufficient for Android memory safety.

Use a separate global prospective/in-flight bound, for example:

    MAX_PROSPECTIVE_BLOCKS = 192

This value is an implementation resource limit, not consensus.

When global capacity is full:
- stop issuing additional block requests where necessary;
- allow completed work to drain;
- resume requests as capacity becomes available.

Do not reject a consensus-valid block merely because a temporary memory/backpressure queue is full.

BLOCK LIFECYCLE
===============
Every downloaded block follows:

    RECEIVED
       |
       v
    SEMANTICALLY VERIFIED
       |
       v
    QUEUED / PROSPECTIVE
       |
       v
    PARENT STATE AVAILABLE?
       |
      no ----------------> WAIT
       |
      yes
       |
       v
    CONTEXTUAL CONSENSUS VALIDATION
       |
       v
    CHAIN SELECTION / REORG LOGIC
       |
       v
    ORDERED STATE TRANSITION
       |
       v
    DURABLE ROCKSDB COMMIT
       |
       v
    CANONICAL

A block must never skip a required stage because it arrived in the same 48-block request window as another block.

FORK HANDLING
=============
ProspectiveBlockSet should maintain structures equivalent to:

    blocks_by_hash
    children_by_parent
    hashes_by_height

Example:

             P
            / \
           A   X
           |   |
           B   Y

A, X, B, and Y can all exist as candidates until consensus/state logic determines the applicable chain.

Do not assume:

    one height = one block

Do not assume:

    one peer's response = canonical chain

Do not assume:

    first received = best chain

Do not assume:

    highest received height = canonical height

HEADER SYNCHRONIZATION
======================
Keep header synchronization separate from full block processing.

Validated headers may establish candidate ancestry and download targets.

Headers must not make a block consensus-valid.

The downloader may use known header ancestry to decide what to request, but StateService remains authoritative for block/state validity.

CONSENSUS-SAFETY: MUST NOT
==========================
The replacement MUST NOT:

1. Change any Ycash consensus rule.
2. Change block validity rules.
3. Change transaction validity rules.
4. Change proof verification requirements.
5. Change signature verification requirements.
6. Change UTXO/spend rules.
7. Change nullifier rules.
8. Change value-pool accounting.
9. Change coinbase rules.
10. Change difficulty or proof-of-work rules.
11. Change timestamp rules.
12. Change block-size/format consensus rules.
13. Change network-upgrade activation heights.
14. Change consensus branch IDs.
15. Change upgrade-specific consensus rules.
16. Treat 48 blocks as one consensus object.
17. Treat 48 blocks as one consensus transaction.
18. Treat 48 blocks as one consensus state transition.
19. Treat 48 blocks as a checkpoint.
20. Treat 48 blocks as finality.
21. Accept blocks merely because they were downloaded.
22. Skip contextual validation because blocks arrived together.
23. Validate a child against the wrong parent state.
24. Let a peer decide the canonical chain.
25. Let peer preference override consensus.
26. Use height alone as block identity.
27. Drop competing forks simply because they arrived later.
28. Parallelize conflicting canonical state mutations.
29. Use RocksDB WriteBatch to redefine consensus semantics.
30. Weaken cryptographic checks to increase throughput.
31. Make one invalid block automatically invalidate or validate unrelated blocks.
32. Assume all blocks in one download window belong to one canonical chain.
33. Use checkpoints as a replacement for consensus validation.
34. Make activation/upgrade behavior depend on the 48-block scheduler.
35. Make consensus acceptance depend on queue size, worker count, or network timing.

NETWORKING VS CONSENSUS BOUNDARY
================================
The following are NON-CONSENSUS implementation parameters:

    MAX_BLOCKS_IN_TRANSIT_PER_PEER = 48
    MAX_PROSPECTIVE_BLOCKS
    verifier worker count
    request concurrency
    peer count
    queue capacity
    RocksDB batch write size
    retry delays
    network timeouts
    telemetry intervals

The following are CONSENSUS-CRITICAL and must remain in the existing Ycash consensus implementation:

    block validity
    transaction validity
    cryptographic verification
    contextual rules
    parent/state relationship
    network-upgrade rules
    activation heights
    chain selection rules
    state transition rules
    UTXO and shielded-pool accounting

The implementation must keep this boundary explicit in the code.

STATE COMMIT DESIGN
===================
Existing YORTAL functionality around:

    prepare_commit_batch()
    apply_prepared_commit()

may remain useful, but it must move behind StateService/BlockWriteWorker.

The network pipeline must NOT directly decide when a consensus state transition is valid merely because a range is complete.

Preferred model:

    StateService
       |
       | produces prepared state update
       v
    BlockWriteWorker
       |
       | RocksDB WriteBatch
       v
    durable state

A WriteBatch can contain all database writes needed for a prepared transition.

That is a database atomicity optimization.

It must never mean:

    "these 48 blocks are one consensus transition."

ORDERING RULE
=============
Semantic verification may be concurrent:

    worker 1 -> block A
    worker 2 -> block B
    worker 3 -> block C
    worker 4 -> block D

Canonical state mutation remains ordered by ancestry/state requirements:

    A -> state
       -> B -> state
       -> C -> state
       -> D -> state

Where forks exist, the state/chain-selection implementation decides which branch can advance canonically.

The single-writer rule prevents concurrent database mutations from creating divergent canonical state.

UPGRADE SAFETY
==============
Consensus rules can change at defined network-upgrade heights.

The pipeline must therefore ask the consensus layer for the rules applicable to the block's actual position in the candidate chain.

It must never infer upgrade activation from:

    batch size
    request count
    peer count
    download completion
    queue position
    local database batch size

ZIP 200 explicitly specifies that consensus rules depending on a network upgrade must be gated by block height, and that incoming blocks with known heights are validated under the consensus rules corresponding to that height.

Therefore:

    height -> applicable consensus rules

not:

    pipeline batch -> applicable consensus rules

CURRENT YORTAL STATE CODE TO PRESERVE
======================================
Do not rewrite functioning consensus/state algorithms merely to change the pipeline.

Preserve and route through the new StateService:

- existing Ycash block validation
- transaction validation
- proof verification
- signature verification
- UTXO handling
- BIP30/existence checks where applicable
- Sprout state
- Sapling state
- Orchard/state components already implemented
- header validation
- chain-selection rules
- RocksDB persistence
- prepared state commit logic
- existing consensus tests and fixtures

The replacement concerns orchestration and synchronization architecture, not the definition of Ycash validity.

FILES / MODULES
===============
Target source organization:

crates/state/src/
    state_service.rs
    prospective.rs
    contextual.rs
    commit.rs
    db.rs

crates/node/src/
    sync.rs
    downloader.rs
    peer_manager.rs
    verifier.rs

crates/ycash-android-node/src/
    sync_coordinator.rs

Remove the old pipeline module and update all imports/references.

Do not leave dead code that can accidentally re-enable the old range scheduler.

CONFIGURATION
=============
Replace the old adaptive range configuration with explicit transport/backpressure settings.

Conceptually:

    max_blocks_in_transit_per_peer = 48
    max_prospective_blocks = 192
    verifier_workers = implementation-controlled

Do not retain old settings such as max_range_len as hidden controls.

TESTING REQUIREMENTS
====================
Add tests for the new architecture.

1. Transport limit:
   Assert every peer satisfies:

       in_flight <= 48

2. Replenishment:
   Completing one request permits another request without waiting for the other 47.

3. Deduplication:
   The same block hash cannot be simultaneously processed twice.

4. Parent ordering:
   A child waits when required parent state is unavailable.

5. Out-of-order arrival:
   Child arriving before parent is retained and later reconsidered.

6. Fork handling:
   Competing blocks at the same height remain distinguishable.

7. Semantic/contextual separation:
   Semantic verification can complete before contextual validation.

8. Canonical writer:
   Only BlockWriteWorker may perform canonical RocksDB mutation.

9. Consensus invariance:
   Changing the networking limit from 48 to another value must not change consensus validation results.

10. Upgrade-height correctness:
    Blocks around every supported network-upgrade activation boundary are validated using the correct height-dependent rules.

11. Invalid block isolation:
    An invalid candidate does not cause unrelated valid candidates to be silently accepted or rejected.

12. Restart:
    Restarting with queued/persisted state does not bypass consensus validation.

13. Genesis:
    Fresh synchronization can begin from genesis when configured to do so.

14. Full-chain audit:
    A complete synchronized chain can be revalidated independently from the network pipeline.

DIAGNOSTICS
===========
Expose separate heights/counters:

    download_height
    highest_header_height
    highest_semantically_verified_height
    highest_contextually_verified_height
    canonical_height

Also expose:

    peers
    blocks_in_flight_total
    blocks_in_flight_by_peer
    prospective_blocks
    semantic_verification_queue
    contextual_queue
    committed_blocks
    verifier_workers
    database_write_time
    write_batch_size
    reorg_count
    invalid_blocks
    duplicate_blocks
    stalled_parent_waits

This makes it possible to distinguish:

    network stall
    verification stall
    missing parent
    contextual-validation stall
    database stall
    canonical-state stall

from the Android UI/logs.

CI ACCEPTANCE CRITERIA
======================
CI must verify:

- no AdaptiveController references
- no RangeScheduler references
- no ValidatedRange references
- no plan_parallel_ranges references
- no max_range_len pipeline dependency
- no max_inflight_ranges pipeline dependency
- no range-based canonical commit barrier
- exactly one canonical state writer
- per-peer in-flight limit is 48
- global prospective queue is bounded
- semantic verification remains available concurrently
- contextual validation remains state-aware
- RocksDB remains the durable state backend
- ARM64 APK/AAR packaging remains intact
- existing consensus tests continue to pass
- full-chain validation test is available
- no legacy pipeline implementation remains reachable

REQUIRED INVARIANTS
===================
The finished implementation must enforce:

    peer.in_flight <= 48

    same block hash is not processed twice simultaneously

    contextual validation waits for required parent state

    canonical state transitions occur in the required order

    one authoritative writer owns canonical RocksDB mutation

    forks remain distinguishable until chain selection

    semantic verification can run concurrently

    queue/backpressure is bounded

    failed downloads do not permanently poison a block hash

    network batch size does not affect consensus validity

    network timing does not affect consensus validity

    worker count does not affect consensus validity

    RocksDB batching does not redefine consensus validity

    network-upgrade activation remains height-driven

FINAL ACCEPTANCE TEST
=====================
The strongest test is to run the same chain through the consensus/state layer using different transport configurations:

    16 blocks/peer
    48 blocks/peer
    64 blocks/peer

The resulting consensus decisions must be identical.

Only synchronization performance, queue depth, memory use, and network utilization should change.

The final architecture should therefore behave conceptually as:

    NETWORK
      |
      | 48 outstanding per peer
      v
    DOWNLOAD
      |
      v
    PARALLEL SEMANTIC VERIFY
      |
      v
    PROSPECTIVE BLOCK TREE
      |
      v
    CONSENSUS / STATE SERVICE
      |
      | ordered state transitions
      v
    SINGLE CANONICAL WRITER
      |
      v
    ROCKSDB

The 48-block value stops at the networking/backpressure boundary.

Ycash consensus remains authoritative for everything after that boundary.

REFERENCE SOURCES
=================
Zcash ZIP repository:
https://zips.z.cash/

Zcash Protocol Specification:
https://zips.z.cash/protocol/protocol.pdf

ZIP 200 — Network Upgrade Mechanism:
https://zips.z.cash/zip-0200

ZIP 204 — Zcash P2P Network Protocol:
https://zips.z.cash/zip-0204

The Zcash ZIP repository identifies the protocol specification as the protocol reference and distinguishes consensus specifications from network specifications. ZIP 200 defines consensus rule sets and height-gated network upgrades. The protocol specification describes candidate blocks as a tree rooted at genesis and selection of the best valid chain by total work.
