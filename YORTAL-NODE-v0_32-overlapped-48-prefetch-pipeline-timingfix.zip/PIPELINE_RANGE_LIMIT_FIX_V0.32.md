# YORTAL v0.32 — 48-block in-flight range hard-limit fix

## Problem
The scheduler advertised a 192-block lookahead (4 × 48-block ranges) but `plan_windows()` only bounded total prospective block height. Repeated planner calls could therefore create more range leases than the configured four-slot transport window. The Android diagnostics could show `ranges 5/4`.

## Fix
The state pipeline now enforces the range-slot invariant at three points:

1. **Planning:** `plan_windows()` refuses to create a new range when the number of pending + leased ranges reaches the configured maximum.
2. **Claiming:** both `claim()` and `claim_upto()` refuse to lease another range when the number of leased ranges is already at the configured maximum. These are defensive checks against scheduler/peer races.
3. **Telemetry:** the live `max_inflight_windows()` value reports the actual leased range count, including zero, while `configured_max_inflight_windows()` remains the four-range ceiling.

The ceiling is derived from the same constants used for transport:

- range size: **48 blocks**
- prospective lookahead: **192 blocks**
- maximum active ranges: **4**
- maximum one range per peer
- ordered canonical commit remains unchanged

## Consensus safety
This changes only network scheduling/backpressure. It does not change block validity rules, transaction validation, state-transition rules, header validation, or commit ordering. A range is still verified before it can enter the ordered commit buffer, and the canonical committer still requires contiguous height order.

## Regression coverage
Added state-pipeline tests cover:

- four active ranges are allowed and a fifth is rejected;
- completing one range allows exactly one replacement range;
- requeuing a stalled range does not create an extra active slot.

The existing `verify-adaptive-pipeline.sh` now also checks the hard-cap implementation and rejects stale 100-block/adaptive-range source text.

## Build verification
The supplied container does not include the Rust toolchain (`cargo`/`rustc`), so a local compile/test run could not be executed here. The source and regression tests were patched into the project and should be run by the project's GitHub Actions Rust test/build job.
