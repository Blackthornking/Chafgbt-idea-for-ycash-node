# YORTAL Zebra-style 48-block transport replacement

Applied to the v0.32 RocksDB project.

- Removed the Rust adaptive scheduler and range scheduler modules from the active build.
- Added a fixed `MAX_BLOCKS_IN_TRANSIT_PER_PEER = 48` transport window and bounded prospective capacity of 192 blocks.
- Removed adaptive pipeline configuration from `config/pipeline.toml` and Android pipeline overrides.
- Kept consensus/state validation in `State`, with the existing prepared-commit path and one permanent canonical writer.
- Kept RocksDB as the durable state backend; database WriteBatch/commit remains a storage atomicity mechanism, not a consensus batch.
- Replaced the old pipeline verification script with fixed 48-block invariants.
- Added `YORTAL_ZEBRA_48_BLOCK_REPLACEMENT_PLAN.md` as the implementation specification.

Important validation limitation: this environment does not contain Cargo/Android SDK, so a full Rust/Gradle build could not be executed here. The source-level replacement and stale active-module/config checks were performed; the first CI run should be treated as the authoritative compile check.
