#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
p="$root/crates/ycash-android-node/src/pipeline_sync.rs"
s="$root/crates/state/src/lib.rs"
c="$root/crates/state/src/chainstate.rs"

grep -q 'MAX_BLOCKS_IN_TRANSIT_PER_PEER' "$p"
grep -q 'MAX_PROSPECTIVE_BLOCKS' "$p"
grep -q 'STAGE_OVERLAP' "$p"
grep -q 'reserve_batch_txids' "$s"
grep -q 'coins.prefetch(&read_tx, &prefetch_ops)' "$s"
grep -q 'fn prepare_commit_batch' "$s"
grep -q 'fn apply_prepared_commit' "$s"
# The old commit-time one-verifier throttle must not remain.
if grep -q 'active_workers.store(1.min(verify_threads())' "$p"; then
  echo 'FAIL: one-verifier commit throttle remains'
  exit 1
fi
if grep -q 'update_commit_cpu_budget(1)' "$p"; then
  echo 'FAIL: fixed one-worker commit CPU budget remains'
  exit 1
fi
printf '%s\n' 'PASS: overlapped pipeline invariants present; no fixed one-verifier commit throttle.'
