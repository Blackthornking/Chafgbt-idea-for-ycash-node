# YORTAL v0.32 — overlapped 48-block pipeline

This revision keeps Ycash consensus ordering intact while overlapping the expensive independent stages.

## Pipeline

1. P2P downloads fixed 48-block ranges.
2. Up to four ranges (192 blocks) remain in flight/lookahead.
3. Semantic verification continues on the adaptive verifier pool while contextual state preparation is running.
4. `State::prepare_commit_batch()` uses a single consistent RocksDB read view and an in-memory `CoinsView` working state for the complete ordered batch.
5. A batch-wide UTXO prefetch is performed before the ordered transaction/state loop. Inputs whose producing transaction is inside the current batch are excluded from negative caching so intra-batch spends remain resolved from the working state.
6. Stateful consensus checks still advance strictly block-by-block and transaction-by-transaction through the working state.
7. `State::apply_prepared_commit()` remains the only canonical publication path and writes the prepared mutations as one RocksDB write transaction/batch.
8. After publication, the adaptive semantic worker count is restored immediately; there is no one-verifier commit throttle.

## Consensus invariants

- No block can publish before its predecessor.
- Network workers never choose canonical state.
- Semantic verification may run ahead, but cannot advance the canonical tip.
- Contextual checks use the ordered working state.
- A failed contextual batch is not partially published.
- `apply_prepared_commit()` rechecks the canonical tip before publication.
- Stale/hedged lease generations cannot publish obsolete verification results.
- The 48-block transport size is not treated as a consensus rule.

## Performance intent

The database and state work is front-loaded where it is safe: canonical UTXO reads are prefetched into the working view, parsing/signature/proof work is already performed by the semantic stage, and later semantic ranges continue while the canonical range is being prepared. The final database publication is therefore limited to applying already-prepared mutations.

The design deliberately does **not** contextually validate independent canonical blocks against the same stale state, and it does not publish later blocks before earlier blocks. Those shortcuts would risk incorrect UTXO, nullifier, tree, or parent-state results.
