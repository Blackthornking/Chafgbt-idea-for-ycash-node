#!/usr/bin/env bash
# Copies the cross-compiled ycash-android-node Rust binary into app/src/main/jniLibs/
# so Android installs it as a native library instead of a plain asset.
#
# Executing a file an app copied into its own getFilesDir() (the old approach) is blocked
# by Android's W^X policy on API 29+ -- the process fails to start with a permission/exec
# error, which is swallowed by NodeService and shows up in the UI as "stuck on STARTING".
# Files under jniLibs/<abi>/ are installed by PackageManager to a location apps are still
# permitted to execute from, so this is the fix, not a workaround.
set -euo pipefail

: "${BINARY:?Set BINARY to the path of the built aarch64-linux-android ycash-android-node binary}"
: "${ABI:=arm64-v8a}"

if [[ ! -f "$BINARY" ]]; then
  echo "BINARY does not exist: $BINARY" >&2
  exit 2
fi
if ! file "$BINARY" | grep -Eq 'ELF 64-bit.*ARM aarch64'; then
  echo "BINARY is not an aarch64 ELF executable:" >&2
  file "$BINARY" >&2
  exit 3
fi

DEST_DIR="$(dirname "$0")/../android-app/app/src/main/jniLibs/${ABI}"
mkdir -p "$DEST_DIR"
cp "$BINARY" "$DEST_DIR/libycashandroidnode.so"
chmod 755 "$DEST_DIR/libycashandroidnode.so"
echo "Installed to $DEST_DIR/libycashandroidnode.so"
file "$DEST_DIR/libycashandroidnode.so"
