#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BIN="$ROOT/android-app/app/src/main/jniLibs/arm64-v8a/libycashandroidnode.so"
if [[ ! -f "$BIN" ]]; then
  echo "FAIL: missing $BIN" >&2
  echo "Build the Rust node first: cargo build --release -p ycash-android-node --target aarch64-linux-android" >&2
  exit 2
fi
if ! file "$BIN" | grep -Eq 'ELF 64-bit.*ARM aarch64'; then
  echo "FAIL: $BIN is not an aarch64 ELF executable" >&2
  file "$BIN" >&2
  exit 3
fi
chmod 755 "$BIN"
# The Android launcher must never prefer a writable private-data copy on API 29+.
if grep -q 'getFilesDir(), LEGACY_ASSET_NAME' "$ROOT/android-app/app/src/main/java/com/ycash/androidnode/NodeService.java" && \
   ! grep -q 'Build.VERSION.SDK_INT >= 29' "$ROOT/android-app/app/src/main/java/com/ycash/androidnode/NodeService.java"; then
  echo "FAIL: unsafe legacy executable fallback detected" >&2
  exit 4
fi
echo "PASS: packaged aarch64 node binary is present and NodeService uses nativeLibraryDir on modern Android"
