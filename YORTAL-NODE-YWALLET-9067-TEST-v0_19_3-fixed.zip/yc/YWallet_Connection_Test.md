# YWallet / lightwalletd connection test — v0.19.2

The YWallet/lightwalletd tester keeps the Ycash endpoint unchanged and adds staged diagnostics.

It reports separately:
1. DNS resolution and resolved address count
2. TCP connection and remote socket
3. TLS version and cipher suite when TLS is enabled
4. ALPN `h2` negotiation when Android exposes it
5. HTTP/2 SETTINGS receipt
6. The exact `CompactTxStreamer/GetLatestBlock` request being sent
7. HTTP/2 frame types/flags/stream IDs/lengths received
8. RST_STREAM / GOAWAY error codes when supplied by the server
9. gRPC response byte count
10. Basic `BlockID` protobuf decode result
11. Total latency

The previous hand-built HTTP/2 probe had an HPACK `content-type` encoding error. v0.19.2 fixes that encoding and sends `:authority` with the port.

The endpoint remains manually editable and is saved across launches.

Recommended Ycash endpoint:
- `lite.ycash.xyz:9067` with TLS enabled

Other useful tests:
- `lite.ycash.xyz:9067` with TLS disabled
- `lightwalletd.ycash.xyz:443` with TLS enabled
- `127.0.0.1:9067` only if a local CompactTxStreamer-compatible lightwalletd service is actually listening there

This is a client-side diagnostic. It does not turn the Android node into a lightwalletd server.


## v0.19.2 node-side diagnostics

The Android app now has a **Test Local Node Ports** check. It reports:
- whether `libycashandroidnode.so` is present in Android's `nativeLibraryDir` and executable
- TCP listening status for P2P `8833`
- TCP listening status for JSON-RPC `8832`
- TCP listening status for the local status API `8834`
- an actual `GET /status` HTTP response on `8834`

The Start Node action performs the executable preflight before launching the service. On Android 10+ it will not fall back to executing a copied asset from `getFilesDir()`.

This deliberately keeps **9067 separate**: `9067` is the YWallet/Lightwalletd gRPC endpoint, while `8833` is Ycash P2P. A successful TLS handshake to `lite.ycash.xyz:9067` therefore does not imply that the local P2P node is configured for TLS.
