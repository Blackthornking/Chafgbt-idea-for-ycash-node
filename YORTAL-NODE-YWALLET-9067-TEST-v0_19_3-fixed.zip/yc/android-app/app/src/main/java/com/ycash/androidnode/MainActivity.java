package com.ycash.androidnode;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.StatFs;
import android.content.Intent;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.view.View;
import android.widget.*;
import java.net.*;
import javax.net.ssl.*;
import java.util.LinkedHashSet;
import java.io.*;
import org.json.JSONObject;
import android.content.SharedPreferences;
// RandomAccessFile is covered by java.io.* above

public class MainActivity extends Activity {
    TextView status, peer, height, sync, log, headersHeight, connectionSource, connectionEndpoint, connectionDetail,
        targetHeight, blocksBehind, syncSpeed, lastBlock, uptime, dbSize, freeStorage, networkType;
    View advancedSection;
    Button toggleAdvanced;
    Handler handler = new Handler();
    boolean running = false;
    boolean advancedShown = false;
    EditText walletEndpoint;
    CheckBox walletTls;
    TextView walletTestResult;
    TextView nodeDiagnostics;
    SharedPreferences prefs;
    int consecutiveFailures = 0;
    // 2s poll interval * 5 = ~10s of nothing listening on 8834 before we tell the user, instead of
    // sitting on "STARTING" forever.
    static final int FAILURE_THRESHOLD = 5;
    // For a client-side sync-speed estimate: last height/time we saw, so we can diff across polls
    // instead of asking the node to track a rate itself.
    long lastSpeedHeight = -1;
    long lastSpeedAtMillis = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status=findViewById(R.id.status);
        peer=findViewById(R.id.peer);
        height=findViewById(R.id.height);
        sync=findViewById(R.id.sync);
        log=findViewById(R.id.log);
        headersHeight=findViewById(R.id.headersHeight);
        connectionSource=findViewById(R.id.connectionSource);
        connectionEndpoint=findViewById(R.id.connectionEndpoint);
        connectionDetail=findViewById(R.id.connectionDetail);
        targetHeight=findViewById(R.id.targetHeight);
        blocksBehind=findViewById(R.id.blocksBehind);
        syncSpeed=findViewById(R.id.syncSpeed);
        lastBlock=findViewById(R.id.lastBlock);
        uptime=findViewById(R.id.uptime);
        dbSize=findViewById(R.id.dbSize);
        freeStorage=findViewById(R.id.freeStorage);
        networkType=findViewById(R.id.networkType);
        advancedSection=findViewById(R.id.advancedSection);
        toggleAdvanced=findViewById(R.id.toggleAdvanced);
        walletEndpoint=findViewById(R.id.walletEndpoint);
        walletTls=findViewById(R.id.walletTls);
        walletTestResult=findViewById(R.id.walletTestResult);
        nodeDiagnostics=findViewById(R.id.nodeDiagnostics);
        prefs=getSharedPreferences("ycash_node",MODE_PRIVATE);
        walletEndpoint.setText(prefs.getString("wallet_endpoint","lite.ycash.xyz:9067"));
        walletTls.setChecked(prefs.getBoolean("wallet_tls",true));
        findViewById(R.id.testWallet).setOnClickListener(v -> testWalletEndpoint());
        findViewById(R.id.testNodePorts).setOnClickListener(v -> testLocalNodePorts());

        toggleAdvanced.setOnClickListener(v -> {
            advancedShown=!advancedShown;
            advancedSection.setVisibility(advancedShown ? View.VISIBLE : View.GONE);
            toggleAdvanced.setText(advancedShown ? "Advanced ▾" : "Advanced ▸");
            if (advancedShown) refreshDeviceStats();
        });

        findViewById(R.id.start).setOnClickListener(v -> {
            File nativeNode = new File(getApplicationInfo().nativeLibraryDir, NodeService.NATIVE_LIB_NAME);
            if (!nativeNode.exists()) {
                status.setText("● NODE BINARY MISSING");
                log.setText("Log: " + NodeService.NATIVE_LIB_NAME + " is not packaged in nativeLibraryDir. Rebuild the APK with the Rust node binary under app/src/main/jniLibs/arm64-v8a/.");
                nodeDiagnostics.setText("Node executable: FAIL — packaged native binary not found");
                return;
            }
            if (!nativeNode.canExecute()) {
                status.setText("● NODE BINARY NOT EXECUTABLE");
                log.setText("Log: native node exists but Android reports it is not executable: " + nativeNode.getAbsolutePath());
                nodeDiagnostics.setText("Node executable: FAIL — " + nativeNode.getAbsolutePath());
                return;
            }
            nodeDiagnostics.setText("Node executable: PASS — " + nativeNode.getAbsolutePath());
            Intent i = new Intent(this, NodeService.class); i.setAction(NodeService.START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            running=true; consecutiveFailures=0; lastSpeedHeight=-1; status.setText("● STARTING"); log.setText("Log: starting Ycash node process"); pollStatus();
        });

        findViewById(R.id.stop).setOnClickListener(v -> {
            Intent i = new Intent(this, NodeService.class); i.setAction(NodeService.STOP); startService(i);
            running=false; status.setText("● STOPPED"); sync.setText("Sync: stopped");
            connectionSource.setText("Connection source: None");
            connectionEndpoint.setText("Endpoint: —");
            connectionDetail.setText("Details: Node stopped");
            blocksBehind.setText("Blocks behind: —");
            syncSpeed.setText("Sync speed: —");
            lastBlock.setText("Last block: —");
            uptime.setText("Node uptime: —");
            log.setText("Log: node stop requested");
        });

        findViewById(R.id.test).setOnClickListener(v -> testNetwork());
    }

    private void pollStatus() {
        if (!running) return;
        new Thread(() -> {
            try {
                URL u=new URL("http://127.0.0.1:8834/status");
                HttpURLConnection c=(HttpURLConnection)u.openConnection();
                c.setConnectTimeout(1500);
                c.setReadTimeout(1500);
                c.setRequestMethod("GET");
                if(c.getResponseCode()==200) {
                    BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));
                    StringBuilder s=new StringBuilder(); String line;
                    while((line=br.readLine())!=null) s.append(line);
                    JSONObject j=new JSONObject(s.toString());
                    runOnUiThread(() -> applyStatus(j));
                }
                c.disconnect();
            } catch(Exception e) {
                consecutiveFailures++;
                if (consecutiveFailures == FAILURE_THRESHOLD) {
                    String tail = readLogTail();
                    runOnUiThread(() -> {
                        status.setText("● NODE NOT RESPONDING");
                        log.setText("Log: no response from the node on :8834 after "+
                            (FAILURE_THRESHOLD*2)+"s. Last error: "+e.getClass().getSimpleName()+
                            (tail.isEmpty() ? "" : "\n\nnode.log tail:\n"+tail));
                    });
                }
                // Below the threshold, keep showing the last real values -- a couple of missed polls
                // during startup is normal and not worth alarming the user over.
            }
            handler.postDelayed(this::pollStatus, 2000);
        }).start();
    }

    /** Reads the last ~2KB of node.log so a "not responding" status is actually actionable. */
    private String readLogTail() {
        File f = new File(getFilesDir(), "node.log");
        if (!f.exists()) return "";
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            long len = raf.length();
            long start = Math.max(0, len - 2048);
            raf.seek(start);
            byte[] buf = new byte[(int)(len - start)];
            raf.readFully(buf);
            return new String(buf);
        } catch (Exception e) {
            return "";
        }
    }

    private void applyStatus(JSONObject j) {
        try {
            consecutiveFailures = 0;
            status.setText("● "+j.optString("status","UNKNOWN").toUpperCase());
            peer.setText("Peers: "+j.optInt("peers",0));
            long blockHeight=j.optLong("height",-1);
            long headerHeight=j.optLong("headers_height",-1);
            long peerTargetHeight=j.optLong("target_height",-1);
            height.setText("Block height: "+(blockHeight < 0 ? "—" : blockHeight));
            headersHeight.setText("Headers height: "+(headerHeight < 0 ? "—" : headerHeight));
            targetHeight.setText("Target height: "+(peerTargetHeight < 0 ? "—" : peerTargetHeight));
            sync.setText("Sync: "+j.optString("sync","unknown"));
            blocksBehind.setText("Blocks behind: "+
                (blockHeight < 0 || peerTargetHeight < 0 ? "—" : Math.max(0, peerTargetHeight-blockHeight)));

            // Sync speed: diffed client-side across polls. The node doesn't track a rate itself,
            // so this is only as smooth as the 2s poll interval -- fine for a rough reading.
            long now=System.currentTimeMillis();
            if (blockHeight >= 0) {
                if (lastSpeedHeight >= 0 && now > lastSpeedAtMillis) {
                    double blocksPerSec=(blockHeight-lastSpeedHeight)*1000.0/(now-lastSpeedAtMillis);
                    syncSpeed.setText(blocksPerSec <= 0 ? "Sync speed: —" :
                        String.format(java.util.Locale.US, "Sync speed: %.1f blocks/s", blocksPerSec));
                }
                lastSpeedHeight=blockHeight; lastSpeedAtMillis=now;
            }

            long tipTime=j.optLong("tip_time",0);
            if (tipTime > 0) {
                long agoSec=Math.max(0, System.currentTimeMillis()/1000 - tipTime);
                lastBlock.setText("Last block: "+formatDuration(agoSec)+" ago");
            } else {
                lastBlock.setText("Last block: —");
            }

            long uptimeSec=j.optLong("uptime_seconds",-1);
            uptime.setText("Node uptime: "+(uptimeSec < 0 ? "—" : formatDuration(uptimeSec)));

            connectionSource.setText("Connection source: "+j.optString("connection_source","None"));
            connectionEndpoint.setText("Endpoint: "+j.optString("connection_endpoint","—"));
            connectionDetail.setText("Details: "+j.optString("connection_detail","—"));
            log.setText("Log: "+j.optString("message","status updated"));
            if (advancedShown) refreshDeviceStats();
        } catch(Exception ignored) {}
    }

    private static String formatDuration(long totalSeconds) {
        long h=totalSeconds/3600, m=(totalSeconds%3600)/60, s=totalSeconds%60;
        if (h > 0) return h+"h "+m+"m";
        if (m > 0) return m+"m "+s+"s";
        return s+"s";
    }

    /**
     * Real device/OS numbers, not node output -- the node process has no reliable, portable way to
     * report its own CPU/RAM from inside another app's process on modern Android, so rather than ship
     * a reading that silently goes wrong on some devices, this sticks to what Android itself can answer
     * accurately: the node's actual database file size, free space on the device, and network type.
     */
    private void refreshDeviceStats() {
        try {
            File db=new File(getFilesDir(),"ycash-node.sqlite");
            dbSize.setText("Node database size: "+(db.exists() ? formatBytes(db.length()) : "—"));
        } catch (Exception e) { dbSize.setText("Node database size: —"); }
        try {
            StatFs stat=new StatFs(getFilesDir().getAbsolutePath());
            freeStorage.setText("Free device storage: "+formatBytes(stat.getAvailableBytes()));
        } catch (Exception e) { freeStorage.setText("Free device storage: —"); }
        try {
            ConnectivityManager cm=(ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities caps = cm==null ? null : cm.getNetworkCapabilities(cm.getActiveNetwork());
            String kind = caps==null ? "none"
                : caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi"
                : caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "mobile"
                : "other";
            networkType.setText("Device network: "+kind);
        } catch (Exception e) { networkType.setText("Device network: —"); }
    }

    private static String formatBytes(long bytes) {
        if (bytes < 1024*1024) return String.format(java.util.Locale.US, "%.0f KB", bytes/1024.0);
        if (bytes < 1024*1024*1024) return String.format(java.util.Locale.US, "%.1f MB", bytes/(1024.0*1024));
        return String.format(java.util.Locale.US, "%.2f GB", bytes/(1024.0*1024*1024));
    }

    /**
     * YWallet/lightwalletd diagnostic probe.
     *
     * Keep the actual wire test small and deterministic, but expose enough
     * information to distinguish DNS, TCP, TLS/ALPN, HTTP/2 and gRPC failures.
     */
    private void testWalletEndpoint() {
        String raw=walletEndpoint.getText().toString().trim();
        boolean tls=walletTls.isChecked();
        prefs.edit().putString("wallet_endpoint",raw).putBoolean("wallet_tls",tls).apply();
        if(raw.isEmpty()) { walletTestResult.setText("YWallet test: enter host:port"); return; }

        String host; int port;
        try {
            String n=raw;
            if(n.startsWith("http://")) n=n.substring(7);
            if(n.startsWith("https://")) n=n.substring(8);
            int slash=n.indexOf('/'); if(slash>=0) n=n.substring(0,slash);
            if(n.startsWith("[")) {
                int close=n.indexOf(']');
                if(close<1) throw new IllegalArgumentException();
                host=n.substring(1,close);
                port=(close+1<n.length() && n.charAt(close+1)==':')
                    ? Integer.parseInt(n.substring(close+2)) : (tls?443:9067);
            } else {
                int colon=n.lastIndexOf(':');
                if(colon>0 && n.indexOf(':')==colon) {
                    host=n.substring(0,colon); port=Integer.parseInt(n.substring(colon+1));
                } else { host=n; port=tls?443:9067; }
            }
            if(host.isEmpty() || port<1 || port>65535) throw new IllegalArgumentException();
        } catch(Exception e) {
            walletTestResult.setText("YWallet test: invalid host:port");
            return;
        }

        final String h=host; final int p=port;
        walletTestResult.setText("YWallet test: testing "+h+":"+p+(tls?" (TLS)":" (plain)")+"…");
        new Thread(() -> {
            long started=System.currentTimeMillis();
            StringBuilder d=new StringBuilder();
            Socket socket=null;
            try {
                // Stage 1: DNS, explicitly shown instead of being hidden in Socket.connect().
                InetAddress[] addrs=InetAddress.getAllByName(h);
                if(addrs.length==0) throw new IOException("DNS returned no addresses");
                d.append("DNS PASS: ").append(addrs[0].getHostAddress());
                if(addrs.length>1) d.append(" (+").append(addrs.length-1).append(")");

                // Stage 2: TCP.
                Socket tcp=new Socket();
                tcp.setSoTimeout(8000);
                tcp.connect(new InetSocketAddress(h,p),6000);
                d.append("\nTCP PASS: ").append(tcp.getRemoteSocketAddress());

                boolean alpn=false;
                String tlsVersion="", cipher="";
                if(tls) {
                    // Wrap the already-connected socket so hostname verification/SNI are tied to h.
                    SSLSocketFactory sf=(SSLSocketFactory)SSLSocketFactory.getDefault();
                    SSLSocket ss=(SSLSocket)sf.createSocket(tcp,h,p,true);
                    if(Build.VERSION.SDK_INT>=29) {
                        try {
                            SSLParameters sp=ss.getSSLParameters();
                            sp.setApplicationProtocols(new String[]{"h2"});
                            ss.setSSLParameters(sp);
                        } catch(Throwable ignored) {}
                    }
                    ss.startHandshake();
                    tlsVersion=ss.getSession().getProtocol();
                    cipher=ss.getSession().getCipherSuite();
                    if(Build.VERSION.SDK_INT>=29) {
                        try { alpn="h2".equals(ss.getApplicationProtocol()); } catch(Throwable ignored) {}
                    }
                    d.append("\nTLS PASS: ").append(tlsVersion).append(" / ").append(cipher);
                    d.append("\nALPN: ").append(alpn?"h2 PASS":"h2 NOT NEGOTIATED");
                    socket=ss;
                } else {
                    socket=tcp;
                    d.append("\nTLS: not requested");
                }

                InputStream in=socket.getInputStream();
                OutputStream out=socket.getOutputStream();

                // HTTP/2 connection preface + client SETTINGS.
                out.write(new byte[]{'P','R','I',' ','*',' ','H','T','T','P','/','2','\r','\n','\r','\n','S','M','\r','\n','\r','\n'});
                out.write(new byte[]{0,0,0,4,0,0,0,0,0});
                out.flush();

                H2Frame sf=readH2Frame(in);
                if(sf==null) throw new IOException("HTTP/2: server closed connection before SETTINGS");
                if(sf.type!=4) {
                    d.append("\nHTTP/2 FAIL: first frame type ").append(sf.type);
                    finishWalletDiagnostic(h,p,tls,alpn,false,false,d.toString(),started);
                    return;
                }
                d.append("\nHTTP/2 SETTINGS PASS ("+sf.len+" bytes)");
                if((sf.flags&1)==0) {
                    out.write(new byte[]{0,0,0,4,1,0,0,0,0});
                    out.flush();
                }

                // Real unary lightwalletd RPC.
                byte[] headers=hpackRequestHeaders(h,p,tls);
                writeH2Frame(out,1,0x4,1,headers); // HEADERS | END_HEADERS
                byte[] grpcEmpty=new byte[]{0,0,0,0,0};
                writeH2Frame(out,0,0x1,1,grpcEmpty); // DATA | END_STREAM
                out.flush();
                d.append("\ngRPC request sent: CompactTxStreamer/GetLatestBlock");

                boolean gotHeaders=false, gotData=false, gotTrailers=false, latest=false;
                byte[] responseData=new byte[0];
                int rstCode=-1, goAwayCode=-1;
                long deadline=System.currentTimeMillis()+8000;
                while(System.currentTimeMillis()<deadline) {
                    H2Frame f=readH2Frame(in);
                    if(f==null) { d.append("\nServer closed connection (EOF)"); break; }
                    d.append("\nHTTP/2 frame: type=").append(f.type)
                      .append(" flags=0x").append(Integer.toHexString(f.flags))
                      .append(" stream=").append(f.stream).append(" len=").append(f.len);
                    if(f.type==4) {
                        if((f.flags&1)==0) {
                            out.write(new byte[]{0,0,0,4,1,0,0,0,0}); out.flush();
                        }
                    } else if(f.type==1) {
                        if(f.stream==1) gotHeaders=true;
                    } else if(f.type==0 && f.stream==1) {
                        gotData=true;
                        if(f.payload.length>=5) {
                            int off=0;
                            while(off+5<=f.payload.length) {
                                int len=((f.payload[off+1]&255)<<24)|((f.payload[off+2]&255)<<16)|
                                    ((f.payload[off+3]&255)<<8)|(f.payload[off+4]&255);
                                int total=5+len;
                                if(len<0 || off+total>f.payload.length) break;
                                byte[] msg=java.util.Arrays.copyOfRange(f.payload,off+5,off+total);
                                responseData=concat(responseData,msg);
                                off+=total;
                            }
                        }
                        if((f.flags&1)!=0) break;
                    } else if(f.type==3 && f.stream==1) {
                        rstCode=f.payload.length>=4 ? ((f.payload[0]&255)<<24)|((f.payload[1]&255)<<16)|
                            ((f.payload[2]&255)<<8)|(f.payload[3]&255) : -1;
                        d.append("\nRST_STREAM code=").append(h2ErrorName(rstCode));
                        break;
                    } else if(f.type==7) {
                        goAwayCode=f.payload.length>=8 ? ((f.payload[4]&255)<<24)|((f.payload[5]&255)<<16)|
                            ((f.payload[6]&255)<<8)|(f.payload[7]&255) : -1;
                        d.append("\nGOAWAY code=").append(h2ErrorName(goAwayCode));
                        break;
                    }
                    if(f.type==1 && (f.flags&1)!=0) gotTrailers=true;
                }
                if(responseData.length>0) latest=looksLikeBlockId(responseData);
                d.append("\ngRPC response bytes: ").append(responseData.length);
                d.append("\nBlockID decode: ").append(latest?"PASS":"not confirmed");
                if(rstCode>=0) d.append("\nRPC reset: ").append(h2ErrorName(rstCode));
                if(goAwayCode>=0) d.append("\nGOAWAY: ").append(h2ErrorName(goAwayCode));
                d.append("\nResult: ").append(latest?"YWallet RPC PASS":
                    gotData?"gRPC DATA received (RPC response not decoded)":
                    gotHeaders?"RPC headers received but no DATA":"transport connected but RPC response absent");
                d.append("\nLatency: ").append(System.currentTimeMillis()-started).append(" ms");
                final String msg=d.toString();
                runOnUiThread(() -> walletTestResult.setText(msg));
            } catch(Exception e) {
                d.append("\nFAIL: ").append(e.getClass().getSimpleName()).append(": ")
                  .append(e.getMessage()==null?"connection failed":e.getMessage());
                d.append("\nLatency: ").append(System.currentTimeMillis()-started).append(" ms");
                final String msg=d.toString();
                runOnUiThread(() -> walletTestResult.setText(msg));
            } finally {
                if(socket!=null) try { socket.close(); } catch(Exception ignored) {}
            }
        }).start();
    }

    private void finishWalletDiagnostic(String h,int p,boolean tls,boolean alpn,boolean h2,boolean rpc,String detail,long started) {
        runOnUiThread(() -> walletTestResult.setText(detail+"\nLatency: "+(System.currentTimeMillis()-started)+" ms"));
    }

    private static String h2ErrorName(int code) {
        switch(code) {
            case 0: return "NO_ERROR(0)";
            case 1: return "PROTOCOL_ERROR(1)";
            case 2: return "INTERNAL_ERROR(2)";
            case 3: return "FLOW_CONTROL_ERROR(3)";
            case 4: return "SETTINGS_TIMEOUT(4)";
            case 5: return "STREAM_CLOSED(5)";
            case 6: return "FRAME_SIZE_ERROR(6)";
            case 7: return "REFUSED_STREAM(7)";
            case 8: return "CANCEL(8)";
            case 9: return "COMPRESSION_ERROR(9)";
            case 10: return "CONNECT_ERROR(10)";
            case 11: return "ENHANCE_YOUR_CALM(11)";
            case 12: return "INADEQUATE_SECURITY(12)";
            case 13: return "HTTP_1_1_REQUIRED(13)";
            default: return "UNKNOWN("+code+")";
        }
    }

    private static class H2Frame {
        int len,type,flags,stream; byte[] payload;
    }

    private static H2Frame readH2Frame(InputStream in) throws IOException {
        byte[] h=new byte[9]; readFully(in,h);
        H2Frame f=new H2Frame();
        f.len=((h[0]&255)<<16)|((h[1]&255)<<8)|(h[2]&255);
        f.type=h[3]&255; f.flags=h[4]&255;
        f.stream=((h[5]&127)<<24)|((h[6]&255)<<16)|((h[7]&255)<<8)|(h[8]&255);
        f.payload=new byte[f.len]; if(f.len>0) readFully(in,f.payload);
        return f;
    }

    private static void readFully(InputStream in,byte[] b) throws IOException {
        int off=0; while(off<b.length) { int n=in.read(b,off,b.length-off); if(n<0) throw new EOFException(); off+=n; }
    }

    private static void writeH2Frame(OutputStream out,int type,int flags,int stream,byte[] p) throws IOException {
        int n=p.length;
        out.write(new byte[]{(byte)(n>>>16),(byte)(n>>>8),(byte)n,(byte)type,(byte)flags,
            (byte)(stream>>>24),(byte)(stream>>>16),(byte)(stream>>>8),(byte)stream});
        out.write(p);
    }

    /* HPACK request block using only RFC 7541 static-table entries plus literal
       values. No dynamic table is needed for this request. */
    private static byte[] hpackRequestHeaders(String host,int port,boolean tls) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();
        // :method POST = static index 3; :scheme = 6(http) or 7(https)
        b.write(0x83); b.write(tls?0x87:0x86);
        hpackLiteralIndexedName(b,":path","/cash.z.wallet.sdk.rpc.CompactTxStreamer/GetLatestBlock",4);
        hpackLiteralIndexedName(b,":authority",host+":"+port,1);
        // content-type: application/grpc = static name index 31.
        // Literal without indexing uses a 4-bit prefix: index 31 => 0x0f, then 0x10.
        b.write(0x0f); b.write(0x10);
        byte[] ct="application/grpc".getBytes("UTF-8");
        b.write(ct.length); b.write(ct);
        hpackLiteralIndexedName(b,"te","trailers",-1);
        hpackLiteralIndexedName(b,"grpc-encoding","identity",-1);
        return b.toByteArray();
    }

    private static void hpackLiteralIndexedName(ByteArrayOutputStream b,String name,String value,int staticIndex) throws IOException {
        byte[] v=value.getBytes("UTF-8");
        if(staticIndex>0) {
            // literal without indexing, 0000xxxx prefix
            writeHpackInt(b,0x00,4,staticIndex);
        } else {
            byte[] n=name.getBytes("UTF-8"); b.write(0x00); writeHpackInt(b,0,7,n.length); b.write(n);
        }
        writeHpackInt(b,0,7,v.length); b.write(v);
    }

    private static void writeHpackInt(ByteArrayOutputStream b,int prefix,int bits,int value) {
        int max=(1<<bits)-1;
        if(value<max){ b.write(prefix|value); return; }
        b.write(prefix|max); value-=max;
        while(value>=128){ b.write((value&127)|128); value>>>=7; }
        b.write(value);
    }

    private static byte[] concat(byte[] a,byte[] c) {
        byte[] r=java.util.Arrays.copyOf(a,a.length+c.length);
        System.arraycopy(c,0,r,a.length,c.length); return r;
    }

    /* BlockID protobuf: field 2 is height (varint); field 1 is the 32-byte hash.
       Accept either order and require at least one valid field. */
    private static boolean looksLikeBlockId(byte[] p) {
        try {
            int i=0; boolean hash=false,height=false;
            while(i<p.length) {
                long tag=readVarint(p,i); int consumed=varintLen(p,i); if(consumed<1) return false; i+=consumed;
                int field=(int)(tag>>>3), wire=(int)(tag&7);
                if(field==1 && wire==2) {
                    long n=readVarint(p,i); int l=varintLen(p,i); i+=l;
                    if(n<1 || n>64 || i+n>p.length) return false;
                    hash=true; i+=(int)n;
                } else if(field==2 && wire==0) {
                    int l=varintLen(p,i); if(l<1) return false; i+=l; height=true;
                } else return false;
            }
            return hash && height;
        } catch(Exception e){ return false; }
    }
    private static long readVarint(byte[] p,int i) {
        long v=0; int s=0; for(int n=0;n<10 && i+n<p.length;n++){ int c=p[i+n]&255; v|=(long)(c&127)<<s; if((c&128)==0)return v; s+=7; } return -1;
    }
    private static int varintLen(byte[] p,int i) {
        for(int n=0;n<10 && i+n<p.length;n++) if((p[i+n]&128)==0)return n+1;
        return -1;
    }

    /** Tests the Android node's local service ports without confusing them with the remote wallet service. */
    private void testLocalNodePorts() {
        nodeDiagnostics.setText("Node diagnostics: testing executable + 8833/8832/8834…");
        new Thread(() -> {
            StringBuilder d = new StringBuilder();
            File bin = new File(getApplicationInfo().nativeLibraryDir, NodeService.NATIVE_LIB_NAME);
            d.append("Executable: ").append(bin.exists() && bin.canExecute() ? "PASS" : "FAIL")
             .append("\nPath: ").append(bin.getAbsolutePath());
            testLocalPort(d, "P2P", "127.0.0.1", 8833);
            testLocalPort(d, "RPC", "127.0.0.1", 8832);
            testLocalPort(d, "Status", "127.0.0.1", 8834);
            try {
                URL u = new URL("http://127.0.0.1:8834/status");
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(1500); c.setReadTimeout(1500); c.setRequestMethod("GET");
                int code = c.getResponseCode();
                d.append("\nStatus HTTP: ").append(code == 200 ? "PASS (200)" : "FAIL (" + code + ")");
                c.disconnect();
            } catch (Exception e) {
                d.append("\nStatus HTTP: FAIL — ").append(e.getClass().getSimpleName()).append(": ").append(e.getMessage());
            }
            d.append("\nWallet service: NOT LOCAL — 9067 is a separate Lightwalletd/gRPC service and is not assumed to be provided by the P2P node.");
            runOnUiThread(() -> nodeDiagnostics.setText(d.toString()));
        }).start();
    }

    private void testLocalPort(StringBuilder d, String name, String host, int port) {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(host, port), 1200);
            d.append("\n").append(name).append(" :").append(port).append(": PASS (listening)");
        } catch (Exception e) {
            d.append("\n").append(name).append(" :").append(port).append(": FAIL — ").append(e.getClass().getSimpleName());
        } finally { try { s.close(); } catch (Exception ignored) {} }
    }

    private void testNetwork() {
        status.setText("● TESTING");
        connectionSource.setText("Connection source: testing all known sources");
        connectionEndpoint.setText("Endpoint: —");
        connectionDetail.setText("Details: DNS seed and fixed seeds will be tested in order");
        log.setText("Log: testing Ycash mainnet connection sources on TCP 8833…");
        new Thread(() -> {
            LinkedHashSet<String> seen = new LinkedHashSet<>();
            java.util.ArrayList<String[]> candidates = new java.util.ArrayList<>();

            try {
                for (InetAddress a : InetAddress.getAllByName("seed.ycash.xyz")) {
                    String endpoint=a.getHostAddress()+":8833";
                    if (seen.add(endpoint)) candidates.add(new String[]{"DNS Seed (seed.ycash.xyz)", endpoint, a.getHostAddress()});
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    connectionSource.setText("Connection source: DNS Seed (seed.ycash.xyz)");
                    connectionEndpoint.setText("Endpoint: —");
                    connectionDetail.setText("Details: DNS resolution failed; testing fixed seeds");
                    log.setText("Log: DNS seed unavailable: "+e.getClass().getSimpleName());
                });
            }

            String[][] fixed = {
                {"Fixed Seed #1", "3.130.144.65", "8833"},
                {"Fixed Seed #2", "13.126.58.237", "8833"}
            };
            for (String[] f : fixed) {
                String endpoint=f[1]+":"+f[2];
                if (seen.add(endpoint)) candidates.add(new String[]{f[0], endpoint, f[1]});
            }

            Exception last=null;
            for (String[] candidate : candidates) {
                final String source=candidate[0];
                final String endpoint=candidate[1];
                runOnUiThread(() -> {
                    connectionSource.setText("Connection source: "+source);
                    connectionEndpoint.setText("Endpoint: "+endpoint);
                    connectionDetail.setText("Details: attempting TCP connection");
                    log.setText("Log: trying "+source+" → "+endpoint);
                });
                try (Socket socket = new Socket()) {
                    socket.connect(new InetSocketAddress(candidate[2], 8833), 7000);
                    runOnUiThread(() -> {
                        status.setText("● NETWORK REACHABLE");
                        connectionSource.setText("Connection source: "+source);
                        connectionEndpoint.setText("Endpoint: "+endpoint);
                        connectionDetail.setText("Details: TCP connection succeeded (P2P handshake is tested by the node)");
                        log.setText("Log: "+source+" succeeded at "+endpoint);
                    });
                    return;
                } catch (Exception e) {
                    last=e;
                    runOnUiThread(() -> log.setText("Log: "+source+" failed at "+endpoint+": "+e.getClass().getSimpleName()));
                }
            }
            Exception failure=last;
            runOnUiThread(() -> {
                status.setText("● CONNECTION FAILED");
                connectionDetail.setText("Details: every known Ycash connection source failed");
                log.setText("Log: all Ycash connection sources failed: "+
                    (failure == null ? "unknown error" : failure.getClass().getSimpleName()+": "+failure.getMessage()));
            });
        }).start();
    }

}
