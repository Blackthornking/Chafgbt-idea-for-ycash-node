//! Transparent UTXO set and Sprout shielded state for ordered block commits.
//!
//! Mirrors ycashd 4.5.0 `ConnectBlock` / `Consensus::CheckTxInputs` /
//! `ContextualCheckInputs` / `CCoinsViewCache::HaveShieldedRequirements`:
//! inputs exist and are unspent, coinbase maturity (100) and the
//! coinbase-must-be-shielded rule, value in >= value out, fees, script
//! verification (P2SH | CHECKLOCKTIMEVERIFY), block sigop limit, BIP30,
//! coinbase amount <= subsidy + fees, Sprout nullifiers and anchors
//! (including intermediate anchors inside one transaction), and the ZIP 209
//! Sprout/Sapling value-pool turnstile.
//!
//! Storage model: an output row is written once with the height that created
//! it and, when spent, the height that spent it. "State as of the batch's
//! first height H" is therefore `height < H AND (spent_height IS NULL OR
//! spent_height >= H)`, which stays correct even when the batch replaces an
//! old branch (rows at >= H are rolled back only after validation passes).
//! Spent rows are pruned once they are deeper than the 100-block maximum
//! reorg length ycashd itself enforces.

use anyhow::{anyhow, bail, Result};
use rusqlite::{params, Transaction};
use std::collections::{HashMap, HashSet};
use ycash_chain::ParsedTransaction;
use ycash_consensus::{
    block_subsidy, is_coinbase, money_range, tx_shielded_value_in, tx_value_out, SproutTree, COINBASE_MATURITY,
    MAX_BLOCK_SIGOPS,
};

/// ycashd `MAX_REORG_LENGTH` is 99; keep spent outputs a little longer.
pub const SPENT_OUTPUT_RETENTION: u64 = 100;

pub type OutPoint = ([u8; 32], u32);

/// Fine-grained timing for the ordered consensus/state connector.
///
/// These values intentionally cover only the state-validation phase; SQL write
/// and SQLite COMMIT timings are measured by `State::commit_blocks_batch`.
#[derive(Debug, Default, Clone, Copy)]
pub struct ConnectTiming {
    pub bip30_us: u64,
    pub sigops_us: u64,
    pub utxo_lookup_us: u64,
    pub sprout_requirements_us: u64,
    pub value_checks_us: u64,
    pub script_us: u64,
    pub coin_state_update_us: u64,
    pub sprout_apply_us: u64,
    pub tx_total_us: u64,
    pub bip30_ms: u64,
    pub sigops_ms: u64,
    pub tx_parse_us: u64,
    pub utxo_lookup_ms: u64,
    pub sprout_requirements_ms: u64,
    pub value_checks_ms: u64,
    pub script_ms: u64,
    pub coin_state_update_ms: u64,
    pub sprout_apply_ms: u64,
    pub tx_total_ms: u64,
    pub bip30_checks: u64,
    pub utxo_lookups: u64,
    pub script_checks: u64,
    pub script_parallel_workers: u64,
    pub script_parallel_us: u64,
    /// Sum of individual input verification CPU time (can exceed wall time
    /// when inputs execute concurrently), plus the slowest input location.
    pub script_input_work_us: u64,
    pub script_slowest_input_index: u64,
    pub script_slowest_input_us: u64,
    pub script_transaction_input_extraction_us: u64,
    pub script_sig_construction_us: u64,
    pub script_pubkey_retrieval_us: u64,
    pub script_parsing_us: u64,
    pub signature_hash_preparation_us: u64,
    pub ecdsa_verification_us: u64,
    pub script_interpreter_us: u64,
    pub script_cache_lookup_us: u64,
    pub script_synchronization_us: u64,
    /// Parallel-script wall-clock diagnostics. Index 0..3 are worker slots.
    pub script_worker_wall_us: [u64; 4],
    pub script_worker_input_work_us: [u64; 4],
    pub script_worker_inputs: [u64; 4],
    pub script_spawn_us: u64,
    pub script_join_us: u64,
    pub script_worker_max_us: u64,
    pub script_worker_min_us: u64,
}


#[derive(Clone, Debug)]
pub struct Coin {
    pub value: i64,
    pub script: Vec<u8>,
    pub height: u64,
    pub coinbase: bool,
}

#[derive(Clone, Debug)]
struct CoinEntry {
    coin: Coin,
    spent_height: Option<u64>,
    /// True when the entry already exists in canonical persistent state (DB or
    /// the canonical RAM cache). Cached entries must never be re-inserted, but
    /// a cached entry that becomes spent still needs its spent_height persisted.
    persisted: bool,
}

pub struct CoinsView<'a> {
    first_height: u64,
    entries: HashMap<OutPoint, CoinEntry>,
    batch_txids: HashSet<[u8; 32]>,
    cache: Option<&'a HashMap<OutPoint, Coin>>,
    pub cache_hits: u64,
    pub cache_misses: u64,
}

impl<'a> CoinsView<'a> {
    pub fn new(first_height: u64, cache: Option<&'a HashMap<OutPoint, Coin>>) -> Self {
        Self { first_height, entries: HashMap::new(), batch_txids: HashSet::new(), cache, cache_hits: 0, cache_misses: 0 }
    }

    pub fn get(&mut self, db: &Transaction<'_>, op: &OutPoint) -> Result<Option<Coin>> {
        if let Some(e) = self.entries.get(op) {
            return Ok(if e.spent_height.is_none() { Some(e.coin.clone()) } else { None });
        }
        // A canonical RAM cache is only a positive cache: a hit is an unspent
        // coin known to belong to the exact parent canonical tip. Misses still
        // consult SQLite, so cache eviction can never create a false negative.
        if let Some(cache) = self.cache {
            if let Some(coin) = cache.get(op) {
                self.cache_hits = self.cache_hits.saturating_add(1);
                self.entries.insert(*op, CoinEntry { coin: coin.clone(), spent_height: None, persisted: true });
                return Ok(Some(coin.clone()));
            }
        }
        self.cache_misses = self.cache_misses.saturating_add(1);
        // Reuse SQLite's prepared statement cache for every input lookup.
        // `connect_tx()` can perform many of these lookups per batch; preparing
        // the statement afresh for each input adds avoidable parse/VM setup
        // overhead without changing consensus semantics.
        let mut stmt = db.prepare_cached(
            "SELECT value,script,height,coinbase FROM utxos
             WHERE txid=?1 AND vout=?2 AND height<?3 AND (spent_height IS NULL OR spent_height>=?3)",
        )?;
        let row = stmt.query_row(
            params![op.0.as_slice(), op.1 as i64, self.first_height as i64],
            |r| {
                Ok(Coin {
                    value: r.get::<_, i64>(0)?,
                    script: r.get::<_, Vec<u8>>(1)?,
                    height: r.get::<_, i64>(2)? as u64,
                    coinbase: r.get::<_, i64>(3)? != 0,
                })
            },
        );
        match row {
            Ok(coin) => {
                self.entries.insert(*op, CoinEntry { coin: coin.clone(), spent_height: None, persisted: true });
                Ok(Some(coin))
            }
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    /// BIP30: a transaction may not overwrite one with unspent outputs.
    pub fn has_unspent_outputs_of(&self, db: &Transaction<'_>, txid: &[u8; 32]) -> Result<bool> {
        if self.batch_txids.contains(txid)
            && self.entries.iter().any(|(k, e)| k.0 == *txid && !e.persisted && e.spent_height.is_none())
        {
            return Ok(true);
        }
        // This is on the hot path for every transaction (BIP30). Reuse the
        // prepared statement just as with input lookups above.
        let mut stmt = db.prepare_cached(
            "SELECT COUNT(*) FROM utxos WHERE txid=?1 AND height<?2 AND (spent_height IS NULL OR spent_height>=?2)",
        )?;
        let unspent_db: i64 = stmt.query_row(
            params![txid.as_slice(), self.first_height as i64],
            |r| r.get(0),
        )?;
        if unspent_db == 0 {
            return Ok(false);
        }
        let spent_in_batch =
            self.entries.iter().filter(|(k, e)| k.0 == *txid && e.persisted && e.spent_height.is_some()).count() as i64;
        Ok(unspent_db > spent_in_batch)
    }

    pub fn spend(&mut self, op: &OutPoint, height: u64) {
        if let Some(e) = self.entries.get_mut(op) {
            e.spent_height = Some(height);
        }
    }

    pub fn add(&mut self, op: OutPoint, coin: Coin) {
        self.batch_txids.insert(op.0);
        self.entries.insert(op, CoinEntry { coin, spent_height: None, persisted: false });
    }

    /// Apply only the entries touched by this batch to the canonical RAM cache.
    /// Unrelated cache entries are retained; spent entries are removed.
    pub fn update_cache(&self, cache: &mut HashMap<OutPoint, Coin>, max_entries: usize) {
        for (op, e) in &self.entries {
            if e.spent_height.is_some() {
                cache.remove(op);
            } else {
                cache.insert(*op, e.coin.clone());
            }
        }
        while cache.len() > max_entries {
            if let Some(k) = cache.keys().next().copied() {
                cache.remove(&k);
            } else {
                break;
            }
        }
    }

    /// Write the batch's UTXO changes. Call after the rollback statements.
    pub fn flush(&self, db: &Transaction<'_>) -> Result<()> {
        let mut insert = db.prepare_cached(
            "INSERT INTO utxos(txid,vout,value,script,height,coinbase,spent_height)
             VALUES(?1,?2,?3,?4,?5,?6,?7)
             ON CONFLICT(txid,vout) DO UPDATE SET
               value=excluded.value, script=excluded.script, height=excluded.height,
               coinbase=excluded.coinbase, spent_height=excluded.spent_height",
        )?;
        let mut mark_spent = db.prepare_cached("UPDATE utxos SET spent_height=?3 WHERE txid=?1 AND vout=?2")?;
        for (op, e) in &self.entries {
            if e.persisted {
                if let Some(h) = e.spent_height {
                    mark_spent.execute(params![op.0.as_slice(), op.1 as i64, h as i64])?;
                }
            } else {
                insert.execute(params![
                    op.0.as_slice(),
                    op.1 as i64,
                    e.coin.value,
                    &e.coin.script,
                    e.coin.height as i64,
                    e.coin.coinbase as i64,
                    e.spent_height.map(|h| h as i64),
                ])?;
            }
        }
        Ok(())
    }
}

/// Sprout state carried through a batch.
pub struct SproutView {
    first_height: u64,
    pub tree: SproutTree,
    /// Final treestate of every block already processed in this batch.
    batch_roots: HashMap<[u8; 32], SproutTree>,
    batch_nullifiers: HashMap<[u8; 32], u64>,
    pub chain_sprout_value: i64,
    pub chain_sapling_value: i64,
    pub rows: Vec<BlockStateRow>,
}

pub struct BlockStateRow {
    pub block_hash: [u8; 32],
    pub height: u64,
    pub sprout_root: [u8; 32],
    pub sprout_frontier: Vec<u8>,
    pub chain_sprout_value: i64,
    pub chain_sapling_value: i64,
}

impl SproutView {
    /// Construct a Sprout view from an exact canonical-parent cache entry.
    /// This is equivalent to `load()` but avoids decoding the same persisted
    /// frontier for every sequential batch.
    pub fn from_cached(first_height: u64, tree: SproutTree, sprout_value: i64, sapling_value: i64) -> Self {
        Self {
            first_height,
            tree,
            batch_roots: HashMap::new(),
            batch_nullifiers: HashMap::new(),
            chain_sprout_value: sprout_value,
            chain_sapling_value: sapling_value,
            rows: Vec::new(),
        }
    }

    pub fn load(db: &Transaction<'_>, first_height: u64, prev: &[u8; 32]) -> Result<Self> {
        let (tree, sprout_value, sapling_value) = if first_height <= 1 {
            // The genesis block's transactions are never connected.
            (SproutTree::new(), 0, 0)
        } else {
            db.query_row(
                "SELECT sprout_frontier,chain_sprout_value,chain_sapling_value FROM block_state
                 WHERE block_hash=?1 AND height=?2",
                params![prev.as_slice(), (first_height - 1) as i64],
                |r| Ok((r.get::<_, Vec<u8>>(0)?, r.get::<_, i64>(1)?, r.get::<_, i64>(2)?)),
            )
            .map_err(|e| anyhow!("missing Sprout/value-pool state for parent block: {e}"))
            .and_then(|(f, a, b)| {
                SproutTree::decode(&f).map(|t| (t, a, b)).map_err(|e| anyhow!("invalid persisted Sprout frontier: {e:?}"))
            })?
        };
        Ok(Self {
            first_height,
            tree,
            batch_roots: HashMap::new(),
            batch_nullifiers: HashMap::new(),
            chain_sprout_value: sprout_value,
            chain_sapling_value: sapling_value,
            rows: Vec::new(),
        })
    }

    fn db_nullifier_exists(&self, db: &Transaction<'_>, nf: &[u8; 32]) -> Result<bool> {
        match db.query_row(
            "SELECT 1 FROM sprout_nullifiers WHERE n=?1 AND height<?2",
            params![nf.as_slice(), self.first_height as i64],
            |r| r.get::<_, i64>(0),
        ) {
            Ok(_) => Ok(true),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(false),
            Err(e) => Err(e.into()),
        }
    }

    fn anchor_tree(&self, db: &Transaction<'_>, anchor: &[u8; 32]) -> Result<Option<SproutTree>> {
        if let Some(t) = self.batch_roots.get(anchor) {
            return Ok(Some(t.clone()));
        }
        if *anchor == SproutTree::empty_root() {
            return Ok(Some(SproutTree::new()));
        }
        match db.query_row(
            "SELECT sprout_frontier FROM block_state WHERE sprout_root=?1 AND height<?2 LIMIT 1",
            params![anchor.as_slice(), self.first_height as i64],
            |r| r.get::<_, Vec<u8>>(0),
        ) {
            Ok(f) => Ok(Some(SproutTree::decode(&f).map_err(|e| anyhow!("invalid persisted Sprout frontier: {e:?}"))?)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }

    /// Sprout half of `HaveShieldedRequirements`.
    pub fn check_requirements(&self, db: &Transaction<'_>, tx: &ParsedTransaction) -> Result<()> {
        let mut intermediates: HashMap<[u8; 32], SproutTree> = HashMap::new();
        for js in &tx.joinsplits {
            for nf in &js.nullifiers {
                if self.batch_nullifiers.contains_key(nf) || self.db_nullifier_exists(db, nf)? {
                    bail!("bad-txns-joinsplit-requirements-not-met: Sprout nullifier already spent");
                }
            }
            let mut tree = match intermediates.get(&js.anchor) {
                Some(t) => t.clone(),
                None => self
                    .anchor_tree(db, &js.anchor)?
                    .ok_or_else(|| anyhow!("bad-txns-joinsplit-requirements-not-met: unknown Sprout anchor"))?,
            };
            for cm in &js.commitments {
                tree.append(*cm).map_err(|e| anyhow!("{e:?}"))?;
            }
            intermediates.entry(tree.root()).or_insert(tree);
        }
        Ok(())
    }

    /// Nullifiers, commitments and value pools after a tx is connected.
    pub fn apply(&mut self, tx: &ParsedTransaction, height: u64) -> Result<()> {
        for js in &tx.joinsplits {
            for nf in &js.nullifiers {
                self.batch_nullifiers.insert(*nf, height);
            }
            for cm in &js.commitments {
                self.tree.append(*cm).map_err(|e| anyhow!("{e:?}"))?;
            }
            self.chain_sprout_value = self
                .chain_sprout_value
                .checked_add(js.vpub_old)
                .and_then(|v| v.checked_sub(js.vpub_new))
                .ok_or_else(|| anyhow!("Sprout value pool overflow"))?;
        }
        self.chain_sapling_value = self
            .chain_sapling_value
            .checked_sub(tx.value_balance)
            .ok_or_else(|| anyhow!("Sapling value pool overflow"))?;
        Ok(())
    }

    pub fn finish_block(&mut self, block_hash: [u8; 32], height: u64) -> Result<()> {
        if self.chain_sprout_value < 0 {
            bail!("turnstile-violation-sprout-shielded-pool at height {height}");
        }
        if self.chain_sapling_value < 0 {
            bail!("turnstile-violation-sapling-shielded-pool at height {height}");
        }
        let root = self.tree.root();
        self.batch_roots.entry(root).or_insert_with(|| self.tree.clone());
        self.rows.push(BlockStateRow {
            block_hash,
            height,
            sprout_root: root,
            sprout_frontier: self.tree.encode(),
            chain_sprout_value: self.chain_sprout_value,
            chain_sapling_value: self.chain_sapling_value,
        });
        Ok(())
    }

    pub fn flush(&self, db: &Transaction<'_>) -> Result<()> {
        let mut nf = db.prepare_cached("INSERT OR REPLACE INTO sprout_nullifiers(n,height) VALUES(?1,?2)")?;
        for (n, h) in &self.batch_nullifiers {
            nf.execute(params![n.as_slice(), *h as i64])?;
        }
        let mut st = db.prepare_cached(
            "INSERT OR REPLACE INTO block_state(block_hash,height,sprout_root,sprout_frontier,chain_sprout_value,chain_sapling_value)
             VALUES(?1,?2,?3,?4,?5,?6)",
        )?;
        for r in &self.rows {
            st.execute(params![
                r.block_hash.as_slice(),
                r.height as i64,
                r.sprout_root.as_slice(),
                &r.sprout_frontier,
                r.chain_sprout_value,
                r.chain_sapling_value,
            ])?;
        }
        Ok(())
    }
}

fn txid_display(txid: &[u8; 32]) -> String {
    txid.iter().rev().map(|b| format!("{b:02x}")).collect()
}

/// Per-block accumulator for fees, sigops and the coinbase amount.
pub struct BlockConnector {
    pub height: u64,
    pub consensus_branch_id: u32,
    pub verify_scripts: bool,
    fees: i64,
    sigops: u64,
    coinbase_value_out: i64,
}

impl BlockConnector {
    pub fn new(height: u64, verify_scripts: bool) -> Self {
        Self {
            height,
            consensus_branch_id: ycash_consensus::consensus_branch_id(height),
            verify_scripts,
            fees: 0,
            sigops: 0,
            coinbase_value_out: 0,
        }
    }

    /// Verify all transparent inputs without mutating consensus state.
    /// This mirrors ycashd's separation of script checks from the ordered coin
    /// state transition: every input observes the same immutable prevout set,
    /// so the checks can run in parallel while the caller still connects the
    /// transaction and mutates UTXO state in strict consensus order.
    fn verify_scripts_parallel(
        &self,
        tx: &ParsedTransaction,
        txid: &[u8; 32],
        prevouts: &[Coin],
        precomputed: Option<&ycash_script::PrecomputedTxData>,
    ) -> Result<(u64, u64, u64, u64, u64, ycash_script::ScriptVerifyTiming, [u64; 4], [u64; 4], [u64; 4], u64, u64, u64, u64)> {
        if tx.vin.is_empty() {
            return Ok((0, 0, 0, 0, 0, ycash_script::ScriptVerifyTiming::default(), [0;4], [0;4], [0;4], 0, 0, 0, 0));
        }
        if tx.vin.len() == 1 {
            let started = std::time::Instant::now();
            let input = &tx.vin[0];
            let coin = &prevouts[0];
            let sink = ycash_script::ScriptTimingSink::new();
            let checker = ycash_script::TransactionChecker {
                tx,
                n_in: 0,
                amount: coin.value,
                consensus_branch_id: self.consensus_branch_id,
                precomputed,
                timing: Some(&sink),
            };
            ycash_script::verify_script(
                &input.script_sig,
                &coin.script,
                ycash_script::BLOCK_SCRIPT_VERIFY_FLAGS,
                &checker,
            ).map_err(|e| anyhow!("mandatory-script-verify-flag-failed ({e:?}): tx {} input 0 at height {}", txid_display(txid), self.height))?;
            let us = started.elapsed().as_micros() as u64;
            return Ok((1, us, us, 0, us, sink.snapshot(), [us,0,0,0], [us,0,0,0], [1,0,0,0], 0, 0, us, us));
        }
        let workers = std::thread::available_parallelism()
            .map(|n| n.get())
            .unwrap_or(1)
            .min(4)
            .min(tx.vin.len());
        let started = std::time::Instant::now();
        let chunk = (tx.vin.len() + workers - 1) / workers;
        let spawn_started = std::time::Instant::now();
        let results = std::thread::scope(|scope| {
            let mut handles = Vec::with_capacity(workers);
            for worker in 0..workers {
                let start = worker * chunk;
                if start >= tx.vin.len() { break; }
                let end = (start + chunk).min(tx.vin.len());
                handles.push(scope.spawn(move || {
                    let worker_started = std::time::Instant::now();
                    let sink = ycash_script::ScriptTimingSink::new();
                    let mut first_error: Option<(usize, ycash_script::ScriptError)> = None;
                    let mut work_us = 0u64;
                    let mut slow_idx = start as u64;
                    let mut slow_us = 0u64;
                    let mut inputs_done = 0u64;
                    for i in start..end {
                        let input = &tx.vin[i];
                        let coin = &prevouts[i];
                        let checker = ycash_script::TransactionChecker {
                            tx,
                            n_in: i,
                            amount: coin.value,
                            consensus_branch_id: self.consensus_branch_id,
                            precomputed,
                            timing: Some(&sink),
                        };
                        let input_started = std::time::Instant::now();
                        let result = ycash_script::verify_script(
                            &input.script_sig,
                            &coin.script,
                            ycash_script::BLOCK_SCRIPT_VERIFY_FLAGS,
                            &checker,
                        );
                        let input_us = input_started.elapsed().as_micros() as u64;
                        work_us = work_us.saturating_add(input_us);
                        inputs_done += 1;
                        if input_us > slow_us { slow_us = input_us; slow_idx = i as u64; }
                        if let Err(e) = result {
                            first_error = Some((i, e));
                            break;
                        }
                    }
                    let worker_wall_us = worker_started.elapsed().as_micros() as u64;
                    (first_error, work_us, slow_idx, slow_us, sink.snapshot(), worker_wall_us, inputs_done)
                }));
            }
            let spawn_us = spawn_started.elapsed().as_micros() as u64;
            let join_started = std::time::Instant::now();
            let joined = handles.into_iter().map(|h| h.join().unwrap()).collect::<Vec<_>>();
            let join_us = join_started.elapsed().as_micros() as u64;
            (joined, spawn_us, join_us)
        });
        let (results, spawn_us, join_us) = results;
        let mut errors = Vec::new();
        let mut input_work_us = 0u64;
        let mut slow_idx = 0u64;
        let mut slow_us = 0u64;
        let mut telemetry = ycash_script::ScriptVerifyTiming::default();
        let mut worker_wall_us = [0u64; 4];
        let mut worker_input_work_us = [0u64; 4];
        let mut worker_inputs = [0u64; 4];
        let mut worker_slot = 0usize;
        for (err, work, idx, us, sample, worker_wall, inputs_done) in results {
            if worker_slot < 4 {
                worker_wall_us[worker_slot] = worker_wall;
                worker_input_work_us[worker_slot] = work;
                worker_inputs[worker_slot] = inputs_done;
            }
            worker_slot += 1;
            input_work_us = input_work_us.saturating_add(work);
            if us > slow_us { slow_us = us; slow_idx = idx; }
            telemetry.transaction_input_extraction_us = telemetry.transaction_input_extraction_us.saturating_add(sample.transaction_input_extraction_us);
            telemetry.script_sig_construction_us = telemetry.script_sig_construction_us.saturating_add(sample.script_sig_construction_us);
            telemetry.script_pubkey_retrieval_us = telemetry.script_pubkey_retrieval_us.saturating_add(sample.script_pubkey_retrieval_us);
            telemetry.script_parsing_us = telemetry.script_parsing_us.saturating_add(sample.script_parsing_us);
            telemetry.signature_hash_preparation_us = telemetry.signature_hash_preparation_us.saturating_add(sample.signature_hash_preparation_us);
            telemetry.ecdsa_verification_us = telemetry.ecdsa_verification_us.saturating_add(sample.ecdsa_verification_us);
            telemetry.script_interpreter_us = telemetry.script_interpreter_us.saturating_add(sample.script_interpreter_us);
            telemetry.cache_lookup_us = telemetry.cache_lookup_us.saturating_add(sample.cache_lookup_us);
            telemetry.synchronization_us = telemetry.synchronization_us.saturating_add(sample.synchronization_us);
            if let Some((i, e)) = err { errors.push((i, e)); }
        }
        if let Some((i, e)) = errors.into_iter().min_by_key(|(i, _)| *i) {
            bail!("mandatory-script-verify-flag-failed ({e:?}): tx {} input {i} at height {}", txid_display(txid), self.height);
        }
        let wall_us = started.elapsed().as_micros() as u64;
        telemetry.synchronization_us = wall_us.saturating_sub(input_work_us.min(wall_us));
        let max_worker_us = worker_wall_us.iter().copied().max().unwrap_or(0);
        let min_worker_us = worker_wall_us.iter().copied().filter(|v| *v != 0).min().unwrap_or(0);
        Ok((workers as u64, wall_us, input_work_us, slow_idx, slow_us, telemetry, worker_wall_us, worker_input_work_us, worker_inputs, spawn_us, join_us, max_worker_us, min_worker_us))
    }

    /// Validate `tx` against the view, then connect it (spend inputs, add
    /// outputs, apply Sprout effects). Order follows `ConnectBlock`.
    pub fn connect_tx(
        &mut self,
        db: &Transaction<'_>,
        coins: &mut CoinsView,
        sprout: &mut SproutView,
        tx: &ParsedTransaction,
        txid: &[u8; 32],
        precomputed: Option<&ycash_script::PrecomputedTxData>,
        timing: &mut ConnectTiming,
    ) -> Result<()> {
        let tx_started = std::time::Instant::now();
        let h = self.height;
        let coinbase = is_coinbase(tx);

        let sigops_started = std::time::Instant::now();
        self.sigops += ycash_script::legacy_sig_op_count(tx) as u64;
        timing.sigops_us = timing.sigops_us.saturating_add(sigops_started.elapsed().as_micros() as u64);
        timing.sigops_ms = timing.sigops_us / 1000;
        if self.sigops > MAX_BLOCK_SIGOPS {
            bail!("bad-blk-sigops at height {h}");
        }
        let bip30_started = std::time::Instant::now();
        timing.bip30_checks += 1;
        if coins.has_unspent_outputs_of(db, txid)? {
            bail!("bad-txns-BIP30: tx {} at height {h}", txid_display(txid));
        }
        timing.bip30_us = timing.bip30_us.saturating_add(bip30_started.elapsed().as_micros() as u64);
        timing.bip30_ms = timing.bip30_us / 1000;

        if coinbase {
            self.coinbase_value_out = tx_value_out(tx).map_err(|e| anyhow!("{e:?}"))?;
        } else {
            let mut prevouts = Vec::with_capacity(tx.vin.len());
            let utxo_started = std::time::Instant::now();
            timing.utxo_lookups += tx.vin.len() as u64;
            for input in &tx.vin {
                let op = (input.prev_txid, input.prev_index);
                let coin = coins.get(db, &op)?.ok_or_else(|| {
                    anyhow!(
                        "bad-txns-inputs-missingorspent: tx {} spends {}:{} at height {h}",
                        txid_display(txid),
                        txid_display(&input.prev_txid),
                        input.prev_index
                    )
                })?;
                prevouts.push(coin);
            }
            let utxo_elapsed_us = utxo_started.elapsed().as_micros() as u64;
            timing.utxo_lookup_us = timing.utxo_lookup_us.saturating_add(utxo_elapsed_us);
            // This is the actual transaction/input extraction from the canonical
            // UTXO view (including cache/SQLite lookup). It is reported separately
            // from script execution because it occurs immediately before verify_script.
            timing.script_transaction_input_extraction_us = timing.script_transaction_input_extraction_us.saturating_add(utxo_elapsed_us);
            timing.utxo_lookup_ms = timing.utxo_lookup_us / 1000;

            let sprout_req_started = std::time::Instant::now();
            sprout.check_requirements(db, tx)?;
            timing.sprout_requirements_us = timing.sprout_requirements_us.saturating_add(sprout_req_started.elapsed().as_micros() as u64);
            timing.sprout_requirements_ms = timing.sprout_requirements_us / 1000;

            for (input, coin) in tx.vin.iter().zip(&prevouts) {
                if ycash_script::is_pay_to_script_hash(&coin.script) {
                    self.sigops += ycash_script::p2sh_sig_op_count(&coin.script, &input.script_sig) as u64;
                }
            }
            if self.sigops > MAX_BLOCK_SIGOPS {
                bail!("bad-blk-sigops at height {h}");
            }

            // Consensus::CheckTxInputs
            let value_started = std::time::Instant::now();
            let mut value_in: i64 = 0;
            for coin in &prevouts {
                if coin.coinbase {
                    if (h as i64) - (coin.height as i64) < COINBASE_MATURITY as i64 {
                        bail!("bad-txns-premature-spend-of-coinbase: tx {} at height {h}", txid_display(txid));
                    }
                    if !tx.vout.is_empty() {
                        bail!("bad-txns-coinbase-spend-has-transparent-outputs: tx {} at height {h}", txid_display(txid));
                    }
                }
                value_in = value_in
                    .checked_add(coin.value)
                    .filter(|v| money_range(coin.value) && money_range(*v))
                    .ok_or_else(|| anyhow!("bad-txns-inputvalues-outofrange at height {h}"))?;
            }
            value_in = value_in
                .checked_add(tx_shielded_value_in(tx).map_err(|e| anyhow!("{e:?}"))?)
                .filter(|v| money_range(*v))
                .ok_or_else(|| anyhow!("bad-txns-inputvalues-outofrange at height {h}"))?;
            let value_out = tx_value_out(tx).map_err(|e| anyhow!("{e:?}"))?;
            if value_in < value_out {
                bail!("bad-txns-in-belowout: tx {} at height {h} ({value_in} < {value_out})", txid_display(txid));
            }
            self.fees = self
                .fees
                .checked_add(value_in - value_out)
                .filter(|v| money_range(*v))
                .ok_or_else(|| anyhow!("bad-txns-fee-outofrange at height {h}"))?;
            timing.value_checks_us = timing.value_checks_us.saturating_add(value_started.elapsed().as_micros() as u64);
            timing.value_checks_ms = timing.value_checks_us / 1000;

            if self.verify_scripts {
                timing.script_checks = timing.script_checks.saturating_add(tx.vin.len() as u64);
                let (workers, script_us, input_work_us, slow_input_index, slow_input_us, script_timing, worker_wall_us, worker_input_work_us, worker_inputs, spawn_us, join_us, worker_max_us, worker_min_us) = self.verify_scripts_parallel(tx, txid, &prevouts, precomputed)?;
                timing.script_parallel_workers = timing.script_parallel_workers.max(workers);
                timing.script_parallel_us = timing.script_parallel_us.saturating_add(script_us);
                timing.script_input_work_us = timing.script_input_work_us.saturating_add(input_work_us);
                timing.script_transaction_input_extraction_us = timing.script_transaction_input_extraction_us.saturating_add(script_timing.transaction_input_extraction_us);
                timing.script_sig_construction_us = timing.script_sig_construction_us.saturating_add(script_timing.script_sig_construction_us);
                timing.script_pubkey_retrieval_us = timing.script_pubkey_retrieval_us.saturating_add(script_timing.script_pubkey_retrieval_us);
                timing.script_parsing_us = timing.script_parsing_us.saturating_add(script_timing.script_parsing_us);
                timing.signature_hash_preparation_us = timing.signature_hash_preparation_us.saturating_add(script_timing.signature_hash_preparation_us);
                timing.ecdsa_verification_us = timing.ecdsa_verification_us.saturating_add(script_timing.ecdsa_verification_us);
                timing.script_interpreter_us = timing.script_interpreter_us.saturating_add(script_timing.script_interpreter_us);
                timing.script_cache_lookup_us = timing.script_cache_lookup_us.saturating_add(script_timing.cache_lookup_us);
                timing.script_synchronization_us = timing.script_synchronization_us.saturating_add(script_timing.synchronization_us);
                for i in 0..4 {
                    timing.script_worker_wall_us[i] = timing.script_worker_wall_us[i].saturating_add(worker_wall_us[i]);
                    timing.script_worker_input_work_us[i] = timing.script_worker_input_work_us[i].saturating_add(worker_input_work_us[i]);
                    timing.script_worker_inputs[i] = timing.script_worker_inputs[i].saturating_add(worker_inputs[i]);
                }
                timing.script_spawn_us = timing.script_spawn_us.saturating_add(spawn_us);
                timing.script_join_us = timing.script_join_us.saturating_add(join_us);
                timing.script_worker_max_us = timing.script_worker_max_us.max(worker_max_us);
                if timing.script_worker_min_us == 0 { timing.script_worker_min_us = worker_min_us; } else if worker_min_us != 0 { timing.script_worker_min_us = timing.script_worker_min_us.min(worker_min_us); }
                if slow_input_us > timing.script_slowest_input_us {
                    timing.script_slowest_input_index = slow_input_index;
                    timing.script_slowest_input_us = slow_input_us;
                }
                timing.script_us = timing.script_us.saturating_add(script_us);
                timing.script_ms = timing.script_us / 1000;
            }

            let coin_state_started = std::time::Instant::now();
            for input in &tx.vin {
                coins.spend(&(input.prev_txid, input.prev_index), h);
            }
            timing.coin_state_update_us = timing.coin_state_update_us.saturating_add(coin_state_started.elapsed().as_micros() as u64);
            timing.coin_state_update_ms = timing.coin_state_update_us / 1000;
        }

        let coin_state_started = std::time::Instant::now();
        for (n, out) in tx.vout.iter().enumerate() {
            if !ycash_script::is_unspendable(&out.script_pubkey) {
                coins.add(
                    (*txid, n as u32),
                    Coin { value: out.value, script: out.script_pubkey.clone(), height: h, coinbase },
                );
            }
        }
        timing.coin_state_update_us = timing.coin_state_update_us.saturating_add(coin_state_started.elapsed().as_micros() as u64);
            timing.coin_state_update_ms = timing.coin_state_update_us / 1000;
        let sprout_apply_started = std::time::Instant::now();
        sprout.apply(tx, h)?;
        timing.sprout_apply_us = timing.sprout_apply_us.saturating_add(sprout_apply_started.elapsed().as_micros() as u64);
        timing.sprout_apply_ms = timing.sprout_apply_us / 1000;
        timing.tx_total_us = timing.tx_total_us.saturating_add(tx_started.elapsed().as_micros() as u64);
        timing.tx_total_ms = timing.tx_total_us / 1000;
        Ok(())
    }

    /// `bad-cb-amount`: coinbase may claim at most subsidy + fees.
    pub fn finish(&self) -> Result<()> {
        let limit = self
            .fees
            .checked_add(block_subsidy(self.height))
            .ok_or_else(|| anyhow!("block reward overflow"))?;
        if self.coinbase_value_out > limit {
            bail!(
                "bad-cb-amount at height {}: coinbase pays {} > subsidy+fees {}",
                self.height,
                self.coinbase_value_out,
                limit
            );
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rusqlite::Connection;
    use std::collections::HashMap;

    #[test]
    fn utxo_cache_hit_does_not_require_db_table() {
        let db = Connection::open_in_memory().unwrap();
        let tx = db.unchecked_transaction().unwrap();
        let txid = [7u8; 32];
        let op = (txid, 0u32);
        let coin = Coin { value: 123, script: vec![0x51], height: 10, coinbase: false };
        let mut cache = HashMap::new();
        cache.insert(op, coin.clone());
        let mut view = CoinsView::new(11, Some(&cache));
        let got = view.get(&tx, &op).unwrap().unwrap();
        assert_eq!(got.value, coin.value);
        assert_eq!(view.cache_hits, 1);
        assert_eq!(view.cache_misses, 0);
    }

    #[test]
    fn utxo_cache_update_removes_spent_and_keeps_new() {
        let txid = [8u8; 32];
        let spent = ([1u8; 32], 0u32);
        let added = (txid, 1u32);
        let mut cache = HashMap::new();
        cache.insert(spent, Coin { value: 1, script: vec![0x51], height: 1, coinbase: false });
        let mut view = CoinsView::new(2, None);
        view.entries.insert(spent, CoinEntry {
            coin: cache.get(&spent).unwrap().clone(),
            spent_height: Some(2),
            persisted: true,
        });
        view.add(added, Coin { value: 2, script: vec![0x51], height: 2, coinbase: false });
        view.update_cache(&mut cache, 100);
        assert!(!cache.contains_key(&spent));
        assert!(cache.contains_key(&added));
    }
}
