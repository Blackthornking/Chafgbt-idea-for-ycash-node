#!/usr/bin/env bash
# Build the Rust Android node for arm64-v8a and package it into the Android app.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

command -v cargo >/dev/null 2>&1 || { echo "ERROR: cargo is required" >&2; exit 1; }
command -v rustup >/dev/null 2>&1 || { echo "ERROR: rustup is required" >&2; exit 1; }

TARGET="aarch64-linux-android"
API="${ANDROID_API_LEVEL:-35}"
ABI="arm64-v8a"

# The workflow installs the target with dtolnay/rust-toolchain. Do not blindly
# run `rustup target add` here: on CI that can force an unnecessary network
# operation and fail the build before Cargo emits any useful diagnostics.
if ! rustup target list --installed | grep -qx "$TARGET"; then
  echo "ERROR: Rust target $TARGET is not installed." >&2
  echo "Installed targets:" >&2
  rustup target list --installed >&2 || true
  exit 1
fi

# Locate the NDK from the standard environment variables or Android SDK layout.
NDK="${ANDROID_NDK_ROOT:-${ANDROID_NDK_HOME:-}}"
if [[ -z "$NDK" && -n "${ANDROID_HOME:-}" && -d "$ANDROID_HOME/ndk" ]]; then
  NDK="$(find "$ANDROID_HOME/ndk" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -1)"
fi
if [[ -z "$NDK" && -n "${ANDROID_SDK_ROOT:-}" && -d "$ANDROID_SDK_ROOT/ndk" ]]; then
  NDK="$(find "$ANDROID_SDK_ROOT/ndk" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -1)"
fi
[[ -n "$NDK" && -d "$NDK" ]] || {
  echo "ERROR: Android NDK not found. Set ANDROID_NDK_ROOT or ANDROID_NDK_HOME." >&2
  exit 1
}

HOST_TAG="linux-x86_64"
if [[ "$(uname -s)" == "Darwin" ]]; then HOST_TAG="darwin-x86_64"; fi
if [[ "$(uname -m)" == "arm64" && "$HOST_TAG" == "darwin-x86_64" && -d "$NDK/toolchains/llvm/prebuilt/darwin-aarch64" ]]; then
  HOST_TAG="darwin-aarch64"
fi
CLANG="$NDK/toolchains/llvm/prebuilt/$HOST_TAG/bin/aarch64-linux-android${API}-clang"
[[ -x "$CLANG" ]] || { echo "ERROR: Android clang not found: $CLANG" >&2; exit 1; }

export CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER="$CLANG"
export CC_aarch64_linux_android="$CLANG"
export CXX_aarch64_linux_android="${CLANG%clang}clang++"

echo "Building ycash-android-node for $TARGET (API $API)..."
if ! cargo build --release -p ycash-android-node --target "$TARGET"; then
  echo "ERROR: Cargo failed while building ycash-android-node for $TARGET." >&2
  echo "Rust: $(rustc --version)" >&2
  echo "Cargo: $(cargo --version)" >&2
  echo "Target: $TARGET" >&2
  echo "NDK: $NDK" >&2
  exit 1
fi

BINARY="$ROOT/target/$TARGET/release/ycash-android-node"
BINARY="$BINARY" "$ROOT/tools/package-node-binary.sh"

echo "Android ARM64 native binary is ready for Gradle packaging."
echo "Next: cd android-app && ./gradlew assembleRelease"
