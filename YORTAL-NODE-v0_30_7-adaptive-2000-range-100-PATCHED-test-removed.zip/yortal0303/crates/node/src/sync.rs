//! v0.23 concurrent multi-peer sync driver.
//!
//! Headers are validated and committed to the header chain first. The current
//! adaptive window is then partitioned into independent ranges. One worker per
//! ready peer fetches and validates ranges concurrently. Validation results are
//! buffered, but State transitions are committed strictly in height order.

use anyhow::{anyhow, bail, Result};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;
use std::io::Cursor;
use std::net::{SocketAddr, TcpStream, ToSocketAddrs};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

use ycash_chain::{read_block_at_height, read_compact_size, read_header_at, txid, BlockHeader};
use ycash_consensus::{add_work, block_proof, validate_for_commit_batched_with_parsed, validate_header, Context, ProofBatch, GENESIS_BITS, GENESIS_TIME, POW_MEDIAN_BLOCK_SPAN};
use ycash_network_transport::runtime::{connect_with_timeout, getdata_payload, getheaders_payload, recv_message, send_message, version_payload, NODE_NETWORK};
use ycash_network_transport::{Hash256, Peer, PeerManager, PeerState};
use ycash_state::pipeline::{adaptive::ResourceSample, range_scheduler::{RangeId, RangeLease}, PipelineEngine};
use ycash_state::{BlockCommit, State};

struct Ycash256;
impl Hash256 for Ycash256 {
    fn hash256(data: &[u8]) -> [u8; 32] {
        let a = Sha256::digest(data);
        let b = Sha256::digest(a);
        let mut out = [0u8; 32]; out.copy_from_slice(&b); out
    }
}

pub struct SyncConfig { pub seeds: Vec<String>, pub connect_timeout: Duration }
impl Default for SyncConfig {
    fn default() -> Self {
        let seeds = std::env::var("YCASH_SEED_NODES").ok()
            .map(|s| s.split(',').map(|x| x.trim().to_string()).filter(|x| !x.is_empty()).collect())
            .unwrap_or_else(|| vec!["seed.ycash.xyz:8833".to_string()]);
        Self { seeds, connect_timeout: Duration::from_secs(10) }
    }
}

/// Main sync coordinator. Peer I/O and block validation happen on worker
/// threads; only this coordinator mutates canonical chain state.
pub fn run_sync_loop(state: State, pipeline: PipelineEngine, cfg: SyncConfig) {
    if cfg.seeds.is_empty() { tracing::warn!("no seed nodes configured"); return; }
    let state = Arc::new(state);
    let pipeline = Arc::new(Mutex::new(pipeline));
    let mut peers = PeerManager::default();
    for (id, seed) in cfg.seeds.iter().enumerate() {
        peers.add(Peer { id:id as u64, addr:seed.clone(), state:PeerState::Connecting, score:0, failures:0 });
    }

    // Keep the header chain authoritative from the first peer that can serve it.
    let (header_peer, mut header_stream) = match connect_first(&cfg.seeds, cfg.connect_timeout, &mut peers) {
        Some(v) => v, None => { tracing::warn!("no Ycash peers could be connected"); return; }
    };

    loop {
        let locator = state.locator_hashes().unwrap_or_default();
        let start_height = state.header_height().unwrap_or(None).unwrap_or(0);
        if send_message::<_, Ycash256>(&mut header_stream, "getheaders", &getheaders_payload(&locator, &[0u8;32])).is_err() { break; }
        let (cmd, resp) = match recv_message::<_, Ycash256>(&mut header_stream) { Ok(v)=>v, Err(e)=>{tracing::warn!(error=%e,"header peer disconnected"); break;} };
        if cmd != "headers" { tracing::warn!(cmd=%cmd,"unexpected header response"); break; }
        let headers = match parse_headers_message(&resp, start_height+1) { Ok(v)=>v, Err(e)=>{tracing::warn!(error=%e,"malformed headers"); break;} };
        if headers.is_empty() { tracing::info!(height=start_height,"headers caught up"); break; }

        let mut accepted=0u64;
        for (i, header) in headers.iter().enumerate() {
            let height=start_height+1+i as u64;
            if let Err(e)=validate_header_against_state(&state,header,height) { tracing::error!(height,error=%e,"consensus header rejection"); return; }
            let work=match block_proof(header.bits){Ok(w)=>w,Err(e)=>{tracing::error!(height,error=?e,"block work failure");return;}};
            let cumulative=accumulate_work(&state,height.saturating_sub(1),&work);
            if let Err(e)=state.put_header(height,&header.hash(),&header.prev,header.time,header.bits,&cumulative,&header.serialize()){tracing::error!(height,error=%e,"header persistence failure");return;}
            accepted+=1;
        }
        tracing::info!(height=start_height+accepted, added=accepted,"validated header batch");

        let tip=start_height+accepted;
        let next=start_height+1;
        // Consensus bring-up mode: the pipeline configuration is authoritative.
        let (worker_count, max_inflight)={ let p=pipeline.lock().unwrap(); (p.max_validation_workers(), p.max_inflight_ranges()) };
        let range_ids={ let mut p=pipeline.lock().unwrap(); p.plan_parallel_ranges(next,tip,worker_count).into_iter().take(max_inflight).collect::<Vec<_>>() };
        if range_ids.is_empty(){continue;}

        // Bounded result channel: validated ranges must not accumulate without limit
        // behind the ordered commit barrier. Workers block here until the coordinator
        // makes room, providing real backpressure instead of an ever-growing queue.
        let (tx,rx)=std::sync::mpsc::sync_channel::<ValidatedRange>(worker_count.saturating_mul(2).max(2));
        let mut handles=Vec::new();
        for (idx,seed) in cfg.seeds.iter().take(worker_count).enumerate() {
            let tx=tx.clone(); let state=Arc::clone(&state); let pipeline=Arc::clone(&pipeline);
            let seed=seed.clone(); let timeout=cfg.connect_timeout;
            handles.push(thread::spawn(move || worker_loop(idx as u64,seed,timeout,state,pipeline,tx)));
        }
        drop(tx);

        let mut buffered:BTreeMap<u64,ValidatedRange>=BTreeMap::new();
        let mut next_commit=next;
        let mut done=0usize;
        let mut last_progress=Instant::now();
        while done < range_ids.len() {
            match rx.recv_timeout(Duration::from_millis(500)) {
                Ok(v)=>{ buffered.insert(v.lease.range.start,v); },
                Err(std::sync::mpsc::RecvTimeoutError::Timeout)=>{},
                Err(std::sync::mpsc::RecvTimeoutError::Disconnected)=>break,
            }
            loop {
                let key=match buffered.keys().next().copied(){Some(k)=>k,None=>break};
                if key!=next_commit {break;}
                let v=buffered.remove(&key).unwrap();
                // A watchdog may have requeued this lease while the worker was
                // still validating. Never commit a stale result from an old lease.
                let current={let p=pipeline.lock().unwrap();p.is_current_lease(v.lease.id,v.lease.generation)};
                if !current {
                    tracing::warn!(start=v.lease.range.start,end=v.lease.range.end,
                        "discarding stale validated range result");
                    continue;
                }
                let started=Instant::now();
                let commit_result = state.commit_blocks_batch(&v.blocks);
                if let Err(e) = commit_result {
                    tracing::error!(error=%e, start=v.lease.range.start, end=v.lease.range.end, "ordered batch commit failed");
                    let mut p = pipeline.lock().unwrap();
                    p.release(v.lease.id);
                    break;
                }
                {
                    let mut p=pipeline.lock().unwrap();
                    p.complete(v.lease.id,v.blocks.len() as u64,v.bytes);
                }
                done+=1; next_commit=v.lease.range.end+1;
                let elapsed=started.elapsed();
                let sample=resource_sample(v.bytes,elapsed,buffered.len(),&pipeline);
                let snap={let mut p=pipeline.lock().unwrap();p.observe(sample)};
                tracing::info!(start=v.lease.range.start,end=v.lease.range.end,bps=snap.bps,rx_bps=snap.rx_bps,window=snap.window,workers=snap.workers,"ordered range committed");
                last_progress=Instant::now();
            }
            // Head-of-line watchdog. A leased range at next_commit that makes
            // no progress for too long is returned to the scheduler. This is
            // deliberately a lease operation, not a consensus skip: the height
            // remains mandatory and must still be fully validated and committed.
            if !buffered.contains_key(&next_commit) {
                let head_id={let p=pipeline.lock().unwrap();p.range_ids_at_start(next_commit)};
                if let Some(id)=head_id {
                    let age={let p=pipeline.lock().unwrap();p.lease_age(id)};
                    if let Some(age)=age {
                        if age >= Duration::from_secs(15) {
                            let mut p=pipeline.lock().unwrap();
                            if p.requeue_if_lease_stalled(id,Duration::from_secs(15)) {
                                tracing::warn!(start=next_commit, age_secs=age.as_secs(),
                                    "stalled head range requeued; commit order remains intact");
                                last_progress=Instant::now();
                            }
                        }
                    }
                }
            }
            // If all workers are gone and the remaining range has been retried
            // to quarantine, do not spin forever.
            if last_progress.elapsed()>Duration::from_secs(30) {
                let terminal={let p=pipeline.lock().unwrap();range_ids.iter().all(|id|p.range_terminal(*id))};
                if terminal {break;}
            }
        }
        for h in handles { let _=h.join(); }
        if done<range_ids.len(){tracing::warn!(done,total=range_ids.len(),"sync window ended before every range committed");break;}
    }
}

#[derive(Debug)]
struct ValidatedRange { lease:RangeLease, blocks:Vec<BlockCommit>, bytes:u64 }

fn worker_loop(_id:u64, seed:String, timeout:Duration, state:Arc<State>, pipeline:Arc<Mutex<PipelineEngine>>, tx:std::sync::mpsc::SyncSender<ValidatedRange>) {
    let addr=match seed.to_socket_addrs().ok().and_then(|mut a|a.next()){Some(a)=>a,None=>{tracing::warn!(peer=%seed,"worker could not resolve peer");return;}};
    let mut stream=match connect_and_handshake(addr,timeout){Ok(s)=>s,Err(e)=>{tracing::warn!(peer=%seed,error=%e,"worker handshake failed");return;}};
    loop {
        let lease={let mut p=pipeline.lock().unwrap();p.claim(&seed)};
        let lease=match lease{Some(l)=>l,None=>break};
        let hashes:Vec<[u8;32]>=(lease.range.start..=lease.range.end).filter_map(|h|state.header_hash_by_height(h).ok().flatten()).filter_map(|v|v.try_into().ok()).collect();
        if hashes.len() as u64!=lease.range.len(){let mut p=pipeline.lock().unwrap();p.release_if_current(lease.id,lease.generation);continue;}
        if let Err(e)=send_message::<_,Ycash256>(&mut stream,"getdata",&getdata_payload(&hashes)){tracing::warn!(peer=%seed,error=%e,"getdata send failed");let mut p=pipeline.lock().unwrap();p.release_if_current(lease.id,lease.generation);break;}
        let mut blocks=Vec::with_capacity(hashes.len()); let mut bytes=0u64; let mut ok=true;
        // Consensus validation is performed before anything reaches the state
        // committer. Keep one ProofBatch for the complete range so Sapling
        // Groth16 proofs are batch-verified, while the original verifier remains
        // authoritative on a batch failure. Full verification is intentional:
        // this worker does not use assume-valid/checkpoint shortcuts.
        let mut proof_batch=ProofBatch::new();
        for h in lease.range.start..=lease.range.end {
            match recv_message::<_,Ycash256>(&mut stream){
                Ok((cmd,raw)) if cmd=="block"=>{bytes+=raw.len() as u64;match validate_block_only(&state,&raw,h,&mut proof_batch){Ok(b)=>blocks.push(b),Err(e)=>{tracing::warn!(peer=%seed,height=h,error=%e,"block consensus validation failed");ok=false;break;}}},
                Ok((cmd,_))=>{tracing::warn!(peer=%seed,cmd=%cmd,"unexpected block response");ok=false;break;},
                Err(e)=>{tracing::warn!(peer=%seed,error=%e,"block receive failed");ok=false;break;}
            }
        }
        if ok && proof_batch.proofs()>0 {
            if let Err((height,e))=proof_batch.finish() {
                tracing::warn!(peer=%seed,height,error=?e,"Sapling proof batch validation failed");
                ok=false;
            }
        }
        if ok {
            if tx.send(ValidatedRange{lease:lease.clone(),blocks,bytes}).is_err(){break;}
        } else {
            let mut p=pipeline.lock().unwrap();
            p.release_if_current(lease.id,lease.generation);
        }
    }
}

fn connect_first(seeds:&[String],timeout:Duration,peers:&mut PeerManager)->Option<(String,TcpStream)> {
    for (idx,seed) in seeds.iter().enumerate(){
        let id=idx as u64; let addr=match seed.to_socket_addrs().ok().and_then(|mut a|a.next()){Some(a)=>a,None=>{peers.penalize(id,10);continue;}};
        match connect_and_handshake(addr,timeout){Ok(s)=>{peers.mark_ready(id);tracing::info!(peer=%seed,"header peer connected");return Some((seed.clone(),s));},Err(e)=>{peers.penalize(id,10);tracing::warn!(peer=%seed,error=%e,"peer connection failed");}}
    } None
}

fn connect_and_handshake(addr:SocketAddr,timeout:Duration)->Result<TcpStream>{
    let mut stream=connect_with_timeout(addr,timeout)?;
    let local=SocketAddr::from(([0,0,0,0],0));
    send_message::<_,Ycash256>(&mut stream,"version",&version_payload(NODE_NETWORK,addr,local,rand_nonce(),"/yortal:0.23/",0))?;
    let (cmd,_)=recv_message::<_,Ycash256>(&mut stream)?; if cmd!="version"{bail!("expected version, got {cmd}");}
    send_message::<_,Ycash256>(&mut stream,"verack",&[])?; let (cmd,_)=recv_message::<_,Ycash256>(&mut stream)?; if cmd!="verack"{bail!("expected verack, got {cmd}");}
    Ok(stream)
}
fn rand_nonce()->u64{use std::time::{SystemTime,UNIX_EPOCH};SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos() as u64}
fn parse_headers_message(payload:&[u8],start_height:u64)->Result<Vec<BlockHeader>>{let mut c=Cursor::new(payload);let count=read_compact_size(&mut c)?;let mut out=Vec::with_capacity(count as usize);for i in 0..count{let h=read_header_at(&mut c,start_height+i)?;if read_compact_size(&mut c)?!=0{bail!("headers message unexpectedly carried transactions")}out.push(h)}Ok(out)}
fn header_at(state:&State,height:u64)->Result<Option<BlockHeader>>{match state.header_by_height(height)?{Some(raw)=>Ok(Some(read_header_at(&mut Cursor::new(raw.as_slice()),height)?)),None=>Ok(None)}}
fn header_history(state:&State,next_height:u64)->Result<(u64,Vec<BlockHeader>)>{if next_height==0{return Ok((0,Vec::new()))}let end=next_height-1;let start=end.saturating_sub(27);let mut out=Vec::new();for h in start..=end{if h==0{out.push(BlockHeader{version:4,prev:[0;32],merkle:[0;32],light_client_root:[0;32],time:GENESIS_TIME,bits:GENESIS_BITS,nonce:[0;32],solution:Vec::new()});continue}let raw=state.header_by_height(h)?.ok_or_else(||anyhow!("missing header {h} for difficulty context"))?;out.push(read_header_at(&mut Cursor::new(raw.as_slice()),h)?)}Ok((start,out))}
fn median_time_past(history:&[BlockHeader],start:u64,end:u64)->u32{let first=end.saturating_sub((POW_MEDIAN_BLOCK_SPAN-1) as u64).max(start);let a=(first-start) as usize;let b=(end-start+1) as usize;if a>=history.len()||b>history.len()||a>=b{return history.last().map(|h|h.time).unwrap_or(0)}let mut t:Vec<u32>=history[a..b].iter().map(|h|h.time).collect();t.sort_unstable();t[t.len()/2]}
fn validate_header_against_state(state:&State,header:&BlockHeader,height:u64)->Result<()>{let prev=header_at(state,height-1)?.ok_or_else(||anyhow!("missing prev header"))?;let(s,h)=header_history(state,height)?;let mtp=median_time_past(&h,s,height-1);validate_header(header,height,&prev,mtp,s,&h).map_err(|e|anyhow!("{e:?}"))}
fn local_median_time_past(state:&State,height:u64)->u32{let start=height.saturating_sub(11).max(1);let mut t=Vec::new();for h in start..height{if let Ok(Some(x))=header_at(state,h){t.push(x.time)}}if t.is_empty(){return GENESIS_TIME}t.sort_unstable();t[t.len()/2]}
fn accumulate_work(state:&State,prev_height:u64,work:&[u8;32])->[u8;32]{let prev=state.header_work_by_height(prev_height).ok().flatten().and_then(|v|v.try_into().ok()).unwrap_or([0;32]);add_work(&prev,work)}
fn validate_block_only(state:&State,raw:&[u8],height:u64,proof_batch:&mut ProofBatch)->Result<BlockCommit>{
    let block=read_block_at_height(raw,height)?;
    let mtp=local_median_time_past(state,height);
    let ctx=Context{height,prev_height:height.saturating_sub(1),median_time_past:mtp};
    // This is the complete stateless consensus entry point. It covers block
    // context, transaction rules, Sprout JoinSplit signatures/proofs, and
    // Sapling transaction checks/proofs (queued into proof_batch).
    let (validated,parsed_txs)=validate_for_commit_batched_with_parsed(raw,ctx,false,proof_batch)
        .map_err(|e|anyhow!("{e:?}"))?;
    if validated.txs.len()!=parsed_txs.len() {
        bail!("consensus decoder returned inconsistent transaction data at height {height}");
    }
    let prev=state.header_hash_by_height(height.saturating_sub(1))?
        .ok_or_else(||anyhow!("missing previous header hash"))?;
    let prev:[u8;32]=prev.try_into().map_err(|_|anyhow!("invalid previous hash length"))?;
    let work=state.header_work_by_height(height)?
        .ok_or_else(||anyhow!("missing cumulative work"))?;
    let work:[u8;32]=work.try_into().map_err(|_|anyhow!("invalid work length"))?;
    let hash=validated.header.hash();
    let txs=validated.txs.iter().map(|t|(txid(t),t.clone())).collect();
    let precomputed_txs=parsed_txs.iter().map(|t| if t.overwintered { ycash_script::PrecomputedTxData::new(t) } else { ycash_script::PrecomputedTxData::new(t) }).collect();
    Ok(BlockCommit{height,hash,prev,work,raw:raw.to_vec(),txs,parsed_txs,precomputed_txs,proofs_verified:true})
}

fn resource_sample(bytes:u64,elapsed:Duration,buffered_ranges:usize,pipeline:&Arc<Mutex<PipelineEngine>>)->ResourceSample{
    let secs=elapsed.as_secs_f64().max(0.001);
    let net=(bytes as f64/secs/5_000_000.0).min(1.0);
    let (cpu,memory)=(read_cpu_pressure(),read_memory_pressure());
    let (validation,db)={
        let p=pipeline.lock().unwrap();
        let s=p.snapshot();
        let v=if s.window==0{0.0}else{buffered_ranges as f64/(s.workers.max(1) as f64)};
        // A bounded commit-latency proxy keeps the controller sensitive to a
        // saturated SQLite writer without pretending SQLite exposes a queue.
        let d=(elapsed.as_secs_f64()/0.250).min(1.0);
        (v.min(1.0),d)
    };
    ResourceSample{cpu_ratio:cpu,memory_ratio:memory,db_queue_ratio:db,network_ratio:net,validation_queue_ratio:validation}
}
fn read_cpu_pressure()->f64{
    if let Ok(s)=std::fs::read_to_string("/proc/loadavg"){if let Some(v)=s.split_whitespace().next().and_then(|x|x.parse::<f64>().ok()){return (v/(std::thread::available_parallelism().map(|n|n.get()).unwrap_or(1) as f64)).min(1.0)}} 0.0
}
fn read_memory_pressure()->f64{
    if let Ok(s)=std::fs::read_to_string("/proc/meminfo"){let mut total=0f64;let mut avail=0f64;for l in s.lines(){let mut p=l.split_whitespace();match p.next(){Some("MemTotal:")=>total=p.next().and_then(|x|x.parse().ok()).unwrap_or(0.0),Some("MemAvailable:")=>avail=p.next().and_then(|x|x.parse().ok()).unwrap_or(0.0),_=>{}}}if total>0.0{return (1.0-avail/total).clamp(0.0,1.0)}}0.0
}
