# Adaptive CI Contract

The pipeline is adaptive. CI must not require fixed worker counts, fixed
in-flight counts, or a fixed batch schedule.

Required safety invariants:
- adaptive worker/in-flight decisions remain bounded by configured safety limits;
- a scheduled range may not overlap another scheduled range;
- ranges must not be duplicated;
- consensus validation and ordered state commitment remain intact;
- the maximum range length is bounded by the configured adaptive ceiling (100 blocks in v0.30.7);
- 1..100 range sizes are valid; CI must not require a fixed range size such as 16;
- adaptive decisions may respond to CPU, memory, database and validation pressure.

CI should verify these invariants rather than asserting a specific worker count,
specific in-flight count, or fixed sequence of batch sizes.
