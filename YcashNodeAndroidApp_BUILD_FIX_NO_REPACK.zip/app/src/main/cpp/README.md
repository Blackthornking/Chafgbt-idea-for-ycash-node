# Real Ycash node integration

The Ycash v4.5.0 source is included under `ycashd/ycash-4.5.0/`.

Important: this is the actual `ycashd` source tree, not a lightwallet client. The Android
wrapper does not claim a mainnet-synchronizing node until the native binary is successfully
cross-compiled with the Android NDK and run on-device.

Build order:
1. Prove the supplied source builds as `ycashd` on a host.
2. Cross-compile the daemon and required libraries for Android/arm64.
3. Package the resulting native executable/library.
4. Start it from NodeController with an app-private data directory.
5. Test peer discovery and sync independently of Yodl.
