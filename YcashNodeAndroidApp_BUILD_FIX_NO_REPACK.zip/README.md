# Ycash Node Standalone v0.2

This package is the standalone Android node project plus the supplied **Ycash 4.5.0 full-node
source tree**.

The node is intentionally independent of Yodl and lightwalletd.

## What is real
- Ycash 4.5.0 `ycashd` source is included.
- The source contains the daemon entry point and P2P/validation/RPC/chain-storage code.
- Android node UI/data-directory lifecycle shell is included.

## What remains before a real Android mainnet node
The C++/Rust daemon must be cross-compiled with Android NDK and its native dependencies.
This package does not falsely claim that an APK is already a synchronized mainnet node.

## Test gates
1. Host `ycashd` build.
2. Android arm64 cross-build.
3. On-device daemon launch.
4. P2P peer discovery.
5. Header/block synchronization.
6. Restart/resume.
7. Independent chain-height/hash verification.
8. Only then connect YTeleport.
