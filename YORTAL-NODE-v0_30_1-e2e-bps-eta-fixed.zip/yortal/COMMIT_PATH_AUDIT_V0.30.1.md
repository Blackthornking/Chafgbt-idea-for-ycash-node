# YORTAL v0.30.1 — SQLite commit path audit and telemetry fix

## Finding
The Android dashboard value previously labelled `AVG DB COMMIT` was the average wall-clock duration of the entire `State::commit_blocks_batch()` call. It was **not** the time spent inside SQLite `Transaction::commit()`.

The commit path is ordered and stateful. The complete call includes:

1. canonical parent state loading and state validation;
2. optional reorg rollback SQL;
3. block/transaction/Sapling/nullifier/UTXO/Sprout database writes;
4. the final `tx.commit()` call.

The source already measured these phases individually, but the Android status API only accumulated the total commit duration. This made a value such as ~787 ms look like an SQLite durability/flush time when it could actually be dominated by state validation or row/index writes.

## Changes made
- `State::commit_blocks_batch()` now starts its state-validation timer after the SQLite connection and transaction have been acquired. The existing total timer remains end-to-end.
- Android runtime state now accumulates separate totals for:
  - complete commit call;
  - state validation;
  - rollback/reorg SQL;
  - DB row/UTXO/Sprout writes;
  - actual SQLite `Transaction::commit()`.
- The status JSON exposes all cumulative phase totals plus the last complete commit duration.
- The Processing panel now shows:
  - AVG VALIDATION (stateless validation);
  - AVG TOTAL COMMIT;
  - AVG STATE;
  - AVG DB WRITE;
  - AVG SQLITE;
  - AVG ROLLBACK.
- The last-commit diagnostic explicitly labels each phase.

## What this deliberately does NOT change
- Consensus rules.
- Ordered commit semantics.
- SQLite WAL mode.
- SQLite `synchronous=NORMAL`.
- Commit batch size.
- Worker count/lookahead.
- Reorg behaviour.

These are intentionally left unchanged until a real device run identifies the dominant phase.

## Interpretation for the next device run
If `AVG SQLITE` is small while `AVG STATE` is large, optimize state/UTXO/Sapling lookups rather than SQLite durability.

If `AVG DB WRITE` dominates, inspect row counts and index maintenance.

If `AVG SQLITE` itself dominates, then investigate Android flash/WAL checkpointing and SQLite durability cost.

The ~787 ms figure from the previous screenshot cannot by itself distinguish these cases.
