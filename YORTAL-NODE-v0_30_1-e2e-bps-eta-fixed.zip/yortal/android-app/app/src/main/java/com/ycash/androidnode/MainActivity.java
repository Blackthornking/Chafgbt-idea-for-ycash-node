package com.ycash.androidnode;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.StatFs;
import android.content.Intent;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.view.View;
import android.widget.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.*;
import java.util.Locale;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.json.JSONObject;
import android.content.SharedPreferences;

/**
 * Dedicated Ycash node monitor/control surface. Wallet UI intentionally excluded.
 *
 * This Activity talks only to the local status API (127.0.0.1:8834) and does not
 * open a gRPC channel itself. The node's YWallet-compatible lightwalletd surface
 * lives in crates/ycash-android-node and is documented here for CI diagnostics:
 *   - Service/method: CompactTxStreamer/GetLatestBlock
 *   - Content-Type: application/grpc
 *   - Negotiated header: grpc-accept-encoding
 *   - HTTP/2 stream teardown: RST_STREAM
 *   - HTTP/2 connection teardown: GOAWAY
 */
public class MainActivity extends Activity {
    TextView status, peer, height, headersHeight, targetHeight, blocksBehind, sync, syncPercent,
        endToEndRate, eta,
        pipelineState, pipelineWindow, inFlight, validationQueue, batchSize, headersRate, blocksRate,
        downloadRate, validationRate, commitRate, rxRate, avgValidation, avgCommit, avgState, avgDbWrite, avgSqlite, avgRollback, lastBlock,
        activeWorkers, verifyingJobs, bufferedRanges, commitBreakdown, rangesCompleted, rangesRetried, rangesQuarantined, lastCommit, pipelineDiagnostic,
        uptime, dbSize, freeStorage, networkType, listeners, connectionSource, connectionEndpoint,
        connectionDetail, diagnostics, log, nodeLog, exportStatus;
    ProgressBar syncProgress;
    View advancedSection;
    Button toggleAdvanced;
    Handler handler = new Handler();
    boolean running = false, advancedShown = false;
    SharedPreferences prefs;
    int consecutiveFailures = 0;
    static final int FAILURE_THRESHOLD = 5;
    long lastPollAt = 0;
    long lastHeight = -1, lastHeaders = -1, lastBlocks = -1, lastValidated = -1, lastHeaderBytes = -1, lastBlockBytes = -1, lastCommits = -1;
    String lastLogMessage = "", lastLogDetail = "", lastLogError = "";
    long lastLoggedHeight = -1, lastLoggedHeaders = -1, lastLoggedBlocks = -1, lastLoggedInFlight = -1;
    static final int NODE_LOG_MAX_LINES = 250;
    static final long NODE_LOG_MAX_BYTES = 256 * 1024;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        final Thread.UncaughtExceptionHandler previousHandler =
            Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            writeAppError("UNCAUGHT EXCEPTION", throwable);
            android.util.Log.e("YcashNode", "UNCAUGHT EXCEPTION", throwable);
            if (previousHandler != null) {
                previousHandler.uncaughtException(thread, throwable);
            }
        });

        setContentView(R.layout.activity_main);
        bind();
        prefs=getSharedPreferences("ycash_node",MODE_PRIVATE);

        toggleAdvanced.setOnClickListener(v -> {
            try {
                advancedShown = !advancedShown;
                if (advancedSection != null) {
                    advancedSection.setVisibility(
                        advancedShown ? View.VISIBLE : View.GONE
                    );
                }
                if (toggleAdvanced != null) {
                    toggleAdvanced.setText(
                        advancedShown ? "Hide diagnostics" : "Show diagnostics"
                    );
                }
                if (advancedShown) {
                    refreshDeviceStatsSafe();
                    refreshNodeLog();
                    refreshAppErrorLog();
                }
            } catch (Throwable t) {
                writeAppError("DIAGNOSTICS CLICK", t);
                safeSetText(log, "Diagnostics error: " +
                    t.getClass().getSimpleName() + " — " +
                    String.valueOf(t.getMessage()));
            }
        });

        findViewById(R.id.start).setOnClickListener(v -> {
            prefs.edit().putString(NodeService.PREF_MANUAL_PEER,
                    ((EditText)findViewById(R.id.manualPeer)).getText().toString().trim()).apply();
            Intent i=new Intent(this,NodeService.class); i.setAction(NodeService.START);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            running=true; consecutiveFailures=0; resetRates();
            status.setText("STARTING"); log.setText("Node: start requested; waiting for :8834/status");
            appendNodeLog(new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date()) + " | NODE START requested");
            pollStatus();
        });
        findViewById(R.id.stop).setOnClickListener(v -> {
            Intent i=new Intent(this,NodeService.class); i.setAction(NodeService.STOP); startService(i);
            running=false; status.setText("STOPPED"); sync.setText("Stopped");
            pipelineState.setText("IDLE"); log.setText("Node: stop requested"); resetRates();
            appendNodeLog(new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date()) + " | NODE STOP requested");
            activeWorkers.setText("0"); lastCommit.setText("never this run"); lastCommit.setTextColor(0xFF667085);
        });
        findViewById(R.id.test).setOnClickListener(v -> testNetwork());
        findViewById(R.id.exportChain).setOnClickListener(v -> startExportChain());
    }

    private void bind() {
        status=findViewById(R.id.status); peer=findViewById(R.id.peer); height=findViewById(R.id.height);
        headersHeight=findViewById(R.id.headersHeight); targetHeight=findViewById(R.id.targetHeight);
        blocksBehind=findViewById(R.id.blocksBehind); sync=findViewById(R.id.sync); syncPercent=findViewById(R.id.syncPercent);
        syncProgress=findViewById(R.id.syncProgress);
        endToEndRate=findViewById(R.id.endToEndRate); eta=findViewById(R.id.eta); pipelineState=findViewById(R.id.pipelineState);
        pipelineWindow=findViewById(R.id.pipelineWindow); inFlight=findViewById(R.id.inFlight);
        validationQueue=findViewById(R.id.validationQueue); batchSize=findViewById(R.id.batchSize);
        headersRate=findViewById(R.id.headersRate); blocksRate=findViewById(R.id.blocksRate);
        downloadRate=findViewById(R.id.downloadRate); validationRate=findViewById(R.id.validationRate);
        commitRate=findViewById(R.id.commitRate); rxRate=findViewById(R.id.rxRate);
        avgValidation=findViewById(R.id.avgValidation); avgCommit=findViewById(R.id.avgCommit); avgState=findViewById(R.id.avgState); avgDbWrite=findViewById(R.id.avgDbWrite); avgSqlite=findViewById(R.id.avgSqlite); avgRollback=findViewById(R.id.avgRollback);
        lastBlock=findViewById(R.id.lastBlock); uptime=findViewById(R.id.uptime);
        activeWorkers=findViewById(R.id.activeWorkers); verifyingJobs=findViewById(R.id.verifyingJobs); bufferedRanges=findViewById(R.id.bufferedRanges); commitBreakdown=findViewById(R.id.commitBreakdown); rangesCompleted=findViewById(R.id.rangesCompleted);
        rangesRetried=findViewById(R.id.rangesRetried); rangesQuarantined=findViewById(R.id.rangesQuarantined);
        lastCommit=findViewById(R.id.lastCommit);
        pipelineDiagnostic=findViewById(R.id.pipelineDiagnostic);
        dbSize=findViewById(R.id.dbSize); freeStorage=findViewById(R.id.freeStorage); networkType=findViewById(R.id.networkType);
        listeners=findViewById(R.id.listeners); connectionSource=findViewById(R.id.connectionSource);
        connectionEndpoint=findViewById(R.id.connectionEndpoint); connectionDetail=findViewById(R.id.connectionDetail);
        diagnostics=findViewById(R.id.diagnostics); log=findViewById(R.id.log); exportStatus=findViewById(R.id.exportStatus);
        nodeLog=findViewById(R.id.nodeLog);
        loadNodeLog();
        toggleAdvanced=findViewById(R.id.toggleAdvanced);
        findViewById(R.id.clearNodeLog).setOnClickListener(v -> clearNodeLog());
        EditText manualPeer=findViewById(R.id.manualPeer);
        manualPeer.setText(prefsOrDefault(NodeService.PREF_MANUAL_PEER,""));
    }

    private String prefsOrDefault(String k,String d){ return getSharedPreferences("ycash_node",MODE_PRIVATE).getString(k,d); }
    private void resetRates(){ lastPollAt=0; lastHeight=lastHeaders=lastBlocks=lastValidated=lastHeaderBytes=lastBlockBytes=lastCommits=-1; }

    private void pollStatus(){
        if(!running)return;
        new Thread(() -> {
            try{
                HttpURLConnection c=(HttpURLConnection)new URL("http://127.0.0.1:8834/status").openConnection();
                c.setConnectTimeout(1500); c.setReadTimeout(1500); c.setRequestMethod("GET");
                if(c.getResponseCode()==200){
                    BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));
                    StringBuilder s=new StringBuilder(); String line; while((line=br.readLine())!=null)s.append(line);
                    JSONObject j=new JSONObject(s.toString()); runOnUiThread(() -> applyStatus(j));
                }
                c.disconnect();
            }catch(Exception e){
                consecutiveFailures++;
                if(consecutiveFailures==FAILURE_THRESHOLD) runOnUiThread(() -> {
                    status.setText("NODE NOT RESPONDING"); log.setText("No response from status API :8834");
                    appendNodeLog(new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date()) +
                        " | ERROR: status API :8834 not responding");
                });
            }
            handler.postDelayed(this::pollStatus,2000);
        }).start();
    }

    private void applyStatus(JSONObject j){
        try{
            consecutiveFailures=0;
            long now=System.currentTimeMillis(); double dt=lastPollAt>0?(now-lastPollAt)/1000.0:0;
            long h=j.optLong("height",-1), hh=j.optLong("headers_height",-1), blocks=j.optLong("blocks_received",0);
            long hb=j.optLong("header_bytes_received",0), bb=j.optLong("block_bytes_received",0), commits=j.optLong("db_commits",0);
            status.setText(j.optString("status","unknown").toUpperCase(Locale.US));
            peer.setText(String.valueOf(j.optInt("peers",0)));
            height.setText(h<0?"—":formatLong(h)); headersHeight.setText(hh<0?"—":formatLong(hh));
            long target=j.optLong("target_height",-1); targetHeight.setText(target<0?"—":formatLong(target));
            long behind=(h>=0&&target>=0)?Math.max(0,target-h):0; blocksBehind.setText(formatLong(behind));
            double endBps=j.optDouble("end_to_end_bps",0.0); endToEndRate.setText(endBps>0?String.format(Locale.US,"%.2f blocks/s",endBps):"— blocks/s");
            long etaSeconds=j.isNull("eta_seconds")?-1:j.optLong("eta_seconds",-1); eta.setText(etaSeconds>=0?formatDuration(etaSeconds):"Calculating…");
            String syncText=j.optString("sync","unknown"); sync.setText(syncText);
            // Blocks progress with 2 decimals (1,760 of 3M used to round to "0%");
            // headers progress kept alongside. Bar has 10000 steps (0.01%).
            double blockPct=(target>0&&h>=0)?Math.min(100.0,Math.max(0.0,h*100.0/target)):0.0;
            double headerPct=(target>0&&hh>=0)?Math.min(100.0,Math.max(0.0,hh*100.0/target)):0.0;
            syncProgress.setProgress((int)Math.round(blockPct*100.0));
            syncPercent.setText(String.format(Locale.US,"%.2f%% · hdr %.2f%%",blockPct,headerPct));
            pipelineState.setText(behind>0?"ACTIVE · FETCH / VALIDATE / COMMIT":"LIVE · READY");
            pipelineWindow.setText(formatLong(j.optLong("current_window",0)));
            inFlight.setText(formatLong(j.optLong("blocks_in_flight",0)));
            validationQueue.setText(formatLong(j.optLong("validation_queue",0)));
            batchSize.setText(formatLong(j.optLong("batch_size",0)));
            activeWorkers.setText(formatLong(j.optLong("active_block_workers",0)));
            verifyingJobs.setText(formatLong(j.optLong("verifying_jobs",0)));
            bufferedRanges.setText(formatLong(j.optLong("buffered_ranges",0)));
            String pipelineMessage=j.optString("message","");
            String pipelineError=j.optString("last_error","");
            String pd=!pipelineError.isEmpty()?"Pipeline error: "+pipelineError:(!pipelineMessage.isEmpty()?"Pipeline: "+pipelineMessage:"Pipeline diagnostic: waiting");
            pipelineDiagnostic.setText(pd);
            pipelineDiagnostic.setTextColor(!pipelineError.isEmpty()?0xFFB42318:0xFF667085);
            long retried=j.optLong("retried_ranges",0), quarantined=j.optLong("quarantined_ranges",0);
            rangesCompleted.setText(formatLong(j.optLong("completed_ranges",0)));
            rangesRetried.setText(formatLong(retried));
            rangesQuarantined.setText(formatLong(quarantined));
            // A worker retries a range when a peer times out or misbehaves mid-claim; that's
            // normal on a weak connection. A nonzero quarantined count means a range hit the
            // retry limit with no peer able to serve it -- the chain is genuinely stuck behind
            // it until a different peer becomes available, independent of headers still moving.
            rangesQuarantined.setTextColor(quarantined>0?0xFFB42318:0xFF111827);
            if(dt>0){
                headersRate.setText(rate(hh,lastHeaders,dt,"headers/s"));
                blocksRate.setText(rate(blocks,lastBlocks,dt,"blocks/s"));
                downloadRate.setText(byteRate(bb,lastBlockBytes,dt));
                validationRate.setText(rate(j.optLong("blocks_validated",0),lastValidated,dt,"valid/s"));
                commitRate.setText(rate(commits,lastCommits,dt,"commits/s"));
                rxRate.setText(byteRate(hb+bb,(lastHeaderBytes<0||lastBlockBytes<0)?-1:lastHeaderBytes+lastBlockBytes,dt));
            }
            long valCount=j.optLong("blocks_validated",0), valMs=j.optLong("validation_ms_total",0);
            long commitCount=j.optLong("db_commits",0), commitMs=j.optLong("db_commit_ms_total",0);
            long stateMsTotal=j.optLong("state_validation_ms_total",0);
            long rollbackMsTotal=j.optLong("rollback_ms_total",0);
            long dbWriteMsTotal=j.optLong("db_write_ms_total",0);
            long sqliteCommitMsTotal=j.optLong("sqlite_commit_ms_total",0);
            avgValidation.setText(valCount>0?String.format(Locale.US,"%.1f ms",(double)valMs/valCount):"—");
            avgCommit.setText(commitCount>0?String.format(Locale.US,"%.1f ms",(double)commitMs/commitCount):"—");
            avgState.setText(commitCount>0?String.format(Locale.US,"%.1f ms",(double)stateMsTotal/commitCount):"—");
            avgDbWrite.setText(commitCount>0?String.format(Locale.US,"%.1f ms",(double)dbWriteMsTotal/commitCount):"—");
            avgSqlite.setText(commitCount>0?String.format(Locale.US,"%.1f ms",(double)sqliteCommitMsTotal/commitCount):"—");
            avgRollback.setText(commitCount>0?String.format(Locale.US,"%.1f ms",(double)rollbackMsTotal/commitCount):"—");
            commitBreakdown.setText(String.format(Locale.US,"Last commit: total %d ms · state %d ms · DB write %d ms · SQLite commit %d ms · rollback %d ms",
                j.optLong("last_total_commit_ms",0), j.optLong("last_state_validation_ms",0), j.optLong("last_db_write_ms",0), j.optLong("last_sqlite_commit_ms",0), j.optLong("last_rollback_ms",0)));
            long tipTime=j.optLong("tip_time",0); lastBlock.setText(tipTime>0?formatDuration(Math.max(0,System.currentTimeMillis()/1000-tipTime))+" ago":"—");
            // tip_time is the *committed* block's own header timestamp (a consensus field, not
            // wall-clock), so on a chain that's still far behind it stays old no matter how fast
            // sync is actually going. last_commit_unix is wall-clock time of the last successful
            // DB commit, which is what actually tells you whether the pipeline is stuck right now
            // -- this is the number that stays frozen in exactly the "headers moving, blocks not"
            // case that prompted adding this panel.
            long lastCommitUnix=j.optLong("last_commit_unix",0);
            if(lastCommitUnix<=0){
                lastCommit.setText("never this run");
                lastCommit.setTextColor(0xFF667085);
            }else{
                long secsSince=Math.max(0,System.currentTimeMillis()/1000-lastCommitUnix);
                lastCommit.setText(formatDuration(secsSince)+" ago");
                lastCommit.setTextColor(secsSince>120?0xFFB42318:0xFF111827);
            }
            uptime.setText(formatDuration(Math.max(0,j.optLong("uptime_seconds",0))));
            listeners.setText("P2P 8833 "+up(j.optBoolean("p2p_listening"))+"   RPC 8832 "+up(j.optBoolean("rpc_listening"))+"   API 8834 "+up(j.optBoolean("api_listening"))+"   YWallet gRPC 9067 "+up(j.optBoolean("lightwallet_listening")));
            connectionSource.setText(j.optString("connection_source","None"));
            connectionEndpoint.setText(j.optString("connection_endpoint","—"));
            connectionDetail.setText(j.optString("connection_detail","—"));
            diagnostics.setText("Outbound: "+j.optLong("outbound_attempts",0)+" attempts / "+j.optLong("outbound_handshakes",0)+" handshakes\n"+
                "Inbound: "+j.optLong("inbound_connections",0)+"   Known peers: "+j.optLong("known_peers",0)+"\n"+
                "Validated: "+j.optLong("blocks_validated",0)+" blocks   Indexed: "+j.optLong("txs_indexed",0)+" txs\n"+
                "Last block: "+formatBytes(j.optLong("last_block_bytes",0))+"   Last height: "+j.optLong("last_block_height",0)+"\n"+
                "Last error: "+j.optString("last_error","—"));
            log.setText(j.optString("message","status updated"));
            lastPollAt=now; lastHeight=h; lastHeaders=hh; lastBlocks=blocks; lastValidated=j.optLong("blocks_validated",0); lastHeaderBytes=hb; lastBlockBytes=bb; lastCommits=commits;
            if(advancedShown)refreshDeviceStats();
        }catch(Exception ignored){}
    }


    /**
     * The node already exposes live diagnostics through /status. Keep a small
     * persistent operator log in the Android app so connection, header-sync and
     * block-pipeline failures remain visible even when the Rust process does not
     * have a console attached.
     */
    private File nodeLogFile() {
        return new File(getFilesDir(), "node-live.log");
    }

    private void loadNodeLog() {
        try {
            File f = nodeLogFile();
            if (!f.exists()) {
                nodeLog.setText("Node log is empty. Start the node to capture live events.");
                return;
            }
            String text = readTextFile(f);
            nodeLog.setText(trimLogLines(text));
        } catch (Throwable t) {
            nodeLog.setText("Unable to read node log: " + t.getMessage());
            writeAppError("NODE LOG READ", t);
        }
    }

    private void appendNodeLog(String line) {
        try {
            File f = nodeLogFile();
            String old = f.exists() ? readTextFile(f) : "";
            String text = trimLogLines(old + line + "\n");
            writeTextFile(f, text);
            safeSetText(nodeLog, text);
        } catch (Throwable t) {
            safeSetText(nodeLog, "Node log write error: " + t.getMessage());
            writeAppError("NODE LOG WRITE", t);
        }
    }

    private String trimLogLines(String text) {
        String[] lines = text.split("\\r?\\n");
        int start = Math.max(0, lines.length - NODE_LOG_MAX_LINES);
        StringBuilder out = new StringBuilder();
        for (int i = start; i < lines.length; i++) {
            if (lines[i].length() == 0 && i == lines.length - 1) continue;
            out.append(lines[i]).append("\n");
        }
        String result = out.toString();
        while (result.getBytes().length > NODE_LOG_MAX_BYTES && result.length() > 0) {
            int nl = result.indexOf('\n');
            if (nl < 0) return "";
            result = result.substring(nl + 1);
        }
        return result;
    }

    private String readTextFile(File f) throws IOException {
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = r.readLine()) != null) b.append(line).append("\n");
        }
        return b.toString();
    }

    private void writeTextFile(File f, String text) throws IOException {
        try (FileWriter w = new FileWriter(f, false)) { w.write(text); }
    }

    private void clearNodeLog() {
        try {
            writeTextFile(nodeLogFile(), "");
            safeSetText(nodeLog, "Node log cleared.");
        } catch (Throwable t) {
            safeSetText(nodeLog, "Unable to clear node log: " + t.getMessage());
            writeAppError("NODE LOG CLEAR", t);
        }
    }

    private void logStatusEvent(JSONObject j) {
        try {
            String message = j.optString("message", "");
            String detail = j.optString("connection_detail", "");
            String error = j.optString("last_error", "");
            long h = j.optLong("height", 0);
            long hh = j.optLong("headers_height", 0);
            long blocks = j.optLong("blocks_received", 0);
            long in = j.optLong("blocks_in_flight", 0);
            boolean changed = !message.equals(lastLogMessage)
                || !detail.equals(lastLogDetail)
                || !error.equals(lastLogError)
                || h != lastLoggedHeight
                || hh != lastLoggedHeaders
                || blocks != lastLoggedBlocks
                || in != lastLoggedInFlight;
            if (!changed) return;

            StringBuilder line = new StringBuilder();
            line.append(new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date()));
            line.append(" | height=").append(h)
                .append(" headers=").append(hh)
                .append(" in_flight=").append(in)
                .append(" blocks=").append(blocks);
            if (!message.isEmpty()) line.append(" | ").append(message);
            if (!detail.isEmpty()) line.append(" | ").append(detail);
            if (!error.isEmpty()) line.append(" | ERROR: ").append(error);
            appendNodeLog(line.toString());

            lastLogMessage = message;
            lastLogDetail = detail;
            lastLogError = error;
            lastLoggedHeight = h;
            lastLoggedHeaders = hh;
            lastLoggedBlocks = blocks;
            lastLoggedInFlight = in;
        } catch (Throwable t) {
            writeAppError("NODE STATUS LOG", t);
        }
    }

    private String up(boolean v){return v?"UP":"DOWN";}
    private String rate(long now,long prev,double dt,String unit){ if(prev<0||now<prev)return"—"; return String.format(Locale.US,"%.1f %s",(now-prev)/dt,unit); }
    private String byteRate(long now,long prev,double dt){ if(prev<0||now<prev)return"—"; return formatBytesPerSecond((now-prev)/dt); }
    private String formatBytesPerSecond(double v){ if(v<1024)return String.format(Locale.US,"%.0f B/s",v); if(v<1024*1024)return String.format(Locale.US,"%.1f KB/s",v/1024); return String.format(Locale.US,"%.2f MB/s",v/(1024*1024)); }
    private String formatLong(long v){return String.format(Locale.US,"%,d",v);}
    private static String formatDuration(long s){long h=s/3600,m=(s%3600)/60,sec=s%60;if(h>0)return h+"h "+m+"m";if(m>0)return m+"m "+sec+"s";return sec+"s";}
    private static String formatBytes(long b){if(b<1024)return b+" B";if(b<1024*1024)return String.format(Locale.US,"%.1f KB",b/1024.0);if(b<1024*1024*1024)return String.format(Locale.US,"%.1f MB",b/(1024.0*1024));return String.format(Locale.US,"%.2f GB",b/(1024.0*1024*1024));}

    private void refreshDeviceStatsSafe(){
        safeSetText(dbSize, "Database: checking…");
        safeSetText(freeStorage, "Free storage: checking…");
        safeSetText(networkType, "Network: checking…");

        try {
            File db = new File(getFilesDir(), "ycash-node.sqlite");
            safeSetText(dbSize, db.exists() ? formatBytes(db.length()) : "—");
        } catch (Throwable t) {
            safeSetText(dbSize, "Database: ERROR " + t.getClass().getSimpleName());
            writeAppError("DATABASE DIAGNOSTIC", t);
        }

        try {
            StatFs s = new StatFs(getFilesDir().getAbsolutePath());
            safeSetText(freeStorage, formatBytes(s.getAvailableBytes()));
        } catch (Throwable t) {
            safeSetText(freeStorage, "Storage: ERROR " + t.getClass().getSimpleName());
            writeAppError("STORAGE DIAGNOSTIC", t);
        }

        try {
            ConnectivityManager cm =
                (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities c = cm == null ? null :
                cm.getNetworkCapabilities(cm.getActiveNetwork());
            String network = c == null ? "None" :
                c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi" :
                c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "Mobile" :
                "Other";
            safeSetText(networkType, network);
        } catch (Throwable t) {
            safeSetText(networkType, "Network: ERROR " + t.getClass().getSimpleName());
            writeAppError("NETWORK DIAGNOSTIC", t);
        }
    }

    // Kept as a compatibility wrapper for any existing callers.
    private void refreshDeviceStats(){
        refreshDeviceStatsSafe();
    }

    private void refreshNodeLog(){
        readDiagnosticFile(new File(getFilesDir(), "node.log"), "node.log", true);
    }

    private void refreshAppErrorLog(){
        readDiagnosticFile(new File(getFilesDir(), "app-error.log"), "app-error.log", false);
    }

    private void readDiagnosticFile(final File file, final String label, final boolean putInLog){
        new Thread(() -> {
            try {
                if (!file.exists()) {
                    if (putInLog) {
                        runOnUiThread(() -> safeSetText(log, label + ": not created yet"));
                    } else {
                        runOnUiThread(() -> safeSetText(diagnostics,
                            diagnosticsText() + "\n\n" + label + ": not created yet"));
                    }
                    return;
                }

                StringBuilder out = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                    String line;
                    int lines = 0;
                    while ((line = br.readLine()) != null) {
                        out.append(line).append('\n');
                        if (++lines >= 300) {
                            out.append("\n… log truncated at 300 lines …\n");
                            break;
                        }
                    }
                }

                String text = out.length() == 0 ? label + ": empty" : out.toString();
                if (putInLog) {
                    runOnUiThread(() -> safeSetText(log, text));
                } else {
                    runOnUiThread(() -> safeSetText(diagnostics,
                        diagnosticsText() + "\n\n===== " + label + " =====\n" + text));
                }
            } catch (Throwable t) {
                writeAppError("READ " + label, t);
                runOnUiThread(() -> {
                    if (putInLog) {
                        safeSetText(log, label + ": ERROR " +
                            t.getClass().getSimpleName() + " — " +
                            String.valueOf(t.getMessage()));
                    }
                });
            }
        }, "ycash-diagnostics").start();
    }

    private String diagnosticsText(){
        try {
            return diagnostics == null ? "" : String.valueOf(diagnostics.getText());
        } catch (Throwable ignored) {
            return "";
        }
    }

    private void safeSetText(final TextView view, final String text){
        try {
            if (view != null) view.setText(text);
        } catch (Throwable ignored) {
        }
    }

    private void writeAppError(String where, Throwable t){
        try {
            File file = new File(getFilesDir(), "app-error.log");
            try (FileWriter w = new FileWriter(file, true)) {
                w.write("\n===== " + System.currentTimeMillis() + " =====\n");
                w.write(where + "\n");
                w.write(t.toString() + "\n");
                StringWriter sw = new StringWriter();
                PrintWriter pw = new PrintWriter(sw);
                t.printStackTrace(pw);
                pw.flush();
                w.write(sw.toString());
                w.write("\n");
            }
        } catch (Throwable ignored) {
        }
    }

    private void testNetwork(){
        new Thread(() -> { long t=System.currentTimeMillis(); try{HttpURLConnection c=(HttpURLConnection)new URL("http://127.0.0.1:8834/status").openConnection();c.setConnectTimeout(3000);c.setReadTimeout(3000);int code=c.getResponseCode();c.disconnect();runOnUiThread(() -> log.setText("Status API: HTTP "+code+" · "+(System.currentTimeMillis()-t)+" ms"));}catch(Exception e){runOnUiThread(() -> log.setText("Status API test failed: "+e.getClass().getSimpleName()));}}).start();
    }

    private void startExportChain(){
        if(!running){exportStatus.setText("Export: start the node first");return;}
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        i.putExtra(Intent.EXTRA_TITLE,"ycash-chain-"+(System.currentTimeMillis()/1000)+".zip");
        exportStatus.setText("Export: choose destination…");
        try{startActivityForResult(i,1001);}catch(Exception e){exportStatus.setText("Export: file picker unavailable");}
    }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==1001&&c==RESULT_OK&&d!=null&&d.getData()!=null)exportChainTo(d.getData());else if(r==1001)exportStatus.setText("Export: cancelled");}
    private void exportChain(android.net.Uri dest){exportChainTo(dest);}

    /**
     * Downloads the chain snapshot from the node and compresses it into a .zip
     * (one entry: ycash-chain-height-N.sqlite) on the fly. Nothing is held in
     * memory and no uncompressed copy is written to shared storage -- bytes go
     * node -> Deflater -> chosen file. If anything fails the partial zip is
     * deleted so a broken archive is never left behind.
     */
    private void exportChainTo(android.net.Uri dest){
        exportStatus.setText("Export: creating snapshot…");
        new Thread(() -> {
            HttpURLConnection c=null;boolean ok=false;
            try{
                c=(HttpURLConnection)new URL("http://127.0.0.1:8834/export").openConnection();
                c.setConnectTimeout(5000);c.setReadTimeout(0);c.setRequestMethod("GET");
                if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());
                final long size=c.getContentLengthLong();
                String h=c.getHeaderField("X-Chain-Height");
                String entryName="ycash-chain-height-"+(h!=null?h.trim():"unknown")+".sqlite";
                long read=0,written;long lastUi=0;
                try(InputStream in=new BufferedInputStream(c.getInputStream(),256*1024);
                    OutputStream raw=getContentResolver().openOutputStream(dest,"w")){
                    if(raw==null)throw new IOException("destination unavailable");
                    CountingOutputStream counted=new CountingOutputStream(new BufferedOutputStream(raw,256*1024));
                    ZipOutputStream zip=new ZipOutputStream(counted);
                    // Block data is mostly already-random hashes/proofs; a high
                    // level burns battery for very little extra saving.
                    zip.setLevel(Deflater.BEST_SPEED);
                    zip.putNextEntry(new ZipEntry(entryName));
                    byte[] buf=new byte[256*1024];int n;
                    while((n=in.read(buf))!=-1){
                        zip.write(buf,0,n);read+=n;
                        long now=System.currentTimeMillis();
                        if(now-lastUi>500){lastUi=now;final long rd=read,wr=counted.count;
                            runOnUiThread(() -> exportStatus.setText("Export: zipping "+formatBytes(rd)+(size>0?" / "+formatBytes(size)+" ("+(rd*100/size)+"%)":"")+" → "+formatBytes(wr)));}
                    }
                    if(size>0&&read!=size)throw new IOException("snapshot truncated ("+read+" of "+size+" bytes)");
                    zip.closeEntry();zip.finish();zip.flush();
                    written=counted.count;
                }
                ok=true;
                final long rd=read,wr=written;
                runOnUiThread(() -> exportStatus.setText("Export: saved zip "+formatBytes(wr)+" (chain data "+formatBytes(rd)+")"));
            }catch(Exception e){
                runOnUiThread(() -> exportStatus.setText("Export: failed — "+e.getMessage()));
            }finally{
                if(c!=null)c.disconnect();
                if(!ok){try{android.provider.DocumentsContract.deleteDocument(getContentResolver(),dest);}catch(Exception ignored){}}
            }
        }).start();
    }

    /** Counts compressed bytes written, for the progress line. */
    private static final class CountingOutputStream extends FilterOutputStream{
        long count;
        CountingOutputStream(OutputStream o){super(o);}
        @Override public void write(int b)throws IOException{out.write(b);count++;}
        @Override public void write(byte[] b,int off,int len)throws IOException{out.write(b,off,len);count+=len;}
    }
}
