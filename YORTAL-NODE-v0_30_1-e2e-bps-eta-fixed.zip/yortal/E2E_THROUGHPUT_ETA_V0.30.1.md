# End-to-End Throughput and ETA — v0.30.1

The dashboard now reports **END-TO-END BLOCK RATE** and **ESTIMATED TIME REMAINING**.

## End-to-end definition

End-to-end blocks/s is based on **canonical blocks successfully committed to the database**, not headers received or blocks merely downloaded:

`(current committed height - height when sync measurement started) / elapsed sync seconds`

The measurement starts when the node first learns a peer target height that is ahead of the local chain. This therefore includes the real wall-clock cost of header acquisition, block download, validation, ordered commit, database writes, and SQLite commit time.

## ETA

`ETA seconds = blocks remaining / end-to-end blocks/s`

Blocks remaining is `target_height - local_height`.

If no committed progress has occurred yet, the dashboard displays **Calculating…** instead of inventing an ETA.

This is a run-average estimate. Network interruptions, peer changes, retries, validation load, database load, and changing throughput can make the actual completion time differ.
